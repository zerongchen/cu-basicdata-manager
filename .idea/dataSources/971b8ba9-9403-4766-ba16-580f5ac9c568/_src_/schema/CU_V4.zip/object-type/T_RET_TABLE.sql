CREATE TYPE "T_RET_TABLE"                                          is table of varchar2(100);

/
