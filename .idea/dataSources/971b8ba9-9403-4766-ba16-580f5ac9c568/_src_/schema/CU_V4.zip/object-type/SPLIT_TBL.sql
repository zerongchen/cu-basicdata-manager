CREATE TYPE "SPLIT_TBL"                                          as table of varchar2(100)

/
