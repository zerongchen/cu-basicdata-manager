CREATE VIEW IDC_UP_BG_BASE_IDC AS select "JYZID","IDCID","IDCNAME","IDCADD","IDCZIP","CORP","OFFICER_NAME","OFFICER_IDTYPE","OFFICER_ID","OFFICER_TEL","OFFICER_MOBILE","OFFICER_EMAIL","EC_NAME","EC_IDTYPE","EC_ID","EC_TEL","EC_MOBILE","EC_EMAIL","HOUSENUMBER","CZLX","DEAL_FLAG","CREATE_TIME","UPDATE_TIME","CREATE_USERID","INFO_COMPLETE","DEL_FLAG","REPORT_TYPE"
          /*"JYZID","IDCID","IDCNAME","IDCADD","IDCZIP","CORP",
          "OFFICER_NAME","OFFICER_IDTYPE","OFFICER_ID","OFFICER_TEL","OFFICER_MOBILE","OFFICER_EMAIL",
          "EC_NAME","EC_IDTYPE","EC_ID","EC_TEL","EC_MOBILE","EC_EMAIL",
          "CZLX","DEAL_FLAG","REPORT_TYPE","CREATE_TIME","UPDATE_TIME","CREATE_USERID"*/
       from idc_isms_base_idc where czlx=2 and del_flag != 1 and deal_flag=1
       union
       select "JYZID","IDCID","IDCNAME","IDCADD","IDCZIP","CORP","OFFICER_NAME","OFFICER_IDTYPE","OFFICER_ID","OFFICER_TEL","OFFICER_MOBILE","OFFICER_EMAIL","EC_NAME","EC_IDTYPE","EC_ID","EC_TEL","EC_MOBILE","EC_EMAIL","HOUSENUMBER","CZLX","DEAL_FLAG","CREATE_TIME","UPDATE_TIME","CREATE_USERID","INFO_COMPLETE","DEL_FLAG","REPORT_TYPE"
          /*"JYZID","IDCID","IDCNAME","IDCADD","IDCZIP","CORP",
          "OFFICER_NAME","OFFICER_IDTYPE","OFFICER_ID","OFFICER_TEL","OFFICER_MOBILE","OFFICER_EMAIL",
          "EC_NAME","EC_IDTYPE","EC_ID","EC_TEL","EC_MOBILE","EC_EMAIL",
          "CZLX","DEAL_FLAG","REPORT_TYPE","CREATE_TIME","UPDATE_TIME","CREATE_USERID"*/
       from idc_isms_base_idc
       where del_flag != 1 and jyzid in (
                     select jyzid
                     from (
                           select jyzid from idc_isms_base_house where czlx = 2 and deal_flag = 1
                           union
                           select jyzid from idc_isms_base_house where czlx = 2 and houseid in (select houseid from idc_isms_base_house_gateway where deal_flag = 1)
                           union
                           select jyzid from idc_isms_base_house where czlx = 2 and houseid in (select houseid from idc_isms_base_house_ipseg where deal_flag = 1)
                           union
                           select jyzid from idc_isms_base_house where czlx = 2 and houseid in (select houseid from idc_isms_base_house_frame where deal_flag = 1)
                          )
                   )
        union
       select "JYZID","IDCID","IDCNAME","IDCADD","IDCZIP","CORP","OFFICER_NAME","OFFICER_IDTYPE","OFFICER_ID","OFFICER_TEL","OFFICER_MOBILE","OFFICER_EMAIL","EC_NAME","EC_IDTYPE","EC_ID","EC_TEL","EC_MOBILE","EC_EMAIL","HOUSENUMBER","CZLX","DEAL_FLAG","CREATE_TIME","UPDATE_TIME","CREATE_USERID","INFO_COMPLETE","DEL_FLAG","REPORT_TYPE"
          /*"JYZID","IDCID","IDCNAME","IDCADD","IDCZIP","CORP",
          "OFFICER_NAME","OFFICER_IDTYPE","OFFICER_ID","OFFICER_TEL","OFFICER_MOBILE","OFFICER_EMAIL",
          "EC_NAME","EC_IDTYPE","EC_ID","EC_TEL","EC_MOBILE","EC_EMAIL",
          "CZLX","DEAL_FLAG","REPORT_TYPE","CREATE_TIME","UPDATE_TIME","CREATE_USERID"*/
       from idc_isms_base_idc
       where del_flag != 1 and jyzid in (
                        select jyzid
                        from (
                                select jyzid from idc_isms_base_user where czlx = 2 and del_flag != 1 and deal_flag = 1
                         and unitname in (select v.username from idc_isms_base_house_ipseg_view v)
                         /*union
                                select jyzid from idc_isms_base_user where czlx = 2 and del_flag != 1 and userid in (
                                select userid from idc_isms_base_user_hh where czlx = 2 and del_flag != 1 and deal_flag = 1
                                )
                         union
                         select jyzid from idc_isms_base_user where czlx = 2 and del_flag != 1 and userid in (
                                select userid from idc_isms_base_user_service where czlx = 2 and del_flag != 1 and deal_flag = 1
                                )*/
                        )
                 )
/
