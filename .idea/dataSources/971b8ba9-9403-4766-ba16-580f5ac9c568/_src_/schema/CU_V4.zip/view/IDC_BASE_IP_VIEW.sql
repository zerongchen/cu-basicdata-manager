CREATE VIEW IDC_BASE_IP_VIEW AS select
   house.houseid,
   house.houseidstr,
   t.iptype,
   t.startip,
   t.endip,
   t.startipstr,
   t.endipstr
from idc_isms_base_house_ipseg t
join idc_isms_base_house house on t.houseid = house.houseid
where t.del_flag = 0
group by house.houseid,house.houseidstr,t.iptype,t.startip,t.endip,t.startipstr,t.endipstr

/
