CREATE VIEW DPI_V1_CFG_USERPOLICYBIND_V AS SELECT tt1."BIND_ID",tt1."P_USERGROUP",tt1."MESSAGE_TYPE",tt1."BINDMESSAGENO",tt1."USERTYPE",tt1."USERNAME",tt1."MESSAGE_NO",tt1."OPERATETYPE",tt1."MESSAGE_SEQUENCENO",tt1."CREATE_TIME",
       NVL(t2.p_usergroup, -1) AS PARENTID, tt2.group_name, tt2.group_mold, tt2.areacode,
       (case when tt2.group_mold = 1 or tt2.group_mold = 3 then tt2.areacode else tt3.parent end) as parent
FROM DPI_V1_CFG_USERPOLICYBIND tt1 LEFT JOIN DPI_V1_CFG_USERPOLICYBIND t2 ON tt1.parentbindid = t2.bind_id
     left join dpi_usergroups tt2 on tt1.p_usergroup = tt2.group_id
     left join dic_chinaarea tt3 on tt2.areacode = tt3.areacode

/
