CREATE VIEW IDC_ISMS_MONITOR_POLICY_V AS select t3.bindmessageno, t3.message_no, t3.house_type, t3.MESSAGE_TYPE, t3.house_id, t1.commandid, t1.command_type, t1.action_block, t1.action_reason, t1.action_log,
       t1.effecttime, t1.expiredtime, t3.OPERATETYPE, t2.ruleid, t2.subtype, t2.valuestart, t2.valueend, t2.keywordrange
from idc_isms_monitor_policy t1 join idc_isms_monitor_policy_rule t2 on t1.commandid = t2.commandid
     join idc_isms_cfg_housepolicybind t3 on t1.message_no = t3.bindmessageno and t3.message_type = 16

/
