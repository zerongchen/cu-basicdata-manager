CREATE VIEW IDC_POLICY AS select
  t1.commandid ||'' commandid,
  (select distinct t.message_name from dpi_v1_cfg_messageno t where t.message_no = t1.message_no and t.message_type = 16) policy_name,
  replace(t2.valuestart,chr(10),' ') policy_content
from idc_isms_monitor_policy t1
join (select * from idc_isms_monitor_policy_rule temp where temp.subtype = 3) t2 on t1.commandid = t2.commandid

/
