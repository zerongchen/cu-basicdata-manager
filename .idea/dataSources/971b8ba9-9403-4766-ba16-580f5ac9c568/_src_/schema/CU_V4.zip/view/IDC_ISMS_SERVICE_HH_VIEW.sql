CREATE VIEW IDC_ISMS_SERVICE_HH_VIEW AS select
  t4.id || t1.hhid id,
  t3.userid,
  t1.serviceid,
  t1.houseid,
  t1.hhid,
  t4.frameid,
  t1.czlx
from (
     select * from (
            select t.hhid,t.houseid,t.serviceid,t.userid,t.czlx, row_number() over(partition by userid,houseid order by serviceid desc) rn from idc_isms_base_service_hh t)
            where rn = 1) t1
join idc_isms_base_user_service t2 on t1.serviceid = t2.serviceid
join idc_isms_base_user t3 on t3.userid = t2.userid
join idc_isms_base_user_frame t4 on t4.unitname = t3.unitname and t4.houseid = t1.houseid
where t2.del_flag != 1

/
