CREATE VIEW IDC_BASE_BLACK_LIST AS select
  t2.houseidstr houseid,
  t1.content content
from (select * from idc_isms_cmd_black_list t where t.delete_flag = 0 and t.operationtype = 0) t1
full join idc_isms_base_house t2 on 1 = 1
group by t2.houseidstr,t1.content
/
