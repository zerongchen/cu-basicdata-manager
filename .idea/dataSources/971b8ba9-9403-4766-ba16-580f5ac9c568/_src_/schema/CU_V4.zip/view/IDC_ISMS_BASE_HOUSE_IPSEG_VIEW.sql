CREATE VIEW IDC_ISMS_BASE_HOUSE_IPSEG_VIEW AS select
  a.ipsegid,
  b.userid,
  b.nature,
  a.houseid,
  a.startip,
  a.endip,
  a.iptype,
  b.unitname as username,
  b.idtype,
  b.idnumber,
  a.usetime,
  a.sourceunit,
  a.allocationunit,
  a.del_flag,
  a.deal_flag,
  a.czlx
from (select * from idc_isms_base_house_ipseg ip where ip.del_flag = 0 and ip.iptype != 2) a
join (select * from idc_isms_base_user u where u.del_flag = 0) b on a.username = b.unitname
union all
select
  a.ipsegid,
  0,
  0,
  a.houseid,
  a.startip,
  a.endip,
  a.iptype,
  a.username,
  a.idtype,
  a.idnumber,
  a.usetime,
  a.sourceunit,
  a.allocationunit,
  a.del_flag,
  a.deal_flag,
  a.czlx
from (select * from idc_isms_base_house_ipseg ip where ip.del_flag = 0 and ip.iptype = 2) a

/
