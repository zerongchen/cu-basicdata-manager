CREATE VIEW IDC_BASE_KEEP_IP_VIEW AS select
   t.houseid,
   t.startip,
   t.endip,
   t.startipstr,
   t.endipstr
from idc_isms_base_house_ipseg t
where t.iptype = 2

/
