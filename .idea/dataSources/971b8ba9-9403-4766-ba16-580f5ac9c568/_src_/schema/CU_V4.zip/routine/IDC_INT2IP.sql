CREATE FUNCTION idc_INT2IP
(
	ip IN number
)
RETURN varchar2 IS
   i number(15); seg1 integer; seg2 integer; seg3 integer; seg4 integer;
BEGIN
  select ip into i from dual;
  IF (sign(ip) = -1) THEN
     select (4294967296 + ip) into i from dual;
  END IF;
  select trunc(i/256/256/256)      into seg1 from dual;
  select mod(trunc(i/256/256),256) into seg2 from dual;
  select mod(trunc(i/256),256)     into seg3 from dual;
  select mod(i,256)                into seg4 from dual;
  return to_char(seg1)||'.'||to_char(seg2)||'.'||to_char(seg3)||'.'||to_char(seg4);
END;

/
