CREATE function DPI_SETCLOG_NEW(
                                     v_op_code IN number,
                                     v_op_type IN number,
                                     v_recid1  IN number,
                                     v_recid2  IN number,
                                     v_isall   IN number,
                                     v_create_oper IN number
                                   ) return INTEGER IS

                                   v_logid number(10);
BEGIN

  select SEQ_dpi_clog_id.NEXTVAL into v_logid from dual;
  insert into dpi_v1_clog
    (logid,
     op_code,
     op_type,
     recid1,
     recid2,
     isall,
     create_oper,
     create_time)
  values
    (v_logid,
     v_op_code,
     v_op_type,
     v_recid1,
     v_recid2,
     v_isall,
     v_create_oper,
     SYSDATE);

     return v_logid;
---COMMIT?？?？？????？
END;

/
