CREATE procedure pro_test_cursor is
x number;  --？？?？
BEGIN
  x:=21;    --????？
  FOR x IN  11..100 LOOP   --reverse？?？?
  DBMS_OUTPUT.PUT_LINE('？:x='||x);
END LOOP;
DBMS_OUTPUT.PUT_LINE('end loop:x='||x);   --x=1 END;
end pro_test_cursor;

/
