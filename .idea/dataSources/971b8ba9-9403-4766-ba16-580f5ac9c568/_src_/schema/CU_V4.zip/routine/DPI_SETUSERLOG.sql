CREATE procedure dpi_setuserlog(
   in_op_code IN NUMBER,
   in_op_type IN NUMBER,
   in_dataId IN NUMBER,
   in_newdesc IN VARCHAR2,
   in_olddesc IN VARCHAR2,
   in_create_oper IN NUMBER
)
is
begin
  INSERT INTO useroperatelog
  (logid,
  op_code,
  op_type,
  dataid,
  desc1,
  desc2,
  create_oper,
  create_time)
VALUES
  (SEQ_operateLog_ID.Nextval,
  in_op_code,
  in_op_type,
  in_dataId,
  in_newdesc,
  in_olddesc,
  in_create_oper,
  SYSDATE);

  --？??commit
end dpi_setuserlog;

/
