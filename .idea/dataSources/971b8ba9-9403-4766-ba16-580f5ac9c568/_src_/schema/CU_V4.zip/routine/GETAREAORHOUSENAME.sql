CREATE FUNCTION GetAreaOrHouseName
(
  p_type in number,
  p_idstr  in varchar
)
RETURN varchar2 IS
returnstr varchar2(100);

BEGIN

  returnstr := 'δ？';
  if p_type = 0 then
    select areaname into returnstr from  DIC_CHINAAREA where areacode = p_idstr;
  else
      returnstr := p_idstr;
  end if;
  return returnstr;
END;

/
