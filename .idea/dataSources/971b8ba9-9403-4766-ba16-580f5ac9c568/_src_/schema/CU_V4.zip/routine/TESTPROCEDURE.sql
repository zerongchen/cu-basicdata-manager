CREATE procedure testProcedure(test1 in out number) is
begin
  while test1 < 10 loop
    begin
      test1 := test1+1; 
    end;
  end loop;
end testProcedure;
/
