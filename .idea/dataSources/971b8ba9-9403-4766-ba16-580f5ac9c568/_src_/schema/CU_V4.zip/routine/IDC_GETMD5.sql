CREATE function idc_GetMd5(
--Md5?？？？???？？？？？?????？？?？？?？？?？？
--Create by :moqj
--Create Time:2007-01-10
input_string VARCHAR2
) return varchar2
IS
raw_input RAW(128);
decrypted_raw RAW(2048);
error_in_input_buffer_length EXCEPTION;
BEGIN
if input_string is null or length(input_string) = 0 Then
  return '';
end if;
raw_input := UTL_RAW.CAST_TO_RAW(input_string);
--dbms_output.put_line(sysdate || '> ?？？??？??？' || input_string);
sys.dbms_obfuscation_toolkit.MD5(input => raw_input,
checksum => decrypted_raw);
--dbms_output.put_line(sysdate || '> ?？？？??？' || rawtohex(decrypted_raw));
return lower(rawtohex(decrypted_raw));
END;

/
