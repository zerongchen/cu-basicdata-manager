CREATE function getRow(tablename varchar2 ,seqcolname varchar2,seqid NUMBER) RETURN VARCHAR2 is
/*
？?？？?？？?？?？?？?
tablename:?？?？？
seqcolname:Ψ？？?？?
seqid??Ψ？ID
??？??？??getRow(dpi_v1_cfg_flowmanage ,Fm_id,1)??
*/

FResult VARCHAR2(5000);
AllResult VARCHAR2(5000);
temp VARCHAR2(5000);
temoCom VARCHAR2(200);
tempsql VARCHAR2(1000);
tempDes VARCHAR2(5000);
TYPE ref_cursor_type IS REF CURSOR;
usrs ref_cursor_type;
begin
temoCom:='';
select COMMENTS INTO temoCom from user_tab_comments where  TABLE_TYPE='TABLE' and table_name=Upper(tablename);

FOR cur IN (SELECT COLUMN_NAME FROM USER_TAB_COLUMNS t WHERE table_name =Upper(tablename))
LOOP
temp:=cur.column_name;
FResult := FResult||''','||temp||':''||'||temp||'||';
END LOOP;

FResult:=ltrim(FResult,',');
FResult:=rtrim(FResult,'||');


tempsql:='SELECT ' ||FResult||' AS COLCONTENT FROM '||tablename ||' WHERE '||seqcolname||' ='||seqid;

open usrs for tempsql ;
  loop
      fetch usrs into tempDes;
      exit when usrs%notfound;
      tempDes:=ltrim(tempDes,',');
      AllResult := AllResult||'{' ||tempDes||'}';
  end loop;
  close usrs;
AllResult:=temoCom||AllResult;
return(AllResult);

end getRow;

/
