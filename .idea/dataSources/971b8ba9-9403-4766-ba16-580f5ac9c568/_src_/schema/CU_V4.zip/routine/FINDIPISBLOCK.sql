CREATE FUNCTION findipisblock
(
  ip IN Varchar2
)
RETURN Int IS
   i number(5);
   v_count number(5);

BEGIN
begin
  i:= 0;
  select count(1) into v_count
               from idc_isms_monitor_policy_rule t_1
              inner join idc_isms_monitor_policy t_2
                 on t_1.commandid = t_2.commandid
              where subtype in (4,5) and ip2int(ip)>=ip2int(valuestart) and ip2int(ip)<= ip2int(valueend) ;

  if v_count = 0 then
    i:= 0;
  end if;

  if v_count = 1 then
    select action_block into i  from idc_isms_monitor_policy_rule t_1
              inner join idc_isms_monitor_policy t_2
                 on t_1.commandid = t_2.commandid
              where subtype in (4,5) and ip2int(ip)>=ip2int(valuestart) and ip2int(ip)<= ip2int(valueend);
  end if;

  if v_count > 1 then
   select action_block into i from  (select action_block ,rownum r from idc_isms_monitor_policy_rule t_1
              inner join idc_isms_monitor_policy t_2
                 on t_1.commandid = t_2.commandid
              where subtype in (4,5) and ip2int(ip)>=ip2int(valuestart) and ip2int(ip)<= ip2int(valueend)) where r = 1;
  end if;
   exception when others then
    return 0;
    end;

  return i;
END;

/
