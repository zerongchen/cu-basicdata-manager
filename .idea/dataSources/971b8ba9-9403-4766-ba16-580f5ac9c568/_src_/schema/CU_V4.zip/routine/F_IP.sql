CREATE FUNCTION F_IP
(
v_real_ip in varchar2,
v_start_ip in varchar2,
v_end_ip in varchar2
)
return varchar2 is
v_result varchar2(4);
v_s_1 varchar2(3);
v_s_2 varchar2(3);
v_s_3 varchar2(3);
v_s_4 varchar2(3);
v_e_1 varchar2(3);
v_e_2 varchar2(3);
v_e_3 varchar2(3);
v_e_4 varchar2(3);
v_r_1 varchar2(3);
v_r_2 varchar2(3);
v_r_3 varchar2(3);
v_r_4 varchar2(3);
begin
select substr(v_start_ip,1,instr(v_start_ip,'.')-1) into v_s_1 from dual;
select substr(v_end_ip,1,instr(v_end_ip,'.')-1) into v_e_1 from dual;
select substr(v_real_ip,1,instr(v_real_ip,'.')-1) into v_r_1 from dual;
select substr(v_start_ip,instr(v_start_ip,'.')+1,instr(v_start_ip,'.',instr(v_start_ip,'.')+1)-1-instr(v_start_ip,'.')) into v_s_2 from dual;
select substr(v_end_ip,instr(v_end_ip,'.')+1,instr(v_end_ip,'.',instr(v_end_ip,'.')+1)-1-instr(v_end_ip,'.')) into v_e_2 from dual;
select substr(v_real_ip,instr(v_real_ip,'.')+1,instr(v_real_ip,'.',instr(v_real_ip,'.')+1)-1-instr(v_real_ip,'.')) into v_r_2 from dual;
select substr(v_start_ip,instr(v_start_ip,'.',instr(v_start_ip,'.')+1)+1,instr(substr(v_start_ip,instr(v_start_ip,'.',instr(v_start_ip,'.')+1)+1),'.',1)-1) into v_s_3 from dual;
select substr(v_end_ip,instr(v_end_ip,'.',instr(v_end_ip,'.')+1)+1,instr(substr(v_end_ip,instr(v_end_ip,'.',instr(v_end_ip,'.')+1)+1),'.',1)-1) into v_e_3 from dual;
select substr(v_real_ip,instr(v_real_ip,'.',instr(v_real_ip,'.')+1)+1,instr(substr(v_real_ip,instr(v_real_ip,'.',instr(v_real_ip,'.')+1)+1),'.',1)-1) into v_r_3 from dual;
select substr(v_start_ip,length(v_start_ip)-instr(reverse(v_start_ip),'.')+2,instr(reverse(v_start_ip),'.')-1) into v_s_4 from dual;
select substr(v_end_ip,length(v_end_ip)-instr(reverse(v_end_ip),'.')+2,instr(reverse(v_end_ip),'.')-1) into v_e_4 from dual;
select substr(v_real_ip,length(v_real_ip)-instr(reverse(v_real_ip),'.')+2,instr(reverse(v_real_ip),'.')-1) into v_r_4 from dual;

if
to_number(v_r_1)=to_number(v_s_1) and
to_number(v_r_1)=to_number(v_e_1) and
to_number(v_r_2)=to_number(v_s_2) and
to_number(v_r_2)=to_number(v_e_2) and
to_number(v_r_3)=to_number(v_s_3) and
to_number(v_r_3)=to_number(v_e_3) and
to_number(v_r_4)>=to_number(v_s_4) and
to_number(v_r_4)<=to_number(v_e_4)
then
v_result :='Yes';
else
v_result:='No';
end if;

return v_result;
end;

/
