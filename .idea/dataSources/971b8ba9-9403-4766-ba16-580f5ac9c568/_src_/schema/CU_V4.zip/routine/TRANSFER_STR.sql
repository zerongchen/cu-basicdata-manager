CREATE function transfer_str(var_str in varchar2,--以逗号分开的字符串
       table_name in varchar2,--关联的表名
       res_name in varchar2,--中文名称列
       code_name in varchar2--数字列
       ) return varchar2 is dest_str varchar2(30000);
       v_acc_res varchar2(50);
       rel_str varchar2(10);
       type ref_cursor is ref cursor;
       X_SQL varchar2(1000);
       v_cursor ref_cursor;
begin
  dest_str := '';
  rel_str := '-';
  X_SQL := 'select concat(concat('||code_name||','''||rel_str||'''),'||res_name||')
  from '||table_name||
  ' where '||code_name||' in ('||var_str||')';
  open v_cursor for X_SQL;
  loop
    fetch v_cursor into v_acc_res;
    exit when v_cursor%notfound;
    if (dest_str is null) then
        dest_str :=trim(v_acc_res);
       else
        dest_str:=trim(dest_str)||','||trim(v_acc_res);
    end if;
    end loop;
 close v_cursor;
return dest_str;
end;
/
