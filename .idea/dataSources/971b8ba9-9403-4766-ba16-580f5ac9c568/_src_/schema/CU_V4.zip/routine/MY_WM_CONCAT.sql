CREATE FUNCTION my_wm_concat (pi_str ConcatObj)
   RETURN clob
   PARALLEL_ENABLE
   AGGREGATE USING type_wm_concat;
/
