CREATE FUNCTION areaCodeMapper(code IN VARCHAR2)
RETURN VARCHAR2 AS
       rs VARCHAR2(2048);
       v1 VARCHAR2(32);
       v2 VARCHAR2(32);
       v3 VARCHAR2(32);
       verror VARCHAR2(2048);
BEGIN
  for v1 in
   (SELECT COLUMN_VALUE
          from table(split_str(code,',')))
   LOOP
       BEGIN
      select t.code,t.codename into v2,v3 from tmp_area_code_map t where t.areacode = v1.COLUMN_VALUE;
       IF rs IS NULL THEN
          rs :=  v2;
       ELSE
          rs := rs || ',' || v2;
       END IF;
       --dbms_output.put_line(v1.COLUMN_VALUE||'-'||v2||'-'||v3||'-'||rs);
       EXCEPTION
           WHEN OTHERS THEN
               verror := SQLCODE;
               DBMS_OUTPUT.put_line('ERROR : 无法找到行政区划码['||v1.COLUMN_VALUE||']对应的隶属单位');
       NULL;
       END;
   end LOOP;
  RETURN rs;
END areaCodeMapper;
/
