CREATE FUNCTION idc_gethousename
(
  p_houseids IN varchar2
)
RETURN varchar2 IS
   v_tmp varchar2(4000);
   v_int  number(10) :=0;
   v_houseid varchar2(256);
   v_housename varchar2(256);
   v_count  number(5);
   v_ret Varchar2(4000);
BEGIN
 begin
      v_ret:='';
      v_tmp := p_houseids || ',';
      loop
              BEGIN
                if v_tmp is null or To_Number(Length(v_tmp))<2 then
                          exit;
                end if;
                v_int:= INSTR(v_tmp,',');
                if(v_int = 0 ) then
                      v_houseid := v_tmp;
                else
                      v_houseid  := substr(v_tmp,0,v_int-1);
                end if;

                select count(*) into v_count from idc_isms_base_house where houseid = v_houseid;
                 if(v_count > 0) then
                      select housename into v_housename from idc_isms_base_house where houseid = v_houseid;
                      v_ret := v_ret || v_housename || ',';
                 end if;

              END;
               v_tmp := substr(v_tmp,v_int+1);
      end loop;
  exception when others then
    return null;
  end;
  return v_ret;
END;

/
