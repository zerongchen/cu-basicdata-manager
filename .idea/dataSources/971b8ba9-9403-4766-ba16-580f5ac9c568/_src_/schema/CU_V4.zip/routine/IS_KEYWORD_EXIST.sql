CREATE FUNCTION IS_KEYWORD_EXIST(VALSTR IN VARCHAR2,sid IN NUMBER) RETURN NUMBER IS
      words_cnt NUMBER;
      l_words_cnt NUMBER;
      l_words VARCHAR2(512);
      cursor c_keywords
       is
       select * from Idc_Isms_Monitor_Keyword WHERE sourceid = sid;
       c_row c_keywords%rowtype;
   BEGIN
      words_cnt := SPLIT_STR(VALSTR, '&').count;
       dbms_output.put_line(words_cnt||VALSTR||l_words_cnt);
       for c_row in c_keywords LOOP
         SELECT COUNT(1) INTO l_words_cnt FROM TABLE(CAST(SPLIT_STR(c_row.content, '&') AS T_RET_TABLE));
         IF words_cnt = l_words_cnt THEN
           SELECT COUNT(1) INTO l_words_cnt FROM ((SELECT * FROM TABLE(CAST(SPLIT_STR(c_row.content, '&') AS T_RET_TABLE)))
                  INTERSECT
           (SELECT * FROM TABLE(CAST(SPLIT_STR(VALSTR, chr(38)) AS T_RET_TABLE))));
           IF words_cnt = l_words_cnt THEN
               RETURN 1;
           END IF;
         END IF;
       end LOOP;
       RETURN 0;
   END IS_KEYWORD_EXIST;

/
