CREATE package IDC_SYSTEM_PARAM_SETTING is

  procedure updateSystemParam(
     p_fieldName in varchar2,
     p_fieldValue in varchar2,
     p_modelType in number,
     p_flag out number
  );

end IDC_SYSTEM_PARAM_SETTING;

/
CREATE package body IDC_SYSTEM_PARAM_SETTING is

  procedure updateSystemParam(
     p_fieldName in varchar2,
     p_fieldValue in varchar2,
     p_modelType in number,
     p_flag out number
  )as
     v_count number;
     BEGIN
       begin
         select count(1) into v_count from IDC_JCDM_JKCS where TYPE = p_fieldName and MODEL_TYPE = p_modelType;
         if v_count > 0 then
            update IDC_JCDM_JKCS set SFYX = 1 where TYPE = p_fieldName and CS_KEY = p_fieldValue and MODEL_TYPE = p_modelType;
            for jkcs_table in (select CS_KEY from IDC_JCDM_JKCS where TYPE = p_fieldName and MODEL_TYPE = p_modelType
                                 minus
                            select CS_KEY from IDC_JCDM_JKCS where TYPE = p_fieldName and CS_KEY = p_fieldValue and MODEL_TYPE = p_modelType)
            loop
              update IDC_JCDM_JKCS set SFYX = 0 where TYPE = p_fieldName and CS_KEY = jkcs_table.cs_key and MODEL_TYPE = p_modelType;
            end loop;
         else
           update IDC_JCDM_JKCS set CS_VALUE = p_fieldValue where CS_KEY = p_fieldName and MODEL_TYPE = p_modelType;
         end if;
         exception
           WHEN OTHERS THEN
              ROLLBACK;
              p_flag := 0;
              RETURN;
       end;
       --commit;
       p_flag := 1;
     END;

end IDC_SYSTEM_PARAM_SETTING;

/
