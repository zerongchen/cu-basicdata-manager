CREATE package IDC_ISMS_SYSTEM_MONITOR_MANAGE is

procedure list_houseMonitorSetting(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number
      );
procedure list_houseMonitorState(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_STATEID in number,
      p_JYZID   in number,
      p_idcname  in varchar2,
      p_HOUSEID in number,
      p_houseName in varchar2,
      p_MONITOR_STATE in number,
      p_DEAL_TYPE in number,
      s_date in varchar2,
      e_date in varchar2
      );
procedure list_monitorPolicy(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_ACTION_LOG in number,
      p_COMMANDID in number,
      p_COMMAND_TYPE in number,
      p_MONITOR_TYPE in number,
      p_SMMS_CMDID in number,
      p_IDCID in varchar2
      );
procedure list_policyRule(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_COMMANDID in number
      );
/*procedure list_houseMonitorErrorInfo(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_HOUSEID in number,
      p_IP in varchar2,
      p_PORT in number,
      p_DOMAIN in varchar2,
      p_SERVICETYPE in varchar2,
      p_ILLEGAL_TYPE in number,
      p_CURRENT_STATE in number,
      p_ICP_ERROR in number,
      p_REG_ERROR in number,
      p_REG_DOMAIN in varchar2,
      p_DEAL_FLAG in number
      );*/

procedure list_ipdomain(
      p_isPaging in number,
      p_pageIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_sortOrder in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_ip in varchar2,
      p_violation in number,
      p_domain in varchar2
      );

 --查询免过滤网站
 procedure list_website_no_filter(
        p_isPaging in number,
        p_pageIndex in number,
        p_pageSize in number,
        p_isCount in number,
        p_sortName in varchar2,
        p_sortOrder in varchar2,

        p_cursor out sys_refcursor,
        p_recordcount out number,

        p_idcId in varchar2,
        p_ip in varchar2,
        p_createTimeBegin in varchar2,
        p_createTimeEnd in varchar2
 );

--查询违法网站
procedure list_website_black(
              p_isPaging in number,
              p_pageIndex in number,
              p_pageSize in number,
              p_isCount in number,
              p_sortName in varchar2,
              p_sortOrder in varchar2,

              p_cursor out sys_refcursor,
              p_recordcount out number,

              p_idcId in varchar2,
              p_ip in varchar2,
              p_createTimeBegin in varchar2,
              p_createTimeEnd in varchar2
);

procedure list_houseMonitorErrorIpInfo(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_houseId in number,
            p_ip in varchar2,
            p_regDomain in varchar2,
            p_domain in varchar2,
            p_curState in number,
            p_regError in number,
            p_dealFlag in number
);

 --查询违法违规网站信息
procedure list_houseMonitorErrorDomain(
      --入参，分页参数
      p_isPaging in number, --是否分页，如果不分页则返回全部数据
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_IsCount    in number,
      p_sortName   in VARCHAR2,
      p_sortOrder  in VARCHAR2,
      --输出
      p_cursor      out sys_refcursor,
      p_recordCount out number, --非空为错误信息
      --入参，查询参数
      p_houseId in number,
      p_domain in varchar2,
      p_curState in number,
      p_illegalType in number,
      p_dealFlag in number
);

procedure list_IdcUpActiveDomainInfo(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_houseId    in number,
      p_actionBlock in number,
      p_topDomainFlag in number,
      p_domain     in VARCHAR2,
      p_topDomain  in VARCHAR2,
      p_ip         in VARCHAR2,
      p_port     in number,
      p_idcId     in VARCHAR2,
      p_visitsCount in number,
      p_recordcount out number,
      p_cursor      out sys_refcursor
);

procedure list_IdcUpActiveIpInfo(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_houseId    in number,
      p_actionBlock in number,
      p_isInIpSeg in number,
      p_port     in number,
      p_protocol  in number,
      p_ip         in VARCHAR2,
      p_idcId     in VARCHAR2,
      p_visitsCount in number,
      p_recordcount out number,
      p_cursor      out sys_refcursor
);

procedure list_websiteStatistics(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_houseId    in number,
      p_startTime  in VARCHAR2, --开始统计时间
      p_endTime  in VARCHAR2, --结束统计时间
      p_sortName   in VARCHAR2,
      p_sortOrder in varchar2,
      p_recordcount out number,
      p_cursor      out sys_refcursor,
      p_userHouseIDStrs in varchar2
);

procedure list_topNWebsiteStatistics(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_id         in number,
      p_houseId    in number,
      p_domain    in VARCHAR2,
      p_findStartTimeStr in VARCHAR2,
      p_findEndTimeStr in VARCHAR2,
      p_sortName   in VARCHAR2,
      p_sortOrder in VARCHAR2,
      p_recordcount out number,
      p_cursor      out sys_refcursor,
       p_userHouseIDStrs in varchar2
);

procedure list_topNWebsiteBlack(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_id         in number,
      p_houseId    in number,
      p_domain    in VARCHAR2,
      p_findStartTimeStr in VARCHAR2,
      p_findEndTimeStr in VARCHAR2,
      p_sortName   in VARCHAR2,
      p_sortOrder in VARCHAR2,
      p_recordcount out number,
      p_cursor      out sys_refcursor,
       p_userHouseIDStrs in varchar2
);
end IDC_ISMS_SYSTEM_MONITOR_MANAGE;

/
CREATE package body IDC_ISMS_SYSTEM_MONITOR_MANAGE is

procedure list_houseMonitorSetting(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_MONITOR_HOUSE_SETTING ';
      v_field    := ' SETTINGID,MONITOR_STATE,MONITOR_TYPE,DEAL_FLAG,CREATE_TIME,CREATE_USERID,JYZID,HOUSEIDLIST,COMMANDID ';

      --条件语句
      v_condition := ' where 1=1 ';
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select SETTINGID,MONITOR_STATE,MONITOR_TYPE,DEAL_FLAG,CREATE_TIME,CREATE_USERID,JYZID,idc_getidcname(jyzid) IDCNAME,HOUSEIDLIST,idc_gethousename(HOUSEIDLIST) HOUSENAME,COMMANDID from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;

procedure list_houseMonitorState(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_STATEID in number,
      p_JYZID   in number,
      p_idcname  in varchar2,
      p_HOUSEID in number,
      p_houseName in varchar2,
      p_MONITOR_STATE in number,
      p_DEAL_TYPE in number,
      s_date in varchar2,
      e_date in varchar2
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_MONITOR_HOUSE_STATE ';
      v_field    := ' STATEID,JYZID,HOUSEID,MONITOR_STATE,DEAL_TIME,DEAL_TYPE ';

      --条件语句
      v_condition := ' where 1=1 ';
      if p_STATEID > 0 then
        v_condition := v_condition || '  and STATEID = ' || (p_STATEID-1);
      end if;
      if p_JYZID > 0 then
        v_condition := v_condition || '  and JYZID = ' || p_JYZID;
      end if;
      if p_HOUSEID > 0 then
        v_condition := v_condition || '  and HOUSEID = ' || p_HOUSEID;
      end if;
      if p_MONITOR_STATE > 0 then
        v_condition := v_condition || '  and MONITOR_STATE = ' || (p_MONITOR_STATE-1);
      end if;
      if p_DEAL_TYPE > 0 then
        v_condition := v_condition || '  and DEAL_TYPE = ' || (p_DEAL_TYPE-1);
      end if;
      if p_idcname is not null and To_Number(Length(p_idcname)) > 0 then
        v_condition := v_condition || ' and jyzid in '||'(select jyzid from idc_isms_base_idc where idcname like ''%'||p_idcname||'%'')';
      end if;
      if p_houseName is not null and To_Number(Length(p_houseName)) > 0 then
        v_condition := v_condition || ' and houseid in '||'(select houseid from idc_isms_base_house where housename like ''%'||p_houseName||'%'')';
      end if;
      if(s_date is not null) then
          v_condition := v_condition || ' and czsj >= to_date(''' || s_date || ''',''yyyy-mm-dd'') ';
      end if;

      if(e_date is not null) then
          v_condition := v_condition || ' and czsj <= to_date(''' || e_date || ' 23:59:59'',''yyyy-mm-dd hh24:mi:ss'') ';
      end if;

      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select STATEID,JYZID,idc_getidcname(JYZID) IDCNAME,HOUSEID,idc_gethousename(HOUSEID) housename,MONITOR_STATE,DEAL_TIME,DEAL_TYPE from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s ;
        end;
      end if;
      open p_cursor for v_sql;
  end;

procedure list_monitorPolicy(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_ACTION_LOG in number,
      p_COMMANDID in number,
      p_COMMAND_TYPE in number,
      p_MONITOR_TYPE in number,
      p_SMMS_CMDID in number,
      p_IDCID in varchar2
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_MONITOR_POLICY ';
      v_field    := ' COMMANDID,MESSAGE_NO,COMMAND_TYPE,ACTION_BLOCK,ACTION_REASON,ACTION_LOG,EFFECTTIME,EXPIREDTIME,MONITOR_TYPE,SMMS_CMDID,IDCID,OPERATETYPE,MESSAGE_SEQUENCENO,CREATE_TIME,CREATE_USERID ';

      --条件语句
      v_condition := ' where 1=1 ';

      if p_COMMAND_TYPE > 0 then
        v_condition := v_condition || '  and COMMAND_TYPE = ' || p_COMMAND_TYPE;
      end if;
      if p_COMMANDID > 0 then
        v_condition := v_condition || '  and COMMANDID = ' || p_COMMANDID;
      end if;
      if p_ACTION_LOG > 0 then
        v_condition := v_condition || '  and ACTION_LOG = ' || (p_ACTION_LOG-1);
      end if;
      if p_MONITOR_TYPE > 0 then
        v_condition := v_condition || '  and MONITOR_TYPE = ' || (p_MONITOR_TYPE-1);
      end if;
      if p_IDCID is not null and To_Number(Length(p_IDCID)) > 0 then
        v_condition := v_condition || ' and IDCID like ''%'|| p_IDCID || '%''';
      end if;
      if p_SMMS_CMDID > 0 then
        v_condition := v_condition || '  and SMMS_CMDID = ' || p_SMMS_CMDID;
      end if;


      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select COMMANDID,MESSAGE_NO,COMMAND_TYPE,ACTION_BLOCK,decode(ACTION_BLOCK,0,''不过滤''，1,''过滤'') ACTION_BLOCK_NAME,ACTION_REASON,ACTION_LOG,decode(ACTION_LOG,0,''不记录'',1,''记录'') ACTION_LOG_NAME,time_t2date(EFFECTTIME) EFFECTTIME,time_t2date(EXPIREDTIME) EXPIREDTIME,MONITOR_TYPE,decode(MONITOR_TYPE,0,''系统自建监测'',1,''工信部下发监测'') MONITOR_TYPE_NAME,SMMS_CMDID,IDCID,OPERATETYPE,MESSAGE_SEQUENCENO,CREATE_TIME,CREATE_USERID from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;
procedure list_policyRule(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_COMMANDID in number
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_MONITOR_POLICY_RULE ';
      v_field    := ' RULEID,COMMANDID,SUBTYPE,VALUESTART,VALUEEND,KEYWORDRANGE,CREATE_TIME ';

      --条件语句
      v_condition := ' where 1=1 ';
      if p_COMMANDID > 0 then
        v_condition := v_condition || '  and COMMANDID = ' || p_COMMANDID;
      end if;

      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select RULEID,COMMANDID,SUBTYPE,VALUESTART,VALUEEND,KEYWORDRANGE,CREATE_TIME from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;

/*procedure list_houseMonitorErrorInfo(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_HOUSEID in number,
      p_IP in varchar2,
      p_PORT in number,
      p_DOMAIN in varchar2,
      p_SERVICETYPE in varchar2,
      p_ILLEGAL_TYPE in number,
      p_CURRENT_STATE in number,
      p_ICP_ERROR in number,
      p_REG_ERROR in number,
      p_REG_DOMAIN in varchar2,
      p_DEAL_FLAG in number
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_MONITOR_ERROR_INFO ';
      v_field    := ' ERRORID,HOUSEID,IP,PORT,DOMAIN,SERVICETYPE,FIRST_FOUND,LAST_FOUND,ILLEGAL_TYPE,CURRENT_STATE,DEAL_USER,DEAL_TIME,ICP_ERROR,REG_ERROR,REG_DOMAIN,CREATE_TIME,DEAL_FLAG ';

      --条件语句
      v_condition := ' where 1=1 ';
      if p_HOUSEID > 0 then
        v_condition := v_condition || '  and HOUSEID = ' || p_HOUSEID;
      end if;
      if p_PORT > 0 then
        v_condition := v_condition || '  and port = ' || p_PORT;
      end if;
      if p_IP is not null and To_Number(Length(p_IP)) > 0 then
        v_condition := v_condition || ' and ip = '|| idc_ip2int(p_IP);
      end if;
      if p_DOMAIN is not null and To_Number(Length(p_DOMAIN)) > 0 then
        v_condition := v_condition || ' and DOMAIN like ''%'|| p_DOMAIN || '%''';
      end if;
      if p_SERVICETYPE is not null and To_Number(Length(p_SERVICETYPE)) > 0 then
        v_condition := v_condition || ' and SERVICETYPE like ''%'|| p_SERVICETYPE || '%''';
      end if;
      if p_ILLEGAL_TYPE > 0 then
        v_condition := v_condition || ' and ILLEGAL_TYPE = ' || (p_ILLEGAL_TYPE-1);
      end if;
      if p_CURRENT_STATE > 0 then
        v_condition := v_condition || ' and CURRENT_STATE = ' || (p_CURRENT_STATE-1);
      end if;
      if p_ICP_ERROR > 0 then
        v_condition := v_condition || ' and ICP_ERROR = ' || (p_ICP_ERROR-1);
      end if;
      if p_REG_ERROR > 0 then
        v_condition := v_condition || ' and REG_ERROR = ' || (p_REG_ERROR-1);
      end if;
      if p_REG_DOMAIN is not null and To_Number(Length(p_REG_DOMAIN)) > 0 then
        v_condition := v_condition || ' and REG_DOMAIN like ''%'|| p_REG_DOMAIN || '%''';
      end if;
      if p_DEAL_FLAG > 0 then
        v_condition := v_condition || ' and DEAL_FLAG = ' || (p_DEAL_FLAG-1);
      end if;
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ERRORID,HOUSEID,IP,idc_int2ip(ip) IPSTR,PORT,DOMAIN,SERVICETYPE,FIRST_FOUND,LAST_FOUND,ILLEGAL_TYPE,decode(ILLEGAL_TYPE,0,''正常网站'',1,''未备案'',999,''其他'') ILLEGAL_TYPE_NAME,CURRENT_STATE,decode(CURRENT_STATE,0,''未处置'',1,''已处置'') CURRENT_STATE_NAME,DEAL_USER,DEAL_TIME,ICP_ERROR,decode(ICP_ERROR,0,''正常'',1,''未备案'') ICP_ERROR_NAME,REG_ERROR,decode(REG_ERROR,0,''正常'',1,''IP登记保留,实际为启用'',2,''IP登记域名有误'',3,''IP未登记'') REG_ERROR_NAME,REG_DOMAIN,CREATE_TIME,DEAL_FLAG,decode(DEAL_FLAG,0,''未上报'',1,''上报中'',2,''上报失败'',3,''上报成功'') DEAL_FLAG_NAME from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;*/

procedure list_ipdomain(
      p_isPaging in number,
      p_pageIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_sortOrder in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_ip in varchar2,
      p_violation in number,
      p_domain in varchar2
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_BASE_IP_DOMAIN ';
      v_field    := ' domain,ip,decode(VIOLATION,1,''正常'',2,''黑名单'',3,''备案未启用'',''未知'') VIOLATIONstr,VIOLATION,id,create_time ';

      --条件语句
      v_condition := ' where 1=1 ';
      if p_ip is not null and To_Number(Length(p_ip)) > 0 then
        v_condition := v_condition || ' and ip = '''|| p_ip || ''' ';
      end if;
      if p_violation > 0 then
        v_condition := v_condition || ' and violation = ' || p_violation;
      end if;
      if p_domain is not null and To_Number(Length(p_domain)) > 0 then
        v_condition := v_condition || ' and DOMAIN like ''%'|| p_domain || '%''';
      end if;

      if p_iscount = 1 then
         v_count := 'select count(1) ' || v_innersql || v_condition;
         execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || p_sortName || '  ' || p_sortOrder;

      --v_sql := 'select domain,ip,decode(VIOLATION,1,''正常'',2,''黑名单'',3,''备案未启用'',''未知'') VIOLATIONstr,VIOLATION,id,create_time from IDC_ISMS_BASE_IP_DOMAIN '||v_condition||v_order;
      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := p_pageIndex * p_pageSize;
          v_s := (p_pageIndex - 1) * p_pageSize + 1;
          v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from ( ';
          v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
      end;

      --查询免过滤网站
      procedure list_website_no_filter(
              p_isPaging in number,
              p_pageIndex in number,
              p_pageSize in number,
              p_isCount in number,
              p_sortName in varchar2,
              p_sortOrder in varchar2,

              p_cursor out sys_refcursor,
              p_recordcount out number,

              p_idcId in varchar2,
              p_ip in varchar2,
              p_createTimeBegin in varchar2,
              p_createTimeEnd in varchar2
       )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
      v_temp varchar2(2000);
    begin

      --内部sql语句
      v_innersql := ' from IDC_ISMS_CMD_NO_FILTER where DELETE_FLAG != 1 and OPERATIONTYPE != 1 ';
      v_field := ' COMMANDID,FILTER_ID,IDCID,COMMANDTYPE,CONTENT,CREATE_USER_ID,UPDATE_TIME,CREATE_TIME ';

      --条件语句
      if (p_idcId is not null) then
        v_condition := v_condition || ' and IDCID like ''%' || p_idcId || '%''';
      end if;
      if (p_ip is not null) then
        v_condition := v_condition || ' and CONTENT like ''%' || p_ip || '%''';
      end if;
      if (p_createTimeBegin is not null) then
        v_condition := v_condition || ' and CREATE_TIME >= to_date(''' || p_createTimeBegin || ''',''yyyy-mm-dd hh24:mi:ss'')';
      end if;
      if (p_createTimeEnd is not null) then
        v_condition := v_condition || ' and CREATE_TIME <= to_date(''' || p_createTimeEnd || ''',''yyyy-mm-dd hh24:mi:ss'')';
      end if;

      if p_iscount = 1 then
         v_count := 'select count(1) ' || v_innersql || v_condition;
         execute immediate v_count into p_recordcount;
      end if;

      v_order := ' order by ' || p_sortName || '  ' || p_sortOrder;

      v_temp := v_field || v_innersql || v_condition || v_order;


      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_temp;
        end;
      else
        begin
          v_e := p_pageIndex * p_pageSize;
          v_s := (p_pageIndex - 1) * p_pageSize + 1;
          v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from ( ';
          v_sql := v_sql || ' select ' || v_temp;
          v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
    end;

      --查询违法网站
      procedure list_website_black(
              p_isPaging in number,
              p_pageIndex in number,
              p_pageSize in number,
              p_isCount in number,
              p_sortName in varchar2,
              p_sortOrder in varchar2,

              p_cursor out sys_refcursor,
              p_recordcount out number,

              p_idcId in varchar2,
              p_ip in varchar2,
              p_createTimeBegin in varchar2,
              p_createTimeEnd in varchar2
       )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
      v_temp varchar2(2000);
    begin

      --内部sql语句
      v_innersql := ' from IDC_ISMS_CMD_BLACK_LIST where DELETE_FLAG != 1 and OPERATIONTYPE != 1 ';
      v_field := ' COMMANDID,BLACK_ID,IDCID,CONTENT,CREATE_USER_ID,UPDATE_TIME,CREATE_TIME,COMMANDTYPE ';

      --条件语句
      if (p_idcId is not null) then
        v_condition := v_condition || ' and IDCID like ''%' || p_idcId || '%''';
      end if;
      if (p_ip is not null) then
        v_condition := v_condition || ' and CONTENT like ''%' || p_ip || '%''';
      end if;
      if (p_createTimeBegin is not null) then
        v_condition := v_condition || ' and CREATE_TIME >= to_date(''' || p_createTimeBegin || ''',''yyyy-mm-dd hh24:mi:ss'')';
      end if;
      if (p_createTimeEnd is not null) then
        v_condition := v_condition || ' and CREATE_TIME <= to_date(''' || p_createTimeEnd || ''',''yyyy-mm-dd hh24:mi:ss'')';
      end if;

      if p_iscount = 1 then
         v_count := 'select count(1) ' || v_innersql || v_condition;
         execute immediate v_count into p_recordcount;
      end if;

      v_order := ' order by ' || p_sortName || '  ' || p_sortOrder;

      v_temp := v_field || v_innersql || v_condition || v_order;


      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_temp;
        end;
      else
        begin
          v_e := p_pageIndex * p_pageSize;
          v_s := (p_pageIndex - 1) * p_pageSize + 1;
          v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from ( ';
          v_sql := v_sql || ' select ' || v_temp;
          v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
    end;

     --查询异常IP信息
     procedure list_houseMonitorErrorIpInfo(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_houseId in number,
            p_ip in varchar2,
            p_regDomain in varchar2,
            p_domain in varchar2,
            p_curState in number,
            p_regError in number,
            p_dealFlag in number
         ) is

         --定义
         v_field     varchar2(2000); --字段
         v_childField varchar2(2000); --子查询的字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录

         begin
            --内部sql语句
            v_innersql := ' from idc_isms_monitor_error_info a
                            left join IDC_ISMS_BASE_HOUSE b on a.houseid = b.houseid ';
           v_field := ' error_id, houseId, reg_error, current_state, deal_flag, ip,port,visit_count,first_found, last_found, deal_user, deal_time, reg_domain, domain, reg_ip_use_way, ip_use_way, create_time,housename,statistic_flag ';
            v_childField := ' a.error_id,a.houseId,a.reg_error,a.current_state,a.deal_flag,a.ip,a.port,a.visit_count,a.first_found,a.last_found,a.deal_user,a.deal_time,a.reg_domain,a.domain,reg_ip_use_way,ip_use_way,a.create_time,b.housename,a.statistic_flag ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' error_id DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';

            if p_houseId > 0 then
               v_condition := v_condition || ' and a.houseId = ' || p_houseId;
            end if;
            if (p_ip is not null) then
               v_condition := v_condition || ' and a.ip like ''' || p_ip || '''';
            end if;
            if (p_regDomain is not null) then
               v_condition := v_condition || ' and a.reg_domain like ''%' || p_regDomain || '%''';
            end if;
            if (p_domain is not null) then
               v_condition := v_condition || ' and a.domain like ''%' || p_domain || '%''';
            end if;
            if p_dealFlag >= 0 then
               v_condition := v_condition || ' and a.DEAL_FLAG = ' || p_dealFlag;
            end if;
            if p_curState >= 0 then
               v_condition := v_condition || ' and current_state = ' || p_curState;
            end if;
            if p_regError >= 0 then
               v_condition := v_condition || ' and REG_ERROR = ' || p_regError;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_childField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || 'select' || v_childField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

     --查询违法违规网站信息
     procedure list_houseMonitorErrorDomain(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_houseId in number,
            p_domain in varchar2,
            p_curState in number,
            p_illegalType in number,
            p_dealFlag in number
         ) is

         --定义
         v_field     varchar2(2000); --字段
         v_childField varchar2(2000); --子查询的字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录

         begin
            --内部sql语句
            v_innersql := ' from IDC_ISMS_MONITOR_ERROR_DOMAIN a
                            left join IDC_ISMS_BASE_HOUSE b on a.houseid = b.houseid ';
            v_field := ' error_id, houseId, current_state, deal_flag, ip, port, first_found, last_found, deal_user, deal_time, domain, create_time,housename,
                         (select temp.mc from idc_jcdm_fwnr temp where temp.sfyx = 1 and temp.id = SERVICETYPE) SERVICETYPE,
                         VISIT_COUNT,ILLEGAL_TYPE,statistic_flag ';
            v_childField := ' a.error_id,a.houseId,a.ILLEGAL_TYPE,a.current_state,a.deal_flag,a.SERVICETYPE,a.VISIT_COUNT,a.DOMAIN,a.ip,a.port,a.first_found,a.last_found,a.deal_user,a.deal_time,a.create_time,b.housename,a.statistic_flag ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' error_id DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';

            if p_houseId > 0 then
               v_condition := v_condition || ' and a.HOUSEID = ' || p_houseId;
            end if;
            if (p_domain is not null) then
               v_condition := v_condition || ' and a.domain like ''%' || p_domain || '%''';
            end if;
            if p_dealFlag >= 0 then
               v_condition := v_condition || ' and a.DEAL_FLAG = ' || p_dealFlag;
            end if;
            if p_curState >= 0 then
               v_condition := v_condition || ' and current_state = ' || p_curState;
            end if;
            if p_illegalType > 0 then
               v_condition := v_condition || ' and ILLEGAL_TYPE = ' || p_illegalType;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_childField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || 'select' || v_childField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

procedure list_IdcUpActiveDomainInfo(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_houseId    in number,
      p_actionBlock in number,
      p_topDomainFlag in number,
      p_domain     in VARCHAR2,
      p_topDomain  in VARCHAR2,
      p_ip         in VARCHAR2,
      p_port       in number,
      p_idcId     in VARCHAR2,
      p_visitsCount in number,
      p_recordcount out number,
      p_cursor      out sys_refcursor
) is
      v_begin     INTEGER;
      v_end       INTEGER;
      v_count     varchar2(2000);
      v_sql       varchar2(2000);
      v_where    varchar2(2000);
      v_field    varchar2(2000);
      v_threshold idc_jcdm_jkcs.cs_value%type;
begin
      v_begin := (p_pageIndex -1) * p_pageSize;
      v_end := p_pageIndex * p_pageSize;

      select trim(t.cs_value) into v_threshold from idc_jcdm_jkcs t
      where t.model_type = 0 and t.cs_key = 'threshold_active_domain' and t.sfyx = 1;

      v_where := ' where (domain is not null and length(trim(domain)) >0) and times >=' || v_threshold;
      v_field := 'idcid, houseid, houseidstr, ip, port, domain, istop, topdomain, a.times visitsCount, firsttime, lasttime, stat_date, isblock, isinipseg, protocol';
      if p_houseId > 0 then
         v_where := v_where || ' and a.houseId = ' || p_houseId;
      end if;
      if p_actionBlock >= 0 then
         v_where := v_where || ' and a.isblock = ' || p_actionBlock;
      end if;
      if p_topDomainFlag >= 0 then
         v_where := v_where || ' and a.ISTOP = ' || p_topDomainFlag;
      end if;
      if p_domain is not null then
         v_where := v_where || ' and a.DOMAIN like ''%' || p_domain || '%''';
      end if;
      if p_topDomain is not null then
         v_where := v_where || ' and a.TOPDOMAIN like ''%' || p_topDomain || '%''';
      end if;
      if p_ip is not null then
         v_where := v_where || ' and a.IP = ''' || p_ip || '''';
      end if;
      if p_port >0 then
         v_where := v_where || ' and a.PORT = ' || p_port;
      end if;
      if p_idcId is not null then
         v_where := v_where || ' and a.IDCID like ''%' || p_idcId || '%''';
      end if;
      if p_visitsCount >= 0 then
         v_where := v_where || ' and a.TIMES >= ' || p_visitsCount;
      end if;
      v_count := 'select count(1) from idc_isms_active_resources  a' || v_where;
      execute immediate v_count into p_recordCount;

      v_sql :='select * from (select rownum as RN,t.* from (select '||v_field||' from idc_isms_active_resources a '|| v_where|| ' order by visitsCount desc) t where rownum <= '||v_end ||') where RN >'||v_begin;
      dbms_output.put_line(v_sql);
      open p_cursor for v_sql;
end;

procedure list_IdcUpActiveIpInfo(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_houseId    in number,
      p_actionBlock in number,
      p_isInIpSeg in number,
      p_port     in number,
      p_protocol  in number,
      p_ip         in VARCHAR2,
      p_idcId     in VARCHAR2,
      p_visitsCount in number,
      p_recordcount out number,
      p_cursor      out sys_refcursor
)is
      v_begin     INTEGER;
      v_end       INTEGER;
      v_count     varchar2(2000);
      v_sql       varchar2(2000);
      v_where    varchar2(2000);
      v_inner_sql varchar2(2000);
      v_group     varchar2(2000);
      v_threshold idc_jcdm_jkcs.cs_value%type;
begin
      v_begin := (p_pageIndex -1) * p_pageSize;
      v_end := p_pageIndex * p_pageSize;

      select trim(t.cs_value) into v_threshold from idc_jcdm_jkcs t
      where t.model_type = 0 and t.cs_key = 'threshold_active_ip' and t.sfyx = 1;

      v_inner_sql := 'idcid, houseid, houseidstr, ip, port, isblock, isinipseg, protocol, sum(times) visitcount, min(firsttime) firsttime, max(lasttime) lasttime';
      v_group := 'group by idcid, houseid, houseidstr, ip, port, isblock, isinipseg, protocol';
      v_where := ' where visitcount >=' || v_threshold;

      if p_houseId > 0 then
         v_where := v_where || ' and a.houseId = ' || p_houseId;
      end if;
      if p_actionBlock >= 0 then
         v_where := v_where || ' and a.isblock = ' || p_actionBlock;
      end if;
      if p_isInIpSeg >= 0 then
         v_where := v_where || ' and a.ISINIPSEG = ' || p_isInIpSeg;
      end if;
      if p_port >0 then
         v_where := v_where || ' and a.PORT = ' || p_port;
      end if;
      if p_protocol >=0 then
         v_where := v_where || ' and a.PROTOCOL = ' || p_protocol;
      end if;
      if p_ip is not null then
         v_where := v_where || ' and a.IP = ''' || p_ip || '''';
      end if;
      if p_idcId is not null then
         v_where := v_where || ' and a.IDCID like ''%' || p_idcId || '%''';
      end if;
      if p_visitsCount >= 0 then
         v_where := v_where || ' and a.visitcount >= ' || p_visitsCount;
      end if;
      dbms_output.put_line(v_where);
      v_count := 'select count(1) from ( ' ;
      v_count := v_count || ' select ' || v_inner_sql || ' from idc_isms_active_resources ';
      v_count := v_count || v_group || ') a' || v_where ;
      execute immediate v_count into p_recordCount;
      v_sql :='select * from (select rownum as RN,t.* from (select * from (select ' || v_inner_sql || ' from idc_isms_active_resources '|| v_group || ') a ' || v_where || ' order by visitcount desc) t where rownum <= '||v_end ||') where RN >'||v_begin;
      dbms_output.put_line(v_sql);
      open p_cursor for v_sql;
end;

procedure list_websiteStatistics(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_houseId    in number,
      p_startTime  in VARCHAR2, --开始统计时间
      p_endTime  in VARCHAR2, --结束统计时间
      p_sortName   in VARCHAR2,
      p_sortOrder in varchar2,
      p_recordcount out number,
      p_cursor      out sys_refcursor,
      p_userHouseIDStrs in varchar2
      )
is
      v_begin     INTEGER;
      v_count     varchar2(2000);
      v_end       INTEGER;
      v_sql       varchar2(4000);
      v_where    varchar2(2000);
begin
      v_begin := (p_pageIndex -1) * p_pageSize;
      v_end := p_pageIndex * p_pageSize;
      v_where := ' where 1=1';
      if p_houseId >0 then
         v_where := v_where || ' and a.HOUSEID = ' || p_houseId;
      end if;
      if (p_startTime is not null) and (p_endTime is not null) then
         v_where := v_where || ' and a.STATISTIC_HOUR between ''' || p_startTime || ''' and ''' || p_endTime || '''';
      elsif (p_startTime is not null) then
         v_where := v_where || ' and a.STATISTIC_HOUR >= ''' || p_startTime || '''';
      elsif (p_endTime is not null) then
         v_where := v_where || ' and a.STATISTIC_HOUR <= ''' || p_endTime || '''';
      end if;
      v_count := 'select count(1) from (select * from idc_isms_domain_statistic where houseid in ('||p_userHouseIDStrs||')) a' || v_where;
      execute immediate v_count into p_recordCount;
      v_sql := 'select * from (select t.*, rownum as RN from (select a.* ,b.houseName,b.houseIdStr from (select * from idc_isms_domain_statistic where houseid in ('||p_userHouseIDStrs||')) a  left join (select * from idc_isms_base_house where houseid in ('||p_userHouseIDStrs||')) b  on a.houseid = b.houseid' || v_where || ' order by ' || p_sortName || ' ' || p_sortOrder ||')t where  rownum <= '||v_end || ') where RN >'||v_begin;
      dbms_output.put_line(v_sql);
      open p_cursor for v_sql;
end;

procedure list_topNWebsiteStatistics(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_id         in number,
      p_houseId    in number,
      p_domain    in VARCHAR2,
      p_findStartTimeStr in VARCHAR2,
      p_findEndTimeStr in VARCHAR2,
      p_sortName   in VARCHAR2,
      p_sortOrder in VARCHAR2,
      p_recordcount out number,
      p_cursor      out sys_refcursor,
      p_userHouseIDStrs in varchar2
      )
is
      v_begin     INTEGER;
      v_end       INTEGER;
      v_count     varchar2(2000);
      v_sql       varchar2(4000);
      v_where    varchar2(2000);
begin
      v_begin := (p_pageIndex -1) * p_pageSize;
      v_end := p_pageIndex * p_pageSize;
      v_where := ' where 1=1';
      if (p_id > 0) then
         v_where := v_where || ' and a.TOPN_ID = ' || p_id;
      end if;
      if p_houseId > 0 then
          v_where := v_where || ' and a.HOUSEID = ' || p_houseId;
      end if;
      if p_domain is not null then
          v_where := v_where || ' and a.DOMAIN like ''%' || p_domain || '%''';
      end if;
      if p_findStartTimeStr is not null then
         v_where := v_where || ' and FIRST_FOUND >= to_date('''||p_findStartTimeStr ||''',''yyyy-MM-dd hh24:mi:ss'')';
       end if;
       if p_findEndTimeStr is not null then
        v_where := v_where ||  ' and FIRST_FOUND <= to_date('''||p_findEndTimeStr ||''',''yyyy-MM-dd hh24:mi:ss'')';
       end if;
      dbms_output.put_line(v_where);
      v_count := 'select count(1) from (select * from idc_isms_topn_domain where houseid in ('||p_userHouseIDStrs||'))  a' || v_where;
      execute immediate v_count into p_recordcount;
      v_sql := 'select * from (select t.*, rownum as RN from (select a.* ,b.houseName,b.houseIdStr from (select * from idc_isms_topn_domain where houseid in ('||p_userHouseIDStrs||')) a  left join (select * from idc_isms_base_house where houseid in ('||p_userHouseIDStrs||')) b  on a.houseid = b.houseid' || v_where || ' order by ' || p_sortName || ' ' || p_sortOrder ||')t where  rownum <= '||v_end || ') where RN >'||v_begin;
      dbms_output.put_line(v_sql);
      open p_cursor for v_sql;
end;

procedure list_topNWebsiteBlack(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_id         in number,
      p_houseId    in number,
      p_domain    in VARCHAR2,
      p_findStartTimeStr in VARCHAR2,
      p_findEndTimeStr in VARCHAR2,
      p_sortName   in VARCHAR2,
      p_sortOrder in VARCHAR2,
      p_recordcount out number,
      p_cursor      out sys_refcursor,
       p_userHouseIDStrs in varchar2
      )
is
      v_begin     INTEGER;
      v_end       INTEGER;
      v_count     varchar2(2000);
      v_sql       varchar2(4000);
      v_where    varchar2(2000);
begin
      v_begin := (p_pageIndex -1) * p_pageSize;
      v_end := p_pageIndex * p_pageSize;
      v_where := ' where 1=1';
      if (p_id > 0) then
         v_where := v_where || ' and a.TOPN_ID = ' || p_id;
      end if;
      if p_houseId > 0 then
          v_where := v_where || ' and a.HOUSEID = ' || p_houseId;
      end if;
      if p_domain is not null then
          v_where := v_where || ' and a.DOMAIN like ''%' || p_domain || '%''';
      end if;
      if p_findStartTimeStr is not null then
         v_where := v_where || ' and FIRST_FOUND >= to_date('''||p_findStartTimeStr ||''',''yyyy-MM-dd hh24:mi:ss'')';
       end if;
       if p_findEndTimeStr is not null then
        v_where := v_where ||  ' and FIRST_FOUND <= to_date('''||p_findEndTimeStr ||''',''yyyy-MM-dd hh24:mi:ss'')';
       end if;
      dbms_output.put_line(v_where);
      v_count := 'select count(1) from (select * from idc_isms_topn_error_domain where houseid in ('||p_userHouseIDStrs||'))  a' || v_where;
      execute immediate v_count into p_recordcount;
      v_sql := 'select * from (select t.*, rownum as RN from (select a.* ,b.houseName,b.houseIdStr from (select * from idc_isms_topn_error_domain where houseid in ('||p_userHouseIDStrs||')) a  left join (select * from idc_isms_base_house where houseid in ('||p_userHouseIDStrs||')) b  on a.houseid = b.houseid' || v_where || ' order by ' || p_sortName || ' ' || p_sortOrder ||')t where  rownum <= '||v_end || ') where RN >'||v_begin;
      dbms_output.put_line(v_sql);
      open p_cursor for v_sql;
end;

end IDC_ISMS_SYSTEM_MONITOR_MANAGE;

/
