CREATE package idc_interface_upload is

   --活动状态上报的处理
   procedure uploadActiveState (
       --出参
       p_idcId          out varchar2,
       p_houseAmount    out number,
       p_errHouseAmount out number,
       p_errorHouseIds  out sys_refcursor,
       v_out_success    out number
     );

   --活跃资源上报成功的处理
   procedure dealResourcesComplete (
       --出参
       v_out_success    out number
     );

   --处理xml文件状态信息
   procedure dealXmlFileState (
       p_commandId  in varchar2,
       p_commandTyoe in number,
       p_fileName   in varchar2,
       p_fileState  in number,
       /*
      1、文件解密失败
      2、文件校验失败
      3、文件解压缩失败
      4、文件格式异常
      5、文件内容异常
      900、其他异常
      0、文件未生成
      990、文件已生成
      991、文件已上传
       */
       p_dmms           in varchar2,
       p_insertOrUpdate in number,
          --出参
       v_out_success    out number
     );

  ---创建上传文件完成的处理
  procedure DealUploadComplete(
       p_idcId in varchar2,
       p_fileName in varchar2,
       p_type in   number,
       /*
       11-基础数据-新增；
       12-基础数据-变更；
       13-基础数据-注销；
       14-基础数据-查询；
       2-基础数据监测数据；
       3-访问日志查询结果；
       4-监测日志；
       5-过滤日志；
       51-山西自定义接口——基础数据及备案信息;
       52-山西自定义接口——域名访问量数据;
       53-山西自定义接口——过滤状态;
       54-山西自定义接口——过滤统计数据;
       56-山西自定义接口——网络协议应用数据;
       6-信息安全管理指令查询结果；
       7-ISMS活动状态;
       8-活跃资源；
       9-违法违规网站监测记录
       10-指令执行情况
       */
       p_ids  in   varchar2,
          --出参
       v_out_success    out number
        );

   --创建上传文件时xsd校验失败的处理
   procedure DealUploadError(
       p_idcId in varchar2,
       p_type in   number,
       /*
       11-基础数据-新增；
       12-基础数据-变更；
       13-基础数据-注销；
       14-基础数据-查询；
       2-基础数据监测数据；
       3-访问日志查询结果；
       4-监测日志；
       5-过滤日志；
       51-山西自定义接口——基础数据及备案信息;
       52-山西自定义接口——域名访问量数据;
       53-山西自定义接口——过滤状态;
       54-山西自定义接口——过滤统计数据;
       56-山西自定义接口——网络协议应用数据;
       6-信息安全管理指令查询结果；
       7-ISMS活动状态;
       8-活跃资源；
       9-违法违规网站监测记录
       10-指令执行情况
       */
       p_ids  in   varchar2,
          --出参
       v_out_success    out number
        );

 --创建上传文件返回的处理
 procedure DealBackdata(
       p_czlx in number,
       /*
       11-基础数据-新增；
       12-基础数据-变更；
       13-基础数据-注销；
       14-基础数据-查询；
       2-基础数据监测数据；
       3-访问日志查询结果；
       4-监测日志；
       5-过滤日志；
       51-山西自定义接口——基础数据及备案信息;
       52-山西自定义接口——域名访问量数据;
       53-山西自定义接口——过滤状态;
       54-山西自定义接口——过滤统计数据;
       56-山西自定义接口——网络协议应用数据;
       6-信息安全管理指令查询结果；
       7-ISMS活动状态;
       8-活跃资源；
       9-违法违规网站监测记录
       */
       -- 1-基础数据-新增；2-基础数据-变更；3-基础数据-注销；4-基础数据-查询；5-基础数据监测数据；6-访问日志查询结果；7-监测日志；8-过滤日志；9-信息安全管理指令查询结果；10-ISMS活动状态
       p_filename in   varchar2,
       p_jgdm  in   number,
       p_dmms  in   varchar2,
          --出参
       v_out_success    out number
        );

  --更新上报后的接口处理状态
   procedure updateReportState(
       v_ids            in varchar2,--传入的id值
       p_type           in number,  --更新的类型，1-新增更新为变更、2-变更更新为变更
       --出参
       v_out_success    out number
        );

   --更新上报后的接口处理状态
   procedure updateReportStateNew(
             v_ids            in varchar2,--传入的id值
             p_type           in number,  --更新的类型，1-新增更新为变更、2-变更更新为变更
             --出参
             v_out_success    out number
        );

end idc_interface_upload;

/
CREATE package body idc_interface_upload is

   --活动状态上报的处理
   procedure uploadActiveState (
       --出参
       p_idcId          out varchar2,
       p_houseAmount    out number,
       p_errHouseAmount out number,
       p_errorHouseIds  out sys_refcursor,
       v_out_success    out number
     ) as
       v_idcId          varchar2(200) := '';
       v_houseAmount    number := 0;
       v_errHouseAmount number := 0;
       v_count number := 0;
   begin
     --idcId
     select count(1) into v_count from idc_isms_base_idc idc where idc.czlx = 2 and rownum = 1 and del_flag != 1;
     if (v_count <> 0) then
        select idc.idcid into v_idcId from idc_isms_base_idc idc where idc.czlx = 2 and rownum = 1 and del_flag != 1;
        --机房总数
        select count(1) into v_houseAmount from idc_isms_base_house house
        where del_flag != 1 and house.jyzid in (select idc.jyzid from idc_isms_base_idc idc where idc.idcid = '' || v_idcId || '' );
     end if;
     --异常机房总数
     select count(1) into v_errHouseAmount from (
        select t.houseid from idc_isms_monitor_error_info t group by t.houseid
        union
        select t1.houseid from idc_isms_monitor_error_domain t1 group by t1.houseid
     );
     p_idcId := v_idcId;
     p_houseAmount := v_houseAmount;
     p_errHouseAmount := v_errHouseAmount;
     --异常机房id
     open p_errorHouseIds for
     select t.houseid from idc_isms_monitor_error_info t group by t.houseid
     union
     select t1.houseid from idc_isms_monitor_error_domain t1 group by t1.houseid;
     exception when others then
        rollback;
        v_out_success:=0;
        return;
     commit;
     v_out_success:=1;
   end;

   --活跃资源上报成功的处理
   procedure dealResourcesComplete (
       --出参
       v_out_success    out number
     ) as
   begin
      /*update idc_isms_active_ip set upload_type = 0;
      update idc_isms_active_doamin set upload_type = 0;
      execute immediate 'truncate table idc_isms_active_dis_domain';
      execute immediate 'truncate table idc_isms_active_dis_ip';
      commit;
      v_out_success:=1;
      exception when others then
         rollback;
         v_out_success := 0;
         return;*/
     dbms_output.put_line('');
   end;

   --处理xml文件状态信息
   procedure dealXmlFileState (
       p_commandId  in varchar2,
       p_commandTyoe in number,
       p_fileName   in varchar2,
       p_fileState  in number,
       /*
        1、文件解密失败
        2、文件校验失败
        3、文件解压缩失败
        4、文件格式异常
        5、文件内容异常
        900、其他异常
        0、文件未生成
        990、文件已生成
        991、文件上传成功
        992、文件上传失败
       */
       p_dmms           in varchar2,
       p_insertOrUpdate in number,
          --出参
       v_out_success    out number
     ) as
 begin
    --添加数据(文件已经生成)
    if (p_insertOrUpdate = 0) then
       insert into idc_isms_cmd_file_state
         (commandid,COMMANDTYPE, filename, file_state, create_time, update_time)
       values
         (p_commandId,p_commandTyoe, p_fileName, p_fileState, sysdate, sysdate);
    end if;
    --更新文件状态
    if (p_insertOrUpdate = 1) then
       update idc_isms_cmd_file_state
          set file_state = p_fileState,
              dmms = p_dmms,
              update_time = sysdate
        where filename = p_fileName;
    end if;
    commit;
    v_out_success:=1;
 exception WHEN OTHERS THEN
    ROLLBACK;
    v_out_success := 0;
    RETURN;
 end;

  --创建上传文件完成的处理
 procedure DealUploadComplete(
       p_idcId in varchar2,
       p_fileName in varchar2,
       p_type in   number,
       /*
       11-基础数据-新增；
       12-基础数据-变更；
       13-基础数据-注销；
       14-基础数据-查询；
       2-基础数据监测数据；
       3-访问日志查询结果；
       4-监测日志；
       5-过滤日志；
       51-山西自定义接口——基础数据及备案信息;
       52-山西自定义接口——域名访问量数据;
       53-山西自定义接口——过滤状态;
       54-山西自定义接口——过滤统计数据;
       56-山西自定义接口——网络协议应用数据;
       6-信息安全管理指令查询结果；
       7-ISMS活动状态;
       8-活跃资源；
       9-违法违规网站监测记录
       10-指令执行情况
       */
       -- 1-基础数据-新增；2-基础数据-变更；3-基础数据-注销；4-基础数据-查询；5-基础数据监测数据；6-访问日志查询结果；7-监测日志；8-过滤日志；9-信息安全管理指令查询结果；10-ISMS活动状态
       p_ids  in   varchar2,
          --出参
       v_out_success    out number
        )as
   v_ids varchar2(500);
   v_sql varchar2(2048);
   v_count number := 0;
 Begin
    v_sql:='';
    v_ids:='(' || p_ids || ')';

    if(p_type=11) then
      updateReportStateNew(p_ids, 1, v_out_success);
      /*v_sql:='update idc_isms_base_idc set deal_flag=0,czlx=2 where  jyzid in ' || v_ids || ' and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_house set deal_flag=0,czlx=2 where  jyzid in ' || v_ids || ' and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_user set deal_flag=0,czlx=2 where  jyzid in ' || v_ids || ' and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_house_gateway set deal_flag=0,czlx=2 where houseid in (select houseid from idc_isms_base_house  where  jyzid in ' || v_ids || ') and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_house_ipseg set deal_flag=0,czlx=2 where houseid in (select houseid from idc_isms_base_house  where  jyzid in ' || v_ids || ') and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_house_frame set deal_flag=0,czlx=2 where houseid in (select houseid from idc_isms_base_house where  jyzid in ' || v_ids || ') and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_user_hh set deal_flag=0,czlx=2 where userid in (select userid from idc_isms_base_user  where  jyzid in ' || v_ids || ') and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_user_service set deal_flag=0,czlx=2 where userid in (select userid from idc_isms_base_user  where  jyzid in ' || v_ids || ') and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_service_domain set deal_flag=0,czlx=2 where userid in (select userid from idc_isms_base_user  where  jyzid in ' || v_ids || ') and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_service_hh set deal_flag=0,czlx=2 where userid in (select userid from idc_isms_base_user  where  jyzid in ' || v_ids || ') and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;*/
    elsif(p_type=12) then
      /*v_sql:='update idc_isms_base_idc set deal_flag=0 where  jyzid in ' || v_ids || ' and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_house set deal_flag=0 where  jyzid in ' || v_ids || ' and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_user set deal_flag=0 where  jyzid in ' || v_ids || ' and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_house_gateway set deal_flag=0 where houseid in (select houseid from idc_isms_base_house  where  jyzid in ' || v_ids || ') and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_house_ipseg set deal_flag=0 where houseid in (select houseid from idc_isms_base_house  where  jyzid in ' || v_ids || ') and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_house_frame set deal_flag=0 where houseid in (select houseid from idc_isms_base_house  where  jyzid in ' || v_ids || ') and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_user_hh set deal_flag=0 where userid in (select userid from idc_isms_base_user  where  jyzid in ' || v_ids || ') and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_user_service set deal_flag=0 where userid in (select userid from idc_isms_base_user  where  jyzid in ' || v_ids || ') and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_service_domain set deal_flag=0 where userid in (select userid from idc_isms_base_user  where  jyzid in ' || v_ids || ') and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_service_hh set deal_flag=0 where userid in (select userid from idc_isms_base_user  where  jyzid in ' || v_ids || ') and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;*/
      updateReportStateNew(p_ids, 2, v_out_success);
    elsif(p_type=13) then
      --v_sql:='update idc_isms_base_delete set deal_flag=4 where  delid in ' || v_ids || ' and deal_flag=1 ';
      v_sql:='update idc_isms_base_delete set deal_flag=4 where deal_flag=1 ';
      execute immediate v_sql;
    elsif(p_type=14) then
      v_sql:='update IDC_ISMS_CMD_IDCINFO_MANAGE set deal_flag=3 where  commandId in ' || v_ids || ' and cmd_type=0';
      execute immediate v_sql;
    elsif(p_type=2) then
      v_sql:='update IDC_ISMS_CMD_IDCINFO_MANAGE set deal_flag=3 where  commandId in ' || v_ids || ' and cmd_type=3 and DEAL_FLAG=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_monitor_error_info ip set ip.deal_flag = 4 where ip.deal_flag = 1';
      execute immediate v_sql;
    elsif(p_type=3) then
      v_sql:='update IDC_ISMS_CMD_LOG_QUERY set deal_flag=3 where  commandId in ' || v_ids || ' and DEAL_FLAG=1 ';
      execute immediate v_sql;
    elsif(p_type=4) then
      v_sql:='update idc_isms_cmd_idc_manage set deal_flag=3 where  commandId in ' || v_ids || ' and cmd_type=1 and DEAL_FLAG=0 ';
      execute immediate v_sql;
    elsif(p_type=5) then
      v_sql:='update idc_isms_cmd_idc_manage set deal_flag=3 where  commandId in ' || v_ids || ' and cmd_type=2 and DEAL_FLAG=0 ';
      execute immediate v_sql;
    elsif(p_type=6) then
      v_sql:='update IDC_ISMS_CMD_IDCMNG_QUERY set deal_flag=3 where  commandId in ' || v_ids || ' and DEAL_FLAG=0 ';
      execute immediate v_sql;
    elsif(p_type=9) then
      v_sql:='update idc_isms_monitor_error_domain set deal_flag = 4 where deal_flag = 1';
      execute immediate v_sql;
      if (v_ids is not null) then
          v_sql:='update idc_isms_monitor_error_domain set deal_flag = 4';
          execute immediate v_sql;
      end if;
    elsif(p_type=10) then
      --更新指令反馈表记录
      v_sql:='update IDC_ISMS_REPLY_CMD_ACK set deal_flag=3 where  commandId in ' || v_ids || ' and DEAL_FLAG=1 ';
      execute immediate v_sql;
      --更新违法信息监测指令记录
      v_sql:='update idc_isms_cmd_idc_manage set deal_flag=3 where  commandId in ' || v_ids || ' and cmd_type=1 and DEAL_FLAG=0 ';
      execute immediate v_sql;
      --更新违法信息过滤指令记录
      v_sql:='update idc_isms_cmd_idc_manage set deal_flag=3 where  commandId in ' || v_ids || ' and cmd_type=2 and DEAL_FLAG=0 ';
      execute immediate v_sql;
      --更新代码发布指令记录
      v_sql:='update idc_isms_cmd_code_list set deal_flag = 3 where commandid in ' || v_ids || ' and deal_flag = 0 ';
      execute immediate v_sql;
      --更新免过滤网站列表指令记录
      v_sql:='update idc_isms_cmd_no_filter set deal_flag = 3 where commandid in ' || v_ids || ' and deal_flag = 0 ';
      execute immediate v_sql;
      --更新违法网站列表指令记录
      v_sql:='update idc_isms_cmd_black_list set deal_flag = 3 where commandid in ' || v_ids || ' and deal_flag = 0 ';
      execute immediate v_sql;
      --更新活跃资源访问量查询指令记录
      v_sql:='update idc_isms_cmd_query_view set deal_flag = 3 where commandid in ' || v_ids || ' and deal_flag = 0 ';
      execute immediate v_sql;
      --更新违法信息管理查询指令记录
      v_sql:='update idc_isms_cmd_command_record set deal_flag = 3 where commandid in ' || v_ids || ' and deal_flag = 0 ';
      execute immediate v_sql;
      v_sql:='update IDC_ISMS_CMD_IDCINFO_MANAGE set deal_flag=3 where  commandId in ' || v_ids || ' and DEAL_FLAG=0 ';
      execute immediate v_sql;
    end if;

    insert into idc_interface_upload_log
           (logid, jlid, czlx, file_name, create_time, iscreate,idcid)
    values (seq_idc_interface_uplogid.nextval, p_ids, p_type, p_fileName, sysdate, 1, p_idcId);

    commit;
    v_out_success := 1;
 exception WHEN OTHERS THEN
    ROLLBACK;
    v_out_success := 0;
    raise;
 end;

   --创建上传文件时xsd校验失败的处理
 procedure DealUploadError(
       p_idcId in varchar2,
       p_type in   number,
       /*
       11-基础数据-新增；
       12-基础数据-变更；
       13-基础数据-注销；
       14-基础数据-查询；
       2-基础数据监测数据；
       3-访问日志查询结果；
       4-监测日志；
       5-过滤日志；
       51-山西自定义接口——基础数据及备案信息;
       52-山西自定义接口——域名访问量数据;
       53-山西自定义接口——过滤状态;
       54-山西自定义接口——过滤统计数据;
       56-山西自定义接口——网络协议应用数据;
       6-信息安全管理指令查询结果；
       7-ISMS活动状态;
       8-活跃资源；
       9-违法违规网站监测记录
       10-指令执行情况
       */
       -- 1-基础数据-新增；2-基础数据-变更；3-基础数据-注销；4-基础数据-查询；5-基础数据监测数据；6-访问日志查询结果；7-监测日志；8-过滤日志；9-信息安全管理指令查询结果；10-ISMS活动状态
       p_ids  in   varchar2,
          --出参
       v_out_success    out number
        )as
   v_ids varchar2(500);
   v_sql varchar2(500);
 begin
    v_sql:='';
    v_ids:='(' || p_ids || ')';
    if(p_type=11) then
      v_sql:='update idc_isms_base_idc set deal_flag=0 where  jyzid in ' || v_ids || ' and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_house set deal_flag=0 where  jyzid in ' || v_ids || ' and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_user set deal_flag=0 where  jyzid in ' || v_ids || ' and czlx=1 and deal_flag=1 ';
      execute immediate v_sql;
    elsif(p_type=12) then
      v_sql:='update idc_isms_base_idc set deal_flag=0 where  jyzid in ' || v_ids || ' and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_house set deal_flag=0 where  jyzid in ' || v_ids || ' and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;
      v_sql:='update idc_isms_base_user set deal_flag=0 where  jyzid in ' || v_ids || ' and czlx=2 and deal_flag=1 ';
      execute immediate v_sql;
    elsif(p_type=13) then
      v_sql:='update idc_isms_base_delete set deal_flag=2 where  delid in ' || v_ids || ' and deal_flag=1 ';
      execute immediate v_sql;
    elsif(p_type=14) then
      v_sql:='update IDC_ISMS_CMD_IDCINFO_MANAGE set deal_flag=2 where  commandId in ' || v_ids || ' and cmd_type=0 and DEAL_FLAG=0 ';
      execute immediate v_sql;
    elsif(p_type=2) then
      v_sql:='update IDC_ISMS_CMD_IDCINFO_MANAGE set deal_flag=2 where  commandId in ' || v_ids || ' and cmd_type=3 and DEAL_FLAG=0 ';
      execute immediate v_sql;
    elsif(p_type=3) then
      v_sql:='update IDC_ISMS_CMD_LOG_QUERY set deal_flag=2 where  commandId in ' || v_ids || ' and DEAL_FLAG=0 ';
      execute immediate v_sql;
    elsif(p_type=4) then
      v_sql:='update idc_isms_cmd_idc_manage set deal_flag=2 where  commandId in ' || v_ids || ' and cmd_type=1 and DEAL_FLAG=0 ';
      execute immediate v_sql;
    elsif(p_type=5) then
      v_sql:='update idc_isms_cmd_idc_manage set deal_flag=2 where  commandId in ' || v_ids || ' and cmd_type=2 and DEAL_FLAG=0 ';
      execute immediate v_sql;
    elsif(p_type=6) then
      v_sql:='update IDC_ISMS_CMD_IDCMNG_QUERY set deal_flag=2 where  commandId in ' || v_ids || ' and DEAL_FLAG=0 ';
      execute immediate v_sql;
    end if;

    insert into idc_interface_upload_log
           (logid, jlid, czlx, file_name, create_time, iscreate,idcid)
    values (seq_idc_interface_uplogid.nextval, p_ids, p_type, '', sysdate, 0, p_idcId);

    commit;
    v_out_success:=1;
 exception WHEN OTHERS THEN
    ROLLBACK;
    v_out_success := 0;
    RETURN;
 end;

 --创建上传文件返回的处理
 procedure DealBackdata(
       p_czlx in number,
       /*
       1-基础数据；
       2-基础数据监测异常记录；
       3-访问日志查询记录；
       4-违法信息监测记录；
       5-违法信息过滤记录；
       6-（保留的值）
       7-ISMS活动状态；
       8-活跃资源监测记录；
       9-违法违规网站监测记录
       */
       p_filename in   varchar2,
       p_jgdm  in   number,
       /*

       */
       p_dmms  in   varchar2,
          --出参
       v_out_success    out number
        ) as
 begin
    insert into idc_interface_upload_back
      (backid, czlx, filename, jgdm, dmms)
    values
      (SEQ_IDC_INTERFACE_UPBACKID.Nextval, p_czlx, p_filename, p_jgdm, p_dmms);
    --更新文件状态表
    idc_interface_upload.dealXmlFileState('','',p_filename, p_jgdm, p_dmms, 1,v_out_success);
    commit;
    v_out_success:=1;
 exception WHEN OTHERS THEN
    ROLLBACK;
    v_out_success := 0;
    RETURN;
 end;

 procedure updateReportState(
       v_ids            in varchar2,
       p_type           in number,
       --出参
       v_out_success    out number
        ) as
   v_count number := 0;
 begin
      --经营者新增上报
      select count(1) into v_count from idc_isms_base_idc where jyzid in v_ids and czlx=p_type and deal_flag=1;
      --更新经营者下的全部子节点
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids and czlx=p_type and deal_flag=1;
         update IDC_ISMS_BASE_HOUSE set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_HOUSE_GATEWAY set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_HOUSE_IPSEG set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_HOUSE_FRAME set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_USER set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_USER_SERVICE set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_SERVICE_DOMAIN set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_SERVICE_HH set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_SERVICE_IPTRANS set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_SERVICE_VIRTUAL set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_USER_HH set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_USER_HH_IPSEG set czlx=2,deal_flag = 4;
      end if;
      --机房新增上报
      select count(1) into v_count from idc_isms_base_house where jyzid in v_ids and czlx=p_type and deal_flag=1;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_HOUSE set czlx=2,deal_flag = 4 where jyzid in v_ids and czlx=p_type and deal_flag=1;
         update IDC_ISMS_BASE_HOUSE_GATEWAY set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_HOUSE_IPSEG set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_HOUSE_FRAME set czlx=2,deal_flag = 4;
      end if;
      --机房子节点新增上报
      select count(1) into v_count from idc_isms_base_house_gateway where czlx=p_type and deal_flag=1;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_HOUSE set czlx=2,deal_flag = 4 where jyzid in v_ids;
         update IDC_ISMS_BASE_HOUSE_GATEWAY set czlx=2,deal_flag = 4 where czlx=p_type and deal_flag=1;
      end if;
      select count(1) into v_count from idc_isms_base_house_ipseg where czlx=p_type and deal_flag=1;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_HOUSE set czlx=2,deal_flag = 4 where jyzid in v_ids;
         update IDC_ISMS_BASE_HOUSE_IPSEG set czlx=2,deal_flag = 4 where czlx=p_type and deal_flag=1;
      end if;
      select count(1) into v_count from idc_isms_base_house_frame where czlx=p_type and deal_flag=1;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_HOUSE set czlx=2,deal_flag = 4 where jyzid in v_ids;
         update IDC_ISMS_BASE_HOUSE_FRAME set czlx=2,deal_flag = 4 where czlx=p_type and deal_flag=1;
      end if;
      --用户新增上报
      select count(1) into v_count from idc_isms_base_user where jyzid in v_ids and czlx=p_type and deal_flag=1;
      --更新用户下的全部子节点和经营者
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_USER set czlx=2,deal_flag = 4 where jyzid in v_ids and czlx=p_type and deal_flag=1;
         update IDC_ISMS_BASE_USER_SERVICE set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_SERVICE_DOMAIN set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_SERVICE_HH set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_SERVICE_IPTRANS set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_SERVICE_VIRTUAL set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_USER_HH set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_USER_HH_IPSEG set czlx=2,deal_flag = 4;
      end if;
      --用户子节点新增上报
      select count(1) into v_count from idc_isms_base_user_service where czlx=p_type and deal_flag=1;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_USER set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_USER_SERVICE set czlx=2,deal_flag = 4 where czlx=p_type and deal_flag=1;
         update IDC_ISMS_BASE_SERVICE_DOMAIN set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_SERVICE_HH set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_SERVICE_IPTRANS set czlx=2,deal_flag = 4;
         update IDC_ISMS_BASE_SERVICE_VIRTUAL set czlx=2,deal_flag = 4;
      end if;
      select count(1) into v_count from idc_isms_base_user_hh where czlx=p_type and deal_flag=1;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_USER set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_USER_HH set czlx=2,deal_flag = 4 where czlx=p_type and deal_flag=1;
         update IDC_ISMS_BASE_USER_HH_IPSEG set czlx=2,deal_flag = 4;
      end if;
      --用户叶子节点新增上报
      select count(1) into v_count from idc_isms_base_service_domain where czlx=p_type and deal_flag=1;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_USER set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_USER_SERVICE set czlx=2,deal_flag = 4
         where serviceid in (
               select serviceid from IDC_ISMS_BASE_SERVICE_DOMAIN where czlx=p_type and deal_flag=1
         );
         update IDC_ISMS_BASE_SERVICE_DOMAIN set czlx=2,deal_flag = 4 where czlx=p_type and deal_flag=1;
      end if;
      select count(1) into v_count from idc_isms_base_service_hh where czlx=p_type and deal_flag=1;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_USER set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_USER_SERVICE set czlx=2,deal_flag = 4
         where serviceid in (
               select serviceid from IDC_ISMS_BASE_SERVICE_HH where czlx=p_type and deal_flag=1
         );
         update IDC_ISMS_BASE_SERVICE_HH set czlx=2,deal_flag = 4 where czlx=p_type and deal_flag=1;
      end if;
      commit;
      v_out_success:=1;
      exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
 end;

 procedure updateReportStateNew(
       v_ids            in varchar2,
       p_type           in number,
       --出参
       v_out_success    out number
        ) as
   v_count number := 0;
   v_reportType number := 0;
   v_cursor sys_refcursor;
   v_id number;
 begin
      --经营者新增上报
      select count(1) into v_count from idc_isms_base_idc where jyzid in v_ids and czlx=p_type and deal_flag=2;
      --更新经营者下的全部子节点
      if (v_count > 0) then
         select report_type into v_reportType from idc_isms_base_idc t where jyzid in v_ids and czlx=p_type and deal_flag=2;
         if (v_reportType = 1) then
             update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids and czlx=p_type and deal_flag=2;
         else
             update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids and czlx=p_type and deal_flag=2;
             update IDC_ISMS_BASE_HOUSE set czlx=2,deal_flag = 4 where del_flag = 0;
             update IDC_ISMS_BASE_HOUSE_GATEWAY set czlx=2,deal_flag = 4 where del_flag = 0;
             update IDC_ISMS_BASE_HOUSE_IPSEG set czlx=2,deal_flag = 4 where del_flag = 0 and ipsegid in (select v.ipsegid from idc_isms_base_house_ipseg_view v where v.czlx = p_type);
             update IDC_ISMS_BASE_HOUSE_FRAME set czlx=2,deal_flag = 4 where del_flag = 0;
             update IDC_ISMS_BASE_USER set czlx=2,deal_flag = 4 where del_flag = 0;
             update IDC_ISMS_BASE_USER_SERVICE set czlx=2,deal_flag = 4 where del_flag = 0;
             update IDC_ISMS_BASE_SERVICE_DOMAIN set czlx=2,deal_flag = 4 where del_flag = 0;
             update IDC_ISMS_BASE_SERVICE_HH set czlx=2,deal_flag = 4 where del_flag = 0;
             update IDC_ISMS_BASE_SERVICE_IPTRANS set czlx=2,deal_flag = 4 where del_flag = 0;
             update IDC_ISMS_BASE_SERVICE_VIRTUAL set czlx=2,deal_flag = 4 where del_flag = 0;
             update IDC_ISMS_BASE_USER_HH set czlx=2,deal_flag = 4 where del_flag = 0;
             update IDC_ISMS_BASE_USER_HH_IPSEG set czlx=2,deal_flag = 4 where del_flag = 0;
         end if;
      end if;
      --机房新增上报
      select count(1) into v_count from idc_isms_base_house where jyzid in v_ids and czlx=p_type and deal_flag=2;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         open v_cursor for select houseid from idc_isms_base_house where jyzid in v_ids and czlx=p_type and deal_flag=2;
         loop
             fetch v_cursor into v_id;
             exit when v_cursor%notfound;
             update IDC_ISMS_BASE_HOUSE set czlx=2,deal_flag = 4 where jyzid in v_ids and houseid = v_id and czlx=p_type and deal_flag=2;
             update IDC_ISMS_BASE_HOUSE_GATEWAY set czlx=2,deal_flag = 4 where houseid = v_id;
             update IDC_ISMS_BASE_HOUSE_IPSEG set czlx=2,deal_flag = 4 where houseid = v_id and ipsegid in (select v.ipsegid from idc_isms_base_house_ipseg_view v where v.czlx = p_type);
             update IDC_ISMS_BASE_HOUSE_FRAME set czlx=2,deal_flag = 4 where houseid = v_id;
         end loop;
         close v_cursor;
      end if;
      --机房子节点新增上报
      select count(1) into v_count from idc_isms_base_house_gateway where /*czlx=p_type and */deal_flag=2;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids;
         update IDC_ISMS_BASE_HOUSE_GATEWAY set czlx=2,deal_flag = 4 where /*czlx=p_type and */deal_flag=2;
         open v_cursor for select houseid into v_id from idc_isms_base_house_gateway where /*czlx=p_type and */deal_flag=2;
         loop
             fetch v_cursor into v_id;
             exit when v_cursor%notfound;
             update IDC_ISMS_BASE_HOUSE set czlx=2,deal_flag = 4 where jyzid in v_ids and houseid = v_id;
         end loop;
         close v_cursor;
      end if;
      select count(1) into v_count from idc_isms_base_house_ipseg where /*czlx=p_type and*/ deal_flag=2;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids;
         update IDC_ISMS_BASE_HOUSE_IPSEG set czlx=2,deal_flag = 4 where /*czlx=p_type and */deal_flag=2;
         open v_cursor for select houseid into v_id from idc_isms_base_house_ipseg where /*czlx=p_type and*/ deal_flag=2;
         loop
             fetch v_cursor into v_id;
             exit when v_cursor%notfound;
             update IDC_ISMS_BASE_HOUSE set czlx=2,deal_flag = 4 where jyzid in v_ids and houseid = v_id;
         end loop;
         close v_cursor;
      end if;
      select count(1) into v_count from idc_isms_base_house_frame where /*czlx=p_type and*/ deal_flag=2;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids;
         update IDC_ISMS_BASE_HOUSE_FRAME set czlx=2,deal_flag = 4 where /*czlx=p_type and */deal_flag=2;
         open v_cursor for select houseid into v_id from idc_isms_base_house_frame where /*czlx=p_type and */deal_flag=2;
         loop
             fetch v_cursor into v_id;
             exit when v_cursor%notfound;
             update IDC_ISMS_BASE_HOUSE set czlx=2,deal_flag = 4 where jyzid in v_ids and houseid = v_id;
         end loop;
         close v_cursor;
      end if;
      --用户新增上报
      select count(1) into v_count from idc_isms_base_user where jyzid in v_ids and czlx=p_type and deal_flag=2;
      --更新用户下的全部子节点和经营者
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         open v_cursor for select userid into v_id from idc_isms_base_user where jyzid in v_ids and czlx=p_type and deal_flag=2;
         loop
             fetch v_cursor into v_id;
             exit when v_cursor%notfound;
             update IDC_ISMS_BASE_USER set czlx=2,deal_flag = 4 where jyzid in v_ids and userid = v_id and czlx=p_type and deal_flag=2;
             update IDC_ISMS_BASE_USER_SERVICE set czlx=2,deal_flag = 4 where userid = v_id;
             update IDC_ISMS_BASE_SERVICE_DOMAIN set czlx=2,deal_flag = 4 where userid = v_id;
             update IDC_ISMS_BASE_SERVICE_HH set czlx=2,deal_flag = 4 where userid = v_id;
             update IDC_ISMS_BASE_SERVICE_IPTRANS set czlx=2,deal_flag = 4 where userid = v_id;
             update IDC_ISMS_BASE_SERVICE_VIRTUAL set czlx=2,deal_flag = 4 where userid = v_id;
             update IDC_ISMS_BASE_USER_HH set czlx=2,deal_flag = 4 where userid = v_id;
             update IDC_ISMS_BASE_USER_HH_IPSEG set czlx=2,deal_flag = 4 where userid = v_id;
         end loop;
         close v_cursor;
      end if;
      --用户子节点新增上报
      select count(1) into v_count from idc_isms_base_user_service where /*czlx=p_type and */deal_flag=2;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_USER_SERVICE set czlx=2,deal_flag = 4 where /*czlx=p_type and */deal_flag=2;
         open v_cursor for select userid into v_id from idc_isms_base_user_service where /*czlx=p_type and */deal_flag=2;
         loop
             fetch v_cursor into v_id;
             exit when v_cursor%notfound;
             update IDC_ISMS_BASE_USER set czlx=2,deal_flag = 4 where jyzid in v_ids and userid = v_id;
             update IDC_ISMS_BASE_SERVICE_DOMAIN set czlx=2,deal_flag = 4 where userid = v_id;
             update IDC_ISMS_BASE_SERVICE_HH set czlx=2,deal_flag = 4 where userid = v_id;
             update IDC_ISMS_BASE_SERVICE_IPTRANS set czlx=2,deal_flag = 4 where userid = v_id;
             update IDC_ISMS_BASE_SERVICE_VIRTUAL set czlx=2,deal_flag = 4 where userid = v_id;
         end loop;
         close v_cursor;
      end if;
      select count(1) into v_count from idc_isms_base_user_hh where /*czlx=p_type and */deal_flag=2;
      if (v_count > 0) then
         update IDC_ISMS_BASE_IDC set czlx=2,deal_flag = 4 where jyzid in v_ids ;
         update IDC_ISMS_BASE_USER_HH set czlx=2,deal_flag = 4 where /*czlx=p_type and */deal_flag=2;
         open v_cursor for select userid into v_id from idc_isms_base_user_hh where /*czlx=p_type and */deal_flag=2;
         loop
             fetch v_cursor into v_id;
             exit when v_cursor%notfound;
             update IDC_ISMS_BASE_USER set czlx=2,deal_flag = 4 where jyzid in v_ids and userid = v_id;
             update IDC_ISMS_BASE_USER_HH_IPSEG set czlx=2,deal_flag = 4 where userid = v_id;
         end loop;
         close v_cursor;
      end if;
      commit;
      v_out_success:=1;
      exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
 end;


end idc_interface_upload;
/
