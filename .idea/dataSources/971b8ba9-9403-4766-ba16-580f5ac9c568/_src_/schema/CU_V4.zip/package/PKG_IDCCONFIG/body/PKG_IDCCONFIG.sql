CREATE PACKAGE BODY PKG_IDCCONFIG IS

  --获取访问日志管理策略
  FUNCTION GetAccessLog(p_cursor OUT C_CURSOR) RETURN INTEGER AS

  BEGIN

    OPEN p_cursor FOR
      select *
        from (select rownum rn, a.*
                from idc_isms_cfg_accesslog a
               where operatetype <> 3)
       where rn = 1;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

  --添加访问日志管理策略
  FUNCTION AddAccessLog(p_msgno   IN NUMBER,
                        p_logflag IN NUMBER,
                        p_operid  IN NUMBER,
                        p_seqno   OUT NUMBER,
                        p_id      OUT NUMBER) RETURN INTEGER AS
    v_msgnew VARCHAR2(5000);
  BEGIN

    p_seqno := PKG_DPICONFIG.MessageSequenceNo(15);

    SELECT SEQ_IDC_ISMS_CFG_ACCESSLOG.NEXTVAL INTO p_id FROM dual;

    insert into idc_isms_cfg_accesslog
      (COMMONID,
       MESSAGE_NO,
       ACCESSLOG_FLAG,
       OPERATETYPE,
       MESSAGE_SEQUENCENO,
       MODIFY_TIME)
    values
      (p_id, p_msgno, p_logflag, 1, p_seqno, sysdate);

    v_msgnew := getRow('idc_isms_cfg_accesslog', 'COMMONID', p_id); --添加日志
    dpi_setclog(20025, 1, p_msgno, p_seqno, p_operid);
    dpi_setuserlog(20025, 1, p_id, v_msgnew, '', p_operid);
    commit;
    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  --删除访问日志管理策略
  FUNCTION DeleteAccessLog(p_id     IN NUMBER,
                           p_msgno  IN NUMBER,
                           p_operid IN NUMBER,
                           p_seqno  OUT NUMBER) RETURN INTEGER AS
    v_msgnew VARCHAR2(5000);
    n_retcode    number(10);
  BEGIN

    p_seqno := PKG_DPICONFIG.MessageSequenceNo(11);

    v_msgnew := getRow('idc_isms_cfg_accesslog', 'COMMONID', p_id); --删除日志

    update idc_isms_cfg_accesslog
       set OPERATETYPE = 3, MESSAGE_SEQUENCENO = p_seqno
     where COMMONID = p_id;
    dpi_setclog(20025, 1, p_msgno, p_seqno, p_operid);
    dpi_setuserlog(20025, 3, p_id, '', v_msgnew, p_operid);

    UPDATE dpi_v1_cfg_messageno
       SET opertype = 3
     where message_no = p_msgno
       and message_type = 15;

  --删除绑定关系
       n_retcode := PKG_IDCCONFIG.deletePolicyHouseBinds(p_msgno,15,p_operid);
    commit;
    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  --修改访问日志管理策略
  FUNCTION UpdateAccessLog(p_commonid IN NUMBER,
                           p_msgno    IN NUMBER,
                           p_operid   IN NUMBER,
                           p_seqno    OUT NUMBER) RETURN INTEGER AS
    v_msgold VARCHAR2(5000);
    v_msgnew VARCHAR2(5000);
  BEGIN

    p_seqno := PKG_DPICONFIG.MessageSequenceNo(15);

    v_msgold := getRow('idc_isms_cfg_accesslog', 'commonid', p_commonid); --操作前日志

    update idc_isms_cfg_accesslog
       set operatetype = 2, message_sequenceno = p_seqno
     where commonid = p_commonid;

    v_msgnew := getRow('idc_isms_cfg_accesslog', 'commonid', p_commonid); --操作后日志

    dpi_setclog(20025, 1, p_msgno, p_seqno, p_operid);

    dpi_setuserlog(20025, 2, p_commonid, v_msgnew, v_msgold, p_operid);

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  --获取IDC规则类型
  FUNCTION GetRuleType(p_cursor OUT C_CURSOR) RETURN INTEGER AS

  BEGIN

    OPEN p_cursor FOR
      select * from IDC_JCDM_GZLX;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

  --
  FUNCTION GetISMS_IDCList(p_cursor OUT C_CURSOR) RETURN INTEGER AS

  BEGIN

    OPEN p_cursor FOR
      select * from IDC_ISMS_BASE_IDC;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

  --获取IDC规则类型 ISMS_BASE_HOUSE
  FUNCTION GetISMS_HouseList(p_cursor OUT C_CURSOR) RETURN INTEGER AS

  BEGIN

    OPEN p_cursor FOR
      select * from IDC_ISMS_BASE_HOUSE where houseidstr is not null;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

  --ISP信息安全策略
  FUNCTION GetIDCISMS_PolicyList(p_pageNo     IN NUMBER,
                                 p_pageSize   IN NUMBER,
                                 p_operstatus IN NUMBER,
                                 p_commandId  IN NUMBER,
                                 p_type       IN NUMBER,
                                 p_blockflag  IN NUMBER,
                                 p_logflag    IN NUMBER,
                                 p_content    IN VARCHAR2,
                                 p_createTimeS    IN VARCHAR2,
                                 p_createTimeE    IN VARCHAR2,
                                 p_policyType     IN VARCHAR2,
                                 p_sysIdentifier  IN VARCHAR2,
                                 p_outcount   OUT NUMBER,
                                 p_cursor     OUT C_CURSOR) RETURN INTEGER AS
    nBegin  INTEGER;
    nEnd    INTEGER;
    p_where VARCHAR2(1000);
    v_cursor sys_refcursor;
    v_commandId VARCHAR2(1000) := '';
    v_tempCommandId number;
  BEGIN

    nBegin  := (p_pageNo - 1) * p_pageSize + 1;
    nEnd    := p_pageNo * p_pageSize;
    p_where := ' WHERE 1=1';

    --管局smms指令不可见的处理
    /*open v_cursor for
    select policy.commandid from idc_isms_monitor_policy policy
    where policy.smms_cmdid in (
      select t.commandid from idc_isms_cmd_idc_manage t where t.operation_type = 0 and t.privilege_visible = 0
    );
    loop
      fetch v_cursor into v_tempCommandId;
      exit when v_cursor%notfound;
      if (length(v_commandId) > 0) then
         v_commandId := v_commandId || ',' || v_tempCommandId;
      else
         v_commandId := v_tempCommandId;
      end if;
    end loop;
    close v_cursor;*/
    if (length(v_commandId) > 0) then
       p_where := p_where || 'and t1.COMMANDID not in (' || v_commandId || ')';
    end if;
    if p_operstatus = -1 then
      p_where := p_where || ' and t1.operatetype<>3 ';
    ELSE
      p_where := p_where || ' and t1.operatetype=3 ';
    end if;
    if p_commandId > 0 then
       p_where := p_where || ' and t1.COMMANDID = ' || p_commandId;
    end if;
    if p_type <> -1 then
      p_where := p_where || ' and COMMAND_TYPE=' || p_type;
    end if;
    if p_blockflag <> -1 then
      p_where := p_where || ' and ACTION_BLOCK=' || p_blockflag;
    end if;
    if p_logflag <> -1 then
      p_where := p_where || ' and ACTION_LOG=' || p_logflag;
    end if;
    if p_createTimeS IS NOT NULL then
      p_where := p_where || ' and t1.create_time >= to_date('''||p_createTimeS||''',''yyyy-mm-dd hh24:mi:ss'')';
    end if;
    if p_createTimeE IS NOT NULL then
      p_where := p_where || ' and t1.create_time <= to_date('''||p_createTimeE||''',''yyyy-mm-dd hh24:mi:ss'')';
    end if;
    if p_content IS NOT NULL then
      p_where := p_where || ' and VALUESTART like ''%' || p_content ||
                 '%''';
    end if;
    if p_policyType =1 then
      p_where := p_where || ' and SMMS_CMDID is not null ' ;
    end if;
    if p_policyType =2 then
      --p_where := p_where || ' and SMMS_CMDID is null ';
      p_where := p_where || ' and SMMS_CMDID is null and monitor_type=0 ';
    end if;
    --begin added by kuangb 2018-03-08
    if p_policyType =3 then
      p_where := p_where || ' and SMMS_CMDID is null and monitor_type=3 ';
    end if;
    if p_policyType =4 then
      p_where := p_where || ' and SMMS_CMDID is null and monitor_type=4 ';
    end if;
    if p_policyType =4 and p_sysIdentifier is not null then
      p_where := p_where || ' and EXISTS(select * from  IDC_ISMS_3RD_COMMAND t4 where t1.message_no=t4.out_link_key and t4.sys_identifier=''' || p_sysIdentifier || ''')';
    end if;
    --end added by kuangb 2018-03-08
    dbms_output.put_line(p_where);
    EXECUTE IMMEDIATE 'select count(1) from (
            SELECT distinct t1.*,t2.message_name from IDC_ISMS_MONITOR_POLICY t1
                 left join dpi_v1_cfg_messageno t2 on t1.message_no=t2.message_no and message_type = 16
                 left join IDC_ISMS_MONITOR_POLICY_RULE t3 on t1.COMMANDID=t3.COMMANDID
                 ' || p_where || '
                )'
      INTO p_outcount;

    dbms_output.put_line(nBegin);
    dbms_output.put_line(nEnd);
    OPEN p_cursor FOR ' SELECT RN,COMMANDID,MESSAGE_NO,COMMAND_TYPE,ACTION_BLOCK,ACTION_REASON,ACTION_LOG,
                     EFFECTTIME,EXPIREDTIME,MONITOR_TYPE,OPERATETYPE,MESSAGE_SEQUENCENO,CREATE_TIME,CREATE_USERID,
                     message_name,SMMS_CMDID FROM  (
                 SELECT rownum as RN,COMMANDID,MESSAGE_NO,COMMAND_TYPE,ACTION_BLOCK,ACTION_REASON,ACTION_LOG,
                     time_t2date(EFFECTTIME)as EFFECTTIME,time_t2date(EXPIREDTIME)as EXPIREDTIME,MONITOR_TYPE,OPERATETYPE,MESSAGE_SEQUENCENO,CREATE_TIME,CREATE_USERID,
                     message_name,SMMS_CMDID FROM (
                 SELECT distinct t1.*,t2.message_name from IDC_ISMS_MONITOR_POLICY t1
                 left join dpi_v1_cfg_messageno t2 on t1.message_no=t2.message_no and message_type = 16
                 left join IDC_ISMS_MONITOR_POLICY_RULE t3 on t1.COMMANDID=t3.COMMANDID
                  ' || p_where || ' order by t1.COMMANDID desc
                ) a  where rownum <=' || nEnd || '
      ) WHERE RN  >=' || nBegin;

    RETURN SUCC_CODE;

    /*EXCEPTION
    WHEN OTHERS THEN
          RAISE;*/
  END;

  --
  FUNCTION GetIDCISMS_PolicyByID(p_id IN NUMBER, p_cursor OUT C_CURSOR)
    RETURN INTEGER AS

  BEGIN

    OPEN p_cursor FOR
      SELECT RULEID, SUBTYPE,  replace(replace(VALUESTART,CHR(10),'&'),chr(13),'') as VALUESTART, VALUEEND, KEYWORDRANGE
        FROM IDC_ISMS_MONITOR_POLICY_RULE
       WHERE COMMANDID = p_id;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN

      RAISE;
  END;

  --
  FUNCTION AddOrUpdateIDCISMS_Policy(p_id        IN NUMBER,
                                     p_msgno     IN NUMBER,
                                     p_type      IN NUMBER,
                                     p_blockflag IN NUMBER,
                                     p_logflag   IN NUMBER,
                                     p_starttime IN NUMBER,
                                     p_endtime   IN NUMBER,
                                     p_operid    IN NUMBER,
                                     p_userName  IN VARCHAR2,
                                     p_unbundFlag IN NUMBER,
                                     p_policyLevel IN NUMBER,
                                     out_newid   OUT NUMBER) RETURN INTEGER AS
    v_msgold VARCHAR2(5000);
    v_msgnew VARCHAR2(5000);
    v_seqno  number(10);
    v_policyState number(10);
  BEGIN
    if p_unbundFlag = 1 then
       v_policyState := 2;
    else
       v_policyState := 0;
    end if;

    if p_id = 0 then
      --添加
      select seq_idc_isms_monitorpolicy_id.nextval
        into out_newid
        from dual;
        if p_unbundFlag = 1 then
           v_seqno := -1;
        else
           v_seqno := PKG_DPICONFIG.MessageSequenceNo(16);
        end if;

      insert into IDC_ISMS_MONITOR_POLICY
        (COMMANDID,
         MESSAGE_NO,
         COMMAND_TYPE,
         ACTION_BLOCK,
         ACTION_LOG,
         EFFECTTIME,
         EXPIREDTIME,
         OPERATETYPE,
         MESSAGE_SEQUENCENO,
         CREATE_TIME,
         CREATE_USERID,
         CREATE_USERNAME,
         POLICY_LEVEL,
         POLICY_STATE
         )
      values
        (out_newid,
         p_msgno,
         p_type,
         p_blockflag,
         p_logflag,
         p_starttime,
         p_endtime,
         1,
         v_seqno,
         sysdate,
         p_operid,
         p_userName,
         p_policyLevel,
         v_policyState
         );

      v_msgnew := getRow('IDC_ISMS_MONITOR_POLICY', 'COMMANDID', out_newid); --添加日志
      if p_unbundFlag = 0 then
         dpi_setclog(20026, 1, p_msgno, v_seqno, p_operid);
      end if;
      dpi_setuserlog(20026, 1, out_newid, v_msgnew, '', p_operid);

    ELSE
      out_newid := p_id;
      v_msgold  := getRow('IDC_ISMS_MONITOR_POLICY', 'COMMANDID', p_id);
      v_seqno   := PKG_DPICONFIG.MessageSequenceNo(16);

      update IDC_ISMS_MONITOR_POLICY
         set COMMAND_TYPE       = p_type,
             ACTION_BLOCK       = p_blockflag,
             ACTION_LOG         = p_logflag,
             EFFECTTIME         = p_starttime,
             EXPIREDTIME        = p_endtime,
             OPERATETYPE        = 2,
             MESSAGE_SEQUENCENO = v_seqno,
             POLICY_STATE       = v_policyState,
             POLICY_LEVEL       = p_policyLevel
       where COMMANDID = p_id;

      v_msgnew := getRow('IDC_ISMS_MONITOR_POLICY', 'COMMANDID', p_id);
      if p_unbundFlag = 0 then
         dpi_setclog(20026, 2, p_msgno, v_seqno, p_operid);
      end if;
      dpi_setuserlog(20026, 2, p_id, v_msgnew, v_msgold, p_operid);

    end if;

    commit;
    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  FUNCTION AddIspPolicyRuleNotCommit(p_id           IN NUMBER,
                                     p_ruleid       IN NUMBER,
                                     p_subtype      IN NUMBER,
                                     p_valuestart   IN VARCHAR2,
                                     p_valueend     IN VARCHAR2,
                                     p_keywordrange IN VARCHAR2,
                                     p_operid       IN NUMBER) RETURN INTEGER AS
    nCnt         NUMBER;
    v_id         NUMBER;
    v_msgold     VARCHAR2(5000);
    nLength      number(10) := 0;
    vWhereLength varchar2(2000) := '';
    v_valueCur     sys_refcursor;
    v_valuestart VARCHAR2(256);
  BEGIN

    vWhereLength := ' COMMANDID=' || p_id || ' and SUBTYPE=' || p_subtype ||
                    ' and VALUESTART=''' || p_valuestart ||
                    ''' and VALUEEND=''' || p_valueend || '''';
    EXECUTE IMMEDIATE 'select count(1) from IDC_ISMS_MONITOR_POLICY_RULE where ' || vWhereLength INTO nLength;

    if nLength = 0 then
      open v_valueCur for select * from TABLE(split_str(p_valuestart,'AND'));
       loop
           fetch v_valueCur into v_valuestart;
           exit when v_valueCur%notfound;
           SELECT seq_idc_isms_policyrule_id.NEXTVAL INTO v_id FROM dual;
           insert into IDC_ISMS_MONITOR_POLICY_RULE
            (RULEID, COMMANDID, SUBTYPE, VALUESTART, VALUEEND, KEYWORDRANGE)
           values
            (v_id, p_id, p_subtype, v_valuestart, p_valueend, p_keywordrange);
       end loop;
       close v_valueCur;

    end if;
    RETURN SUCC_CODE;
  END;

  --添加或者修改或者删除列表
  FUNCTION AddUpdateIDCISP_PolicyRule(p_tag          IN NUMBER, --id=1为添加操作 2修改 3 删除
                                      p_id           IN NUMBER,
                                      p_ruleid       IN NUMBER,
                                      p_subtype      IN NUMBER,
                                      p_valuestart   IN VARCHAR2,
                                      p_valueend     IN VARCHAR2,
                                      p_keywordrange IN VARCHAR2,
                                      p_operid       IN NUMBER)
    RETURN INTEGER AS
    nCnt         NUMBER;
    v_id         NUMBER;
    v_msgnew     VARCHAR2(5000);
    v_msgold     VARCHAR2(5000);
    nLength      number(10) := 0;
    vWhereLength varchar2(2000) := '';
  BEGIN

    v_msgnew := 'COMMANDID:' || p_id || ',SUBTYPE:' || p_subtype ||
                ',VALUESTART:' || p_valuestart || ',VALUEEND:' ||
                p_valueend || ',KEYWORDRANGE:' || p_keywordrange;

    if p_tag = 1 then
      --添加
      vWhereLength := ' COMMANDID=' || p_id || ' and SUBTYPE=' || p_subtype ||
                      ' and VALUESTART=''' || p_valuestart || '''';
      if p_valueend is null then
        vWhereLength := vWhereLength || ' and VALUEEND is null';
      else
        vWhereLength := vWhereLength || ' and VALUEEND=''' || p_valueend || '''';
      end if;
      if p_keywordrange is null then
        vWhereLength := vWhereLength || ' and KEYWORDRANGE is null';
      else
        vWhereLength := vWhereLength ||
                        ' and KEYWORDRANGE=''||p_keywordrange||''';
      end if;

      EXECUTE IMMEDIATE 'select count(1) from IDC_ISMS_MONITOR_POLICY_RULE
         where ' || vWhereLength
        INTO nLength;

      if nLength = 0 then
        SELECT seq_idc_isms_policyrule_id.NEXTVAL INTO v_id FROM dual;
        insert into IDC_ISMS_MONITOR_POLICY_RULE
          (RULEID, COMMANDID, SUBTYPE, VALUESTART, VALUEEND, KEYWORDRANGE)
        values
          (v_id, p_id, p_subtype, p_valuestart, p_valueend, p_keywordrange);
        --dpi_setuserlog(20026,1,v_id,v_msgnew,'',p_operid);
      end if;

    elsif p_tag = 2 then
      --修改
      select count(1)
        into nCnt
        from IDC_ISMS_MONITOR_POLICY_RULE
       where COMMANDID = p_id
         and RULEID = p_ruleid;

      if nCnt = 0 then

        --v_msgold:=getRow('IDC_ISMS_MONITOR_POLICY_RULE','RULEID',p_id);--操作前日志

        update IDC_ISMS_MONITOR_POLICY_RULE
           set SUBTYPE      = p_subtype,
               VALUESTART   = p_valuestart,
               VALUEEND     = p_valueend,
               KEYWORDRANGE = p_keywordrange
         where RULEID = p_ruleid;

        --dpi_setuserlog(20026,2,p_ruleid,v_msgnew,v_msgold,p_operid);

      end if;
    else

      --v_msgold:=getRow('IDC_ISMS_MONITOR_POLICY_RULE','COMMANDID',p_id);--操作前日志
      delete IDC_ISMS_MONITOR_POLICY_RULE where COMMANDID = p_id;
      --dpi_setuserlog(20026,3,p_id,'',v_msgold,p_operid);

    end if;
    commit;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  --
  FUNCTION DeleteIDCISMS_Policy(p_id     IN NUMBER,
                                p_msgno  IN NUMBER,
                                p_operid IN NUMBER) RETURN INTEGER AS
    v_seqno      number(10);
    v_msgold     VARCHAR2(5000);
    c_bindCur    sys_refcursor;
    n_bindid     number(10);
    n_message_no number(10);
    n_retcode    number(10);
  BEGIN
    v_msgold := getRow('IDC_ISMS_MONITOR_POLICY', 'COMMANDID', p_id); --操作前日志
    v_seqno  := PKG_DPICONFIG.MessageSequenceNo(16);

    UPDATE IDC_ISMS_MONITOR_POLICY
       SET operatetype = 3, message_sequenceno = v_seqno
     WHERE COMMANDID = p_id;
    --delete IDC_ISMS_MONITOR_POLICY_RULE where COMMANDID=p_id;

    dpi_setclog(20026, 3, p_msgno, v_seqno, p_operid);
    dpi_setuserlog(20026, 3, p_id, '', v_msgold, p_operid);

    --delete dpi_v1_cfg_messageno where message_no=p_msgno and message_type=16;
    UPDATE dpi_v1_cfg_messageno
       SET opertype = 3
     WHERE message_no = p_msgno
       and message_type = 16;
       --删除绑定关系
       n_retcode := PKG_IDCCONFIG.deletePolicyHouseBinds(p_msgno,16,p_operid);
    commit;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  FUNCTION BatchDeleteIDCISMS_Policy(p_id     IN VARCHAR2,
                                p_msgno  IN VARCHAR2
                                )RETURN INTEGER AS
    v_command      varchar2(2000);
    v_message      varchar2(2000);
  BEGIN
    v_command := 'DELETE FROM IDC_ISMS_MONITOR_POLICY WHERE COMMANDID in (' || p_id || ') and message_no in ('|| p_msgno|| ')';
    execute immediate v_command;
    v_message :=  'DELETE FROM dpi_v1_cfg_messageno where message_no in ('||p_msgno||') and message_type = 16';
    execute immediate v_message;
    commit;
    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  ---分页获取 ISMS流量结果上报策略
  FUNCTION GetFlowUpload(p_pageNo     IN NUMBER,
                         p_pageSize   IN NUMBER,
                         p_operstatus IN NUMBER,
                         p_type       IN NUMBER,
                         p_subtype    IN NUMBER,
                         p_method     IN NUMBER,
                         p_outcount   OUT NUMBER,
                         p_cursor     OUT C_CURSOR) RETURN INTEGER AS
    nBegin  NUMBER;
    nEnd    NUMBER;
    p_where VARCHAR2(1000);
  BEGIN

    nBegin := (p_pageNo - 1) * p_pageSize + 1;
    nEnd   := p_pageNo * p_pageSize;

    p_where := ' WHERE ';

    if p_operstatus = -1 then
      p_where := p_where || ' OPERATETYPE<>3 ';
    ELSE
      p_where := p_where || ' OPERATETYPE=3 ';
    end if;
    IF p_type <> -1 THEN
      p_where := p_where || ' and PACKET_TYPE= ' || p_type;
    END IF;

    IF p_subtype <> -1 THEN
      p_where := p_where || ' and PACKET_SUBTYPE= ' || p_subtype;
    END IF;

    IF p_method <> -1 THEN
      p_where := p_where || ' and R_METHOD= ' || p_method;
    END IF;

    EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM  (select  distinct(a.seq_id) from IDC_ISMS_CFG_FLOWUPLOAD  a  join dpi_v1_cfg_messageno b on a.MESSAGE_NO=b.MESSAGE_NO ' ||
                      p_where || ' and b.MESSAGE_TYPE = 11)'
      INTO p_outcount;

    OPEN p_cursor FOR 'SELECT *  FROM (
                    select  rownum as RN,c.*  from (select distinct a.*,b.MESSAGE_NAME from IDC_ISMS_CFG_FLOWUPLOAD a join dpi_v1_cfg_messageno b on a.MESSAGE_NO=b.MESSAGE_NO
                    ' || p_where || ' and b.MESSAGE_TYPE = 11 order by CREATE_TIME desc) c
                  )  where RN <=  ' || nEnd || 'and RN  >=' || nBegin;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

FUNCTION GetFlowUploadTwo(p_pageNo     IN NUMBER,
                         p_pageSize   IN NUMBER,
                         p_houseName  IN VARCHAR2,
                         p_operstatus IN NUMBER,
                         p_type       IN NUMBER,
                         p_subtype    IN NUMBER,
                         p_method     IN NUMBER,
                         p_outcount   OUT NUMBER,
                         p_cursor     OUT C_CURSOR) RETURN INTEGER AS
    nBegin  NUMBER;
    nEnd    NUMBER;
    p_where VARCHAR2(1000);
    p_whereOne VARCHAR2(500);
  BEGIN

    nBegin := (p_pageNo - 1) * p_pageSize + 1;
    nEnd   := p_pageNo * p_pageSize;

    p_where := ' WHERE ';
    p_whereOne :=' WHERE 1=1 ';
    if(p_houseName is not null)then
       p_whereOne := p_whereOne || ' and a.house_id in(select houseidstr from IDC_ISMS_BASE_HOUSE where housename= ''' || p_houseName || ''')';
    end if;
    if p_operstatus = -1 then
      p_where := p_where || ' OPERATETYPE<>3 ';
    ELSE
      p_where := p_where || ' OPERATETYPE=3 ';
    end if;
    IF p_type <> -1 THEN
      p_where := p_where || ' and PACKET_TYPE= ' || p_type;
    END IF;

    IF p_subtype <> -1 THEN
      p_where := p_where || ' and PACKET_SUBTYPE= ' || p_subtype;
    END IF;

    IF p_method <> -1 THEN
      p_where := p_where || ' and R_METHOD= ' || p_method;
    END IF;

    dbms_output.put_line(p_whereOne);

    EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM  (select
    a.*,
    to_char(wm_concat(b.r_destip||'/'||b.r_destport||'/'||b.r_servername)) as IP_PORT_NAME
  from
  (select d.*
        from
        (select
             a.*,b.MESSAGE_NAME
         from IDC_ISMS_CFG_FLOWUPLOAD a inner join dpi_v1_cfg_messageno b on a.MESSAGE_NO=b.MESSAGE_NO
             and b.MESSAGE_TYPE=11 ' ||
          p_where ||
           'group by a.seq_id,a.message_no,a.packet_type,a.packet_subtype,a.r_method,a.operatetype,a.message_sequenceno,a.create_time,b.message_name
           order by a.seq_id)d inner join
         (select
           a.house_id,
           a.bindmessageno,
           b.MESSAGE_NAME
         from IDC_ISMS_CFG_HOUSEPOLICYBIND a inner join dpi_v1_cfg_messageno b on a.BINDMESSAGENO=b.MESSAGE_NO
           and b.MESSAGE_TYPE=133 ' || p_whereOne ||
         'group by a.house_id,a.bindmessageno,b.message_name)e on d.message_no=e.bindmessageno
  )a left join IDC_ISMS_CFG_FLOWUPLOAD_SERVER b on a.seq_id=b.seq_id
            group by a.seq_id,a.message_no, a.packet_type,a.packet_subtype,a.r_method,
                     a.operatetype,a.message_sequenceno, a.create_time,a.message_name)'
      INTO p_outcount;

    OPEN p_cursor FOR 'SELECT *  FROM (
                    select  rownum as RN,c.*  from (select
    a.*,
    to_char(wm_concat(b.r_destip||'/'||b.r_destport||'/'||b.r_servername)) as IP_PORT_NAME
  from
  (select d.*
        from
        (select
             a.*,b.MESSAGE_NAME
         from IDC_ISMS_CFG_FLOWUPLOAD a inner join dpi_v1_cfg_messageno b on a.MESSAGE_NO=b.MESSAGE_NO
             and b.MESSAGE_TYPE=11 ' ||
          p_where ||
           'group by a.seq_id,a.message_no,a.packet_type,a.packet_subtype,a.r_method,a.operatetype,a.message_sequenceno,a.create_time,b.message_name
           order by a.seq_id)d inner join
         (select
           a.house_id,a.bindmessageno,b.MESSAGE_NAME
         from IDC_ISMS_CFG_HOUSEPOLICYBIND a inner join dpi_v1_cfg_messageno b on a.BINDMESSAGENO=b.MESSAGE_NO
           and b.MESSAGE_TYPE=133 ' ||  p_whereOne ||
         'group by a.house_id,a.bindmessageno,b.message_name)e on d.message_no=e.bindmessageno
  )a left join IDC_ISMS_CFG_FLOWUPLOAD_SERVER b on a.seq_id=b.seq_id
        group by a.seq_id,a.message_no, a.packet_type,a.packet_subtype,a.r_method,
                     a.operatetype,a.message_sequenceno, a.create_time,a.message_name) c
                   where rownum <=  ' || nEnd || ') d where d.RN  >=' || nBegin;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;
 ---分页获取 ISMS流量结果上报策略1
  FUNCTION GetFlowUploadOne(p_pageNo     IN NUMBER,
                         p_pageSize   IN NUMBER,
                         p_houseName  IN VARCHAR2,
                         p_operstatus IN NUMBER,
                         p_type       IN NUMBER,
                         p_subtype    IN NUMBER,
                         p_method     IN NUMBER,
                         p_outcount   OUT NUMBER,
                         p_cursor     OUT C_CURSOR) RETURN INTEGER AS
    nBegin  NUMBER;
    nEnd    NUMBER;
    p_where VARCHAR2(1000);
    p_whereOne VARCHAR2(500);
  BEGIN

    nBegin := (p_pageNo - 1) * p_pageSize + 1;
    nEnd   := p_pageNo * p_pageSize;

    p_where := ' WHERE ';
    p_whereOne :=' WHERE 1=1 ';
    if(p_houseName is not null)then
       p_whereOne := p_whereOne || ' and a.house_id in(select houseidstr from IDC_ISMS_BASE_HOUSE where housename= ''' || p_houseName || ''')';
    end if;
    if p_operstatus = -1 then
      p_where := p_where || ' OPERATETYPE<>3 ';
    ELSE
      p_where := p_where || ' OPERATETYPE=3 ';
    end if;
    IF p_type <> -1 THEN
      p_where := p_where || ' and PACKET_TYPE= ' || p_type;
    END IF;

    IF p_subtype <> -1 THEN
      p_where := p_where || ' and PACKET_SUBTYPE= ' || p_subtype;
    END IF;

    IF p_method <> -1 THEN
      p_where := p_where || ' and R_METHOD= ' || p_method;
    END IF;

    dbms_output.put_line(p_whereOne);

    EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM  (select
    a.*,
    b.r_destip,
    b.r_destport,
    b.r_servername
  from
  (select d.*,e.bindsuc,e.bindfai
        from
        (select
             a.*,
             b.MESSAGE_NAME,
             count(decode(c.status,0,1,null)) policysuc,
             count(decode(c.status,1,1,null)) policyfai
         from IDC_ISMS_CFG_FLOWUPLOAD a inner join dpi_v1_cfg_messageno b on a.MESSAGE_NO=b.MESSAGE_NO
             and b.MESSAGE_TYPE=11 inner join DPI_V1_POLICY_STATUS c on a.message_no=c.message_no and c.message_type=11' ||
          p_where ||
           'group by a.seq_id,a.message_no,a.packet_type,a.packet_subtype,a.r_method,a.operatetype,a.message_sequenceno,a.create_time,b.message_name
           order by a.seq_id)d inner join
         (select
           a.house_id,
           a.bindmessageno,
           b.MESSAGE_NAME,
           count(decode(c.status,0,1,null)) bindsuc,
           count(decode(c.status,1,1,null)) bindfai
         from IDC_ISMS_CFG_HOUSEPOLICYBIND a inner join dpi_v1_cfg_messageno b on a.BINDMESSAGENO=b.MESSAGE_NO
           and b.MESSAGE_TYPE=133 inner join DPI_V1_POLICY_STATUS c on a.message_no=c.message_no and
           c.message_type=133' || p_whereOne ||
         'group by a.house_id,a.bindmessageno,b.message_name)e on d.message_no=e.bindmessageno
  )a left join IDC_ISMS_CFG_FLOWUPLOAD_SERVER b on a.seq_id=b.seq_id)'
      INTO p_outcount;

    OPEN p_cursor FOR 'SELECT *  FROM (
                    select  rownum as RN,c.*  from (select
    a.*,
    b.r_destip,
    b.r_destport,
    b.r_servername
  from
  (select d.*,e.bindsuc,e.bindfai
        from
        (select
             a.*,
             b.MESSAGE_NAME,
             count(decode(c.status,0,1,null)) policysuc,
             count(decode(c.status,1,1,null)) policyfai
         from IDC_ISMS_CFG_FLOWUPLOAD a inner join dpi_v1_cfg_messageno b on a.MESSAGE_NO=b.MESSAGE_NO
             and b.MESSAGE_TYPE=11 inner join DPI_V1_POLICY_STATUS c on a.message_no=c.message_no and c.message_type=11' ||
          p_where ||
           'group by a.seq_id,a.message_no,a.packet_type,a.packet_subtype,a.r_method,a.operatetype,a.message_sequenceno,a.create_time,b.message_name
           order by a.seq_id)d inner join
         (select
           a.house_id,
           a.bindmessageno,
           b.MESSAGE_NAME,
           count(decode(c.status,0,1,null)) bindsuc,
           count(decode(c.status,1,1,null)) bindfai
         from IDC_ISMS_CFG_HOUSEPOLICYBIND a inner join dpi_v1_cfg_messageno b on a.BINDMESSAGENO=b.MESSAGE_NO
           and b.MESSAGE_TYPE=133 inner join DPI_V1_POLICY_STATUS c on a.message_no=c.message_no and
           c.message_type=133' ||  p_whereOne ||
         'group by a.house_id,a.bindmessageno,b.message_name)e on d.message_no=e.bindmessageno
  )a left join IDC_ISMS_CFG_FLOWUPLOAD_SERVER b on a.seq_id=b.seq_id) c
                   where rownum <=  ' || nEnd || ') d where d.RN  >=' || nBegin;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

  ---查询 ISMS流量结果上报策略 服务器
  FUNCTION GetFlowUploadServer(p_id       IN NUMBER,
                               p_outcount OUT NUMBER,
                               p_cursor   OUT C_CURSOR) RETURN INTEGER AS
  BEGIN

    EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM  IDC_ISMS_CFG_FLOWUPLOAD_SERVER  where SEQ_ID= ' || p_id
      INTO p_outcount;

    OPEN p_cursor FOR 'SELECT * FROM  IDC_ISMS_CFG_FLOWUPLOAD_SERVER  where SEQ_ID= ' || p_id;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

  --添加 ISMS流量结果上报策略
  FUNCTION AddFlowUpload(p_msgno   IN NUMBER,
                         p_type    IN NUMBER,
                         p_subtype IN NUMBER,
                         p_method  IN NUMBER,
                         p_operid  IN NUMBER,
                         p_seqno   OUT NUMBER,
                         p_id      OUT NUMBER) RETURN INTEGER AS
    v_msgnew VARCHAR2(5000);
  BEGIN

    p_seqno := PKG_DPICONFIG.MessageSequenceNo(11);

    SELECT SEQ_IDC_ISMS_CFG_FLOWUPLOADID.NEXTVAL INTO p_id FROM dual;

    insert into IDC_ISMS_CFG_FLOWUPLOAD
      (SEQ_ID,
       MESSAGE_NO,
       PACKET_TYPE,
       PACKET_SUBTYPE,
       R_METHOD,
       OPERATETYPE,
       MESSAGE_SEQUENCENO,
       CREATE_TIME)
    values
      (p_id, p_msgno, p_type, p_subtype, p_method, 1, p_seqno, sysdate);

    v_msgnew := getRow('IDC_ISMS_CFG_FLOWUPLOAD', 'SEQ_ID', p_id); --添加日志

    dpi_setuserlog(20028, 1, p_id, v_msgnew, '', p_operid);

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  --添加 ISMS流量结果上报策略 服务器
  FUNCTION AddFlowUploadServer(p_id   IN NUMBER,
                               p_ip   IN VARCHAR2,
                               p_port IN NUMBER,
                               p_name IN VARCHAR2,
                               p_pwd  IN VARCHAR2) RETURN INTEGER AS
    nLength number(10) := 0;
  BEGIN
    select count(1)
      into nLength
      from IDC_ISMS_CFG_FLOWUPLOAD_SERVER
     where SEQ_ID = p_id
       and R_DESTIP = p_ip
       and R_DESTPORT = p_port;

    if nLength = 0 then
      insert into IDC_ISMS_CFG_FLOWUPLOAD_SERVER
        (SEQ_ID, R_DESTIP, R_DESTPORT, R_SERVERNAME, R_SERVERPWD)
      values
        (p_id, p_ip, p_port, p_name, p_pwd);
    end if;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  --修改 ISMS流量结果上报策略
  FUNCTION UpdateFlowUpload(p_id      IN NUMBER,
                            p_msgno   IN NUMBER,
                            p_type    IN NUMBER,
                            p_subtype IN NUMBER,
                            p_method  IN NUMBER,
                            p_operid  IN NUMBER,
                            p_seqno   OUT NUMBER) RETURN INTEGER AS
    v_msgnew VARCHAR2(5000);
  BEGIN

    p_seqno := PKG_DPICONFIG.MessageSequenceNo(11);

    update IDC_ISMS_CFG_FLOWUPLOAD
       set PACKET_TYPE        = p_type,
           PACKET_SUBTYPE     = p_subtype,
           R_METHOD           = p_method,
           OPERATETYPE        = 2,
           MESSAGE_SEQUENCENO = p_seqno
     where SEQ_ID = p_id;

    delete IDC_ISMS_CFG_FLOWUPLOAD_SERVER where SEQ_ID = p_id;

    v_msgnew := getRow('IDC_ISMS_CFG_FLOWUPLOAD', 'SEQ_ID', p_id); --修改日志

    dpi_setuserlog(20028, 2, p_id, v_msgnew, '', p_operid);
    commit;
    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  --删除 ISMS流量结果上报策略
  FUNCTION DeleteFlowUpload(p_id     IN NUMBER,
                            p_msgno  IN NUMBER,
                            p_operid IN NUMBER,
                            p_seqno  OUT NUMBER) RETURN INTEGER AS
    v_msgnew VARCHAR2(5000);
    n_retcode    number(10);
  BEGIN

    p_seqno := PKG_DPICONFIG.MessageSequenceNo(11);

    v_msgnew := getRow('IDC_ISMS_CFG_FLOWUPLOAD', 'SEQ_ID', p_id); --删除日志

    update IDC_ISMS_CFG_FLOWUPLOAD
       set OPERATETYPE = 3, MESSAGE_SEQUENCENO = p_seqno
     where SEQ_ID = p_id;

    --delete IDC_ISMS_CFG_FLOWUPLOAD_SERVER where SEQ_ID=p_id;

    dpi_setuserlog(20028, 3, p_id, '', v_msgnew, p_operid);

    --delete dpi_v1_cfg_messageno where message_no=p_msgno and message_type=11;
    UPDATE dpi_v1_cfg_messageno
       SET opertype = 3
     where message_no = p_msgno
       and message_type = 11;

   --删除绑定关系
       n_retcode := PKG_IDCCONFIG.deletePolicyHouseBinds(p_msgno,11,p_operid);

    commit;
    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  ---分页获取 IDC机房与IP地址段对应信息下发
  FUNCTION GetHouseIpList(p_pageNo     IN NUMBER,
                          p_pageSize   IN NUMBER,
                          p_operstatus IN NUMBER,
                          p_houseid    IN varchar2,
                          p_outcount   OUT NUMBER,
                          p_cursor     OUT C_CURSOR,
                          p_userHouseIDStrs in varchar2) RETURN INTEGER AS
    nBegin  NUMBER;
    nEnd    NUMBER;
    p_where VARCHAR2(1000);
  BEGIN

    nBegin := (p_pageNo - 1) * p_pageSize + 1;
    nEnd   := p_pageNo * p_pageSize;

    p_where := ' WHERE ';

    if p_operstatus = -1 then
      p_where := p_where || ' a.operatetype<>3 ';
    ELSE
      p_where := p_where || ' a.operatetype=3 ';
    end if;
    IF p_houseid <> '-1' THEN
      p_where := p_where || ' and a.house_id= ''' || p_houseid || ''' ';
    END IF;

     p_where := p_where || 'and c.DEL_FLAG = 0 ';


      EXECUTE IMMEDIATE 'select count(*) from idc_isms_cfg_houseip_ip a
                         inner join idc_isms_cfg_houseip b on a.house_id=b.house_id
                         inner join (select * from idc_isms_base_house temp where temp.del_flag = 0
                         and temp.houseid in ('||p_userHouseIDStrs||') ) c  on a.house_id=c.houseidstr' ||
                         p_where

      INTO p_outcount;


    OPEN p_cursor FOR 'SELECT *  FROM ( select rownum as rn,t.* from
                   (select a.*,b.message_no,c.housename from idc_isms_cfg_houseip_ip a
                   inner join idc_isms_cfg_houseip b on a.house_id=b.house_id
                   inner join (select * from idc_isms_base_house temp where temp.del_flag = 0
                   and temp.houseid in ('||p_userHouseIDStrs||') ) c  on a.house_id=c.houseidstr
                    ' || p_where || ' order by a.house_id desc
                  )t  where rownum <=  ' || nEnd ||') where rn  >=' || nBegin;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

  ---查询 IDC机房与IP地址段对应信息下发 houseid是否存在
  FUNCTION GetHouseIp(p_houseid IN varchar2, p_cursor OUT C_CURSOR)
    RETURN INTEGER AS
  BEGIN

    OPEN p_cursor FOR
      select * from idc_isms_cfg_houseip where house_id = p_houseid;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

  --添加  IDC机房与IP地址段对应信息下发
  FUNCTION AddHouseIp(p_msgno   IN NUMBER,
                      p_seqno   IN NUMBER,
                      p_houseid IN varchar2,
                      p_operid  IN NUMBER) RETURN INTEGER AS
    v_msgnew VARCHAR2(5000);
  BEGIN

    insert into idc_isms_cfg_houseip
      (HOUSE_ID, MESSAGE_NO, OPERATETYPE, MESSAGE_SEQUENCENO, CREATE_TIME)
    values
      (p_houseid, p_msgno, 1, p_seqno, sysdate);

    --v_msgnew:=getRow('idc_isms_cfg_houseip','house_id',p_houseid);--添加日志

    --dpi_setuserlog(20029,1,p_houseid,v_msgnew,'',p_operid);

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  --修改  IDC机房与IP地址段对应信息下发
  FUNCTION UpadateHouseIp(p_seqno   IN NUMBER,
                          p_houseid IN varchar2,
                          p_operid  IN NUMBER) RETURN INTEGER AS
    v_msgnew VARCHAR2(5000);
  BEGIN

    update idc_isms_cfg_houseip
       set MESSAGE_SEQUENCENO = p_seqno, OPERATETYPE = 2
     where HOUSE_ID = p_houseid;

    --v_msgnew:=getRow('idc_isms_cfg_houseip','house_id',p_houseid);--添加日志

    --dpi_setuserlog(20029,2,p_houseid,v_msgnew,'',p_operid);

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  --添加 IDC机房与IP地址段对应信息下发 IP
  FUNCTION AddHouseIp_Ip(p_seqno   IN NUMBER,
                         p_houseid IN varchar2,
                         p_userip  IN VARCHAR2,
                         p_prefic  IN NUMBER,
                         p_operid  IN NUMBER) RETURN INTEGER AS
    v_msgnew VARCHAR2(5000);
    v_id     NUMBER;
    nLength  number(10) := 0;
    v_ipstart VARCHAR2(5000);
  BEGIN
    select count(1)
      into nLength
      from idc_isms_cfg_houseip_ip
     where MESSAGE_SEQUENCENO = p_seqno
       and USERIP = p_userip
       and USERIP_PREFIX = p_prefic;

    if nLength = 0 then
      SELECT SEQ_IDC_ISMS_CFG_HOUSE_IP_ID.NEXTVAL INTO v_id FROM dual;

      insert into idc_isms_cfg_houseip_ip
        (SEQ_ID,
         HOUSE_ID,
         USERIP,
         USERIP_PREFIX,
         OPERATETYPE,
         MESSAGE_SEQUENCENO,
         CREATE_TIME)
      values
        (v_id, p_houseid, p_userip, p_prefic, 1, p_seqno, sysdate);

      --将一个网段的ip地址添加的地址库表，用于活跃资源的数据过滤
      v_ipstart := substr(p_userip, 0, INSTR(p_userip, '.', -1));
      insert into idc_isms_base_ip_info
        (id, startip, endip, iptype, houseidstr)
      values
        (v_id, ip2int(v_ipstart || 0), ip2int(v_ipstart || 255), 0, p_houseid);

      v_msgnew := getRow('idc_isms_cfg_houseip_ip', 'SEQ_ID', v_id); --添加日志

      dpi_setuserlog(20029, 1, v_id, v_msgnew, '', p_operid);
    end if;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  --删除 IDC机房与IP地址段对应信息下发 IP
  FUNCTION DeleteHouseIp_Ip(p_id     IN NUMBER,
                            p_seqno  IN NUMBER,
                            p_operid IN NUMBER) RETURN INTEGER AS
    v_msgnew VARCHAR2(5000);
  BEGIN
    v_msgnew := getRow('idc_isms_cfg_houseip_ip', 'SEQ_ID', p_id); --删除日志

    update idc_isms_cfg_houseip_ip
       set OPERATETYPE = 3, MESSAGE_SEQUENCENO = p_seqno
     where SEQ_ID = p_id;

    delete from idc_isms_base_ip_info t where t.id = p_id;

    dpi_setuserlog(20029, 3, p_id, '', v_msgnew, p_operid);

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

  --获取机房/应用策略绑定
  /*FUNCTION GetHousePolicyBind(
      p_pageNo                    IN NUMBER,
      p_pageSize                  IN NUMBER,
      p_operstatus                IN NUMBER,
      p_type                      IN NUMBER,
      p_bindmsgno                  IN NUMBER,
      p_name                       IN VARCHAR2,
      p_outcount                   OUT NUMBER,
      p_cursor                    OUT C_CURSOR
    )
    RETURN INTEGER AS
    nBegin INTEGER;
    nEnd   INTEGER;
    p_where VARCHAR2(1000);
    BEGIN

      nBegin := (p_pageNo - 1) * p_pageSize + 1;
      nEnd   := p_pageNo * p_pageSize;
      p_where:=' WHERE  t1.operatetype<>3   ';

      if p_type<>-1 then
         p_where:= p_where ||'and MESSAGE_TYPE='||p_type;
      end if;
      if p_bindmsgno<>-1 then
         p_where:= p_where ||'and BINDMESSAGENO='||p_bindmsgno;
      end if;
      if p_name IS NOT NULL then
         p_where:= p_where ||'and housename like ''%'||p_name||'%''';
      end if;

      p_where := p_where || ' and t2.message_type = 133 and t3.message_type=t1.message_type ';

      EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM  IDC_ISMS_CFG_HOUSEPOLICYBIND  t1
                   left join dpi_v1_cfg_messageno t2 on t1.message_no=t2.message_no
                   left join dpi_v1_cfg_messageno t3 on t1.bindmessageno=t3.message_no
                   left join IDC_ISMS_BASE_HOUSE t4
                   on t1.house_id=t4.houseidstr' || p_where INTO p_outcount;

      OPEN p_cursor FOR
        ' SELECT RN,BIND_ID,MESSAGE_TYPE,BINDMESSAGENO,HOUSE_ID,HOUSE_TYPE,MESSAGE_NO,OPERATETYPE,bindmessagename,message_name,housename,HOUSEIDSTR,jyzid FROM  (
              SELECT rownum as RN,BIND_ID,HOUSE_ID,HOUSE_TYPE,MESSAGE_TYPE,OPERATETYPE,BINDMESSAGENO,bindmessagename,MESSAGE_NO,message_name,housename,HOUSEIDSTR,jyzid  FROM (
                   SELECT t1.*,t2.message_name,t3.message_name as bindmessagename,t4.housename,t4.HOUSEIDSTR,t4.jyzid  from IDC_ISMS_CFG_HOUSEPOLICYBIND t1
                   left join dpi_v1_cfg_messageno t2 on t1.message_no=t2.message_no
                   left join dpi_v1_cfg_messageno t3 on t1.bindmessageno=t3.message_no
                   left join IDC_ISMS_BASE_HOUSE t4
                   on t1.house_id=t4.houseidstr
                    ' || p_where || '  order by BIND_ID desc
                  ) a  where rownum <='|| nEnd || '
        ) WHERE RN  >=' || nBegin;

     RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
          RAISE;
    END;*/

  --查询机房策略绑定信息
  FUNCTION getHousePolicyBinds(p_isPaging  in number,
                               p_curIndex  in number,
                               p_pageSize  in number,
                               p_isCount   in number,
                               p_sortName  in varchar2,
                               p_direction in varchar2,

                               p_cursor      out sys_refcursor,
                               p_recordCount out number,

                               p_isBindHouse   in number,
                               p_houseNo       in varchar2,
                               p_messageType   in number,
                               p_bindMessageNo in varchar2,
                               p_userHouseIDStrs in varchar2) RETURN INTEGER AS
      v_field      varchar2(2000); --字段
    v_innerField varchar2(2000); --sql最内层的字段
    v_innerSql   varchar2(2000); --内部语句，完整的查询sql
    v_order      varchar2(500); --内部排序语句
    v_condition  varchar2(2000) := ''; --条件语句
    v_countSql   varchar2(2000); --统计记录总数语句
    v_sql        varchar2(2000); --查询语句
    v_startIndex number(10); --开始记录
    v_endIndex   number(10); --结束记录
    v_cursor sys_refcursor;
    v_bindNoStr NVARCHAR2(4000) := '';
    v_tempBindNo number;
    v_visibleSql varchar2(2000) := '';
    v_count     number := 0;
    v_countsqlstr varchar2(2000);
  BEGIN


    v_innerField := 'select bind_id,house_type,a.message_no,message_title,message_name,a.bindmessageno,houseName,a.house_id ';
    v_field      := ' bind_id,house_type,message_no,message_title,message_name,bindmessageno,houseName,house_id ';
    v_innerSql   := ' from idc_isms_cfg_housepolicybind a
                       left join dpi_v1_dict_messagetype b on a.message_type = b.message_type
                       left join dpi_v1_cfg_messageno c on a.bindmessageno = c.message_no
                       left join (select * from idc_isms_base_house temp where temp.del_flag = 0) d  on a.house_id = d.houseidstr where a.OPERATETYPE != 3 and a.MESSAGE_TYPE = c.MESSAGE_TYPE ';

    v_order := ' order by ' || p_sortName || ' ' || p_direction;
    v_visibleSql := ' select bind.bind_id from (select t1.* from idc_isms_cfg_housepolicybind t1 left join idc_isms_base_house t2 on t1.house_id = t2.houseidstr where t2.houseid in ('||p_userHouseIDStrs||') ) bind
     where bind.message_type = 16 and bind.bindmessageno in (
           select policy.message_no from idc_isms_monitor_policy policy
           where policy.smms_cmdid in (
              select t.commandid from idc_isms_cmd_idc_manage t
              where t.operation_type = 0 and t.privilege_visible = 0))';

    --管局smms指令违法信息不可见的处理
    /*v_countsqlstr := 'select count(1)  from (select t1.* from idc_isms_cfg_housepolicybind t1 left join idc_isms_base_house t2 on t1.house_id = t2.houseidstr where t2.houseid in ('||p_userHouseIDStrs||') )  bind
    where bind.message_type = 16 and bind.bindmessageno in (
           select policy.message_no from idc_isms_monitor_policy policy
           where policy.smms_cmdid in (
              select t.commandid from idc_isms_cmd_idc_manage t
              where t.operation_type = 0 and t.privilege_visible = 0))';
    dbms_output.put_line(v_countsqlstr);
    execute immediate v_countsqlstr  into v_count; */

    if (v_count > 0) then
       v_condition := v_condition || ' and a.bind_id not in(' || v_visibleSql || ')';
    end if;
    if p_isBindHouse is not null then
      v_condition := v_condition || ' and HOUSE_TYPE = ' || p_isBindHouse;
    end if;
    if (p_houseNo is not null) then
      --v_condition := v_condition || ' and HOUSE_ID = ''' || p_houseNo || '''';
      v_condition := v_condition || ' and HOUSE_ID = (select houseidstr from idc_isms_base_house where houseidstr =''' || p_houseNo || ''')';
    end if;
    if p_messageType >= 0 then
      v_condition := v_condition || ' and a.MESSAGE_TYPE = ' ||
                     p_messageType;
    end if;
    if (p_bindMessageNo is not null) then
      v_condition := v_condition || ' and bindmessageno in(' ||
                     p_bindMessageNo || ')';
    end if;
    --统计总记录数
    if p_isCount = 1 then
      v_countSql := 'select count(1) ' || v_innerSql || v_condition;
      execute immediate v_countSql
        into p_recordCount;
    end if;

    v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
    v_endIndex   := p_curIndex * p_pageSize;
    if p_isPaging = 1 then
      v_sql := 'select ' || v_field || ' from (select e.*,rownum rn from (';
      v_sql := v_sql || v_innerField || v_innerSql || v_condition || v_order;
      v_sql := v_sql || ') e where rownum <= ' || v_endIndex;
      v_sql := v_sql || ') where rn >= ' || v_startIndex;
    else
      v_sql := v_innerField || v_innerSql || v_condition || v_order;
    end if;
    dbms_output.put_line(v_sql);
    open p_cursor for v_sql;
    return 1;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      return 0;
      RAISE;
  END;

  --添加或者修改机房/应用策略绑定
  FUNCTION AddOrUpdateHousePolicy(p_id        IN NUMBER,
                                  p_msgno     IN NUMBER,
                                  p_housetype IN NUMBER,
                                  p_houseid   IN VARCHAR2,
                                  p_type      IN NUMBER,
                                  p_bindmsgno IN NUMBER,
                                  p_operid    IN NUMBER) RETURN INTEGER AS
    v_id     NUMBER;
    v_msgold VARCHAR2(5000);
    v_msgnew VARCHAR2(5000);
    v_seqno  number(10);
  BEGIN

    if p_id = 0 or p_id is null then
      --添加
      select seq_dpi_v1_cfg_bindid.nextval into v_id from dual;
      v_seqno := PKG_DPICONFIG.MessageSequenceNo(133);
      insert into IDC_ISMS_CFG_HOUSEPOLICYBIND
        (BIND_ID,
         HOUSE_TYPE,
         HOUSE_ID,
         MESSAGE_TYPE,
         BINDMESSAGENO,
         MESSAGE_NO,
         operatetype,
         message_sequenceno)
      values
        (v_id,
         p_housetype,
         p_houseid,
         p_type,
         p_bindmsgno,
         p_msgno,
         1,
         v_seqno);

      v_msgnew := getRow('IDC_ISMS_CFG_HOUSEPOLICYBIND', 'BIND_ID', v_id); --添加日志
      dpi_setclog(20030, 1, p_msgno, v_seqno, p_operid);
      dpi_setuserlog(20030, 1, v_id, v_msgnew, '', p_operid);

    ELSE
      v_id     := p_id;
      v_msgold := getRow('IDC_ISMS_CFG_HOUSEPOLICYBIND', 'BIND_ID', v_id);
      v_seqno  := PKG_DPICONFIG.MessageSequenceNo(133);

      update IDC_ISMS_CFG_HOUSEPOLICYBIND
         set HOUSE_TYPE         = p_housetype,
             HOUSE_ID           = p_houseid,
             MESSAGE_TYPE       = p_type,
             BINDMESSAGENO      = p_bindmsgno,
             operatetype        = 2,
             message_sequenceno = v_seqno
       where BIND_ID = v_id;

      v_msgnew := getRow('IDC_ISMS_CFG_HOUSEPOLICYBIND', 'BIND_ID', v_id);
      dpi_setclog(20030, 1, p_msgno, v_seqno, p_operid);
      dpi_setuserlog(20030, 2, v_id, v_msgnew, v_msgold, p_operid);

    end if;

    commit;
    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END AddOrUpdateHousePolicy;

  --删除某一个机房/应用策略绑定(yufs 支持批量删除)
  FUNCTION DeleteHousePolicy(p_vIds    IN VARCHAR2, --如10，9，
                             p_nOperid IN NUMBER) RETURN INTEGER AS
    nId      number(10) := 0;
    vIds     varchar2(2000) := p_vIds;
    nLength  number(10) := 0;
    v_seqno  number(10) := 0;
    p_msgno  number(10) := 0;
    v_msgold varchar2(5000) := '';
    v_countStatus number(10);
  BEGIN
    nLength := instr(vIds, ',');
    while (nLength > 0) loop
      nId     := to_number(substr(vIds, 0, nLength - 1));
      v_seqno := PKG_DPICONFIG.MessageSequenceNo(133);

      v_msgold := getRow('IDC_ISMS_CFG_HOUSEPOLICYBIND', 'BIND_ID', nId); --操作前日志
      select message_no
        into p_msgno
        from IDC_ISMS_CFG_HOUSEPOLICYBIND
       where BIND_ID = nId;
      update IDC_ISMS_CFG_HOUSEPOLICYBIND
         set operatetype = 3, message_sequenceno = v_seqno
       where BIND_ID = nId;

      dpi_setclog(20030, 1, p_msgno, v_seqno, p_nOperid); --应罗贤文要求 将状态改成1添加。便于主动下发
      dpi_setuserlog(20030, 3, nId, '', v_msgold, p_nOperid);
      --delete dpi_v1_cfg_messageno where message_no=p_msgno and message_type=133;
      UPDATE dpi_v1_cfg_messageno
         SET opertype = 3
       where message_no = p_msgno
         and message_type = 133;
      commit;

      --重置
      vIds    := substr(vIds, nLength + 1);
      nLength := instr(vIds, ',');
    end loop;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;

  END DeleteHousePolicy;


--删除一个策略下的所有的绑定
FUNCTION deletePolicyHouseBinds(
         p_msgno  IN NUMBER,
         p_msgType IN NUMBER,
         p_operid IN NUMBER
) RETURN INTEGER AS
    c_bindCur    sys_refcursor;
    n_bindid     number(10);
    n_message_no number(10);
    n_retcode    number(10);
BEGIN
    open c_bindCur for
      select bind_id, message_no from idc_isms_cfg_housepolicybind
       where bindmessageno = p_msgno and message_type = p_msgType and operatetype < 3;
    loop
      fetch c_bindCur into n_bindid, n_message_no;
      exit when c_bindCur%notfound;
      n_retcode := PKG_IDCCONFIG.DeleteHousePolicy(n_bindid || ',', p_operid);
    end loop;
    commit;
    RETURN SUCC_CODE;
END;

 --根据起始,结束策略Id批量删除绑定
 function batchDeletePolicy
  (
      p_operid                IN NUMBER,
      p_messageNo             IN NUMBER
  )
  RETURN INTEGER AS
      v_seqno  number(10) := 0;
  BEGIN
      v_seqno := PKG_DPICONFIG.MessageSequenceNo(133);
      update IDC_ISMS_CFG_HOUSEPOLICYBIND set  operatetype = 3, message_sequenceno = v_seqno
      where MESSAGE_NO = p_messageNo;
      dpi_setclog(20030, 1, p_messageNo, v_seqno, p_operid); --同一个messageNo删除，只写一个clog
      UPDATE dpi_v1_cfg_messageno SET opertype = 3 where message_no = p_messageNo and message_type = 133;
      commit;
      RETURN SUCC_CODE;
  END;

  --分页获取所有设备静态信息
  FUNCTION GetDeviceStatusList(p_pageNo   IN NUMBER,
                               p_pageSize IN NUMBER,
                               p_name     IN VARCHAR2,
                               p_outcount OUT NUMBER,
                               p_cursor   OUT C_CURSOR) RETURN INTEGER AS
    nBegin  NUMBER;
    nEnd    NUMBER;
    p_where VARCHAR2(1000);
  BEGIN
    nBegin  := (p_pageNo - 1) * p_pageSize + 1;
    nEnd    := p_pageNo * p_pageSize;
    p_where := ' WHERE 1=1  ';

    if (p_name is not null) then
      p_where := p_where || 'and  lower(t1.dpi_dev_name) like ''%' ||
                 p_name || '%''';
    end if;

    p_where := p_where || 'and t1.operatetype<3';

    EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM dpi_v1_cfg_dpiinfo t1 inner JOIN IDC_ISMS_CFG_DEVICESTATIC t2 ON t1.dev_id=t2.dev_id
          ' || p_where
      INTO p_outcount;

    OPEN p_cursor FOR 'SELECT *  FROM (SELECT rownum as rn, t1.dev_id, t1.dpi_dev_name AS dev_name, softwareversion, deploy_mode, total_capability, slotnum, preprocslotnum, analysisslotnum, gpslotnum, createtime
         FROM dpi_v1_cfg_dpiinfo t1 inner JOIN IDC_ISMS_CFG_DEVICESTATIC t2 ON t1.dev_id=t2.dev_id
          ' || p_where || '
         ORDER BY t1.dev_id ASC) where rn <=  ' || nEnd || 'and rn  >=' || nBegin;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

  --修改dpi设备状态
  FUNCTION EditCfgDevStatus(p_type   IN NUMBER,
                            p_frep   IN NUMBER,
                            p_type2  IN NUMBER,
                            p_frep2  IN NUMBER,
                            p_operid IN NUMBER) RETURN INTEGER AS

    v_msgold VARCHAR2(5000);
    v_msgno     NUMBER(10);
    v_ret       NUMBER(10);
    v_msgnew VARCHAR2(5000);
    v_msgname   VARCHAR2(100);
    v_seqno  number(10);
    n_count  number(5);
  BEGIN
    select count(1) into n_count from idc_isms_cfg_devicestatus where R_Type = p_type;
    if n_count = 0 then
      SELECT to_char(systimestamp, 'yyyymmddhh24missff3') ||
           trunc(dbms_random.value(1000, 9999)) INTO v_msgname FROM dual;
       v_ret := PKG_DPICONFIG.AddMessageNo(210, v_msgname, v_msgno);
       v_seqno := PKG_DPICONFIG.MessageSequenceNo(210);
       insert into idc_isms_cfg_devicestatus values(p_type,v_msgno,p_frep,1,v_seqno,sysdate);
       dpi_setclog(20042, 1,v_msgno, v_seqno, p_operid);
       dpi_setuserlog(20042, 1, p_type, v_msgnew, '', p_operid);
    else
      v_msgold := getRow('idc_isms_cfg_devicestatus', 'R_Type', p_type); --操作前日志
      v_seqno  := PKG_DPICONFIG.MessageSequenceNo(210);
      select MESSAGE_NO into v_msgno from idc_isms_cfg_devicestatus where R_Type = p_type;
      UPDATE idc_isms_cfg_devicestatus
         SET R_Freq = p_frep, operatetype = 1, message_sequenceno = v_seqno
       WHERE R_Type = p_type;
      v_msgnew := getRow('idc_isms_cfg_devicestatus', 'R_Type', p_type); --操作后日志

      dpi_setclog(20042, 1, v_msgno, v_seqno, p_operid);
      dpi_setuserlog(20042, 2, p_type, v_msgnew, v_msgold, p_operid);
    end if;

    select count(1) into n_count from idc_isms_cfg_devicestatus where R_Type = p_type2;
    if n_count = 0 then
       SELECT to_char(systimestamp, 'yyyymmddhh24missff3') ||
           trunc(dbms_random.value(1000, 9999)) INTO v_msgname FROM dual;
       v_ret := PKG_DPICONFIG.AddMessageNo(210, v_msgname, v_msgno);
       insert into idc_isms_cfg_devicestatus values(p_type2,v_msgno,p_frep2,1,v_seqno,sysdate);
       dpi_setclog(20042, 1,v_msgno, v_seqno, p_operid);
       dpi_setuserlog(20042, 1, p_type2, v_msgnew, '', p_operid);
    else
      v_msgold := getRow('idc_isms_cfg_devicestatus', 'R_Type', p_type2); --操作前日志
      v_seqno  := PKG_DPICONFIG.MessageSequenceNo(210);
      select MESSAGE_NO into v_msgno from idc_isms_cfg_devicestatus where R_Type = p_type2;
      UPDATE idc_isms_cfg_devicestatus
         SET R_Freq             = p_frep2,
             operatetype        = 1,
             message_sequenceno = v_seqno
       WHERE R_Type = p_type2;
      v_msgnew := getRow('idc_isms_cfg_devicestatus', 'R_Type', p_type2); --操作后日志
      dpi_setclog(20042, 1, v_msgno, v_seqno, p_operid);
      dpi_setuserlog(20042, 2, p_type2, v_msgnew, v_msgold, p_operid);
    end if;
    COMMIT;
    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;

--初始化dpi状态查询
  FUNCTION DetailCfgDevStatus(
                              p_cursor  OUT C_CURSOR)
                              RETURN INTEGER AS

  BEGIN

    OPEN p_cursor FOR
      SELECT * FROM IDC_ISMS_CFG_DEVICESTATUS ORDER BY r_type;
   RETURN SUCC_CODE;

  EXCEPTION
  WHEN OTHERS THEN
     RAISE;
  END;

  --获取设备静态端口信息
  FUNCTION GetDeviceStaticPortByDevId(p_devid  IN NUMBER,
                                      p_cursor OUT C_CURSOR) RETURN INTEGER AS
  BEGIN
    OPEN p_cursor FOR
      SELECT dev_id,
             porttype,
             portno,
             portdescription,
             m_linkid,
             m_linkdesc
        FROM idc_isms_cfg_devicestatic_port
       WHERE dev_id = p_devid
       ORDER BY portno ASC;

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

  --获取设备动态端口信息
  FUNCTION GetDeviceDynamicPortByDevId(p_devid     IN NUMBER, --对应ID
                                       p_ports     IN VARCHAR2, --端口字串
                                       p_starttime IN VARCHAR2, --开始时间
                                       p_endtime   IN VARCHAR2, --结束时间
                                       p_cursor    OUT C_CURSOR)
    RETURN INTEGER AS
    v_sql varchar2(1000) := '';
  BEGIN
    if (p_ports is null) then
      v_sql := v_sql ||
               'select * FROM idc_isms_cfg_devicedynamicport where dev_id = ' ||
               p_devid;
    else
      v_sql := v_sql ||
               'select * FROM idc_isms_cfg_devicedynamicport where dev_id = ' ||
               p_devid;
      v_sql := v_sql || ' and portno in(' || p_ports || ')';
    end if;
    if (p_starttime is not null) then
      v_sql := v_sql || ' and to_char(createtime,''yyyyMMddhh24miss'') >= ' ||
               to_char(to_date(p_starttime, 'yyyy-MM-dd hh24:mi:ss'),
                       'yyyyMMddhh24miss');
    end if;
    if (p_endtime is not null) then
      v_sql := v_sql || ' and to_char(createtime,''yyyyMMddhh24miss'') <= ' ||
               to_char(to_date(p_endtime, 'yyyy-MM-dd hh24:mi:ss'),
                       'yyyyMMddhh24miss');
    end if;
    dbms_output.put_line(v_sql);
    v_sql := v_sql || ' ORDER BY createtime, portno';
    open p_cursor for v_sql;
    RETURN SUCC_CODE;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

  --获取设备动态端口(去重)
  FUNCTION ShowDeviceDynamicPortByDevId(p_devid  IN NUMBER, --对应ID
                                        p_count  IN NUMBER, --展示数目(-1全部)
                                        p_cursor OUT C_CURSOR) RETURN NUMBER AS
    vWhere varchar2(100) := ''; --条件
  BEGIN
    if p_count > 0 then
      vWhere := 'WHERE RN<=' || p_count;
    end if;
    OPEN p_cursor FOR 'SELECT * FROM(
          SELECT ROWNUM RN,T.* FROM (
            select distinct portno,PORTINFO
            from idc_isms_cfg_devicedynamicport
            where DEV_ID=' || p_devid || '
            order by portno
          )T
       )' || vWhere;

    RETURN SUCC_CODE;

  END ShowDeviceDynamicPortByDevId;

  --获取设备动态CPU(去重)
  FUNCTION ShowtDeviceDynamicCpuByDevId(p_devid  IN NUMBER, --对应ID
                                        p_count  IN NUMBER, --展示数目(-1全部)
                                        p_cursor OUT C_CURSOR) RETURN NUMBER AS
    vWhere varchar2(100) := ''; --条件
  BEGIN
    if p_count > 0 then
      vWhere := 'WHERE RN<=' || p_count;
    end if;
    OPEN p_cursor FOR 'SELECT * FROM(
          SELECT ROWNUM RN,T.* FROM (
            select distinct cpu_no
            from idc_isms_cfg_devicedynamiccpu
            where DEV_ID=' || p_devid || '
            order by cpu_no
          )T
       )' || vWhere;

    RETURN SUCC_CODE;
  END ShowtDeviceDynamicCpuByDevId;

  --获取设备动态CPU信息
  FUNCTION GetDeviceDynamicCpuByDevId(p_devid     IN NUMBER, --对应ID
                                      p_cpus      IN VARCHAR2, --cpu字串
                                      p_starttime IN VARCHAR2, --开始时间
                                      p_endtime   IN VARCHAR2, --结束时间
                                      p_cursor    OUT C_CURSOR)
    RETURN INTEGER AS
    v_sql varchar2(1000) := '';
  BEGIN
    if (p_cpus is null) then
      v_sql := v_sql ||
               'select * FROM idc_isms_cfg_devicedynamiccpu where dev_id = ' ||
               p_devid;
    else
      v_sql := v_sql ||
               'select * FROM idc_isms_cfg_devicedynamiccpu where dev_id = ' ||
               p_devid;
      v_sql := v_sql || ' and cpu_no in(' || p_cpus || ')';
    end if;
    if (p_starttime is not null) then
      v_sql := v_sql || ' and to_char(createtime,''yyyyMMddhh24miss'') >= ' ||
               to_char(to_date(p_starttime, 'yyyy-MM-dd hh24:mi:ss'),
                       'yyyyMMddhh24miss');
    end if;
    if (p_endtime is not null) then
      v_sql := v_sql || ' and to_char(createtime,''yyyyMMddhh24miss'') <= ' ||
               to_char(to_date(p_endtime, 'yyyy-MM-dd hh24:mi:ss'),
                       'yyyyMMddhh24miss');
    end if;
    dbms_output.put_line(v_sql);
    v_sql := v_sql || ' ORDER BY createtime, cpu_no';
    open p_cursor for v_sql;
    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

--分页综分设备信息
  FUNCTION GetZFDeviceInfo(
        p_isPaging in number,
        p_curIndex in number,
        p_pageSize in number,
        p_isCount in number,
        p_sortName in varchar2,
        p_direction in varchar2,
        p_cursor out sys_refcursor,
        p_recordCount out number,

        p_deviceIP in varchar2,
        p_devicePort in number,
        p_deviceName in varchar2
  )
  RETURN INTEGER
  AS
      v_field     varchar2(2000); --字段
      v_innerSql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_countSql  varchar2(2000); --统计记录总数语句
      v_sql varchar2(2000); --查询语句
      v_startIndex number(10); --开始记录
      v_endIndex number(10); --结束记录
      v_temSql varchar2(500); --临时语句
  BEGIN
      v_field := ' DEV_ID,DEV_IP,DEV_PORT,DEV_NAME,IS_CITED ';
      v_innerSql := ' from DPI_V1_CFG_ZONGFENINFO WHERE 1=1 ';

      v_order := ' order by ' || p_sortName || ' ' || p_direction;
      v_condition:=' ';
      if length(p_deviceIP)>0  then
         v_condition := v_condition || ' and DEV_IP like ''%' || p_deviceIP || '%'' escape ''\'' ';
      end if;
      if p_devicePort > 0 then
         v_condition := v_condition || ' and DEV_PORT = ' || p_devicePort;
      end if;
      if length(p_deviceName)>0  then
         v_condition := v_condition || ' and DEV_NAME like ''%'|| p_deviceName ||'%'' escape ''\'' ';
      end if;

      v_temSql := v_innerSql || v_condition;
      --统计总记录数
      if p_isCount = 1 then
         v_countSql := 'select count(1) from ( select' || v_field || v_temSql ||')';
         execute immediate v_countSql into p_recordCount;
      end if;

      v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
      v_endIndex := p_curIndex * p_pageSize;
      if p_isPaging = 1 then
         v_sql := 'select ' || v_field || ' from (select a.*,rownum rn from (';
         v_sql := v_sql || 'select ' || v_field || v_temSql || v_order;
         v_sql := v_sql || ') a where rownum <= ' || v_endIndex;
         v_sql := v_sql || ') where rn >= ' || v_startIndex;
      else
         v_sql := 'select ' || v_field || v_temSql || v_order;
      end if;

      open p_cursor for v_sql;
      RETURN SUCC_CODE;
  END;




 --分页综分设备信息1
  FUNCTION GetZFDeviceInfo1(
        p_isPaging in number,
        p_curIndex in number,
        p_pageSize in number,
        p_isCount in number,
        p_sortName in varchar2,
        p_direction in varchar2,
        p_cursor out sys_refcursor,
        p_recordCount out number,

        p_deviceIP in varchar2,
        p_devicePort in number,
        p_deviceName in varchar2
  )
  RETURN INTEGER
  AS
      v_field     varchar2(2000); --字段
      v_innerSql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_countSql  varchar2(2000); --统计记录总数语句
      v_sql varchar2(2000); --查询语句
      v_startIndex number(10); --开始记录
      v_endIndex number(10); --结束记录
      v_temSql varchar2(500); --临时语句
      v_group varchar2(200);
  BEGIN
      v_field := ' A.Dev_Id,A.Dev_Ip, A.Dev_Port, A.Dev_Name,A.IS_CITED, count(decode(B.Connectflag, 1, 1, null)) count1, count(decode(B.Connectflag, 0, 1,null)) count2 ';
      v_innerSql := ' from DPI_V1_CFG_ZONGFENINFO A
                 left join DPI_V1_CFG_DPIINFO B on A.DEV_ID = B.Zongfen_Id ';

      v_group :='group by A.Dev_Id,A.Dev_Ip, A.Dev_Port, A.Dev_Name';
      v_order :=  ' order by ' || p_sortName || ' ' || p_direction;
      v_condition:=' WHERE 1=1';
      if (p_deviceIP is not null) then
         v_condition := v_condition || ' and DEV_IP like ''%' || p_deviceIP || '%'' escape ''\'' ';
      end if;
      if p_devicePort > 0 then
         v_condition := v_condition || ' and DEV_PORT = ' || p_devicePort;
      end if;
      if ( p_deviceName is not null) then
         v_condition := v_condition || ' and DEV_NAME like ''%' || p_deviceName || '%'' escape ''\'' ';
      end if;
      if(p_deviceIP=null and p_devicePort=null and p_deviceName=null) then
          v_temSql := v_innerSql || v_condition|| v_group;
      else
          v_temSql := v_innerSql || v_group;
      end if;
      --统计总记录数
      if(p_deviceIP=null and p_devicePort=null and p_deviceName=null) then
          if p_isCount = 1 then
             v_countSql := 'select count(1) from ( select' || v_field || v_temSql ||')';
             execute immediate v_countSql into p_recordCount;
          end if;
      else
          if p_isCount = 1 then
             v_countSql := 'select count(1) from ( select' || v_field || v_temSql || ')' || 'where 1=1 ' || v_condition;
             execute immediate v_countSql into p_recordCount;
          end if;
      end if;
      v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
      v_endIndex := p_curIndex * p_pageSize;
      if p_isPaging = 1 then
         v_sql := 'select * from(select a.*,rownum rn from (';
         v_sql := v_sql || 'select ' || v_field || v_temSql || v_order;
         v_sql := v_sql || ') a where 1=1' || v_condition || 'and rownum <= ' || v_endIndex;
         v_sql := v_sql || ') where rn >= ' || v_startIndex;
      else
         v_sql := 'select ' || v_field || v_temSql || v_order;
      end if;
      dbms_output.put_line(v_sql);
      open p_cursor for v_sql;
      RETURN SUCC_CODE;
  END;

   --添加综分设备信息
  FUNCTION AddZFDeviceInfo(
         p_ip in VARCHAR2,
         p_port IN NUMBER,
         p_dev_name IN VARCHAR2,
         p_operid   IN NUMBER
  ) RETURN INTEGER
  AS
    n_dev_id NUMBER(10);
    v_msgnew VARCHAR2(5000);
  BEGIN
     SELECT SEQ_DPI_V1_CFG_ZONGFENINFO_ID.nextval INTO n_dev_id FROM dual;

     INSERT INTO dpi_v1_cfg_zongfeninfo
       (dev_id,dev_ip, dev_port,dev_name, createtime)
     VALUES
       (n_dev_id, p_ip, p_port, p_dev_name, sysdate);

     v_msgnew:=getRow('dpi_v1_cfg_zongfeninfo','dev_id',n_dev_id);--添加日志

     dpi_setuserlog(20038,1,n_dev_id,v_msgnew,'',p_operid);

     COMMIT;
     RETURN SUCC_CODE;
  END;

   --修改综分设备信息
  FUNCTION EditZFDeviceInfo(
         p_dev_id IN NUMBER,
         p_ip IN VARCHAR2,
         p_port IN NUMBER,
         p_dev_name IN VARCHAR2,
         p_operid   IN NUMBER,
         p_isCited IN NUMBER
  ) RETURN INTEGER
  AS
    v_msgold VARCHAR2(5000);
    v_msgnew VARCHAR2(5000);
  BEGIN
     v_msgold:=getRow('dpi_v1_cfg_zongfeninfo','dev_id',p_dev_id);

     UPDATE dpi_v1_cfg_zongfeninfo
        SET dev_ip = p_ip,
            dev_port = p_port,
            dev_name = p_dev_name,
            is_cited = p_isCited
      WHERE dev_id = p_dev_id;

     v_msgnew:=getRow('dpi_v1_cfg_zongfeninfo','dev_id',p_dev_id);--添加日志
     dpi_setuserlog(20038,2,p_dev_id,v_msgnew,v_msgold,p_operid);

     COMMIT;
     RETURN SUCC_CODE;
  END;

  --删除综分设备信息
  FUNCTION DelZFDeviceInfo(
         p_dev_id IN NUMBER,
         p_operid   IN NUMBER
  ) RETURN INTEGER
  AS
  v_msgold VARCHAR2(5000);
  BEGIN
     v_msgold:=getRow('dpi_v1_cfg_zongfeninfo','dev_id',p_dev_id);

     delete dpi_v1_cfg_zongfeninfo
     WHERE dev_id = p_dev_id;

     dpi_setuserlog(20038,3,p_dev_id,'',v_msgold,p_operid);

     COMMIT;
     RETURN SUCC_CODE;
  END;

--分页dpi设备信息
  FUNCTION GetDpiDeviceInfo(
          p_isPaging in number,
          pageindex IN NUMBER,
          pagesize  IN NUMBER,
          p_isCount in number,
          p_sortName in varchar2,
          p_direction in varchar2,
          p_cursor          OUT C_CURSOR,
          v_out_recordcount OUT NUMBER,
          p_zongfen_id IN NUMBER,
          p_ip    IN VARCHAR2,
          p_name    IN VARCHAR2,
          p_areaCode    IN NUMBER,
          p_houseId    IN varchar2,
          p_userHouseIDStrs in varchar2
  )
  RETURN INTEGER
  AS
  nBegin NUMBER;
  nEnd NUMBER;
  v_sql varchar2(2000);
  p_where VARCHAR2(1000);
  BEGIN
      nBegin := (pageindex - 1) * pagesize + 1;
      nEnd := pageindex * pagesize;
      p_where:=' WHERE 1=1  ';

      if length(p_zongfen_id)>0 then
         p_where:= p_where ||' and zongfen_id = '||p_zongfen_id;
      end if;

      if length(p_ip)>0 then
       p_where:= p_where ||' and  dpi_ip like ''%'|| p_ip || '%'' escape ''\'' ';
      end if;

      if length(p_name)>0 then
       p_where:= p_where ||' and  dpi_dev_name like ''%'|| p_name || '%'' escape ''\'' ';
      end if;

      if(p_areaCode is not null ) then
       p_where:= p_where ||' and area_code = '||p_areaCode;
      end if;

      if(p_houseId is not null ) then
       p_where:= p_where ||' and house_idlist = ''' ||p_houseId ||''' ';
      end if;

      p_where:= p_where ||' and operatetype<3';
     -- dbms_output.put_line(p_where);

      v_sql := 'SELECT a.dev_id, message_no, dpi_ip, dpi_port, dpi_dev_name, dpi_site_name, dev_flag,zongfen_id,area_code,idc_port,house_idlist
                           FROM dpi_v1_cfg_dpiinfo a left join
                           (
                                select dev_id,wm_concat(house_id) as house_idlist from (select  t1.*  from dpi_v1_cfg_dpiinfo_house t1 inner join idc_isms_base_house t2 on t1.house_id = t2.houseidstr  where  t2.houseid in ('||p_userHouseIDStrs||')) group by dev_id
                           )b on a.dev_id=b.dev_id
                          ' || p_where || '
                           ORDER BY ' || p_sortName || ' ' || p_direction;

      if p_isCount = 1 then
         EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM ('||v_sql||')' INTO  v_out_recordcount;
      end if;

      if p_isPaging = 1 then

          v_sql := 'SELECT dev_id, message_no, dpi_ip, dpi_port, dpi_dev_name, dpi_site_name, dev_flag,zongfen_id,area_code,idc_port,house_idlist
               FROM (SELECT dev_id, message_no, dpi_ip, dpi_port, dpi_dev_name, dpi_site_name, dev_flag,zongfen_id,area_code,idc_port,house_idlist, rownum AS rn
                     FROM (

                          SELECT a.dev_id, message_no, dpi_ip, dpi_port, dpi_dev_name, dpi_site_name, dev_flag,zongfen_id,area_code,idc_port,house_idlist
                           FROM dpi_v1_cfg_dpiinfo a left join
                           (
                                select dev_id,wm_concat(house_id) as house_idlist from (select  t1.*  from dpi_v1_cfg_dpiinfo_house t1 inner join idc_isms_base_house t2 on t1.house_id = t2.houseidstr  where  t2.houseid in ('||p_userHouseIDStrs||')) group by dev_id
                           )b on a.dev_id=b.dev_id
                          ' || p_where || '
                           ORDER BY ' || p_sortName || ' ' || p_direction
                     || ') t
                     WHERE rownum<=' || nEnd || ') tt
             WHERE rn>=' || nBegin || '';
         end if;
         --dbms_output.put_line(v_sql);
         open p_cursor for v_sql;
      RETURN SUCC_CODE;
  END;

--分页dpi设备信息1
  FUNCTION GetDpiDeviceInfo1(
          p_isPaging in number,
          pageindex IN NUMBER,
          pagesize  IN NUMBER,
          p_isCount in number,
          p_sortName in varchar2,
          p_direction in varchar2,
          p_cursor          OUT C_CURSOR,
          v_out_recordcount OUT NUMBER,
          p_zongfen_id IN NUMBER,
          p_ip    IN VARCHAR2,
          p_name    IN VARCHAR2,
          p_areaCode    IN NUMBER,
          p_houseId    IN varchar2,
          p_userHouseIDStrs in varchar2
  )
  RETURN INTEGER
  AS
  nBegin NUMBER;
  nEnd NUMBER;
  v_sql varchar2(2000);
  p_where VARCHAR2(1000);
  BEGIN
      nBegin := (pageindex - 1) * pagesize + 1;
      nEnd := pageindex * pagesize;
      p_where:=' WHERE 1=1  ';

      if length(p_zongfen_id)>0 then
         p_where:= p_where ||' and zongfen_id = '||p_zongfen_id;
      end if;

      if length(p_ip)>0 then
       p_where:= p_where ||' and  dpi_ip like ''%'|| p_ip || '%'' escape ''\''';
      end if;

      if length(p_name)>0 then
       p_where:= p_where ||' and  dpi_dev_name like ''%'|| p_name || '%'' escape ''\''';
      end if;

      if(p_areaCode is not null ) then
       p_where:= p_where ||' and area_code = '||p_areaCode;
      end if;

      if(p_houseId is not null ) then

      -- p_where:= p_where || ' and '|| p_houseId ||' in (select * from table(splitstr(house_idlist,'',''))) ';
       p_where:= p_where ||' and a.dev_id in (select dev_id from DPI_V1_CFG_DPIINFO_HOUSE where house_id = ''' || p_houseId ||''') ';
      end if;

      p_where:= p_where ||' and operatetype<3';
     -- dbms_output.put_line(p_where);

      v_sql := 'select a.dev_id, a.message_no, a.dpi_ip, a.dpi_port, a.dpi_dev_name, a.dpi_site_name, a.dev_flag,a.zongfen_id,a.area_code,a.idc_port,a.house_idlist,b.dev_ip,b.dev_name
                           FROM(SELECT a.dev_id, message_no, dpi_ip, dpi_port, dpi_dev_name, dpi_site_name, dev_flag,zongfen_id,area_code,idc_port,house_idlist
                           FROM dpi_v1_cfg_dpiinfo a left join
                           (
                                select dev_id,wm_concat(house_id) as house_idlist from (select  t1.*  from dpi_v1_cfg_dpiinfo_house t1 inner join idc_isms_base_house t2 on t1.house_id = t2.houseidstr where  t2.houseid in ('||p_userHouseIDStrs||')) group by dev_id
                           )b on a.dev_id=b.dev_id '|| p_where ||')a left join dpi_v1_cfg_zongfeninfo b on a.zongfen_id=b.dev_id
                           ORDER BY  ' || p_sortName || ' ' || p_direction
                     || '';

      if p_isCount = 1 then
         EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM ('||v_sql||')' INTO  v_out_recordcount;
      end if;

      if p_isPaging = 1 then

          v_sql := 'SELECT dev_id, message_no, dpi_ip, dpi_port, dpi_dev_name, dpi_site_name, dev_flag,zongfen_id,area_code,idc_port,house_idlist,dev_ip,dev_name
               FROM (SELECT dev_id, message_no, dpi_ip, dpi_port, dpi_dev_name, dpi_site_name, dev_flag,zongfen_id,area_code,idc_port,house_idlist,dev_ip,dev_name, rownum AS rn
                     FROM ('||v_sql||') t
                     WHERE rownum<=' || nEnd || ') tt
             WHERE rn>=' || nBegin || '';
      end if;
         --dbms_output.put_line(v_sql);
         open p_cursor for v_sql;
      RETURN SUCC_CODE;
  END;

  --添加DPI设备信息
  FUNCTION AddDpiDeviceInfo(
         p_msgno                   IN NUMBER,
         p_dev_flag                IN NUMBER,
         p_ip                      in VARCHAR2,
         p_port                    IN NUMBER,
         p_dev_name                IN VARCHAR2,
         p_site_name               IN VARCHAR2,
         p_zongfen_id              IN NUMBER,
         p_operid                  IN NUMBER,
         p_areacode                IN NUMBER,
         p_idcport                 IN NUMBER,
         n_dev_id                  OUT NUMBER
  ) RETURN INTEGER
  AS
    v_msgnew VARCHAR2(5000);
    v_seqno NUMBER(10);
  BEGIN
     SELECT SEQ_DPI_V1_CFG_DPIINFO_ID.nextval INTO n_dev_id FROM dual;

     v_seqno := PKG_DPICONFIG.MessageSequenceNo(209);

     INSERT INTO dpi_v1_cfg_dpiinfo
       (dev_id, message_no, dpi_ip, dpi_port, dpi_dev_name, dpi_site_name, operatetype, message_sequenceno, dev_flag,zongfen_id,AREA_CODE,IDC_PORT,PROBE_TYPE)
     VALUES
       (n_dev_id, p_msgno, p_ip, p_port, p_dev_name, p_site_name, 1, v_seqno, 1,p_zongfen_id,p_areacode,p_idcport,1);


     dpi_setclog(20031,1,p_msgno,v_seqno,p_operid);

     v_msgnew:=getRow('dpi_v1_cfg_dpiinfo','dev_id',n_dev_id);--添加日志
     dpi_setuserlog(20031,1,n_dev_id,v_msgnew,'',p_operid);

     COMMIT;
     RETURN SUCC_CODE;
  END;

 --添加DPI设备信息与机房关系
  FUNCTION AddDpiDeviceInfo_House(
         p_dev_id   IN NUMBER,
         p_house_id IN VARCHAR2
  ) RETURN INTEGER
  AS
  BEGIN
     INSERT INTO dpi_v1_cfg_dpiinfo_house(dev_id, house_id) VALUES (p_dev_id, p_house_id);
     COMMIT;

     RETURN SUCC_CODE;
  END;


  --修改DPI设备信息
  FUNCTION EditDpiDeviceInfo(
         p_dev_id IN NUMBER,
         p_msgno IN NUMBER,
         p_dev_name IN VARCHAR2,
         p_site_name IN VARCHAR2,
         p_zongfen_id  IN NUMBER,
         p_operid   IN NUMBER
  ) RETURN INTEGER
  AS
    v_msgold VARCHAR2(5000);
    v_msgnew VARCHAR2(5000);
    v_seqno NUMBER(10);
    v_zongfen_id NUMBER(10);
  BEGIN
     v_msgold:=getRow('dpi_v1_cfg_dpiinfo','dev_id',p_dev_id);
     v_seqno := PKG_DPICONFIG.MessageSequenceNo(209);

     select zongfen_id into v_zongfen_id  from dpi_v1_cfg_dpiinfo where dev_id = p_dev_id;

     if p_zongfen_id<>v_zongfen_id then
        dpi_setclog(20039,1,v_zongfen_id,p_dev_id,p_operid);
     end if;

     UPDATE dpi_v1_cfg_dpiinfo
        SET dpi_dev_name = p_dev_name,
            dpi_site_name = p_site_name,
            operatetype = 2,
            message_sequenceno = v_seqno,
            zongfen_id=p_zongfen_id
      WHERE dev_id = p_dev_id;

     dpi_setclog(20031,1,p_msgno,v_seqno,p_operid);

     v_msgnew:=getRow('dpi_v1_cfg_dpiinfo','dev_id',p_dev_id);--添加日志
     dpi_setuserlog(20031,2,p_dev_id,v_msgnew,v_msgold,p_operid);

     COMMIT;
     RETURN SUCC_CODE;
  END;

   --删除DPI设备信息关联的机房信息
  FUNCTION DelDpiDeviceInfo_House(
         p_dev_id IN NUMBER
  ) RETURN INTEGER
  AS
  BEGIN

     delete dpi_v1_cfg_dpiinfo_house
     WHERE dev_id = p_dev_id;

     COMMIT;
     RETURN SUCC_CODE;
  END;

  --删除DPI设备信息
  FUNCTION DelDpiDeviceInfo(
         p_dev_id IN NUMBER,
         p_msgno IN NUMBER,
         p_operid   IN NUMBER
  ) RETURN INTEGER
  AS
  v_msgold VARCHAR2(5000);
  v_seqno NUMBER(10);
  v_ret NUMBER(10);
  BEGIN
     v_msgold:=getRow('dpi_v1_cfg_dpiinfo','dev_id',p_dev_id);
     v_seqno := PKG_DPICONFIG.MessageSequenceNo(209);

     UPDATE dpi_v1_cfg_dpiinfo
     SET operatetype = 3,
         message_sequenceno = v_seqno
     WHERE dev_id = p_dev_id;

     v_ret := PKG_IDCCONFIG.DelDpiDeviceInfo_House(p_dev_id);--删除相关联的机房信息

     dpi_setclog(20031,1,p_msgno,v_seqno,p_operid);
     dpi_setuserlog(20031,3,p_dev_id,'',v_msgold,p_operid);

     COMMIT;
     RETURN SUCC_CODE;
  END;

  --删除全部表idc_isms_monitor_policy数据
  FUNCTION deleteBatchISMPolicy RETURN INTEGER AS
  v_msgno     NUMBER(10);
  BEGIN
    v_msgno := 0;
    select max(t.message_no) into v_msgno from idc_isms_monitor_policy t where smms_cmdid is not null;
    delete from dpi_v1_cfg_messageno t1 where MESSAGE_TYPE = 16 and t1.message_no in (select t.message_no from idc_isms_monitor_policy t where smms_cmdid is null);
    delete from IDC_ISMS_CFG_HOUSEPOLICYBIND t1 where t1.MESSAGE_TYPE = 16 and t1.bindmessageno in (select t.message_no from idc_isms_monitor_policy t where smms_cmdid is null);
    delete from idc_isms_monitor_policy_rule t where t.commandid in (select commandid from idc_isms_monitor_policy where smms_cmdid is null);
    delete from idc_isms_monitor_policy t where t.smms_cmdid is null;
    update dpi_v1_dict_messagetype t1 set t1.MESSAGE_SEQUENCENO = v_msgno where t1.MESSAGE_TYPE = 16;
    commit;
    RETURN SUCC_CODE;
  END;

  --同时添加policy,policyRule,MessageNo
  FUNCTION addPolicyAndPolicyRule(p_commandType IN NUMBER,
                                  p_actionBlock IN NUMBER,
                                  p_starttime   IN NUMBER,
                                  p_endtime     IN NUMBER,
                                  p_valueStart  IN VARCHAR2,
                                  p_subType     IN NUMBER,
                                  p_msgNo       OUT NUMBER) RETURN INTEGER AS
    v_msgname   VARCHAR2(100);
    v_msgno     NUMBER(10);
    v_seqno     number(10);
    v_commandId number(10);
    v_msgnew    VARCHAR2(5000);
    v_ret       NUMBER(10);
    v_keyRange  VARCHAR2(100);
    v_valueEnd  VARCHAR2(100);
  BEGIN
    SELECT to_char(systimestamp, 'yyyymmddhh24missff3') ||
           trunc(dbms_random.value(1000, 9999))
      INTO v_msgname
      FROM dual;
    v_ret := PKG_DPICONFIG.AddMessageNo(16, v_msgname, v_msgno);

    v_seqno := PKG_DPICONFIG.MessageSequenceNo(16);
    select seq_idc_isms_monitorpolicy_id.nextval
      into v_commandId
      from dual;
    insert into IDC_ISMS_MONITOR_POLICY
      (COMMANDID,
       MESSAGE_NO,
       COMMAND_TYPE,
       ACTION_BLOCK,
       ACTION_LOG,
       EFFECTTIME,
       EXPIREDTIME,
       OPERATETYPE,
       MESSAGE_SEQUENCENO,
       CREATE_TIME,
       CREATE_USERID)
    values
      (v_commandId,
       v_msgno,
       p_commandType,
       p_actionBlock,
       1,
       p_starttime,
       p_endtime,
       1,
       v_seqno,
       sysdate,
       -2);
    p_msgNo  := v_msgno;
    v_msgnew := getRow('IDC_ISMS_MONITOR_POLICY', 'COMMANDID', v_commandId); --添加日志
    --dpi_setclog(20026,1,v_msgno,v_seqno,p_operid);
    --dpi_setuserlog(20026,1,v_commandId,v_msgnew,'',p_operid);

    if (p_subType = 3) then
      v_keyRange := '0,1,2';
      v_valueEnd := '';
    elsif (p_subType = 4 or p_subType = 5) then
      v_keyRange := '0,1,2';
      v_valueEnd := p_valueStart;
    else
      v_keyRange := '';
      v_valueEnd := '';
    end if;
    v_ret := PKG_IDCCONFIG.AddIspPolicyRuleNotCommit(v_commandId,
                                                     0,
                                                     p_subType,
                                                     p_valueStart,
                                                     v_valueEnd,
                                                     v_keyRange,
                                                     -2);
    commit;
    RETURN SUCC_CODE;
  END;

 --获取全部[国家标准地区码]清单
  FUNCTION F_getChinaAreaAllList(
     out_curList       OUT C_CURSOR--返回清单
  )RETURN NUMBER
  AS
  BEGIN
     OPEN out_curList FOR
        SELECT * FROM dic_chinaarea
           ORDER BY areacode;

     RETURN SUCC_CODE;

  END F_getChinaAreaAllList;

--同时添加policy,policyRule,MessageNo
FUNCTION addUserOperateLog
(
    p_opCode           IN NUMBER,
    p_opType           IN NUMBER,
    p_seqNo            IN NUMBER,
    p_operId           IN NUMBER,
    p_tableName        IN VARCHAR2,
    p_tableId          IN VARCHAR2
)RETURN NUMBER AS
    v_msg VARCHAR2(5000);
  BEGIN
      v_msg := getRow(p_tableName, p_tableId, p_seqNo); --添加日志

      dpi_setuserlog(p_opCode, p_opType, p_seqNo, v_msg, '', p_operId);

    RETURN SUCC_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END ;

--添加流量镜像策略
  FUNCTION AddPolicyMirror(
         p_mirrorId               IN OUT NUMBER,
         p_messageNo              IN NUMBER,
         p_appType                IN NUMBER,
         p_appId                  IN NUMBER,
         p_startTime              IN NUMBER,
         p_endTime                IN NUMBER,
         p_mirrorPort             IN NUMBER,
         p_mirrorDirection        IN NUMBER,
         p_trafficForward         IN NUMBER,
         p_mirrorSocketLength     IN NUMBER
  ) RETURN INTEGER
  AS
    v_seqno NUMBER(10);
    v_msgnew VARCHAR2(5000);
    v_msgold VARCHAR2(5000);
  BEGIN
    if(p_mirrorId = 0) then
      SELECT seq_dpi_v1_cfg_mirrorid.NEXTVAL INTO p_mirrorId FROM dual;

      v_seqno := PKG_DPICONFIG.MessageSequenceNo(9);

      insert into dpi_v1_cfg_flowmirror(Mirror_id,Message_No,MappType,MappID,M_startTime,M_endTime,M_groupNo,M_Direction,message_sequenceno,Mflowadd,Cutlength)
      values(p_mirrorId,p_messageNo,p_appType,p_appId,p_startTime,p_endTime,p_mirrorPort,p_mirrorDirection,v_seqno,p_trafficForward,p_mirrorSocketLength);
      v_msgnew:=getRow('dpi_v1_cfg_flowmirror','Mirror_id',p_mirrorId);--添加日志
          dpi_setclog(20009,1,p_messageNo,v_seqno,-1);
          dpi_setuserlog(20009,1,p_mirrorId,v_msgnew,'',-1);
    else
      v_msgold:=getRow('dpi_v1_cfg_flowmirror','Mirror_id',p_mirrorId);--操作前日志
      v_seqno := PKG_DPICONFIG.MessageSequenceNo(9);
      update dpi_v1_cfg_flowmirror set M_startTime=p_startTime,M_endTime=p_endTime where Mirror_id=p_mirrorId and Message_No=p_messageNo;
      delete from DPI_V1_CFG_FLOWMIRROR_IP where Mirror_id=p_mirrorId;
      delete from DPI_V1_CFG_FLOWMIRROR_PORT where Mirror_id=p_mirrorId;
      v_msgnew:=getRow('dpi_v1_cfg_flowmirror','Mirror_id',p_mirrorId);--操作后日志

      dpi_setclog(20009,2,p_messageNo,v_seqno,-1);
      dpi_setuserlog(20009,2,p_mirrorId,v_msgnew,v_msgold,-1);
     end if;
     COMMIT;
     RETURN SUCC_CODE;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
      RAISE;
  END;


--删除流量镜像策略
 FUNCTION DelCfgFlowMirror(
                     p_id            IN NUMBER,
                     p_msgno         IN NUMBER
 )
 RETURN INTEGER as
 v_seqno number(10);
 v_msgold VARCHAR2(5000);
 begin

   v_msgold:=getRow('dpi_v1_cfg_flowmirror','Mirror_id',p_id);--操作前日志
   v_seqno := PKG_DPICONFIG.MessageSequenceNo(9);
   UPDATE dpi_v1_cfg_flowmirror SET operatetype=3,message_sequenceno=v_seqno WHERE Mirror_id=p_id;

    dpi_setclog(20009,3,p_msgno,v_seqno,-1);
    dpi_setuserlog(20009,3,p_id,'',v_msgold,-1);

    update dpi_v1_cfg_messageno set opertype=3 where message_no=p_msgno and message_type=9;

    COMMIT;
    RETURN SUCC_CODE;

EXCEPTION
    WHEN OTHERS THEN
       ROLLBACK;
       RAISE;
 END ;

 --添加或者修改用户/应用策略绑定
  FUNCTION AddPolicyBind
  (
    p_id                    IN NUMBER,
    p_msgno                 IN NUMBER,
    p_type                  IN NUMBER,
    p_bindmsgno             IN NUMBER,
    p_groupid               IN NUMBER,
    p_usertype              IN NUMBER,
    p_username              IN VARCHAR2,
    p_operid                IN NUMBER
  )
  RETURN INTEGER AS
  v_id NUMBER := 0;
  v_msgnew VARCHAR2(5000);
  v_msgname VARCHAR2(60);
  v_msgno NUMBER(10);
  v_seqno number(10);
  v_groupId number(10);
  v_groupmold NUMBER(5);
  v_parentbindId NUMBER(10);
  c_cur SYS_REFCURSOR;
  v_ret NUMBER(10);
  v_count NUMBER;
  BEGIN

  select count(*) into v_count from DPI_V1_CFG_USERPOLICYBIND where P_USERGROUP=p_groupid and MESSAGE_TYPE=p_type
  and BINDMESSAGENO =p_bindmsgno and USERTYPE=p_usertype and USERNAME=p_username and MESSAGE_NO = p_msgno and operatetype<>3;

  if v_count>0 then
                RETURN 1;
  end if;

   if p_id=0 then --添加
        IF  p_usertype = 3 THEN

            SELECT group_mold INTO v_groupmold FROM dpi_usergroups WHERE group_id=p_groupid;

           -- IF v_groupmold = 1 OR v_groupmold = 2 THEN

                SELECT to_char(systimestamp,'yyyymmddhh24missff3') || trunc(dbms_random.value(1000,9999)) INTO v_msgname FROM dual;

                -- v_ret := PKG_DPICONFIG.AddMessageNo(133, v_msgname, v_msgno); 统一由程序处理

                select seq_dpi_v1_cfg_bindid.nextval into v_id from dual;

                v_seqno := PKG_DPICONFIG.MessageSequenceNo(133); --统一由程序处理


                insert into DPI_V1_CFG_USERPOLICYBIND(BIND_ID,P_USERGROUP,MESSAGE_TYPE,BINDMESSAGENO,USERTYPE,USERNAME,MESSAGE_NO,operatetype,message_sequenceno, PARENTBINDID)
                values(v_id,p_groupid,p_type,p_bindmsgno,p_usertype,p_username,p_msgno,1,v_seqno, 0);

                v_msgnew:=getRow('DPI_V1_CFG_USERPOLICYBIND','BIND_ID',v_id);--添加日志

                dpi_setclog(20011,1,p_msgno,v_seqno,p_operid);

                dpi_setuserlog(20011,1,v_id,v_msgnew,'',p_operid);

        ELSE

            select seq_dpi_v1_cfg_bindid.nextval into v_id from dual;

            v_seqno := PKG_DPICONFIG.MessageSequenceNo(133);--统一由程序处理

            insert into DPI_V1_CFG_USERPOLICYBIND(BIND_ID,P_USERGROUP,MESSAGE_TYPE,BINDMESSAGENO,USERTYPE,USERNAME,MESSAGE_NO,operatetype,message_sequenceno, PARENTBINDID)
            values(v_id,p_groupid,p_type,p_bindmsgno,p_usertype,p_username,p_msgno,1,v_seqno, 0);

            v_msgnew:=getRow('DPI_V1_CFG_USERPOLICYBIND','BIND_ID',v_id);--添加日志

            dpi_setclog(20011,1,p_msgno,v_seqno,p_operid);

            dpi_setuserlog(20011,1,v_id,v_msgnew,'',p_operid);
        END IF;

    end if;

    commit;
    RETURN SUCC_CODE;

EXCEPTION
  WHEN OTHERS THEN
  ROLLBACK;
  RAISE;
  END;


--删除某一个用户/应用策略绑定
  FUNCTION DeletePolicyBind
  (
      p_id IN NUMBER,
      p_msgno IN NUMBER,
      p_operid       IN NUMBER
  )
  RETURN INTEGER
  AS
  v_seqno number(10);
  v_msgold VARCHAR2(5000):=to_char(p_msgno);--把p_msgno的warning去掉yfs
  v_bindid NUMBER(10);
  v_msgno NUMBER(10);
  c_cur SYS_REFCURSOR;
  BEGIN

      OPEN c_cur FOR
         SELECT bind_id,message_no FROM DPI_V1_CFG_USERPOLICYBIND WHERE bind_id = p_id OR PARENTBINDID=p_id AND operatetype<3;
      LOOP
         FETCH c_cur into v_bindid, v_msgno;
         EXIT WHEN c_cur%notfound;

         v_seqno := PKG_DPICONFIG.MessageSequenceNo(133);
         v_msgold:=getRow('DPI_V1_CFG_USERPOLICYBIND','BIND_ID',v_bindid);--操作前日志
         update DPI_V1_CFG_USERPOLICYBIND  set operatetype=3,message_sequenceno=v_seqno where MESSAGE_NO=v_msgno;--由主键改为message_no

         dpi_setclog(20011,1,v_msgno,v_seqno,p_operid);--应罗贤文要求 将状态改成1添加。便于主动下发
         dpi_setuserlog(20011,3,v_bindid,'',v_msgold,p_operid);

         update dpi_v1_cfg_messageno set opertype=3 where message_no=v_msgno and message_type=133;

      END LOOP;
      CLOSE c_cur;

  commit;

  RETURN SUCC_CODE;

  EXCEPTION
  WHEN OTHERS THEN
  ROLLBACK;
   RAISE;
  END;
END PKG_IDCCONFIG;
/
