CREATE package idc_interface_down_command is

  --处理基础数据管理指令
  procedure DealIdcinfoManage(
                         p_cmdId         in number,
                         p_cmdType       in varchar2,
                         p_queryDayfrom  in varchar2,
                         p_queryDayto    in varchar2,
                         p_idcId         in varchar2,
                         p_userIds       in varchar2,
                         p_houseIds      in varchar2,
                         p_timeStamp     in varchar2,
                         --出参
                         v_out_success   out number
                         );

  --处理信息安全管理指令
  procedure DealIdcManage(
                         p_cmdId in   number,
                         p_timeStamp in   varchar2,
                         p_cmdType in   number,
                         p_actionBlock in   number,
                         p_actionReason in   varchar2,
                         p_actionLog in   number,
                         p_actionReport in   number,
                         p_effectTime in varchar2,
                         p_expiredTime in varchar2,
                         p_privilegeOwner in varchar2,
                         p_privilegeVisible in number,
                         p_idcId in   varchar2,
                         p_houseIds in   varchar2,
                         p_operationType in number,
                         p_levelBinary   in varchar2,
                         p_levelDecimal  in number,
                         p_unbund_flag   in number,
                         --出参
                         v_out_success    out number,
                         v_out_cmdid      out number
                         );

  --处理信息安全管理指令规则表
  procedure AddIdcmngRule(
                         p_cmdId          in   number,
                         p_subType        in   number,
                         p_valueStart     in   varchar2,
                         p_valueEnd       in   varchar2,
                         p_valueStartStr  in   varchar2,
                         p_valueEndStr    in   varchar2,
                         p_keyRange       in   varchar2,
                         p_monitor_cmdId  in   number,
                         --出参
                         v_out_success    out number
                         );

  --处理信息安全管理指令规则表
  procedure DelIdcmngRule(
                         p_cmdId in   number,
                         p_monitor_cmdId in   number,
                         --出参
                         v_out_success    out number
                         );

  --处理访问日志查询指令
  procedure DealLogQuery(
                         p_cmdId in   number,
                         p_idcId in   varchar2,
                         p_houseId in   number,
                         p_startTime in varchar2,
                         p_endTime in varchar2,
                         p_srcStartIp   in varchar2,
                         p_srcEndIp   in varchar2,
                         p_destStartIp  in varchar2,
                         p_destEndIp  in varchar2,
                         p_srcPort    in number,
                         p_dstPort    in number,
                         p_protocolType  in number,
                         p_url        in varchar2,
                         p_timeStamp in   varchar2,
                         --出参
                         v_out_success    out number
                         );

  --处理信息安全管理指令查询指令
  procedure DealIdcmngQuery(
                         p_cmdId in   number,
                         p_idcId in   varchar2,
                         p_houseIds in   varchar2,
                         p_timeStamp in   varchar2,
                         --出参
                         v_out_success    out number
                         );
 --处理基础数据核验处理指令
 procedure dealReturnInfo(
                         p_idcId          in varchar2,
                         p_returnCode     in number,
                         p_returnMsg      in varchar2,
                         p_timeStamp      in varchar2,
                         --出参
                         v_out_success    out number,
                         v_returnInfoId   out number
                         );
 --处理退回机房数据
 procedure dealReturnHouseInfo(
                         p_returnInfoId     in number,
                         p_houseId          in number,
                         p_gatewayId        in number,
                         p_ipsegId          in number,
                         p_frameInfoId      in number,
                         --出参
                         v_out_success      out number
                         );
 --处理退回用户数据
 procedure dealReturnUserInfo(
                         p_returnInfoId         in number,
                         p_userId               in number,
                         p_hhId                 in number,
                         --出参
                         v_out_success          out number,
                         v_returnInfoId         out number
                         );
 --处理退回用户服务数据
 procedure dealReturnUserServiceInfo(
                         p_returnInfoId        in number,
                         p_serviceId           in number,
                         p_domainId            in number,
                         p_hhId                in number,
                         --出参
                         v_out_success         out number
                         );
  --处理免过滤域名列表指令
 procedure dealNoFilter(
                       p_commandId       in number,
                       p_idcId           in varchar2,
                       p_operationType   in number,
                       p_type            in number,
                       p_contents        in varchar2,
                       p_levelBinary     in varchar2,
                       p_levelDecimal    in number,
                       p_timeStamp       in varchar2,
                       p_unbund_flag     in number,
                       --出参
                       v_out_success     out number
                       );
  --处理违法网站列表指令
  procedure dealBlackList(
                       p_commandId       in number,
                       p_idcId           in varchar2,
                       p_operationType   in number,
                       p_type            in number,
                       p_contents        in varchar2,
                       p_levelBinary     in varchar2,
                       p_levelDecimal    in number,
                       p_timeStamp       in varchar2,
                       --出参
                       v_out_success         out number
                       );
  --处理活跃资源访问量查询指令
  procedure dealQueryView(
                       p_commandId       in number,
                       p_idcId           in varchar2,
                       p_type            in number,
                       p_content         in varchar2,
                       p_quryTime        in varchar2,
                       p_timeStamp       in varchar2,
                       --出参
                       v_out_success         out number
                       );
  --处理违法管理指令执行记录指令
  procedure dealCommandRecord(
                       p_commandId       in number,
                       p_idcId           in varchar2,
                       p_controlsId      in number,
                       p_timeStamp       in varchar2,
                       --出参
                       v_out_success         out number
                       );
  --添加数据到指令执行情况表
  procedure AddReplyCmdAck(
                         p_cmdId in   number,
                         p_houseId in   varchar2,
                         p_cmdType in   number,
                         p_retCode in   number,
                         p_msgInfo in   varchar2,
                         p_idcId in   varchar2,
                         p_cmdFileId in   number,
                         --出参
                         v_out_success    out number
                         );
  --监测或过滤策略下发的处理
  procedure dealMonitorFilterPolicy(
                         v_smms_cmdid     in   number,
                         v_command_type   in   number,
                         v_action_block   in   number,
                         v_action_reason  in   varchar2,
                         v_action_log     in   number,
                         p_actionReport   in   number,
                         v_effecttime     in   varchar2,
                         v_expiredtime    in   varchar2,
                         v_idcid          in   varchar2,
                         v_houseIds       in   varchar2,
                         v_opType         in   number,
                         v_unbundFlag     in   number,
                         --出参
                         v_out_success    out number,
                         v_out_cmdid      out number
                         );

  procedure addNoFilterOrBlackList(
                        p_commandId       in number,
                        p_idcId           in varchar2,
                        p_operationType   in number,
                        p_type            in number,
                        p_contents        in varchar2,
                        p_levelDecimal    in number,
                        p_commandType      in number,
                        --出参
                        v_out_success     out number
                        );

end idc_interface_down_command;

/
CREATE package body idc_interface_down_command is

  --处理基础数据管理指令
  procedure DealIdcinfoManage(
                         p_cmdId         in number,
                         p_cmdType       in varchar2,
                         p_queryDayfrom  in varchar2,
                         p_queryDayto    in varchar2,
                         p_idcId         in varchar2,
                         p_userIds       in varchar2,
                         p_houseIds      in varchar2,
                         p_timeStamp     in varchar2,
                         --出参
                         v_out_success   out number
                         )
  as
  v_count number(5);
  v_tmp varchar2(2048);
  v_int  number(10) :=0;
  v_houseid varchar2(256);
  v_out_ret number(5);
  Begin
       begin
          select count(*) into v_count from idc_isms_cmd_idcinfo_manage where commandid=p_cmdId;
          if(v_count=0) then
            insert into idc_isms_cmd_idcinfo_manage
              (commandid, cmd_type, querydayfrom, querydayto,
              idcid, useridlist, houseidlist, timestamp)
            values
              (p_cmdId, p_cmdType, to_date(p_queryDayfrom,'yyyy-mm-dd'),to_date(p_queryDayto,'yyyy-mm-dd'),
              p_idcId, p_userIds, p_houseIds, to_date(p_timeStamp,'yyyy-mm-dd hh24:mi:ss'));

            if(p_cmdType in (1,2)) then
                if(p_houseIds is null or Length(p_houseIds)<1) then
                   v_tmp :='0,';
                else
                   v_tmp := p_houseIds || ',';
                end if;
                loop
                        BEGIN
                          if v_tmp is null or To_Number(Length(v_tmp))<2 then
                                    exit;
                          end if;
                          v_int:= INSTR(v_tmp,',');
                          if(v_int = 0 ) then
                                v_houseid := v_tmp;
                          else
                                v_houseid  := substr(v_tmp,0,v_int-1);
                          end if;
                          AddReplyCmdAck(p_cmdId,v_houseid,3,0,'',p_idcId,0,v_out_ret);

                        END;
                         v_tmp := substr(v_tmp,v_int+1);
                end loop;
            end if;
          end if;
       exception
        WHEN OTHERS THEN
              ROLLBACK;
              v_out_success := 0;
              raise;
       end;
       commit;
       v_out_success:=1;
  end;

  --处理信息安全管理指令
  procedure DealIdcManage(
                         p_cmdId in   number,
                         p_timeStamp in   varchar2,
                         p_cmdType in   number,
                         p_actionBlock in   number,
                         p_actionReason in   varchar2,
                         p_actionLog in   number,
                         p_actionReport in   number,
                         p_effectTime in varchar2,
                         p_expiredTime in varchar2,
                         p_privilegeOwner in varchar2,
                         p_privilegeVisible in number,
                         p_idcId in   varchar2,
                         p_houseIds in   varchar2,
                         p_operationType in number,
                         p_levelBinary   in varchar2,
                         p_levelDecimal  in number,
                         p_unbund_flag   in number,
                         --出参
                         v_out_success    out number,
                         v_out_cmdid      out number
                         )
  as
  v_count number(5);
  v_out   number;
  v_out_ret number(5);
  v_commandid number := 0;
  Begin
       begin
          select count(*) into v_count from idc_isms_cmd_idc_manage where commandid=p_cmdId;
          if(v_count=0) then
            insert into idc_isms_cmd_idc_manage
              (commandid, timestamp, cmd_type, action_block, action_reason, action_log,
              action_report, effecttime, expiredtime, idcid, houseidlist, privilege_owner, privilege_visible,
              operation_type, level_binary, level_decimal)
            values
              (p_cmdId, to_date(p_timeStamp,'yyyy-mm-dd hh24:mi:ss'), p_cmdType, p_actionBlock, p_actionReason, p_actionLog,
              p_actionReport, to_date(p_effectTime,'yyyy-mm-dd hh24:mi:ss'),
              to_date(p_expiredTime,'yyyy-mm-dd hh24:mi:ss'), p_idcId, p_houseIds,
              p_privilegeOwner, p_privilegeVisible, p_operationType, p_levelBinary, p_levelDecimal);
          else
            if(p_operationType=1) then
                update idc_isms_cmd_idc_manage set operation_type=p_operationType where commandid=p_cmdId;
            end if;
          end if;
          AddReplyCmdAck(p_cmdId,p_houseIds,p_cmdType,0,'',p_idcId,0,v_out_ret);
          --添加数据到策略相关表
          /*if (p_unbund_flag = 1) then
              v_commandid := seq_idc_isms_monitorpolicy_id.nextval;
              insert into idc_isms_monitor_policy
                (commandid, message_no, command_type, action_block, action_reason, action_log,
                effecttime, expiredtime, monitor_type, smms_cmdid, idcid, operatetype, message_sequenceno,
                create_time, create_userid, policy_level, policy_state)
              values
                (v_commandid, -1, p_cmdType, p_actionBlock, p_actionReason, p_actionLog,
                date2time_t(to_date(p_effectTime,'yyyy-mm-dd hh24:mi:ss')), date2time_t(to_date(p_expiredTime,'yyyy-mm-dd hh24:mi:ss')),
                1, p_cmdId, p_idcId, p_operationType, -1, sysdate, -1, p_levelDecimal, 2);
              v_out_cmdid := v_commandid;
          else
             idc_isms_monitor_manage.DealMonitorPolicy(p_cmdId,p_cmdType,p_actionBlock,p_actionReason,
                                               p_actionLog,p_actionReport,p_effectTime,p_expiredTime,
                                               p_idcId,p_houseIds,p_operationType,p_levelDecimal,v_out,v_out_cmdid);
          end if;*/
          idc_isms_monitor_manage.DealMonitorPolicy(p_cmdId,p_cmdType,p_actionBlock,p_actionReason,
                                               p_actionLog,p_actionReport,p_effectTime,p_expiredTime,
                                               p_idcId,p_houseIds,p_operationType,p_levelDecimal,v_out,v_out_cmdid);

       exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
       end;
       commit;
       v_out_success:=1;
  end;

  --处理信息安全管理指令规则表
  procedure AddIdcmngRule(
                         p_cmdId               in   number,
                         p_subType             in   number,
                         p_valueStart          in   varchar2,
                         p_valueEnd            in   varchar2,
                         p_valueStartStr       in   varchar2,
                         p_valueEndStr         in   varchar2,
                         p_keyRange            in   varchar2,
                         p_monitor_cmdId       in   number,
                         --出参
                         v_out_success    out number
                         )
  as
  v_valueEnd varchar2(1024);
  Begin
       begin
           if p_subType = 6 or p_subType = 7 then
              if p_valueEnd is null then
                 v_valueEnd := p_valueStart;
               else
                 v_valueEnd := p_valueEnd;
               end if;
           else
           v_valueEnd := p_valueEnd;
           end if;

          insert into idc_isms_cmd_idcmng_rule
            (ruleid, commandid, subtype, valuestart, valueend, keywordrange, valuestartstr, valueendstr)
          values
           (SEQ_ISMS_CMD_IDCMNG_RULEID.Nextval, p_cmdId, p_subType, p_valueStart, v_valueEnd, p_keyRange, p_valueStartStr, p_valueEndStr);

          insert into idc_isms_monitor_policy_rule
            (ruleid, commandid, subtype, valuestart, valueend, keywordrange, valuestartstr, valueendstr)
          values
            (seq_idc_isms_policyrule_id.NEXTVAL,p_monitor_cmdId,p_subType,p_valueStart,v_valueEnd,p_keyRange, p_valueStartStr, p_valueEndStr);

       exception WHEN OTHERS THEN
              ROLLBACK;
              v_out_success := 0;
              raise;
       end;
       commit;
       v_out_success:=1;
  end;

  --处理信息安全管理指令规则表
  procedure DelIdcmngRule(
                         p_cmdId in   number,
                         p_monitor_cmdId in   number,
                         --出参
                         v_out_success    out number
                         )
  as

  Begin

       begin
         delete idc_isms_cmd_idcmng_rule
          where commandid=p_cmdId;

         delete IDC_ISMS_MONITOR_POLICY_RULE
          where COMMANDID=p_monitor_cmdId;

       exception
        WHEN OTHERS THEN
              ROLLBACK;
              v_out_success := 0;
              raise;
       end;
       commit;
       v_out_success:=1;
  end;

  --处理访问日志查询指令
  procedure DealLogQuery(
                         p_cmdId in   number,
                         p_idcId in   varchar2,
                         p_houseId in   number,
                         p_startTime in varchar2,
                         p_endTime in varchar2,
                         p_srcStartIp   in varchar2,
                         p_srcEndIp   in varchar2,
                         p_destStartIp  in varchar2,
                         p_destEndIp  in varchar2,
                         p_srcPort    in number,
                         p_dstPort    in number,
                         p_protocolType  in number,
                         p_url        in varchar2,
                         p_timeStamp in   varchar2,
                         --出参
                         v_out_success    out number
                         )
  as
  v_count number(5);
  Begin

       begin
          select count(*) into v_count from idc_isms_cmd_log_query where commandid=p_cmdId;
          if(v_count=0) then
             insert into idc_isms_cmd_log_query
               (commandid, idcid, houseid, starttime,
               endtime, srcip_start, srcip_end,
               destip_start, destip_end, srcport, dstport, url,
               timestamp, deal_flag, protocoltype)
             values
               (p_cmdId, p_idcId, p_houseId, to_date(p_startTime,'yyyy-mm-dd hh24:mi:ss'),
               to_date(p_endTime,'yyyy-mm-dd hh24:mi:ss'), p_srcStartIp, p_srcEndIp,
               p_destStartIp, p_destEndIp, p_srcPort, p_dstPort, p_url,
               to_date(p_timeStamp,'yyyy-mm-dd hh24:mi:ss'), 0, p_protocolType);
          end if;
       exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
       end;
       commit;
       v_out_success:=1;
  end;

  --处理信息安全管理指令查询指令
  procedure DealIdcmngQuery(
                         p_cmdId in   number,
                         p_idcId in   varchar2,
                         p_houseIds in   varchar2,
                         p_timeStamp in   varchar2,
                         --出参
                         v_out_success    out number
                         )
  as
  v_count number(5);
  Begin

       begin
          select count(*) into v_count from idc_isms_cmd_idcmng_query where commandid=p_cmdId;
          if(v_count=0) then
            insert into idc_isms_cmd_idcmng_query
              (commandid,idcid, houseidlist, timestamp)
            values
              (p_cmdId,p_idcId, p_houseIds, to_date(p_timeStamp,'yyyy-mm-dd hh24:mi:ss'));

          end if;
       exception
        WHEN OTHERS THEN
              ROLLBACK;
              v_out_success := 0;
              raise;
       end;
       commit;
       v_out_success:=1;
  end;

  --处理基础数据核验处理指令
 procedure dealReturnInfo(
                         p_idcId          in varchar2,
                         p_returnCode     in number,
                         p_returnMsg      in varchar2,
                         p_timeStamp      in varchar2,
                         --出参
                         v_out_success    out number,
                         v_returnInfoId   out number
                         )
  as
  Begin
       begin
          select seq_isms_cmd_return_info.nextval into v_returnInfoId from dual;
          insert into idc_isms_cmd_return_info
            (returninfoid, idcid, returncode, retrunmsg, timestamp)
          values
            (v_returnInfoId, p_idcId, p_returnCode, p_returnMsg, to_date(p_timeStamp,'yyyy-mm-dd hh24:mi:ss'));
       exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
       end;
       commit;
       v_out_success:=1;
  end;
  --处理退回机房数据
  procedure dealReturnHouseInfo(
                         p_returnInfoId     in number,
                         p_houseId          in number,
                         p_gatewayId        in number,
                         p_ipsegId          in number,
                         p_frameInfoId      in number,
                         --出参
                         v_out_success      out number
                         )
  as
  Begin
       begin
          insert into idc_isms_cmd_return_house_info
            (returninfoid, houseid, gatewayid, ipsegid, frameinfoid)
          values
            (p_returnInfoId, p_houseId, p_gatewayId, p_ipsegId, p_frameInfoId);
       exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
       end;
       commit;
       v_out_success:=1;
  end;
  --处理退回用户数据
  procedure dealReturnUserInfo(
                         p_returnInfoId         in number,
                         p_userId               in number,
                         p_hhId                 in number,
                         --出参
                         v_out_success          out number,
                         v_returnInfoId         out number
                         )
  as
  Begin
       begin
           v_returnInfoId := p_returnInfoId;
           insert into idc_isms_cmd_return_user_info
             (returninfoid, userid, hhid)
           values
             (v_returnInfoId, p_userId, p_hhId);
       exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
       end;
       commit;
       v_out_success:=1;
  end;
  --处理退回用户服务数据
  procedure dealReturnUserServiceInfo(
                         p_returnInfoId         in number,
                         p_serviceId           in number,
                         p_domainId            in number,
                         p_hhId                in number,
                         --出参
                         v_out_success         out number
                         )
  as
  Begin
       begin
          insert into idc_isms_cmd_return_us_info
            (returninfoid, serviceid, domainid, hhid)
          values
            (p_returnInfoId, p_serviceId, p_domainId, p_hhId);
       exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
       end;
       commit;
       v_out_success:=1;
  end;

  --处理免过滤域名列表指令
  procedure dealNoFilter(
                       p_commandId       in number,
                       p_idcId           in varchar2,
                       p_operationType   in number,
                       p_type            in number,
                       p_contents        in varchar2,
                       p_levelBinary     in varchar2,
                       p_levelDecimal    in number,
                       p_timeStamp       in varchar2,
                       p_unbund_flag     in number,
                       --出参
                       v_out_success     out number
                       )
  as
  v_count number;
  v_out_ret number(5);
  v_policy_state number(5) := 1;
  Begin
       begin
          select count(*) into v_count from idc_isms_cmd_no_filter t where t.commandid = p_commandId;
          if(v_count = 0) then
              if (p_unbund_flag = 1) then
                 v_policy_state := 2;
              end if;
              insert into idc_isms_cmd_no_filter
                (commandid, idcid, operationtype, commandtype, content, timestamp,
                level_binary, level_decimal, policy_state)
              values
                (p_commandId, p_idcId, p_operationType, p_type, trim(p_contents), to_date(p_timeStamp,'yyyy-mm-dd hh24:mi:ss'),
                p_levelBinary, p_levelDecimal, v_policy_state);
          else
             if(p_operationType = 1) then
                update idc_isms_cmd_no_filter t set t.operationtype = p_operationType where t.commandid = p_commandId;
             end if;
          end if;
          --添加指令执行情况记录
          AddReplyCmdAck(p_commandId, 0, 5, 0, '' , p_idcId , 0 , v_out_ret);
          --添加免过滤网站列表指令策略
          addNoFilterOrBlackList(p_commandId, p_idcId, p_operationType, p_type, p_contents, p_levelDecimal, 5, v_out_success);
       exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
       end;
       commit;
       v_out_success:=1;
  end;

  --处理违法网站列表指令
  procedure dealBlackList(
                       p_commandId       in number,
                       p_idcId           in varchar2,
                       p_operationType   in number,
                       p_type            in number,
                       p_contents        in varchar2,
                       p_levelBinary     in varchar2,
                       p_levelDecimal    in number,
                       p_timeStamp       in varchar2,
                       --出参
                       v_out_success         out number
                       )
  as
  v_count number;
  v_out_ret number(5);
  v_commandId number;
  v_policyId number;
  v_message_no number := 0;
  v_func_ret      number;
  Begin
       begin
          select count(*) into v_count from idc_isms_cmd_black_list t where t.commandid = p_commandId;
          if(v_count = 0) then
              insert into idc_isms_cmd_black_list
                (commandid, idcid, operationtype, commandtype, content, timestamp,
                level_binary, level_decimal)
              values
                (p_commandId, p_idcId, p_operationType, p_type, trim(p_contents), to_date(p_timeStamp,'yyyy-mm-dd hh24:mi:ss'),
                p_levelBinary, p_levelDecimal);
          else
             if(p_operationType = 1) then
                update idc_isms_cmd_black_list t set t.operationtype = p_operationType where t.commandid = p_commandId;
             end if;
          end if;
          --添加指令执行情况记录
          AddReplyCmdAck(p_commandId, 0, 6, 0, '' , p_idcId , 0 , v_out_ret);
          --添加违法网站列表指令策略
          addNoFilterOrBlackList(p_commandId, p_idcId, p_operationType, p_type, p_contents, p_levelDecimal, 6, v_out_success);
       exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
       end;
       commit;
       v_out_success:=1;
  end;

  --处理活跃资源访问量查询指令
  procedure dealQueryView(
                       p_commandId       in number,
                       p_idcId           in varchar2,
                       p_type            in number,
                       p_content         in varchar2,
                       p_quryTime        in varchar2,
                       p_timeStamp       in varchar2,
                       --出参
                       v_out_success         out number
                       )
  as
  v_count number;
  v_out_ret number(5);
  Begin
       begin
          select count(*) into v_count from idc_isms_cmd_query_view t where t.commandid = p_commandId;
          if(v_count = 0) then
             insert into idc_isms_cmd_query_view
               (commandid, idcid, querytype, content, querytime, timestamp)
             values
               (p_commandId, p_idcId, p_type, trim(p_content),
               to_date(p_quryTime,'yyyy-mm-dd hh24:mi:ss'), to_date(p_timeStamp,'yyyy-mm-dd hh24:mi:ss'));
          else
             update idc_isms_cmd_query_view
                set idcid = p_idcId,
                    querytype = p_type,
                    content = trim(p_content),
                    querytime = to_date(p_quryTime,'yyyy-mm-dd hh24:mi:ss'),
                    timestamp = to_date(p_timeStamp,'yyyy-mm-dd hh24:mi:ss')
              where commandid = p_commandId;
          end if;
          --添加指令执行情况记录
          AddReplyCmdAck(p_commandId, 0, 7, 0, '' , p_idcId , 0 , v_out_ret);
       exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
       end;
       commit;
       v_out_success:=1;
  end;

  --处理违法管理指令执行记录指令
  procedure dealCommandRecord(
                       p_commandId       in number,
                       p_idcId           in varchar2,
                       p_controlsId      in number,
                       p_timeStamp       in varchar2,
                       --出参
                       v_out_success         out number
                       )
  as
  v_count number;
  v_out_ret number(5);
  v_houseIds varchar(128);
  Begin
       begin
          select count(*) into v_count from idc_isms_cmd_command_record t where t.commandid = p_commandId;
          if(v_count = 0) then
             insert into idc_isms_cmd_command_record
               (commandid, idcid, controlsid, timestamp)
             values
               (p_commandId, p_idcId, p_controlsId, to_date(p_timeStamp,'yyyy-mm-dd hh24:mi:ss'));
          else
             update idc_isms_cmd_command_record
                set idcid = p_idcId,
                    controlsid = p_controlsId,
                    timestamp = to_date(p_timeStamp,'yyyy-mm-dd hh24:mi:ss')
              where commandid = p_commandId;
          end if;
          --根据p_controlsId违法信息安全管理指令id去查询idc_isms_cmd_idc_manage表的机房信息
          select manage.houseidlist into v_houseIds from idc_isms_cmd_idc_manage manage
          where manage.commandid = p_controlsId;
          --添加指令执行情况记录
          if (v_houseIds is not null) then
             AddReplyCmdAck(p_commandId, v_houseIds, 8, 0, '' , p_idcId , 0 , v_out_ret);
          else
             AddReplyCmdAck(p_commandId, 0, 8, 0, '' , p_idcId , 0 , v_out_ret);
          end if;
       exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
       end;
       commit;
       v_out_success:=1;
  end;

  --添加数据到指令执行情况表
  procedure AddReplyCmdAck(
                         p_cmdId in   number,
                         p_houseId in   varchar2,
                         p_cmdType in   number,
                         p_retCode in   number,
                         p_msgInfo in   varchar2,
                         p_idcId in   varchar2,
                         p_cmdFileId in   number,
                         --出参
                         v_out_success    out number
                         )
  as
  v_count number(5);
  Begin

       begin
           insert into idc_isms_reply_cmd_ack
             (ackid,commandid, houseid, cmd_type, result_code, msginfo, idcid, commandfileid, timestamp,deal_flag)
           values
             (Seq_idc_isms_cmd_ack.Nextval,p_cmdId, p_houseId, p_cmdType, p_retCode,p_msgInfo,p_idcId,p_cmdFileId, sysdate,0);
          /*select count(*) into v_count from idc_isms_reply_cmd_ack where commandid=p_cmdId and cmd_type = p_cmdType;
           v_tmp := p_houseId || ',';
            loop
                 BEGIN
                      if v_tmp is null or To_Number(Length(v_tmp))<2 then
                         exit;
                      end if;
                      v_int:= INSTR(v_tmp,',');
                      if(v_int = 0 ) then
                            v_houseid := v_tmp;
                      else
                            v_houseid  := substr(v_tmp,0,v_int-1);
                      end if;

                     select count(*) into v_count1 from idc_isms_base_house where houseid=v_houseid;
                     if((v_count1>0 and v_count=0) or v_houseid = 0) then
                        insert into idc_isms_reply_cmd_ack
                          (commandid, houseid, cmd_type, result_code, msginfo, idcid, commandfileid, timestamp,deal_flag)
                        values
                          (p_cmdId,v_houseid,p_cmdType,p_retCode,p_msgInfo,p_idcId,p_cmdFileId, sysdate,0);
                     else
                        update idc_isms_reply_cmd_ack
                               set timestamp=sysdate,
                                   deal_flag=0
                        where commandid = p_cmdId and houseid in (select houseid from idc_isms_base_house);
                     end if;
                 END;
                 v_tmp := substr(v_tmp,v_int+1);
            end loop;*/
       exception WHEN OTHERS THEN
          ROLLBACK;
          v_out_success := 0;
          raise;
       end;
       commit;
       v_out_success:=1;
  end;

  procedure dealMonitorFilterPolicy(
                         v_smms_cmdid        in   number,
                         v_command_type      in   number,
                         v_action_block      in   number,
                         v_action_reason     in   varchar2,
                         v_action_log        in   number,
                         p_actionReport      in   number,
                         v_effecttime        in   varchar2,
                         v_expiredtime       in   varchar2,
                         v_idcid             in   varchar2,
                         v_houseIds          in   varchar2,
                         v_opType            in   number,
                         v_unbundFlag        in   number,
                         --出参
                         v_out_success       out  number,
                         v_out_cmdid         out  number
  ) as
  begin
      if (v_unbundFlag = 1) then
         --添加数据到策略相关表
          idc_isms_monitor_manage.DealMonitorPolicy(
                         v_smms_cmdid,
                         v_command_type,
                         v_action_block,
                         v_action_reason,
                         v_action_log,
                         p_actionReport,
                         v_effecttime,
                         v_expiredtime,
                         v_idcid,
                         v_houseIds,
                         v_opType,
                         1024,
                         v_out_success,
                         v_out_cmdid);
      end if;
  end;

  procedure addNoFilterOrBlackList(
                        p_commandId       in number,
                        p_idcId           in varchar2,
                        p_operationType   in number,
                        p_type            in number,
                        p_contents        in varchar2,
                        p_levelDecimal    in number,
                        p_commandType      in number,
                        --出参
                        v_out_success     out number
  ) as
    v_effecttime date;
    v_expiredtime date;
    v_effecttimeStr varchar2(60);
    v_expiredtimeStr varchar2(60);
    v_out number;
    v_out_cmdid number;
    v_commandType number;
    v_actionBlock number;
  Begin
    begin
      select sysdate,sysdate + interval '1' year into v_effecttime,v_expiredtime from dual;
      v_effecttimeStr:= to_char(v_effecttime,'yyyy-mm-dd hh24:mi:ss');
      v_expiredtimeStr := to_char(v_expiredtime,'yyyy-mm-dd hh24:mi:ss');
      if (p_commandType = 5) then
         v_actionBlock := 0;
      elsif (p_commandType = 6) then
         v_actionBlock := 1;
      end if;
      --添加策略
      idc_isms_monitor_manage.DealMonitorPolicy(
                                                p_commandId,
                                                p_commandType,
                                                v_actionBlock,
                                                '',
                                                1,
                                                1,
                                                v_effecttimeStr,
                                                v_expiredtimeStr,
                                                p_idcId,
                                                null,
                                                p_operationType,
                                                p_levelDecimal,
                                                v_out,
                                                v_out_cmdid);
      --添加规则
      if v_out = 1 then
        if p_type = 1 then
           AddIdcmngRule(p_commandId, 1, p_contents, null, null, null, null, v_out_cmdid, v_out_success);
        end if;
        if p_type = 2 then
           AddIdcmngRule(p_commandId, 5, p_contents, p_contents, ip2int(p_contents), ip2int(p_contents), null, v_out_cmdid, v_out_success);
        end if;
      end if;
      exception WHEN OTHERS THEN
        ROLLBACK;
        v_out_success := 0;
        raise;
    end;
    commit;
    v_out_success:=1;
  end;

end idc_interface_down_command;

/
