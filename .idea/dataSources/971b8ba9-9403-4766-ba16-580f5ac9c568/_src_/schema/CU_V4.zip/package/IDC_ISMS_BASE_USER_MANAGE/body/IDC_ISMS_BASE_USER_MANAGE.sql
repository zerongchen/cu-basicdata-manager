CREATE package body IDC_ISMS_BASE_USER_MANAGE is
        procedure prelist_user_information(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_nature in NUMBER,
            p_unitName in VARCHAR2,
            p_userCode in VARCHAR2,
            p_unitNature in number,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            p_officerName in VARCHAR2,
            p_officerIdType in NUMBER,
            p_officerId in VARCHAR2,
            p_officerTelephone in VARCHAR2,
            p_officerMobile in VARCHAR2,
            p_officerEmail in VARCHAR2,
            p_unitAddress in VARCHAR2,
            p_unitZipCode in varchar2,
            p_registeTimeS in VARCHAR2,
            p_registeTimeE in VARCHAR2,
            p_serviceRegTimeS in VARCHAR2,
            p_serviceRegTimeE in VARCHAR2,
            p_otherCondition in varchar2,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_czlx in number,
            p_userLevel in number,
            p_identify in number,
            p_houseId  in varchar2
         ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(4000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(8000); --条件语句
             v_count     varchar2(8000); --统计记录总数语句
             v_sql       varchar2(8000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
             v_innersql := ' from PRE_IDC_ISMS_BASE_USER ';
            v_field    := 'CLIENTID,DATADATE,IS_ABNORMAL,ABNORMAL_INFORMATION,OPERTYPE, USERCODE, userid, nature, identify,unitname, unitnature, idtype, idnumber, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, unitadd, unitaddprovincec, unitaddprovincen, unitaddcityc, unitaddcityn, unitaddareac, unitaddarean, zipcode, registertime, czlx, deal_flag, create_time, update_time, create_userid, INFO_COMPLETE,SERVERREGISTERTIME,DEL_FLAG, SUBORDINATEUNIT_AREACODE ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' CLIENTID DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if (p_jyzId > 0) then
                v_condition := v_condition || ' and jyzId = ' || p_jyzId ;
            end if;
            if (p_nature > 0) then
                v_condition := v_condition || ' and nature = ' || p_nature ;
            end if;
            if (p_unitName is not null ) then
                v_condition := v_condition || ' and unitname like ''%' || p_unitName || '%''' ;
            end if;
            if  (p_identify >0) then
                v_condition := v_condition || ' and identify = '|| p_identify ;
             end if;
             if (p_userCode is not null ) then
                v_condition := v_condition || ' and usercode like ''%' || p_userCode || '%''' ;
            end if;
            if (p_unitNature > 0) then
                v_condition := v_condition || ' and unitnature = ' || p_unitNature ;
            end if;
            if (p_idType > 0) then
                v_condition := v_condition || ' and idtype = ' || p_idType ;
            end if;
            if (p_idNumber is not null) then
                v_condition := v_condition || ' and idnumber like ''%' || p_idNumber || '%''' ;
            end if;
            if (p_officerName is not null) then
                v_condition := v_condition || ' and officer_name like ''%' || p_officerName || '%''' ;
            end if;
            if (p_officerIdType > 0) then
                v_condition := v_condition || ' and officer_idtype = ' || p_officerIdType ;
            end if;
            if (p_officerId  is not null) then
                v_condition := v_condition || ' and officer_id like ''%' || p_officerId || '%''' ;
            end if;
            if (p_officerTelephone is not null) then
                v_condition := v_condition || ' and officer_tel like ''%' || p_officerTelephone || '%''' ;
            end if;
            if (p_officerMobile is not null) then
                v_condition := v_condition || ' and officer_mobile like ''%' || p_officerMobile || '%''' ;
            end if;
            if (p_officerEmail is not null) then
                v_condition := v_condition || ' and officer_email like ''%' || p_officerEmail || '%''' ;
            end if;
            if (p_unitAddress is not null) then
                v_condition := v_condition || ' and unitadd like ''%' || p_unitAddress || '%''' ;
            end if;
            if (p_unitZipCode is not null) then
                v_condition := v_condition || ' and zipcode like ''%' || p_unitZipCode || '%''' ;
            end if;
            if (p_registeTimeS is not null) then
                v_condition := v_condition || ' and registertime  >= ''' || p_registeTimeS || '''';
            end if;
            if (p_registeTimeE is not null) then
                v_condition := v_condition || ' and registertime <= ''' || p_registeTimeE || '''';
            end if;
            if (p_serviceRegTimeS is not null) then
                v_condition := v_condition || ' and SERVERREGISTERTIME >= ''' || p_serviceRegTimeS || '''';
            end if;
            if (p_serviceRegTimeE is not null) then
                v_condition := v_condition || ' and SERVERREGISTERTIME <= ''' || p_serviceRegTimeE || '''';
            end if;
            if(p_otherCondition  is not null) then
                v_condition := v_condition || p_otherCondition;
            end if;
            if p_dealFlag >= 0 then
                v_condition := v_condition || ' and DEAL_FLAG = ' || p_dealFlag;
            end if;
            if p_czlx >0  then
                v_condition := v_condition || ' and czlx = ' || p_czlx;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                DBMS_OUTPUT.put_line(v_count);
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;

        procedure list_user_information(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_nature in NUMBER,
            p_unitName in VARCHAR2,
            p_userCode in VARCHAR2,
            p_unitNature in number,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            p_officerName in VARCHAR2,
            p_officerIdType in NUMBER,
            p_officerId in VARCHAR2,
            p_officerTelephone in VARCHAR2,
            p_officerMobile in VARCHAR2,
            p_officerEmail in VARCHAR2,
            p_unitAddress in VARCHAR2,
            p_unitZipCode in varchar2,
            p_registeTimeS in VARCHAR2,
            p_registeTimeE in VARCHAR2,
            p_serviceRegTimeS in VARCHAR2,
            p_serviceRegTimeE in VARCHAR2,
            p_otherCondition in varchar2,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_czlx in number,
            p_userLevel in number,
            p_identify in number,
            p_houseId  in varchar2,
            p_infoComplete in varchar2
         ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(4000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(8000); --条件语句
             v_count     varchar2(8000); --统计记录总数语句
             v_sql       varchar2(8000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            if (p_houseId is not null) then
                     v_innersql := ' from (select USERCODE, userid, identify,a.jyzid, idcname, nature, unitname, unitnature, idtype, idnumber, a.officer_name, a.officer_idtype, a.officer_id, a.officer_tel, a.officer_mobile, a.officer_email, unitadd, unitaddprovincec, unitaddprovincen, unitaddcityc, unitaddcityn, unitaddareac, unitaddarean, zipcode, registertime, a.czlx, a.deal_flag, a.create_time, a.update_time, a.create_userid,a.DEL_FLAG,a.INFO_COMPLETE,SERVERREGISTERTIME, SUBORDINATEUNIT_AREACODE ' ||
                                       ' from (select * from idc_isms_base_user where userid in (select userid from idc_isms_base_user_hh where del_flag=0 and split_areacode(SUBORDINATEUNIT_AREACODE,'''||p_areaCode||''')=1 and houseid in ('||p_houseId||')))  a ' ||
                                       ' left join idc_isms_base_idc b on a.jyzid = b.jyzid) ';
            else
                     v_innersql := ' from (select USERCODE, userid, identify,a.jyzid, idcname, nature, unitname, unitnature, idtype, idnumber, a.officer_name, a.officer_idtype, a.officer_id, a.officer_tel, a.officer_mobile, a.officer_email, unitadd, unitaddprovincec, unitaddprovincen, unitaddcityc, unitaddcityn, unitaddareac, unitaddarean, zipcode, registertime, a.czlx, a.deal_flag, a.create_time, a.update_time, a.create_userid,a.DEL_FLAG,a.INFO_COMPLETE,SERVERREGISTERTIME, SUBORDINATEUNIT_AREACODE ' ||
                                       ' from idc_isms_base_user a left join idc_isms_base_idc b on a.jyzid = b.jyzid )';
            end if;

            v_field    := ' USERCODE, userid, jyzid, idcname, nature, identify,unitname, unitnature, idtype, idnumber, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, unitadd, unitaddprovincec, unitaddprovincen, unitaddcityc, unitaddcityn, unitaddareac, unitaddarean, zipcode, registertime, czlx, deal_flag, create_time, update_time, create_userid, INFO_COMPLETE,SERVERREGISTERTIME,DEL_FLAG, SUBORDINATEUNIT_AREACODE ';
            v_order := ' ORDER BY info_complete asc,';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' userid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if (p_jyzId > 0) then
                v_condition := v_condition || ' and jyzId = ' || p_jyzId ;
            end if;
            if (p_nature > 0) then
                v_condition := v_condition || ' and nature = ' || p_nature ;
            end if;
            if (p_unitName is not null ) then
                v_condition := v_condition || ' and unitname like ''%' || p_unitName || '%''' ;
            end if;
            if  (p_identify >0) then
                v_condition := v_condition || ' and identify = '|| p_identify ;
             end if;
             if (p_userCode is not null ) then
                v_condition := v_condition || ' and usercode like ''%' || p_userCode || '%''' ;
            end if;
            if (p_unitNature > 0) then
                v_condition := v_condition || ' and unitnature = ' || p_unitNature ;
            end if;
            if (p_idType > 0) then
                v_condition := v_condition || ' and idtype = ' || p_idType ;
            end if;
            if (p_idNumber is not null) then
                v_condition := v_condition || ' and idnumber like ''%' || p_idNumber || '%''' ;
            end if;
            if (p_officerName is not null) then
                v_condition := v_condition || ' and officer_name like ''%' || p_officerName || '%''' ;
            end if;
            if (p_officerIdType > 0) then
                v_condition := v_condition || ' and officer_idtype = ' || p_officerIdType ;
            end if;
            if (p_officerId  is not null) then
                v_condition := v_condition || ' and officer_id like ''%' || p_officerId || '%''' ;
            end if;
            if (p_officerTelephone is not null) then
                v_condition := v_condition || ' and officer_tel like ''%' || p_officerTelephone || '%''' ;
            end if;
            if (p_officerMobile is not null) then
                v_condition := v_condition || ' and officer_mobile like ''%' || p_officerMobile || '%''' ;
            end if;
            if (p_officerEmail is not null) then
                v_condition := v_condition || ' and officer_email like ''%' || p_officerEmail || '%''' ;
            end if;
            if (p_unitAddress is not null) then
                v_condition := v_condition || ' and unitadd like ''%' || p_unitAddress || '%''' ;
            end if;
            if (p_unitZipCode is not null) then
                v_condition := v_condition || ' and zipcode like ''%' || p_unitZipCode || '%''' ;
            end if;
            if (p_registeTimeS is not null) then
                v_condition := v_condition || ' and registertime  >= ''' || p_registeTimeS || '''';
            end if;
            if (p_registeTimeE is not null) then
                v_condition := v_condition || ' and registertime <= ''' || p_registeTimeE || '''';
            end if;
            if (p_serviceRegTimeS is not null) then
                v_condition := v_condition || ' and SERVERREGISTERTIME >= ''' || p_serviceRegTimeS || '''';
            end if;
            if (p_serviceRegTimeE is not null) then
                v_condition := v_condition || ' and SERVERREGISTERTIME <= ''' || p_serviceRegTimeE || '''';
            end if;
            --隶属单位条件查询
            if (p_areaCode is not null) then
               v_condition := v_condition || ' and split_areacode(SUBORDINATEUNIT_AREACODE,'''||p_areaCode||''')=1';
            end if;
            if(p_otherCondition  is not null) then
                v_condition := v_condition || p_otherCondition;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and DEL_FLAG = ' || p_delFlag;
            end if;
            if p_dealFlag >= 0 then
                v_condition := v_condition || ' and DEAL_FLAG = ' || p_dealFlag;
            end if;
            if p_czlx >0  then
                v_condition := v_condition || ' and czlx = ' || p_czlx;
            end if;
            if (p_infoComplete is not null) then
                v_condition := v_condition || ' and INFO_COMPLETE  = ''' || p_infoComplete || '''' ;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                DBMS_OUTPUT.put_line(v_count);
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --用户查询列表的数据查询
         procedure user_query_list_information(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_nature in NUMBER,
            p_unitName in VARCHAR2,
            p_unitNature in VARCHAR2,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            p_officerName in VARCHAR2,
            p_officerIdType in NUMBER,
            p_officerId in VARCHAR2,
            p_officerTelephone in VARCHAR2,
            p_officerMobile in VARCHAR2,
            p_officerEmail in VARCHAR2,
            p_unitAddress in VARCHAR2,
            p_unitZipCode in NUMBER,
            p_registeTime in VARCHAR2,
            p_otherCondition in varchar2 --其它而外的查询条件
         ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_hist_base_user ';
            v_field    := ' histid,userid, jyzid, nature, unitname, unitnature, idtype, idnumber, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, unitadd, zipcode, registertime, create_time, update_time, create_userid ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' userid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_jyzId  is not null ) then
                v_condition := v_condition || ' and jyzId = ' || p_jyzId ;
            end if;
            if(p_nature  is not null ) then
                v_condition := v_condition || ' and nature = ' || p_nature ;
            end if;
            if(p_unitName is not null ) then
                v_condition := v_condition || ' and unitname like ''%' || p_unitName || '%''' ;
            end if;
            if(p_unitNature  is not null ) then
                v_condition := v_condition || ' and unitnature = ' || p_unitNature ;
            end if;
            if(p_idType  is not null ) then
                v_condition := v_condition || ' and idtype = ' || p_idType ;
            end if;
            if(p_idNumber is not null ) then
                v_condition := v_condition || ' and idnumber like ''%' || p_idNumber || '%''' ;
            end if;
            if(p_officerName is not null ) then
                v_condition := v_condition || ' and officer_name like ''%' || p_officerName || '%''' ;
            end if;
            if(p_officerIdType is not null ) then
                v_condition := v_condition || ' and officer_idtype = ' || p_officerIdType ;
            end if;
            if(p_officerId  is not null ) then
                v_condition := v_condition || ' and officer_id like ''%' || p_officerId || '%''' ;
            end if;
            if(p_officerTelephone is not null ) then
                v_condition := v_condition || ' and officer_tel like ''%' || p_officerTelephone || '%''' ;
            end if;
            if(p_officerMobile is not null ) then
                v_condition := v_condition || ' and officer_mobile like ''%' || p_officerMobile || '%''' ;
            end if;
            if(p_officerEmail is not null ) then
                v_condition := v_condition || ' and officer_email like ''%' || p_officerEmail || '%''' ;
            end if;
            if(p_unitAddress is not null ) then
                v_condition := v_condition || ' and unitadd like ''%' || p_unitAddress || '%''' ;
            end if;
            if(p_unitZipCode is not null ) then
                v_condition := v_condition || ' and zipcode like ''%' || p_unitZipCode || '%''' ;
            end if;
            if(p_registeTime   is not null ) then
                v_condition := v_condition || ' and registertime like ''%' || p_registeTime || '%''' ;
            end if;
            if(p_otherCondition  is not null ) then
                v_condition := v_condition || p_otherCondition;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

        procedure prelist_user_service_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_userId in NUMBER,
            p_serviceContent in VARCHAR2,
            p_unitName in VARCHAR2,
            p_business in NUMBER,
            p_domainName in varchar2,
            p_registerId in VARCHAR2,
            p_setmode in NUMBER,
            p_otherCondition in varchar2,
            p_delFlag in number,
            p_dealFlag in number,
            p_userHouseIDStrs in varchar2,
            p_userLevel in number,
            p_houseId in varchar2
        ) is
             --定义
             v_field     varchar2(2000); --字段
             v_secondField varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;

            --内部sql语句
            v_innersql := '   from PRE_IDC_ISMS_BASE_USER_SERVICE a
                  left join PRE_IDC_ISMS_BASE_USER b on a.CLIENTID = b.CLIENTID ';
            v_field    := 'DATADATE,IS_ABNORMAL,ABNORMAL_INFORMATION,CLIENTID,SERVERIDSTR, serviceid, servicecontent, SERVICETYPE,regid, regtype, setmode, BUSINESS,userid, czlx, deal_flag, create_time, update_time,INFO_COMPLETE,DEL_FLAG,UNITNAME,SUBORDINATEUNIT_AREACODE ';
            v_secondField := 'a.DATADATE,a.IS_ABNORMAL,a.ABNORMAL_INFORMATION,a.CLIENTID, a.SERVERIDSTR, a.serviceid, servicecontent, SERVICETYPE,regid, regtype, setmode, BUSINESS,a.userid, a.czlx, a.deal_flag, a.create_time, a.update_time,a.INFO_COMPLETE,a.DEL_FLAG,UNITNAME,a.SUBORDINATEUNIT_AREACODE ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' SERVERIDSTR DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if (p_userId  is not null) then
                v_condition := v_condition || ' and a.userid = ' || p_userId ;
            end if;
            if (p_serviceContent  is not null ) then
                v_condition := v_condition || ' and a.servicecontent like ''%' || p_serviceContent || '%''' ;
            end if;
            if (p_registerId is not null) then
                v_condition := v_condition || ' and a.regid like ''%' || p_registerId || '%''' ;
            end if;
            if (p_unitName is not null) then
                v_condition := v_condition || ' and unitName like ''%' || p_unitName || '%''' ;
            end if;
            if (p_business is not null) then
                v_condition := v_condition || ' and a.business like ''%' || p_business || '%''' ;
            end if;
            if (p_domainName is not null) then
                v_condition := v_condition || ' and a.serviceid in (' || p_domainName ||')' ;
            end if;
            if (p_setmode is not null) then
                v_condition := v_condition || ' and a.setmode = ' || p_setmode ;
            end if;
            if (p_otherCondition  is not null) then
                v_condition := v_condition || p_otherCondition;
            end if;
            if (p_dealFlag is not null) then
                v_condition := v_condition || ' and a.DEAL_FLAG = ' || p_dealFlag;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    dbms_output.put_line(v_sql);
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;

        procedure list_user_service_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_userId in NUMBER,
            p_serviceContent in VARCHAR2,
            p_unitName in VARCHAR2,
            p_business in NUMBER,
            p_domainName in varchar2,
            p_registerId in VARCHAR2,
            p_setmode in NUMBER,
            p_otherCondition in varchar2,
            p_delFlag in number,
            p_dealFlag in number,
            p_userHouseIDStrs in varchar2,
            p_userLevel in number,
            p_houseId in varchar2
        ) is
             --定义
             v_field     varchar2(2000); --字段
             v_secondField varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;

            --内部sql语句
            --v_innersql := ' from idc_isms_base_user_service a left join IDC_ISMS_BASE_USER b on a.USERID = b.USERID left join idc_isms_base_service_domain c on a.serviceid = c.serviceid ';
            if p_userHouseIDStrs is not null then
               --if p_userLevel <=2 then--管理员登陆
                v_innersql := '   from (select  a.*,b.unitname from idc_isms_base_user_service a
                 left join IDC_ISMS_BASE_USER b on a.USERID = b.USERID  ) a ';
                --else
                -- v_innersql := '   from (select  a.*,b.unitname from (select distinct * from idc_isms_base_user_service where userid in (select userid from idc_isms_base_user where userid not in (select userid from idc_isms_base_user_hh) and split_areacode(SUBORDINATEUNIT_AREACODE,'''||p_userHouseIDStrs||''')=1 union select userid from idc_isms_base_user where userid in (select userid from idc_isms_base_user_hh where houseid in ('||p_houseId||')) )
                 --) a left join IDC_ISMS_BASE_USER b on a.USERID = b.USERID ) a ';
                -- end if;

              else
                  v_innersql := '   from (select a.*,b.unitname from (select distinct * from idc_isms_base_user_service where serviceid in (select serviceid from idc_isms_base_service_hh where 1!=1)
                 ) a left join IDC_ISMS_BASE_USER b on a.USERID = b.USERID ) a ';
              end if;
            v_field    := ' serviceid, servicecontent, SERVICETYPE,regid, regtype, setmode, BUSINESS,userid, czlx, deal_flag, create_time, update_time,INFO_COMPLETE,DEL_FLAG,UNITNAME,SUBORDINATEUNIT_AREACODE ';
            v_secondField := 'distinct a.serviceid, servicecontent, SERVICETYPE,regid, regtype, setmode, BUSINESS,a.userid, a.czlx, a.deal_flag, a.create_time, a.update_time,a.INFO_COMPLETE,a.DEL_FLAG,UNITNAME,a.SUBORDINATEUNIT_AREACODE ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' serviceid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';

            if (p_userHouseIDStrs is not null ) then
                v_condition := v_condition || ' and split_areacode(a.SUBORDINATEUNIT_AREACODE,''' ||p_userHouseIDStrs||''')=1 ';
            end if;
            if (p_userId  is not null) then
                v_condition := v_condition || ' and a.userid = ' || p_userId ;
            end if;
            if (p_serviceContent  is not null ) then
                v_condition := v_condition || ' and a.servicecontent like ''%' || p_serviceContent || '%''' ;
            end if;
            if (p_registerId is not null) then
                v_condition := v_condition || ' and a.regid like ''%' || p_registerId || '%''' ;
            end if;
            if (p_unitName is not null) then
                v_condition := v_condition || ' and unitName like ''%' || p_unitName || '%''' ;
            end if;
            if (p_business is not null) then
                v_condition := v_condition || ' and a.business like ''%' || p_business || '%''' ;
            end if;
            if (p_domainName is not null) then
                v_condition := v_condition || ' and a.serviceid in (' || p_domainName ||')' ;
            end if;
            if (p_setmode is not null) then
                v_condition := v_condition || ' and a.setmode = ' || p_setmode ;
            end if;
            if (p_otherCondition  is not null) then
                v_condition := v_condition || p_otherCondition;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and a.DEL_FLAG = ' || p_delFlag;
            end if;
            if (p_dealFlag is not null) then
                v_condition := v_condition || ' and a.DEAL_FLAG = ' || p_dealFlag;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                dbms_output.put_line(v_count);
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    dbms_output.put_line(v_sql);
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure list_user_service_infor_new(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_userId in NUMBER,
            p_serviceContent in VARCHAR2,
            p_registerId in VARCHAR2,
            p_setmode in NUMBER,
            p_otherCondition in varchar2,
            p_delFlag in number
        ) is
             --定义
             v_field     varchar2(2000); --字段
             v_secondField varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_isms_base_user_service a left join IDC_ISMS_BASE_USER b on a.USERID = b.USERID';
            v_field    := ' serviceid, servicecontent, SERVICETYPE,regid, setmode, BUSINESS,userid, czlx, deal_flag, create_time, update_time,INFO_COMPLETE,DEL_FLAG,UNITNAME ';
            v_secondField := ' serviceid, servicecontent, SERVICETYPE,regid, setmode, BUSINESS,a.userid, a.czlx, a.deal_flag, a.create_time, a.update_time,a.INFO_COMPLETE,a.DEL_FLAG,UNITNAME ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' serviceid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if (p_userId  is not null) then
                v_condition := v_condition || ' and a.userid = ' || p_userId ;
            end if;
            if (p_serviceContent  is not null ) then
                v_condition := v_condition || ' and a.servicecontent like ''%' || p_serviceContent || '%''' ;
            end if;
            if (p_registerId is not null) then
                v_condition := v_condition || ' and a.regid like ''%' || p_registerId || '%''' ;
            end if;
            if (p_setmode is not null) then
                v_condition := v_condition || ' and a.setmode = ' || p_setmode ;
            end if;
            if (p_otherCondition  is not null) then
                v_condition := v_condition || p_otherCondition;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and a.DEL_FLAG = ' || p_delFlag;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;


         --用户服务的查询列表的数据查询
         procedure user_service_query_list (
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_userId in NUMBER,
            p_serviceContent in VARCHAR2,
            p_registerType in NUMBER,
            p_registerId in VARCHAR2,
            p_setmode in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
        ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_hist_base_user_service userService ';
            v_field    := ' histid,serviceid, servicecontent, regtype, regid, setmode, userid, create_time, update_time ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' serviceid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_userId  is not null ) then
                v_condition := v_condition || ' and userService.userid = ' || p_userId ;
            end if;
            if(p_serviceContent  is not null ) then
                v_condition := v_condition || ' and userService.servicecontent like ''%' || p_serviceContent || '%''' ;
            end if;
            if(p_registerType  is not null ) then
                v_condition := v_condition || ' and userService.regtype = ' || p_registerType ;
            end if;
            if(p_registerId is not null ) then
                v_condition := v_condition || ' and userService.regid like ''%' || p_registerId || '%''' ;
            end if;
            if(p_setmode is not null ) then
                v_condition := v_condition || ' and userService.setmode = ' || p_setmode ;
            end if;
            if(p_otherCondition  is not null ) then
                v_condition := v_condition || p_otherCondition;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure service_ip_query_list (
            -- 入参，分页参数
            p_isPaging    in number, --是否分页，如果不分页返回全部数据
            p_pageIndex   in number, --页索引
            p_pageSize    in number, --页大小
            p_isCount     in number,
            p_sortName    in varchar2,
            p_sortOrder   in varchar2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number,
            --入参，查询参数
            p_unitName    in varchar2,
            p_regId  in varchar2,
            p_business    in number,
            p_houseName   in varchar2,
            p_internetStartIP in varchar2,
            p_internetEndIP   in varchar2,
            p_netStartIP  in varchar2,
            p_netEndIP    in varchar2,
            p_userHouseIDStrs in varchar2,
            p_delFlag     in number,
            p_areaCode in varchar2,
            p_userLevel in number
         ) is
             --定义
             v_field       varchar2(2000);  --字段
             v_innersql    varchar2(8000);  --内部语句，完整的查询sql
             v_order       varchar2(500);   --内部排序语句
             v_condition   varchar2(2000);  --条件语句
             v_having      varchar2(2000);  --having语句
             v_count       varchar2(8000);  --统计记录总数语句
             v_sql         varchar2(8000);  --查询语句
             v_s           number(10); --开始记录
             v_e           number(10); --结束记录
         begin
             p_recordCount := 0;
             v_having := '';
             --内部sql语句
              if p_areaCode is not null then
                if p_userLevel <=2 then--管理员登陆
                   v_innersql := ' FROM (select a.*, b.houseId,b.subordinateunit_areacode areaCode from idc_isms_base_service_iptrans a join idc_isms_base_service_hh b on a.hhid = b.hhid and b.houseid in ('||p_areaCode||')) IP' ||
                           ' LEFT JOIN IDC_ISMS_BASE_USER U ON IP.USERID = U.USERID ' ||
                           ' LEFT JOIN IDC_ISMS_BASE_USER_SERVICE S ON IP.SERVICEID = S.SERVICEID ' ||
                           ' LEFT JOIN IDC_ISMS_BASE_SERVICE_HH HH ON HH.HHID = IP.HHID ' ||
                           ' JOIN IDC_ISMS_BASE_HOUSE H ON H.HOUSEID = IP.HOUSEID';
                   else
                   v_innersql := ' FROM (select a.*, b.houseId,b.subordinateunit_areacode areaCode from idc_isms_base_service_iptrans a join idc_isms_base_service_hh b on a.hhid = b.hhid and b.subordinateunit_areacode in ('||p_areaCode||')) IP' ||
                           ' LEFT JOIN IDC_ISMS_BASE_USER U ON IP.USERID = U.USERID ' ||
                           ' LEFT JOIN IDC_ISMS_BASE_USER_SERVICE S ON IP.SERVICEID = S.SERVICEID ' ||
                           ' LEFT JOIN IDC_ISMS_BASE_SERVICE_HH HH ON HH.HHID = IP.HHID ' ||
                           ' JOIN IDC_ISMS_BASE_HOUSE H ON H.HOUSEID = IP.HOUSEID';
                end if;
                else
                v_innersql := ' FROM (select a.*, b.houseId from idc_isms_base_service_iptrans a join idc_isms_base_service_hh b on a.hhid = b.hhid where 1!=1) IP' ||
                           ' LEFT JOIN IDC_ISMS_BASE_USER U ON IP.USERID = U.USERID ' ||
                           ' LEFT JOIN IDC_ISMS_BASE_USER_SERVICE S ON IP.SERVICEID = S.SERVICEID ' ||
                           ' LEFT JOIN IDC_ISMS_BASE_SERVICE_HH HH ON HH.HHID = IP.HHID ' ||
                           ' JOIN IDC_ISMS_BASE_HOUSE H ON H.HOUSEID = IP.HOUSEID';
               end if;
             v_field := ' IP.SELIPTRANS,IP.DEL_FLAG, IP.USERID, S.SERVICEID, IP.IPTRANSID, HH.HOUSEID, ' ||
                        ' HH.HHID,HH.subordinateunit_areacode areaCode, U.UNITNAME, S.REGID, S.BUSINESS, H.HOUSENAME,' ||
                        ' IP.INTERNET_STARTIP, IP.INTERNET_STARTIPSTR, IP.INTERNET_ENDIP, IP.INTERNET_ENDIPSTR, IP.NET_STARTIP, ' ||
                        ' IP.NET_STARTIPSTR, IP.NET_ENDIP, IP.NET_ENDIPSTR, HH.DISTRIBUTETIME, HH.BANDWIDTH ';
             v_order := ' ORDER BY ';
             if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
             else
                v_order := v_order || ' IPTRANSID DESC';
             end if;
             --条件语句
             v_condition := ' WHERE IP.DEL_FLAG = ' || p_delFlag || ' AND U.DEL_FLAG = 0 AND U.NATURE = 1 AND S.DEL_FLAG = 0 AND HH.DEL_FLAG = 0 ';
             if (p_unitName is not null) then
                v_condition := v_condition || ' AND UNITNAME like ''%' || p_unitName || '%''';
             end if;
             if (p_regId is not null) then
                v_condition := v_condition || ' AND REGID like ''%' || p_regId || '%''';
             end if;
             if (p_business is not null) then
                v_condition := v_condition || ' AND BUSINESS like ''%' || p_business || '%''';
             end if;
             if (p_houseName is not null) then
                v_condition := v_condition || ' AND H.HOUSENAME like ''%' || p_houseName || '%''';
             end if;
             if(p_internetStartIP is not null) then
                v_condition := v_condition || ' AND to_number(INTERNET_STARTIPSTR) >= ' || to_number(p_internetStartIP);
             end if;
             if(p_internetEndIP is not null) then
                v_condition := v_condition || ' AND to_number(INTERNET_ENDIPSTR) <= ' || to_number(p_internetEndIP);
             end if;
             if(p_netStartIP is not null) then
                v_condition := v_condition || ' AND to_number(NET_STARTIPSTR) >= ' || to_number(p_netStartIP);
             end if;
             if(p_netEndIP is not null) then
                v_condition := v_condition || ' AND to_number(NET_ENDIPSTR) <= ' || to_number(p_netEndIP);
             end if;
             if(p_userHouseIDStrs is not null) then
                v_condition := v_condition || ' AND H.HOUSEID in (' || p_userHouseIDStrs || ') ';
             end if;
             --如果需要统计则统计记录总数
             if p_IsCount = 1 then
                v_count := 'select count(1) from (select IP.IPTRANSID ' || v_innersql || v_condition || ')';
                execute immediate v_count into p_recordCount;
             end if;
             if p_ispaging = 0 then
                --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
             else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select * from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure preuser_ip_query_list (
            -- 入参，分页参数
            p_isPaging    in number, --是否分页，如果不分页返回全部数据
            p_pageIndex   in number, --页索引
            p_pageSize    in number, --页大小
            p_isCount     in number,
            p_sortName    in varchar2,
            p_sortOrder   in varchar2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number,
            --入参，查询参数
            p_unitName    in varchar2,
            p_houseName   in varchar2,
            p_startIP  in varchar2,
            p_endIP    in varchar2,
            p_userHouseIDStrs in varchar2,
            p_delFlag  in number,
            p_areaCode in varchar2,
            p_userLevel in number
         ) is
             --定义
             v_field       varchar2(2000);  --字段
             v_innersql    varchar2(2000);  --内部语句，完整的查询sql
             v_order       varchar2(500);   --内部排序语句
             v_condition   varchar2(8000);  --条件语句
             v_count       varchar2(8000);  --统计记录总数语句
             v_sql         varchar2(8000);  --查询语句
             v_s           number(10); --开始记录
             v_e           number(10); --结束记录
         begin
             p_recordCount := 0;
             --内部sql语句
             v_innersql := ' FROM  PRE_idc_isms_base_house_ipseg t1 inner join PRE_IDC_ISMS_BASE_USER t2 on t1.username=t2.unitname
inner join PRE_IDC_ISMS_BASE_HOUSE t3 on t1.roomid=t3.roomid ';

             v_field := ' t3.housename,t1.ipsegidstr,t2.unitname,t1.roomid,t1.startip,t1.endip ';
             v_order := ' ORDER BY ';
             if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
             else
                v_order := v_order || ' IPSEGIDSTR DESC';
             end if;
             --条件语句
             v_condition := ' where iptype!=2 ';
             if (p_unitName is not null) then
                v_condition := v_condition || ' AND UNITNAME like ''%' || p_unitName || '%''';
             end if;
             if (p_houseName is not null) then
                v_condition := v_condition || ' AND HOUSENAME like ''%' || p_houseName || '%''';
             end if;
             if(p_startIP is not null) then
                v_condition := v_condition || ' AND to_number(STARTIPSTR) >= ' || to_number(p_startIP);
             end if;
             if(p_endIP is not null) then
                v_condition := v_condition || ' AND to_number(ENDIPSTR) <= ' || to_number(p_endIP);
             end if;

             --如果需要统计则统计记录总数
             if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
             end if;
             if p_ispaging = 0 then
                --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
             else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select * from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order ;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --用户ip的查询列表的数据查询
         procedure user_ip_query_list (
            -- 入参，分页参数
            p_isPaging    in number, --是否分页，如果不分页返回全部数据
            p_pageIndex   in number, --页索引
            p_pageSize    in number, --页大小
            p_isCount     in number,
            p_sortName    in varchar2,
            p_sortOrder   in varchar2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number,
            --入参，查询参数
            p_unitName    in varchar2,
            p_houseName   in varchar2,
            p_startIP  in varchar2,
            p_endIP    in varchar2,
            p_userHouseIDStrs in varchar2,
            p_delFlag  in number,
            p_areaCode in varchar2,
            p_userLevel in number
         ) is
             --定义
             v_field       varchar2(2000);  --字段
             v_innersql    varchar2(2000);  --内部语句，完整的查询sql
             v_order       varchar2(500);   --内部排序语句
             v_condition   varchar2(8000);  --条件语句
             v_count       varchar2(8000);  --统计记录总数语句
             v_sql         varchar2(8000);  --查询语句
             v_s           number(10); --开始记录
             v_e           number(10); --结束记录
         begin
             p_recordCount := 0;
             --内部sql语句
             if p_areaCode is not null then
                v_innersql := ' FROM (select * from idc_isms_base_house_ipseg where subordinateunit_areacode in ('||p_areaCode||') )ip' ||
                              ' inner join idc_isms_base_user u  on ip.username = u.unitname' ||
                              ' inner join idc_isms_base_house h on ip.houseid =  h.houseid';

                 else
                    v_innersql := ' FROM (select * from idc_isms_base_house_ipseg where 1!=1 )ip' ||
                              ' inner join idc_isms_base_user u  on ip.username = u.unitname' ||
                              ' inner join idc_isms_base_house h on ip.houseid =  h.houseid';
                 end if;
             v_field := ' u.userid,u.unitname,IP.STARTIP,  IP.ENDIP,h.houseName,h.houseid ';
             v_order := ' ORDER BY ';
             if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
             else
                v_order := v_order || ' IPSEGID DESC';
             end if;
             --条件语句
             v_condition := ' WHERE IP.DEL_FLAG = ' || p_delFlag || ' AND U.DEL_FLAG = 0  '|| ' AND h.DEL_FLAG = 0  ';
             if (p_unitName is not null) then
                v_condition := v_condition || ' AND UNITNAME like ''%' || p_unitName || '%''';
             end if;
             if (p_houseName is not null) then
                v_condition := v_condition || ' AND HOUSENAME like ''%' || p_houseName || '%''';
             end if;
             if(p_startIP is not null) then
                v_condition := v_condition || ' AND to_number(STARTIPSTR) >= ' || to_number(p_startIP);
             end if;
             if(p_endIP is not null) then
                v_condition := v_condition || ' AND to_number(ENDIPSTR) <= ' || to_number(p_endIP);
             end if;

             --如果需要统计则统计记录总数
             if p_IsCount = 1 then
                v_count := 'select count(1) from (select IP.IPSEGID ' || v_innersql || v_condition || ')';
                execute immediate v_count into p_recordCount;
             end if;
             if p_ispaging = 0 then
                --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
             else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select * from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order ;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --虚拟主机信息的查询列表的数据查询
         procedure virtual_host_query_list(
            --入参，分页参数
            p_isPaging        in number, --是否分页，如果不分页返回全部数据
            p_pageIndex       in number, --页索引
            p_pageSize        in number, --页大小
            p_isCount         in number,
            p_sortName        in varchar2,
            p_sortOrder       in varchar2,
            --输出
            p_cursor          out sys_refcursor,
            p_recordCount     out number,
            --入参，查询参数
            p_unitName        in varchar2,
            p_regId           in varchar2,
            p_business        in number,
            p_houseName       in varchar2,
            p_hostName        in varchar2,
            p_networkAddress  in varchar2,
            p_status          in number,
            p_type            in number,
            p_mgnAddress      in varchar2,
            p_userHouseIDStrs in varchar2,
            p_delFlag         in number,
            p_areaCode        in varchar2,
            p_userLevel       in number,
            p_userSubAreaCode in varchar2
         ) is
             --定义
             v_field       varchar2(2000);  --字段
             v_innersql    varchar2(8000);  --内部语句，完整的查询sql
             v_order       varchar2(500);   --内部排序语句
             v_condition   varchar2(2000);  --条件语句
             v_count       varchar2(8000);  --统计记录总数语句
             v_sql         varchar2(8000);  --查询语句
             v_s           number(10); --开始记录
             v_e           number(10); --结束记录
         begin
             p_recordCount := 0;
             --内部sql语句
             if p_areaCode is not null then
                v_innersql := ' FROM (select * from IDC_ISMS_BASE_SERVICE_VIRTUAL where houseid in ('||p_areaCode||')) V ' ||
                           ' LEFT JOIN IDC_ISMS_BASE_USER U ON V.USERID = U.USERID ' ||
                           ' INNER JOIN IDC_ISMS_BASE_HOUSE H ON H.HOUSEID = V.HOUSEID';
                else
                  v_innersql := ' FROM (select a.*, b.houseId from IDC_ISMS_BASE_SERVICE_VIRTUAL a join idc_isms_base_service_hh b on a.hhid = b.hhid where 1!=1) V ' ||
                         ' LEFT JOIN IDC_ISMS_BASE_USER U ON V.USERID = U.USERID ' ||
                         ' LEFT JOIN IDC_ISMS_BASE_USER_SERVICE S ON V.SERVICEID = S.SERVICEID ' ||
                         ' LEFT JOIN IDC_ISMS_BASE_SERVICE_HH HH ON HH.HHID = V.HHID ' ||
                         ' INNER JOIN IDC_ISMS_BASE_HOUSE H ON H.HOUSEID = V.HOUSEID ';
                end if;
             v_field := ' V.USERID, V.DEL_FLAG, V.VIRTUALID,V.HOUSEID, ' ||
                        ' U.UNITNAME, H.HOUSENAME, ' ||
                        ' V.VIRTUALHOST_NO, V.VIRTUALHOST_NAME, V.VIRTUALHOST_STATE, V.VIRTUALHOST_TYPE, ' ||
                        ' V.NETWORK_ADDRESS, V.MGN_ADDRESS ';
             v_order := ' ORDER BY ';
             if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
             else
                v_order := v_order || ' VIRTUALID DESC';
             end if;
             --条件语句
             v_condition := ' WHERE ( select COLUMN_VALUE from table(cux_pub_str_split(U.SUBORDINATEUNIT_AREACODE,'','')) intersect select COLUMN_VALUE from table(cux_pub_str_split('''||p_userSubAreaCode||''','','')) ) is not null' ||
             ' AND V.DEL_FLAG = ' || p_delFlag || ' AND U.DEL_FLAG = 0 AND U.NATURE = 1  ';

             if (p_unitName is not null) then
                v_condition := v_condition || ' AND UNITNAME like ''%' || p_unitName || '%''';
             end if;
             if (p_regId is not null) then
                v_condition := v_condition || ' AND REGID like ''%' || p_regId || '%''';
             end if;
             if (p_business is not null) then
                v_condition := v_condition || ' AND BUSINESS = ' || p_business || ' ';
             end if;
             if (p_houseName is not null) then
                v_condition := v_condition || ' AND HOUSENAME like ''%' || p_houseName || '%'' ';
             end if;
             if (p_hostName is not null) then
                v_condition := v_condition || ' AND VIRTUALHOST_NAME like ''%' || p_hostName || '%'' ';
             end if;
             if (p_networkAddress is not null) then
                v_condition := v_condition || ' AND NETWORK_ADDRESS like ''%' || p_networkAddress || '%'' ';
             end if;
             if (p_status is not null) then
                v_condition := v_condition || ' AND VIRTUALHOST_STATE = ' || p_status || ' ';
             end if;
             if (p_type is not null) then
                v_condition := v_condition || ' AND VIRTUALHOST_TYPE = ' || p_type || ' ';
             end if;
             if (p_mgnAddress is not null) then
                v_condition := v_condition || ' AND MGN_ADDRESS like ''%' || p_mgnAddress || '%'' ';
             end if;
             if (p_userHouseIDStrs is not null) then
                v_condition := v_condition || ' AND V.HOUSEID in (' || p_userHouseIDStrs || ')';
             end if;
             --如果需要统计则统计记录总数
             if p_IsCount = 1 then
                v_count := 'select count(1) from (select VIRTUALID ' || v_innersql || v_condition || ')';
                dbms_output.put_line(v_count);
                execute immediate v_count into p_recordCount;
             end if;
             if p_ispaging = 0 then
                --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                    dbms_output.put_line(v_sql);
                end;
             else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select * from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;

          procedure previrtual_host_query_list(
            --入参，分页参数
            p_isPaging        in number, --是否分页，如果不分页返回全部数据
            p_pageIndex       in number, --页索引
            p_pageSize        in number, --页大小
            p_isCount         in number,
            p_sortName        in varchar2,
            p_sortOrder       in varchar2,
            --输出
            p_cursor          out sys_refcursor,
            p_recordCount     out number,
            --入参，查询参数
            p_unitName        in varchar2,
            p_regId           in varchar2,
            p_business        in number,
            p_houseName       in varchar2,
            p_hostName        in varchar2,
            p_networkAddress  in varchar2,
            p_status          in number,
            p_type            in number,
            p_mgnAddress      in varchar2,
            p_userHouseIDStrs in varchar2,
            p_delFlag         in number,
            p_areaCode        in varchar2,
            p_userLevel       in number
         ) is
             --定义
             v_field       varchar2(2000);  --字段
             v_innersql    varchar2(8000);  --内部语句，完整的查询sql
             v_order       varchar2(500);   --内部排序语句
             v_condition   varchar2(2000);  --条件语句
             v_count       varchar2(8000);  --统计记录总数语句
             v_sql         varchar2(8000);  --查询语句
             v_s           number(10); --开始记录
             v_e           number(10); --结束记录
         begin
             p_recordCount := 0;
             --内部sql语句
             v_innersql := ' FROM  pre_idc_isms_base_service_vir t1 inner join PRE_IDC_ISMS_BASE_USER_HH t on t1.sroomid=t.croomid
inner join PRE_IDC_ISMS_BASE_USER t2 on t.clientid=t2.clientid
inner join PRE_IDC_ISMS_BASE_HOUSE t3 on t.roomid=t3.roomid ';

             v_field := 't1.id,t1.VIRTUALHOST_NO,t1.DATADATE,t1.IS_ABNORMAL,t1.ABNORMAL_INFORMATION,t1.OPERTYPE,t1.sroomid,t2.clientid,t3.roomid, t1.VIRTUALID,t2.unitname,t3.housename,t1.virtualhost_name,t1.virtualhost_state,t1.virtualhost_type,t1.network_address,t1.mgn_address ';
             v_order := ' ORDER BY ';
             if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
             else
                v_order := v_order || ' id DESC';
             end if;
             --条件语句
             v_condition := ' where 1=1 ';
             if (p_unitName is not null) then
                v_condition := v_condition || ' AND UNITNAME like ''%' || p_unitName || '%''';
             end if;
             if (p_regId is not null) then
                v_condition := v_condition || ' AND REGID like ''%' || p_regId || '%''';
             end if;
             if (p_business is not null) then
                v_condition := v_condition || ' AND BUSINESS = ' || p_business || ' ';
             end if;
             if (p_houseName is not null) then
                v_condition := v_condition || ' AND HOUSENAME like ''%' || p_houseName || '%'' ';
             end if;
             if (p_hostName is not null) then
                v_condition := v_condition || ' AND VIRTUALHOST_NAME like ''%' || p_hostName || '%'' ';
             end if;
             if (p_networkAddress is not null) then
                v_condition := v_condition || ' AND NETWORK_ADDRESS like ''%' || p_networkAddress || '%'' ';
             end if;
             if (p_status is not null) then
                v_condition := v_condition || ' AND VIRTUALHOST_STATE = ' || p_status || ' ';
             end if;
             if (p_type is not null) then
                v_condition := v_condition || ' AND VIRTUALHOST_TYPE = ' || p_type || ' ';
             end if;
             if (p_mgnAddress is not null) then
                v_condition := v_condition || ' AND MGN_ADDRESS like ''%' || p_mgnAddress || '%'' ';
             end if;
             --如果需要统计则统计记录总数
             if p_IsCount = 1 then
                v_count := 'select count(1) from (select VIRTUALID ' || v_innersql || v_condition || ')';
                dbms_output.put_line(v_count);
                execute immediate v_count into p_recordCount;
             end if;
             if p_ispaging = 0 then
                --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                    dbms_output.put_line(v_sql);
                end;
             else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select * from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure preservice_hh_frame_query_list(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_unitName        in varchar2,
            p_houseName       in varchar2,
            p_frameName         in varchar2,
            p_userHouseIDStrs in varchar2,
            p_areaCode in varchar2,
            p_userLevel in number
         ) is
             --定义
             v_field       varchar2(2000);  --字段
             v_innersql    varchar2(2000);  --内部语句，完整的查询sql
             v_order       varchar2(500);   --内部排序语句
             v_condition   varchar2(2000);  --条件语句
             v_count       varchar2(2000);  --统计记录总数语句
             v_sql         varchar2(2500);  --查询语句
             v_s           number(10); --开始记录
             v_e           number(10); --结束记录
         begin
             p_recordCount := 0;
             --内部sql语句
             v_innersql := 'from ( select t1.datadate,t1.is_abnormal,t1.abnormal_information,t1.opertype,t1.roomid,t1.rackid,t1.ID, t1.HOUSEID, t2.HOUSENAME, t1.FRAMEID, t3.FRAMENAME, t1.UNITNAME from PRE_IDC_ISMS_BASE_USER_FRAME t1
              left join PRE_IDC_ISMS_BASE_HOUSE t2 on t1.roomid=t2.roomid  left join PRE_IDC_ISMS_BASE_HOUSE_FRAME t3 on t1.rackid=t3.rackid )';

             v_field := 'datadate,is_abnormal,abnormal_information,opertype,roomid,rackid, ID, HOUSEID, HOUSENAME, FRAMEID, FRAMENAME, UNITNAME ';
             v_order := ' ORDER BY ';
             if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                   v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                   v_order := v_order || p_sortName || ' DESC';
                end if;
             else
                v_order := v_order || ' roomid DESC ';
             end if;
             --条件语句
             v_condition := ' WHERE 1 = 1 ';
             if (p_unitName is not null) then
                v_condition := v_condition || ' AND UNITNAME like ''%' || p_unitName || '%''';
             end if;
             if (p_houseName is not null) then
                v_condition := v_condition || ' AND HOUSENAME like ''%' || p_houseName || '%'' ';
             end if;
             if (p_frameName is not null) then
                v_condition := v_condition || ' AND FRAMENAME LIKE ''%' || p_frameName || '%'' ';
             end if;
             if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
             end if;
             if p_ispaging = 0 then
                --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
             else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition ||  v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
                dbms_output.put_line(v_sql);
            end if;
            open p_cursor for v_sql;
         end;

         procedure service_hh_frame_query_list(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_unitName        in varchar2,
            p_houseName       in varchar2,
            p_frameName         in varchar2,
            p_userHouseIDStrs in varchar2,
            p_areaCode in varchar2,
            p_userLevel in number
         ) is
             --定义
             v_field       varchar2(2000);  --字段
             v_innersql    varchar2(2000);  --内部语句，完整的查询sql
             v_order       varchar2(500);   --内部排序语句
             v_condition   varchar2(2000);  --条件语句
             v_count       varchar2(2000);  --统计记录总数语句
             v_sql         varchar2(2500);  --查询语句
             v_s           number(10); --开始记录
             v_e           number(10); --结束记录
         begin
             p_recordCount := 0;
             --内部sql语句
             if p_areaCode is not null then
                v_innersql := ' FROM ( ' ||
                           ' SELECT T.ID, T.HOUSEID, H.HOUSENAME, T.FRAMEID, F.FRAMENAME, T.UNITNAME, F.CREATE_TIME, F.UPDATE_TIME, U.USERID ' ||
                           ' FROM (select a.* from IDC_ISMS_BASE_USER_FRAME a join idc_isms_base_house_frame b on a.frameid = b.frameid and b.subordinateunit_areacode in ('||p_areaCode||')) T ' ||
                           ' LEFT JOIN IDC_ISMS_BASE_HOUSE H ON H.HOUSEID = T.HOUSEID ' ||
                           ' LEFT JOIN IDC_ISMS_BASE_HOUSE_FRAME F ON F.FRAMEID = T.FRAMEID ' ||
                           ' inner JOIN IDC_ISMS_BASE_USER U ON U.UNITNAME = T.UNITNAME and u.del_flag=0 )';

                 else
                 v_innersql := ' FROM ( ' ||
                           ' SELECT T.ID, T.HOUSEID, H.HOUSENAME, T.FRAMEID, F.FRAMENAME, T.UNITNAME, F.CREATE_TIME, F.UPDATE_TIME, U.USERID ' ||
                           ' FROM (select a.* from IDC_ISMS_BASE_USER_FRAME a where 1!=1) T ' ||
                           ' LEFT JOIN IDC_ISMS_BASE_HOUSE H ON H.HOUSEID = T.HOUSEID ' ||
                           ' LEFT JOIN IDC_ISMS_BASE_HOUSE_FRAME F ON F.FRAMEID = T.FRAMEID ' ||
                           ' inner JOIN IDC_ISMS_BASE_USER U ON U.UNITNAME = T.UNITNAME and u.del_flag=0 )';
              end if;
             v_field := ' ID, HOUSEID, HOUSENAME, FRAMEID, FRAMENAME, UNITNAME, USERID ';
             v_order := ' ORDER BY ';
             if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                   v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                   v_order := v_order || p_sortName || ' DESC';
                end if;
             else
                v_order := v_order || ' UPDATE_TIME DESC NULLS LAST, CREATE_TIME DESC ';
             end if;
             --条件语句
             v_condition := ' WHERE 1 = 1 ';
             if (p_unitName is not null) then
                v_condition := v_condition || ' AND UNITNAME like ''%' || p_unitName || '%''';
             end if;
             if (p_houseName is not null) then
                v_condition := v_condition || ' AND HOUSENAME like ''%' || p_houseName || '%'' ';
             end if;
             if (p_frameName is not null) then
                v_condition := v_condition || ' AND FRAMENAME LIKE ''%' || p_frameName || '%'' ';
             end if;
             if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
             end if;
             if p_ispaging = 0 then
                --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
             else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition ||  v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
                dbms_output.put_line(v_sql);
            end if;
            open p_cursor for v_sql;
         end;

         procedure prelist_house_occupancy_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_unitName in VARCHAR2,
            p_houseId in VARCHAR2,
            p_beginDistributeTime in VARCHAR2,
            p_endDistributeTime in VARCHAR2,
            p_bandWidth in NUMBER,
            p_otherCondition in varchar2,
            p_areaCode in varchar2,
            p_userLevel in number,
            p_delFlag in number,
            p_houseIds in varchar2
        ) is
             --定义
             v_field     varchar2(2000); --字段
             v_secondField varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from (select a.DATADATE,a.IS_ABNORMAL,a.ABNORMAL_INFORMATION,a.CROOMID,a.CLIENTID,a.ROOMID,hhid,a.houseid,a.SUBORDINATEUNIT_AREACODE,HOUSENAME,UNITNAME, a.userid,DISTRIBUTETIME,BANDWIDTH,a.CZLX,a.info_complete,a.Deal_Flag, a.DEL_FLAG
from PRE_IDC_ISMS_BASE_USER_HH a left join PRE_IDC_ISMS_BASE_HOUSE b on a.ROOMID=b.ROOMID  left join PRE_IDC_ISMS_BASE_USER c on a.CLIENTID = c.CLIENTID ) d';

            v_secondField    := 'DATADATE,IS_ABNORMAL,ABNORMAL_INFORMATION,CROOMID,CLIENTID,ROOMID, d.HHID,HOUSEID,USERID,DISTRIBUTETIME,BANDWIDTH,CZLX,DEAL_FLAG,INFO_COMPLETE,DEL_FLAG,HOUSENAME,UNITNAME,SUBORDINATEUNIT_AREACODE ';
            v_field    := 'DATADATE,IS_ABNORMAL,ABNORMAL_INFORMATION,CROOMID,CLIENTID,ROOMID,HHID,HOUSEID,USERID,DISTRIBUTETIME,SUBORDINATEUNIT_AREACODE,BANDWIDTH,CZLX,DEAL_FLAG,INFO_COMPLETE,DEL_FLAG,HOUSENAME,UNITNAME ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' CROOMID DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if (p_unitName is not null) then
                v_condition := v_condition || ' and unitname like ''%' || p_unitName || '%''' ;
            end if;
            if (p_houseId is not null) then
                v_condition := v_condition || ' and ROOMID =''' || p_houseId || '''';
            end if;
            if(p_beginDistributeTime is not null) then
                v_condition := v_condition || ' and DISTRIBUTETIME >= ''' || p_beginDistributeTime || '''';
            end if;
            if(p_endDistributeTime is not null) then
                v_condition := v_condition || ' and DISTRIBUTETIME <= ''' || p_endDistributeTime || '''';
            end if;
            if p_bandWidth >= 0 then
                v_condition := v_condition || ' and bandwidth = ' || p_bandWidth ;
            end if;
            if(p_otherCondition  is not null) then
                v_condition := v_condition || p_otherCondition;
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum rn, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField  || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where rn >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure list_house_occupancy_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_unitName in VARCHAR2,
            p_houseId in number,
            p_beginDistributeTime in VARCHAR2,
            p_endDistributeTime in VARCHAR2,
            p_bandWidth in NUMBER,
            p_otherCondition in varchar2,
            p_areaCode in varchar2,
            p_userLevel in number,
            p_delFlag in number,
            p_houseIds in varchar2
        ) is
             --定义
             v_field     varchar2(2000); --字段
             v_secondField varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;
            --内部sql语句
            if p_areaCode is not null then

                   v_innersql := ' from (select hhid,a.houseid,a.SUBORDINATEUNIT_AREACODE,HOUSENAME,UNITNAME,a.userid,DISTRIBUTETIME,BANDWIDTH,a.CZLX,a.info_complete,a.Deal_Flag,a.DEL_FLAG,houseidstr || ''('' || housename || '')'' as houseNo from
                                               (select * from idc_isms_base_user_hh where houseid in ('||p_houseIds||') and split_areacode(SUBORDINATEUNIT_AREACODE,'''||p_areaCode||''')=1 ) a
                                               left join idc_isms_base_house b on a.houseid=b.houseid
                                               left join IDC_ISMS_BASE_USER c on a.USERID = c.USERID) d';

            else
                   v_innersql := ' from (select hhid,a.houseid,a.SUBORDINATEUNIT_AREACODE,HOUSENAME,UNITNAME,a.userid,DISTRIBUTETIME,BANDWIDTH,a.CZLX,a.info_complete,a.Deal_Flag,a.DEL_FLAG,houseidstr || ''('' || housename || '')'' as houseNo from
                                               (select * from idc_isms_base_user_hh where 1!=1) a
                                               left join idc_isms_base_house b on a.houseid=b.houseid
                                               left join IDC_ISMS_BASE_USER c on a.USERID = c.USERID) d';
            end if;

            v_secondField    := ' d.HHID,HOUSEID,USERID,DISTRIBUTETIME,BANDWIDTH,CZLX,DEAL_FLAG,HOUSENO,INFO_COMPLETE,DEL_FLAG,HOUSENAME,UNITNAME,SUBORDINATEUNIT_AREACODE ';
            v_field    := ' HHID,HOUSEID,USERID,DISTRIBUTETIME,SUBORDINATEUNIT_AREACODE,BANDWIDTH,CZLX,DEAL_FLAG,HOUSENO,INFO_COMPLETE,DEL_FLAG,HOUSENAME,UNITNAME ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' hhid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if (p_unitName is not null) then
                v_condition := v_condition || ' and unitname like ''%' || p_unitName || '%''' ;
            end if;
            if p_houseId > 0 then
                v_condition := v_condition || ' and HOUSEID = ' || p_houseId ;
            end if;
            if(p_beginDistributeTime is not null) then
                v_condition := v_condition || ' and DISTRIBUTETIME >= ''' || p_beginDistributeTime || '''';
            end if;
            if(p_endDistributeTime is not null) then
                v_condition := v_condition || ' and DISTRIBUTETIME <= ''' || p_endDistributeTime || '''';
            end if;
            if p_bandWidth >= 0 then
                v_condition := v_condition || ' and bandwidth = ' || p_bandWidth ;
            end if;
            if(p_otherCondition  is not null) then
                v_condition := v_condition || p_otherCondition;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and DEL_FLAG = ' || p_delFlag;
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum rn, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField  || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where rn >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --用户占用的机房查询列表的数据查询
         procedure hh_query_list (
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_userId in NUMBER,
            p_distributeTime in VARCHAR2,
            p_bandWidth in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
        ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_hist_base_user_hh userHH ';
            v_field    := ' histid,hhid, houseid, distributetime, bandwidth, userid, create_time, update_time ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' hhid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_userId  is not null ) then
                v_condition := v_condition || ' and userHH.userid = ' || p_userId ;
            end if;
            if(p_distributeTime  is not null ) then
                v_condition := v_condition || ' and userHH.distributetime like ''%' || p_distributeTime || '%''' ;
            end if;
            if(p_bandWidth  is not null ) then
                v_condition := v_condition || ' and userHH.bandwidth = ' || p_bandWidth ;
            end if;
            if(p_otherCondition  is not null ) then
                v_condition := v_condition || p_otherCondition;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure list_hh_ipSegment_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_hhId in NUMBER,
            p_startIP in varchar2,
            p_endIP in varchar2,
            p_otherCondition in varchar2,
            p_delFlag in number
        ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_isms_base_user_hh_ipseg hhIpSeg ';
            v_field    := ' ipsegid, startip, endip, hhid, userid, create_time, update_time,CZLX,DEAL_FLAG,DEL_FLAG ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' ipsegid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if (p_hhId > 0 ) then
                v_condition := v_condition || ' and hhIpSeg.hhid = ' || p_hhId ;
            end if;
            if (p_startIP is not null) then
                v_condition := v_condition || ' and to_number(hhIpSeg.STARTIPSTR) >= ' || to_number(p_startIP);
            end if;
            if (p_endIP is not null) then
                v_condition := v_condition || ' and to_number(hhIpSeg.ENDIPSTR) <= ' || to_number(p_endIP);
            end if;
            if (p_otherCondition is not null) then
                v_condition := v_condition || p_otherCondition;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and DEL_FLAG = ' || p_delFlag;
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --其它用户占用机房的ip地址段
         procedure hh_ipSegment_query_list (
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_hhId in NUMBER,
            p_userId in NUMBER,
            p_startIP in NUMBER,
            p_endIP in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
        ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_hist_base_user_hh_ipseg hhIpSeg ';
            v_field    := ' histid,ipsegid, startip, endip, hhid, userid, DEAL_FLAG,CZLX,create_time, update_time ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' ipsegid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_hhId is not null ) then
                v_condition := v_condition || ' and hhIpSeg.hhid = ' || p_hhId ;
            end if;
            if(p_userId is not null ) then
                v_condition := v_condition || ' and hhIpSeg.userid = ' || p_userId ;
            end if;
            if(p_startIP is not null ) then
                v_condition := v_condition || ' and hhIpSeg.startip = ' || p_startIP ;
            end if;
            if(p_endIP is not null ) then
                v_condition := v_condition || ' and hhIpSeg.endip = ' || p_endIP ;
            end if;
            if(p_otherCondition  is not null ) then
                v_condition := v_condition || p_otherCondition;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure list_service_domain_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_serviceId in NUMBER,
            p_userId in NUMBER,
            p_domainName in VARCHAR2,
            p_otherCondition in varchar2,
            p_delFlag in number
        ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_isms_base_service_domain serviceDomain ';
            v_field    := ' domainid, domainname, serviceid, czlx, deal_flag, userid, create_time, update_time,DEL_FLAG ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' domainid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_serviceId is not null ) then
                v_condition := v_condition || ' and serviceDomain.serviceid =' || p_serviceId ;
            end if;
            if(p_userId is not null ) then
                v_condition := v_condition || ' and serviceDomain.userid =' || p_userId ;
            end if;
            if(p_domainName is not null ) then
                v_condition := v_condition || ' and serviceDomain.domainname like ''%' || p_domainName || '%''' ;
            end if;
            if(p_otherCondition  is not null ) then
                v_condition := v_condition || p_otherCondition;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and DEL_FLAG = ' || p_delFlag;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --服务域名的查询列表的数据查询
         procedure service_domain_query_list (
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_serviceId in NUMBER,
            p_userId in NUMBER,
            p_domainName in VARCHAR2,
            p_otherCondition in varchar2 --其它而外的查询条件
        ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_hist_base_service_domain serviceDomain ';
            v_field    := ' histid,domainid, domainname, serviceid, userid, create_time, update_time ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' domainid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_serviceId is not null ) then
                v_condition := v_condition || ' and serviceDomain.serviceid =' || p_serviceId ;
            end if;
            if(p_userId is not null ) then
                v_condition := v_condition || ' and serviceDomain.userid =' || p_userId ;
            end if;
            if(p_domainName is not null ) then
                v_condition := v_condition || ' and serviceDomain.domainname like ''%' || p_domainName || '%''' ;
            end if;
            if(p_otherCondition  is not null ) then
                v_condition := v_condition || p_otherCondition;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure list_service_hh_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_serviceId in NUMBER,
            p_houseId in number,
            --p_nodeNo in varchar2,
            p_beginDistributeTime in VARCHAR2,
            p_endDistributeTime in VARCHAR2,
            p_bandWidth in NUMBER,
            --p_business in number,
            p_otherCondition in varchar2,
            p_delFlag in number
         ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(20000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(20000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
             v_field2    varchar2(1000);
         begin
             p_recordcount := 0;
            --内部sql语句

            v_field2 := 'd.HHID,FRAMENOS,FRAMEIDS,frameNames,HOUSENAME,HOUSEID,USERID,SERVICEID,DISTRIBUTETIME,BANDWIDTH,CZLX,DEAL_FLAG,HOUSENO,INFO_COMPLETE,del_flag ';
            v_field := 'HHID,FRAMENOS,FRAMEIDS,frameNames,HOUSENAME,HOUSEID,USERID,SERVICEID,DISTRIBUTETIME,BANDWIDTH,CZLX,DEAL_FLAG,HOUSENO,INFO_COMPLETE,del_flag ';
            v_innersql := ' from (select hhid,wm_concat(frameno) as framenos,wm_concat(a.frameid) as frameids,wm_concat(FRAMENAME) as frameNames
                                 from idc_isms_base_house_frame a right join IDC_ISMS_BASE_SERVICE_HH_FRAME b on a.frameid=b.frameid group by hhid) c
                                         right join
                                 (select hhid,a.houseid,HOUSENAME,userid,SERVICEID,DISTRIBUTETIME,BANDWIDTH,a.CZLX,a.info_complete,a.Deal_Flag,a.del_flag,houseidstr || ''('' || housename || '')'' as houseNo from IDC_ISMS_BASE_SERVICE_HH a
                                               left join idc_isms_base_house b on a.houseid=b.houseid) d
                                         on c.hhid=d.hhid  ';

            v_order := ' ORDER BY ';
            if (p_sortName is not null) then
                if (p_sortOrder is not null) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' hhid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if (p_serviceId > 0) then
                v_condition := v_condition || ' and serviceid = ' || p_serviceId ;
            end if;
            if p_houseId > 0 then
                v_condition := v_condition || ' and HOUSEID = ' || p_houseId ;
            end if;
            if (p_beginDistributeTime is not null) then
                v_condition := v_condition || ' and DISTRIBUTETIME >= ''' || p_beginDistributeTime || '''';
            end if;
            if (p_endDistributeTime is not null) then
                v_condition := v_condition || ' and DISTRIBUTETIME <= ''' || p_endDistributeTime || '''';
            end if;
            if (p_bandWidth is not null) then
                v_condition := v_condition || ' and bandwidth = ' || p_bandWidth ;
            end if;
            if (p_otherCondition  is not null) then
                v_condition := v_condition || p_otherCondition;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and DEL_FLAG = ' || p_delFlag;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field2 || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field2 || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --服务占用机房的查询列表的数据查询
         procedure service_hh_query_list (
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_serviceId in NUMBER,
            p_userId in NUMBER,
            p_distributeTime in VARCHAR2,
            p_bandWidth in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
         ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_hist_base_service_hh serviceHH ';
            v_field    := ' histid,hhid, houseid, distributetime, bandwidth, serviceid, userid, create_time, update_time ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' hhid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_serviceId is not null ) then
                v_condition := v_condition || ' and serviceHH.serviceid = ' || p_serviceId ;
            end if;
            if(p_userId is not null ) then
                v_condition := v_condition || ' and serviceHH.userid = ' || p_userId ;
            end if;
            if(p_distributeTime is not null ) then
                v_condition := v_condition || ' and serviceHH.distributetime like ''%' || p_distributeTime || '%''' ;
            end if;
            if(p_bandWidth is not null ) then
                v_condition := v_condition || ' and serviceHH.bandwidth = ' || p_bandWidth ;
            end if;
            if(p_otherCondition  is not null ) then
                v_condition := v_condition || p_otherCondition;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --服务占用机房ip地址转换
         procedure list_service_hh_trans_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_hhId in NUMBER,
            p_internetStartIP in varchar2,
            p_internetEndIP in varchar2,
            p_netStartIP in varchar2,
            p_netEndIP in varchar2,
            p_otherCondition in varchar2,
            p_delFlag in number
         ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from select idc_isms_base_service_iptrans serviceIPTrans ';
            v_field    := ' iptransid, internet_startip, internet_endip, net_startip, net_endip, hhid, serviceid, userid,CZLX,DEAL_FLAG, create_time, update_time,DEL_FLAG  ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' iptransid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_hhId is not null) then
                v_condition := v_condition || ' and serviceIPTrans.hhid = ' || p_hhId ;
            end if;
            if(p_internetStartIP is not null) then
                v_condition := v_condition || ' and to_number(serviceIPTrans.INTERNET_STARTIPSTR) >= ' || to_number(p_internetStartIP);
            end if;
            if(p_internetEndIP is not null) then
                v_condition := v_condition || ' and to_number(serviceIPTrans.INTERNET_ENDIPSTR) <= ' || to_number(p_internetEndIP);
            end if;
            if(p_netStartIP is not null) then
                v_condition := v_condition || ' and to_number(serviceIPTrans.NET_STARTIPSTR) >= ' || to_number(p_netStartIP);
            end if;
            if(p_netEndIP is not null) then
                v_condition := v_condition || ' and to_number(serviceIPTrans.NET_ENDIPSTR) <= ' || to_number(p_netEndIP);
            end if;
            if(p_otherCondition  is not null) then
                v_condition := v_condition || p_otherCondition;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and DEL_FLAG = ' || p_delFlag;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --ip地址转换的查询列表的数据查询
         procedure service_hh_trans_query_list (
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_hhId in NUMBER,
            p_serviceId in NUMBER,
            p_userId in NUMBER,
            p_internetStartIP in NUMBER,
            p_internetEndIP in NUMBER,
            p_netStartIP in NUMBER,
            p_netEndIP in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
         ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000); --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
             p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_hist_base_service_iptrans serviceIPTrans ';
            v_field    := ' histid,iptransid, internet_startip, internet_endip, net_startip, net_endip, hhid, serviceid, userid, create_time, update_time ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' iptransid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_hhId is not null ) then
                v_condition := v_condition || ' and serviceIPTrans.hhid = ' || p_hhId ;
            end if;
            if(p_serviceId is not null ) then
                v_condition := v_condition || ' and serviceIPTrans.serviceid = ' || p_serviceId ;
            end if;
            if(p_userId is not null ) then
                v_condition := v_condition || ' and serviceIPTrans.userid = ' || p_userId ;
            end if;
            if(p_internetStartIP is not null ) then
                v_condition := v_condition || ' and serviceIPTrans.internet_startip = ' || p_internetStartIP ;
            end if;
            if(p_internetEndIP is not null ) then
                v_condition := v_condition || ' and serviceIPTrans.internet_endip = ' || p_internetEndIP ;
            end if;
            if(p_netStartIP is not null ) then
                v_condition := v_condition || ' and serviceIPTrans.net_startip = ' || p_netStartIP ;
            end if;
            if(p_netEndIP is not null ) then
                v_condition := v_condition || ' and serviceIPTrans.net_endip = ' || p_netEndIP ;
            end if;
            if(p_otherCondition  is not null ) then
                v_condition := v_condition || p_otherCondition;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure del_user_hh_information(
            p_hhId in varchar2,
            --出参
            v_out_success out number
         ) as

          v_idcid idc_isms_base_idc.idcid%type;
          v_userid idc_isms_base_user_hh.userid%type;
          v_czlx idc_isms_base_user_hh.czlx%type;
          v_hhId idc_isms_base_user_hh.hhid%type;
          v_hhIdCur sys_refcursor;
          v_sql varchar2(1600);
          Begin
               begin
                    if (p_hhId is null) then
                      v_sql := 'select HHID from IDC_ISMS_BASE_USER_HH where DEAL_FLAG != 1';
                    else
                      v_sql := 'select HHID from IDC_ISMS_BASE_USER_HH where HHID in (' || p_hhId || ')';
                    end if;
                    open v_hhIdCur for v_sql;
                    loop
                      fetch v_hhIdCur into v_hhId;
                      exit when v_hhIdCur%notfound;
                      select czlx into v_czlx from idc_isms_base_user_hh a where a.hhid = v_hhId;
                      if (v_czlx = 2) then
                          select userid into v_userid from idc_isms_base_user_hh where hhid = v_hhId;
                          select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid = v_userid);
                          insert into idc_isms_base_delete(delid,del_type,idcid,userid,userhhid)
                                 values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userid,v_hhId);
                      end if;
                      /*--添加历史记录start
                      --ip地址段
                      insert into idc_hist_base_user_hh_ipseg
                        (histid, ipsegid, startip, endip, hhid, userid, create_time, update_time,CREATE_USERID)
                      select SEQ_ISMS_HIST_HISTID.NEXTVAL,ipsegid, startip, endip, hhid, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_hh_ipseg where hhid = p_hhId;
                      --占用机房对应的机房及机架信息
                      insert into idc_hist_base_user_hh_frame
                        (HHID,HOUSEID,FRAMEID)
                      select HHID,HOUSEID,FRAMEID from IDC_ISMS_BASE_USER_HH_FRAME where HHID = p_hhId;
                      --占用机房
                      insert into idc_hist_base_user_hh
                        (histid, hhid, houseid, distributetime, bandwidth, userid, create_time, update_time,CREATE_USERID)
                      select SEQ_ISMS_HIST_HISTID.NEXTVAL, hhid, houseid, distributetime, bandwidth, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_hh where hhid = p_hhId;
                      --end*/
                      --delete idc_isms_base_user_hh_ipseg where hhid = p_hhId;
                      --delete idc_isms_base_user_hh_frame where hhid = p_hhId;

                      delete from idc_isms_base_user_hh_ipseg a where a.hhid = v_hhId;
                      delete from idc_isms_base_user_hh a where a.hhid = v_hhId;
                  end loop;
                  close v_hhIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
           end;

         procedure delete_user_hh_information(
            p_hhId in varchar2,
            --出参
            v_out_success out number
         ) as

          v_idcid idc_isms_base_idc.idcid%type;
          v_userid idc_isms_base_user_hh.userid%type;
          v_czlx idc_isms_base_user_hh.czlx%type;
          v_hhId idc_isms_base_user_hh.hhid%type;
          v_hhIdCur sys_refcursor;
          v_sql varchar2(1600);
          Begin
               begin
                    if (p_hhId is null) then
                      v_sql := 'select HHID from IDC_ISMS_BASE_USER_HH where DEAL_FLAG != 1';
                    else
                      v_sql := 'select HHID from IDC_ISMS_BASE_USER_HH where HHID in (' || p_hhId || ')';
                    end if;
                    open v_hhIdCur for v_sql;
                    loop
                      fetch v_hhIdCur into v_hhId;
                      exit when v_hhIdCur%notfound;
                      select czlx into v_czlx from idc_isms_base_user_hh a where a.hhid = v_hhId;
                      if (v_czlx = 2) then
                          select userid into v_userid from idc_isms_base_user_hh where hhid = v_hhId;
                          select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid = v_userid);
                          insert into idc_isms_base_delete(delid,del_type,idcid,userid,userhhid)
                                 values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userid,v_hhId);
                      end if;
                      /*--添加历史记录start
                      --ip地址段
                      insert into idc_hist_base_user_hh_ipseg
                        (histid, ipsegid, startip, endip, hhid, userid, create_time, update_time,CREATE_USERID)
                      select SEQ_ISMS_HIST_HISTID.NEXTVAL,ipsegid, startip, endip, hhid, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_hh_ipseg where hhid = p_hhId;
                      --占用机房对应的机房及机架信息
                      insert into idc_hist_base_user_hh_frame
                        (HHID,HOUSEID,FRAMEID)
                      select HHID,HOUSEID,FRAMEID from IDC_ISMS_BASE_USER_HH_FRAME where HHID = p_hhId;
                      --占用机房
                      insert into idc_hist_base_user_hh
                        (histid, hhid, houseid, distributetime, bandwidth, userid, create_time, update_time,CREATE_USERID)
                      select SEQ_ISMS_HIST_HISTID.NEXTVAL, hhid, houseid, distributetime, bandwidth, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_hh where hhid = p_hhId;
                      --end*/
                      --delete idc_isms_base_user_hh_ipseg where hhid = p_hhId;
                      --delete idc_isms_base_user_hh_frame where hhid = p_hhId;

                      update idc_isms_base_user_hh_ipseg a set a.del_flag = 1 where a.hhid = v_hhId;
                      update idc_isms_base_user_hh a set a.del_flag = 1 where a.hhid = v_hhId;
                  end loop;
                  close v_hhIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
           end;

          --删除其他用户占用机房IP地址段
          procedure del_user_hh_ipseg(
               p_ipsegId in varchar2,
               v_out_success out number
          )as
               v_idcId idc_isms_base_idc.idcid%type;
               v_userId idc_isms_base_user_hh_ipseg.userid%type;
               v_userHHId idc_isms_base_user_hh_ipseg.hhid%type;
               v_ipsegId idc_isms_base_user_hh_ipseg.ipsegid%type;
               v_opeType idc_isms_base_user_hh_ipseg.czlx%type;
               v_ipsegIdCur sys_refcursor;
               v_sql varchar2(1600);
          BEGIN
            begin
                if (p_ipsegId is null) then
                  v_sql := 'select IPSEGID from IDC_ISMS_BASE_USER_HH_IPSEG where DEAL_FLAG != 1';
                else
                  v_sql := 'select IPSEGID from IDC_ISMS_BASE_USER_HH_IPSEG where IPSEGID in (' || p_ipsegId || ')';
                end if;
                open v_ipsegIdCur for v_sql;
                loop
                  fetch v_ipsegIdCur into v_ipsegId;
                  exit when v_ipsegIdCur%notfound;
                  select a.czlx,a.userid,a.hhid into v_opeType,v_userId,v_userHHId from idc_isms_base_user_hh_ipseg a where a.IPSEGID = v_ipsegId;
                  /*if v_opeType = 2 then
                    select IDCID into v_idcId from idc_isms_base_idc where JYZID = (select JYZID from idc_isms_base_user where userID = v_userId);
                    insert into IDC_ISMS_BASE_DELETE(Delid,DEL_TYPE,Idcid,Userid,Userhhid,Ipsegid)
                           values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcId,v_userId,v_userHHId,v_ipsegId);
                  end if;*/
                  /*--添加历史记录begin
                  --ip地址段
                  insert into idc_hist_base_user_hh_ipseg
                    (histid, ipsegid, startip, endip, hhid, userid, create_time, update_time,CREATE_USERID)
                  select SEQ_ISMS_HIST_HISTID.NEXTVAL,ipsegid, startip, endip, hhid, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_hh_ipseg where IPSEGID = p_ipsegId;
                  --添加历史记录end*/

                  update idc_isms_base_user_hh_ipseg a set a.del_flag = 1 where a.IPSEGID = v_ipsegId;
               end loop;
               close v_ipsegIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
            end;
             commit;
             v_out_success := 1;
          END;

          procedure delete_service_hh_information(
                p_hhId   in varchar2,
                --出参
                v_out_success    out number
           ) as
            --v_count number(5);
            v_idcid idc_isms_base_idc.idcid%type;
            v_userid idc_isms_base_user_service.userid%type;
            v_serviceid idc_isms_base_service_hh.serviceid%type;
            v_czlx idc_isms_base_service_hh.czlx%type;
            v_hhId idc_isms_base_service_hh.hhid%type;
            v_hhIdCur Sys_Refcursor;
            v_sql varchar2(1600);
          Begin
               begin
                    if (p_hhId is null) then
                      v_sql := 'select HHID from IDC_ISMS_BASE_SERVICE_HH where DEAL_FLAG != 1';
                    else
                      v_sql := 'select HHID from IDC_ISMS_BASE_SERVICE_HH where HHID in (' || p_hhId ||')';
                    end if;
                    open v_hhIdCur for v_sql;
                    loop
                      fetch v_hhIdCur into v_hhId;
                      exit when v_hhIdCur%notfound;
                      select czlx into v_czlx from idc_isms_base_service_hh where hhid = v_hhId;
                      if (v_czlx = 2) then
                          select serviceid into v_serviceid from idc_isms_base_service_hh where hhid = v_hhId;
                          select userid into v_userid from idc_isms_base_user_service where serviceid = v_serviceid;
                          select idcid into v_idcid from idc_isms_base_idc where jyzid in (select jyzid from idc_isms_base_user where userid=v_userid);
                          insert into idc_isms_base_delete(delid,del_type,idcid,userid,serviceid,servicehhid)
                                 values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userid,v_serviceid,v_hhId);
                      end if;
                      /*--添加历史记录start
                      --ip地址段
                      insert into idc_hist_base_service_iptrans
                        (histid, iptransid, internet_startip, internet_endip, net_startip, net_endip, hhid, serviceid, userid, create_time, update_time,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR)
                      select SEQ_ISMS_HIST_HISTID.NEXTVAL,IPTRANSID, INTERNET_STARTIP, INTERNET_ENDIP, NET_STARTIP, NET_ENDIP, HHID, SERVICEID, USERID, CREATE_TIME, UPDATE_TIME,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR from idc_isms_base_service_iptrans where hhid = p_hhId;
                      --虚拟主机
                      insert into IDC_HIST_BASE_SERVICE_VIRTUAL(HISTID,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID)
                      select SEQ_ISMS_HIST_HISTID.NEXTVAL,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID from IDC_ISMS_BASE_SERVICE_VIRTUAL where HHID = p_hhId;
                      --占用机房对应的机房及机架
                      insert into idc_hist_base_service_hh_frame(HHID,HOUSEID,FRAMEID)
                      select HHID,HOUSEID,FRAMEID from idc_isms_base_service_hh_frame where hhid = p_hhId;
                      --占用机房
                      insert into idc_hist_base_service_hh
                        (histid, hhid, houseid,NODENO, distributetime, bandwidth, serviceid, userid, create_time, update_time,CREATE_USERID)
                      select SEQ_ISMS_HIST_HISTID.NEXTVAL, hhid, houseid,NODENO, distributetime, bandwidth, serviceid, userid, create_time, update_time,CREATE_USERID from idc_isms_base_service_hh where hhid = p_hhId;
                      --end*/
                      update idc_isms_base_service_iptrans a set a.del_flag = 1 where a.hhid = v_hhId;
                      update IDC_ISMS_BASE_SERVICE_VIRTUAL a set a.del_flag = 1 where a.hhid = v_hhId;
                      --delete idc_isms_base_service_hh_frame where hhid = p_hhId;
                      update idc_isms_base_service_hh a set a.del_flag = 1 where a.hhid = v_hhId;
                  end loop;
                  close v_hhIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
           end;

          procedure del_service_hh_information(
                p_hhId   in varchar2,
                --出参
                v_out_success    out number
           ) as
            --v_count number(5);
            v_idcid idc_isms_base_idc.idcid%type;
            v_userid idc_isms_base_user_service.userid%type;
            v_serviceid idc_isms_base_service_hh.serviceid%type;
            v_czlx idc_isms_base_service_hh.czlx%type;
            v_hhId idc_isms_base_service_hh.hhid%type;
            v_hhIdCur Sys_Refcursor;
            v_sql varchar2(1600);
          Begin
               begin
                    if (p_hhId is null) then
                      v_sql := 'select HHID from IDC_ISMS_BASE_SERVICE_HH where DEAL_FLAG != 1';
                    else
                      v_sql := 'select HHID from IDC_ISMS_BASE_SERVICE_HH where HHID in (' || p_hhId ||')';
                    end if;
                    open v_hhIdCur for v_sql;
                    loop
                      fetch v_hhIdCur into v_hhId;
                      exit when v_hhIdCur%notfound;
                      select czlx into v_czlx from idc_isms_base_service_hh where hhid = v_hhId;
                      if (v_czlx = 2) then
                          select serviceid into v_serviceid from idc_isms_base_service_hh where hhid = v_hhId;
                          select userid into v_userid from idc_isms_base_user_service where serviceid = v_serviceid;
                          select idcid into v_idcid from idc_isms_base_idc where jyzid in (select jyzid from idc_isms_base_user where userid=v_userid);
                          insert into idc_isms_base_delete(delid,del_type,idcid,userid,serviceid,servicehhid)
                                 values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userid,v_serviceid,v_hhId);
                      end if;
                      /*--添加历史记录start
                      --ip地址段
                      insert into idc_hist_base_service_iptrans
                        (histid, iptransid, internet_startip, internet_endip, net_startip, net_endip, hhid, serviceid, userid, create_time, update_time,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR)
                      select SEQ_ISMS_HIST_HISTID.NEXTVAL,IPTRANSID, INTERNET_STARTIP, INTERNET_ENDIP, NET_STARTIP, NET_ENDIP, HHID, SERVICEID, USERID, CREATE_TIME, UPDATE_TIME,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR from idc_isms_base_service_iptrans where hhid = p_hhId;
                      --虚拟主机
                      insert into IDC_HIST_BASE_SERVICE_VIRTUAL(HISTID,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID)
                      select SEQ_ISMS_HIST_HISTID.NEXTVAL,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID from IDC_ISMS_BASE_SERVICE_VIRTUAL where HHID = p_hhId;
                      --占用机房对应的机房及机架
                      insert into idc_hist_base_service_hh_frame(HHID,HOUSEID,FRAMEID)
                      select HHID,HOUSEID,FRAMEID from idc_isms_base_service_hh_frame where hhid = p_hhId;
                      --占用机房
                      insert into idc_hist_base_service_hh
                        (histid, hhid, houseid,NODENO, distributetime, bandwidth, serviceid, userid, create_time, update_time,CREATE_USERID)
                      select SEQ_ISMS_HIST_HISTID.NEXTVAL, hhid, houseid,NODENO, distributetime, bandwidth, serviceid, userid, create_time, update_time,CREATE_USERID from idc_isms_base_service_hh where hhid = p_hhId;
                      --end*/
                      delete from idc_isms_base_service_iptrans a where a.hhid = v_hhId;
                      delete from IDC_ISMS_BASE_SERVICE_VIRTUAL a where a.hhid = v_hhId;
                      --delete idc_isms_base_service_hh_frame where hhid = p_hhId;
                      delete from idc_isms_base_service_hh a where a.hhid = v_hhId;
                  end loop;
                  close v_hhIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
           end;

           procedure del_serv_domain_information(
                p_domainId in varchar2,
                --出参
                v_out_success out number
           ) as
            --v_count number(5);
            v_idcid idc_isms_base_idc.idcid%type;
            v_userid idc_isms_base_user_service.userid%type;
            v_serviceid idc_isms_base_service_domain.serviceid%type;
            v_czlx idc_isms_base_service_domain.czlx%type;
            v_domainId idc_isms_base_service_domain.domainid%type;
            v_domainIdCur sys_refcursor;
            v_sql varchar2(1600);
          Begin
               begin
                    if(p_domainId is null) then
                      v_sql := 'select DOMAINID from IDC_ISMS_BASE_SERVICE_DOMAIN where DEAL_FLAG != 1';
                    else
                      v_sql := 'select DOMAINID from IDC_ISMS_BASE_SERVICE_DOMAIN where DOMAINID in (' || p_domainId || ')';
                    end if;
                    open v_domainIdCur for v_sql;
                    loop
                      fetch v_domainIdCur into v_domainId;
                      exit when v_domainIdCur%notfound;
                      select czlx into v_czlx from idc_isms_base_service_domain where domainid = v_domainId;
                      if (v_czlx = 2) then
                          select serviceid into v_serviceid from idc_isms_base_service_domain where domainid = v_domainId;
                          select userid into v_userid from idc_isms_base_user_service where serviceid = v_serviceid;
                          select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid=v_userid);
                          insert into idc_isms_base_delete(delid,del_type,idcid,userid,serviceid,domainid)
                                 values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userid,v_serviceid,v_domainId);
                      end if;
                      /*--插入历史记录start
                      insert into idc_hist_base_service_domain
                        (histid, domainid, domainname, serviceid, userid, create_time, update_time,CREATE_USER_ID)
                      select SEQ_ISMS_HIST_HISTID.NEXTVAL,domainid, domainname, serviceid, userid, create_time, update_time,CREATE_USER_ID from idc_isms_base_service_domain where domainid = p_domainId;
                      --end*/
                      update idc_isms_base_service_domain a set a.del_flag = 1 where domainid = v_domainId;
                   end loop;
                   close v_domainIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
           end;


               procedure delete_serv_domain_information(
                p_domainId in varchar2,
                --出参
                v_out_success out number
           ) as
            --v_count number(5);
            v_idcid idc_isms_base_idc.idcid%type;
            v_userid idc_isms_base_user_service.userid%type;
            v_serviceid idc_isms_base_service_domain.serviceid%type;
            v_czlx idc_isms_base_service_domain.czlx%type;
            v_domainId idc_isms_base_service_domain.domainid%type;
            v_domainIdCur sys_refcursor;
            v_sql varchar2(1600);
          Begin
               begin
                    if(p_domainId is null) then
                      v_sql := 'select DOMAINID from IDC_ISMS_BASE_SERVICE_DOMAIN where DEAL_FLAG != 1';
                    else
                      v_sql := 'select DOMAINID from IDC_ISMS_BASE_SERVICE_DOMAIN where DOMAINID in (' || p_domainId || ')';
                    end if;
                    open v_domainIdCur for v_sql;
                    loop
                      fetch v_domainIdCur into v_domainId;
                      exit when v_domainIdCur%notfound;
                      select czlx into v_czlx from idc_isms_base_service_domain where domainid = v_domainId;
                      if (v_czlx = 2) then
                          select serviceid into v_serviceid from idc_isms_base_service_domain where domainid = v_domainId;
                          select userid into v_userid from idc_isms_base_user_service where serviceid = v_serviceid;
                          select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid=v_userid);
                          insert into idc_isms_base_delete(delid,del_type,idcid,userid,serviceid,domainid)
                                 values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userid,v_serviceid,v_domainId);
                      end if;
                      /*--插入历史记录start
                      insert into idc_hist_base_service_domain
                        (histid, domainid, domainname, serviceid, userid, create_time, update_time,CREATE_USER_ID)
                      select SEQ_ISMS_HIST_HISTID.NEXTVAL,domainid, domainname, serviceid, userid, create_time, update_time,CREATE_USER_ID from idc_isms_base_service_domain where domainid = p_domainId;
                      --end*/
                      delete from idc_isms_base_service_domain a where domainid = v_domainId;
                   end loop;
                   close v_domainIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
           end;

         --删除虚拟主机信息
         procedure delete_service_virtual_infor(
            p_virtualId in varchar2,
            --出参
            v_out_success out number
         ) as

          v_idcid  idc_isms_base_idc.idcid%type;
          v_userId idc_isms_base_service_virtual.userid%type;
          v_serviceId idc_isms_base_service_virtual.serviceid%type;
          v_HHId idc_isms_base_service_virtual.hhid%type;
          v_czlx idc_isms_base_service_virtual.czlx%type;
          v_virtualId idc_isms_base_service_virtual.virtualid%type;
          v_virtualIdCur sys_refcursor;
          v_sql varchar2(1600);
          Begin
               begin
                    if (p_virtualId is null) then
                      v_sql := 'select VIRTUALID from IDC_ISMS_BASE_SERVICE_VIRTUAL where DEAL_FLAG != 1';
                    else
                      v_sql := 'select VIRTUALID from IDC_ISMS_BASE_SERVICE_VIRTUAL where VIRTUALID in (' || p_virtualId || ')';
                    end if;
                    open v_virtualIdCur for v_sql;
                    loop
                      fetch v_virtualIdCur into v_virtualId;
                      exit when v_virtualIdCur%notfound;
                      select czlx into v_czlx from idc_isms_base_service_virtual where VIRTUALID = v_virtualId;
                      if (v_czlx = 2) then
                         select HHID,SERVICEID,USERID into v_HHId,v_serviceId,v_userId from idc_isms_base_service_virtual where VIRTUALID = v_virtualId;
                         select IDCID into v_idcid from idc_isms_base_idc where JYZID = (select JYZID from idc_isms_base_user where userid = v_userId);
                         insert into idc_isms_base_delete(delid,del_type,idcid,USERID,SERVICEID,SERVICEHHID,VIRTUALID)
                         values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userId,v_serviceId,v_HHId,v_virtualId);
                      end if;
                       /*--添加历史记录start
                       insert into IDC_HIST_BASE_SERVICE_VIRTUAL
                        (HISTID,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID from IDC_ISMS_BASE_SERVICE_VIRTUAL where VIRTUALID = p_virtualId;
                       --end*/
                      update IDC_ISMS_BASE_SERVICE_VIRTUAL a set a.del_flag = 1 where a.VIRTUALID = v_virtualId;
                   end loop;
                   close v_virtualIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

          --删除服务占用机房IP转换
          procedure del_service_hh_iptrans(
               p_iptransId in varchar2,
               v_out_success out number
          )as
               v_idcId idc_isms_base_idc.idcid%type; --IDC/ISP许可证号
               v_userId idc_isms_base_service_iptrans.userid%type; --提供服务用户ID
               v_serviceId idc_isms_base_service_iptrans.serviceid%type; --服务ID
               v_hhId idc_isms_base_service_iptrans.hhid%type; --服务下占用机房ID
               v_iptransId idc_isms_base_service_iptrans.iptransid%type;
               v_opeType idc_isms_base_service_iptrans.czlx%type; --操作类型
               v_ipTransIdCur sys_refcursor;
               v_sql varchar2(1600);
          BEGIN
            begin
                if (p_iptransId is null) then
                  v_sql := 'select IPTRANSID from IDC_ISMS_BASE_SERVICE_IPTRANS where DEAL_FLAG != 1';
                else
                  v_sql := 'select IPTRANSID from IDC_ISMS_BASE_SERVICE_IPTRANS where IPTRANSID in (' || p_iptransId || ')';
                end if;
                open v_ipTransIdCur for v_sql;
                loop
                  fetch v_ipTransIdCur into v_iptransId;
                  exit when v_ipTransIdCur%notfound;
                  select CZLX,USERID,SERVICEID,HHID into v_opeType,v_userId,v_serviceId,v_hhId from idc_isms_base_service_iptrans where IPTRANSID = v_iptransId;
                  if v_opeType = 2 then
                    select IDCID into v_idcId from idc_isms_base_idc where JYZID = (select JYZID from idc_isms_base_user where userID = v_userId);
                    insert into IDC_ISMS_BASE_DELETE(Delid,DEL_TYPE,Idcid,Userid,SERVICEID,SERVICEHHID,IPTRANSID)
                           values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcId,v_userId,v_serviceId,v_hhId,v_iptransId);
                  end if;
                  /*--添加历史记录begin
                  --ip地址段
                  insert into idc_hist_base_service_iptrans
                     (histid, iptransid, internet_startip, internet_endip, net_startip, net_endip, hhid, serviceid, userid, create_time, update_time,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR)
                  select SEQ_ISMS_HIST_HISTID.NEXTVAL,IPTRANSID, INTERNET_STARTIP, INTERNET_ENDIP, NET_STARTIP, NET_ENDIP, HHID, SERVICEID, USERID, CREATE_TIME, UPDATE_TIME,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR from idc_isms_base_service_iptrans where IPTRANSID = p_iptransId;
                  --添加历史记录end*/

                  update idc_isms_base_service_iptrans a set a.del_flag = 1 where a.IPTRANSID = v_iptransId;
               end loop;
               close v_ipTransIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
            end;
             commit;
             v_out_success := 1;
          END;

          procedure del_service_information(
                p_serviceId in varchar2,
                --出参
                v_out_success out number
           ) as
             v_idcid idc_isms_base_idc.idcid%type;
             v_userid idc_isms_base_user_service.userid%type;
             v_czlx idc_isms_base_user_service.czlx%type;
             v_serviceId idc_isms_base_user_service.serviceid%type;
             v_serviceIdCur sys_refcursor;
             v_sql varchar2(1600);
            Begin
                 begin
                      if(p_serviceId is null) then
                        v_sql := 'select SERVICEID from IDC_ISMS_BASE_USER_SERVICE where DEAL_FLAG != 1';
                      else
                        v_sql := 'select SERVICEID from IDC_ISMS_BASE_USER_SERVICE where SERVICEID in (' || p_serviceId || ')';
                      end if;
                      open v_serviceIdCur for v_sql;
                      loop
                        fetch v_serviceIdCur into v_serviceId;
                        exit when v_serviceIdCur%notfound;
                         select czlx into v_czlx from idc_isms_base_user_service where serviceid = v_serviceId;
                         if (v_czlx = 2) then
                           select userid into v_userid from idc_isms_base_user_service where serviceid = v_serviceId;
                           select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid=v_userid);
                             insert into idc_isms_base_delete(delid,del_type,idcid,userid,serviceid)
                             values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userid,v_serviceId);
                         end if;
                       /*--插入历史记录start
                       --ip地址段
                       insert into idc_hist_base_service_iptrans
                         (histid, iptransid, internet_startip, internet_endip, net_startip, net_endip, hhid, serviceid, userid, create_time, update_time,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL,IPTRANSID, INTERNET_STARTIP, INTERNET_ENDIP, NET_STARTIP, NET_ENDIP, HHID, SERVICEID, USERID, CREATE_TIME, UPDATE_TIME,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR from idc_isms_base_service_iptrans where serviceId = p_serviceId;
                       --虚拟主机
                       insert into IDC_HIST_BASE_SERVICE_VIRTUAL
                         (HISTID,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID from IDC_ISMS_BASE_SERVICE_VIRTUAL where serviceId = p_serviceId;
                       --占用机房
                       insert into idc_hist_base_service_hh
                         (histid, hhid, houseid,NODENO, distributetime, bandwidth, serviceid, userid, create_time, update_time,CREATE_USERID)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL, hhid, houseid,NODENO, distributetime, bandwidth, serviceid, userid, create_time, update_time,CREATE_USERID from idc_isms_base_service_hh where serviceId = p_serviceId;
                       --域名
                       insert into idc_hist_base_service_domain
                         (histid, domainid, domainname, serviceid, userid, create_time, update_time,CREATE_USER_ID)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL,domainid, domainname, serviceid, userid, create_time, update_time,CREATE_USER_ID from idc_isms_base_service_domain where serviceId = p_serviceId;
                       --服务
                       insert into idc_hist_base_user_service
                         (histid, serviceid, servicecontent,SERVICETYPE, regid, setmode,BUSINESS, userid, create_time, update_time,CREATE_USERID)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL,serviceid, servicecontent,SERVICETYPE, regid, setmode,BUSINESS, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_service where serviceId = p_serviceId;
                       --end*/
                         delete from idc_isms_base_service_domain a where a.serviceid = v_serviceId;
                         delete from idc_isms_base_service_hh a where a.serviceid = v_serviceId;
                         delete from idc_isms_base_service_iptrans a where a.serviceid = v_serviceId;
                         delete from idc_isms_base_service_virtual a where a.serviceid = v_serviceId;
                         delete from idc_isms_base_user_service a where a.serviceid = v_serviceId;
                      end loop;
                      close v_serviceIdCur;
                 exception
                 WHEN OTHERS THEN
                      ROLLBACK;
                      v_out_success := 0;
                      RETURN;
                 end;
                 commit;
                 v_out_success:=1;
             end;

           procedure delete_service_ip_infomation(
                 p_iptransId     in number,
                 p_hhId          in number,
                 p_statusCode    out varchar2,
                 p_message       out varchar2
           ) is
                 v_count    number;
           begin
                select count(1) into v_count from IDC_ISMS_BASE_SERVICE_IPTRANS where HHID = p_hhId and del_flag = 0 and IPTRANSID <> p_iptransId;
                if (v_count > 0) then
                   update IDC_ISMS_BASE_SERVICE_IPTRANS set del_flag = 1 where IPTRANSID = p_iptransId;
                   commit;
                   p_statusCode := '1';
                   p_message := '删除成功';
                else
                   p_statusCode := '0';
                   p_message := '删除失败，用户占用机房至少需要保留一个IP信息';
                end if;
           end;

           procedure del_service_ip(
                 p_iptransId     in varchar2,
                 p_statusCode    out varchar2,
                 p_message       out varchar2
           ) is
                v_sql varchar2(500);
           begin
                v_sql := 'delete from idc_isms_base_service_iptrans where iptransid in (' || p_iptransId || ')';
                execute immediate v_sql;
                p_statusCode := '1';
                p_message := '删除成功';
           end;

           procedure del_user_ip(
                 p_ipsegId       in varchar2,
                 p_statusCode    out varchar2,
                 p_message       out varchar2
           ) is
                v_sql varchar2(500);
           begin
                v_sql := 'delete from IDC_ISMS_BASE_USER_HH_IPSEG where ipsegId in (' || p_ipsegId || ')';
                execute immediate v_sql;
                p_statusCode := '1';
                p_message := '删除成功';
           end;

           procedure del_virtual_host(
                 p_virtualId    in varchar2,
                 p_statusCode    out varchar2,
                 p_message       out varchar2
           ) is
                v_sql varchar2(500);
           begin
                v_sql := 'delete from IDC_ISMS_BASE_SERVICE_VIRTUAL where virtualId in (' || p_virtualId || ')';
                execute immediate v_sql;
                p_statusCode := '1';
                p_message := '删除成功';
           end;

           procedure check_batch_del_service_ip(
                 p_hhId          in number,
                 p_count_iptransId     in number,
                 p_isCan         out varchar2
           ) is
                 v_count    number;
           begin
                 select count(1) into v_count from IDC_ISMS_BASE_SERVICE_IPTRANS where HHID = p_hhId and del_flag = 0;
                 if (v_count = p_count_iptransId) then
                    p_isCan := '0'; -- 删除的数量与总量一致，不能删除
                 else
                    p_isCan := '1';
                 end if;
           end;

           procedure check_batch_del_user_ip(
                 p_hhId          in number,
                 p_count_ipsegId     in number,
                 p_isCan         out varchar2
           ) is
                 v_count    number;
           begin
                 select count(1) into v_count from IDC_ISMS_BASE_USER_HH_IPSEG where HHID = p_hhId and del_flag = 0;
                 if (v_count = p_count_ipsegId) then
                    p_isCan := '0'; -- 删除的数量与总量一致，不能删除
                 else
                    p_isCan := '1';
                 end if;
           end;

           procedure batchDel_service_ip_infor(
                 p_iptransIds    in varchar2,
                 p_statusCode    out varchar2,
                 p_message       out varchar2
           ) is
                 v_sql varchar2(1600);
           begin
                 -- v_sql := 'delete from IDC_ISMS_BASE_SERVICE_IPTRANS where IPTRANSID in ('|| p_iptransIds || ')';
                 v_sql := 'update IDC_ISMS_BASE_SERVICE_IPTRANS set del_flag = 1 where IPTRANSID in (' || p_iptransIds || ')';
                 execute immediate v_sql;
                 p_statusCode := '1';
                 p_message := '批量删除成功';
           end;

           procedure batchDel_user_ip_infor(
                 p_ipsegIds      in varchar2,
                 p_statusCode    out varchar2,
                 p_message       out varchar2
           ) is
                 v_sql varchar2(1600);
           begin
                 --v_sql := 'delete from IDC_ISMS_BASE_USER_HH_IPSEG where ipsegId in ('|| p_ipsegIds || ')';
                 v_sql := 'update IDC_ISMS_BASE_USER_HH_IPSEG set del_flag = 1 where ipsegId in ('|| p_ipsegIds || ')';
                 execute immediate v_sql;
                 p_statusCode := '1';
                 p_message := '批量删除成功';
           end;

           procedure batchDelete_virtual_host_info(
                 p_virtualIds    in varchar2,
                 p_statusCode    out varchar2,
                 p_message       out varchar2
           ) is
                v_sql varchar2(1600);
           begin
                v_sql := 'update IDC_ISMS_BASE_SERVICE_VIRTUAL set del_flag = 1 where VIRTUALID in (' || p_virtualIds || ')';
                execute immediate v_sql;
                p_statusCode := '1';
                p_message := '批量删除成功';
           end;

            procedure batchDel_service_hh_frame_info(
                 p_frameIds    in varchar2,
                 p_statusCode    out varchar2,
                 p_message       out varchar2
           ) as
               v_sql varchar2(1600);
           begin
                v_sql := 'delete idc_isms_base_user_frame where id in(' || p_frameIds || ')';
                execute immediate v_sql;
                p_statusCode := '1';
                p_message := '批量删除成功';
           end;

           procedure delete_user_ip_information(
                 p_ipsegId       in number,
                 p_hhId          in number,
                 p_statusCode    out varchar2,
                 p_message       out varchar2
           ) is
                 v_count    number;
           begin
                 select count(1) into v_count from IDC_ISMS_BASE_USER_HH_IPSEG where HHID = p_hhId and del_flag = 0 and IPSEGID <> p_ipsegId;
                 if (v_count > 0) then
                    update IDC_ISMS_BASE_USER_HH_IPSEG set del_flag = 1 where IPSEGID = p_ipsegId;
                    commit;
                    p_statusCode := '1';
                   p_message := '删除成功';
                 else
                    p_statusCode := '0';
                   p_message := '删除失败，其他用户占用机房至少需要保留一个IP信息';
                 end if;
           end;

           procedure delete_virtual_host_info(
                 p_virtualId     in varchar2,
                 p_statusCode    out varchar2,
                 p_message       out varchar2
           ) is
                 v_count    number;
           begin
                 update IDC_ISMS_BASE_SERVICE_VIRTUAL set del_flag = 1 where virtualId = p_virtualId;
                 commit;
                 p_statusCode := '1';
                 p_message := '删除成功';
           end;

           procedure delete_service_information(
                p_serviceId in varchar2,
                --出参
                v_out_success out number
           ) as
             v_idcid idc_isms_base_idc.idcid%type;
             v_userid idc_isms_base_user_service.userid%type;
             v_czlx idc_isms_base_user_service.czlx%type;
             v_serviceId idc_isms_base_user_service.serviceid%type;
             v_serviceIdCur sys_refcursor;
             v_sql varchar2(1600);
            Begin
                 begin
                      if(p_serviceId is null) then
                        v_sql := 'select SERVICEID from IDC_ISMS_BASE_USER_SERVICE where DEAL_FLAG != 1';
                      else
                        v_sql := 'select SERVICEID from IDC_ISMS_BASE_USER_SERVICE where SERVICEID in (' || p_serviceId || ')';
                      end if;
                      open v_serviceIdCur for v_sql;
                      loop
                        fetch v_serviceIdCur into v_serviceId;
                        exit when v_serviceIdCur%notfound;
                         select czlx into v_czlx from idc_isms_base_user_service where serviceid = v_serviceId;
                         if (v_czlx = 2) then
                           select userid into v_userid from idc_isms_base_user_service where serviceid = v_serviceId;
                           select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid=v_userid);
                             insert into idc_isms_base_delete(delid,del_type,idcid,userid,serviceid)
                             values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userid,v_serviceId);
                         end if;
                       /*--插入历史记录start
                       --ip地址段
                       insert into idc_hist_base_service_iptrans
                         (histid, iptransid, internet_startip, internet_endip, net_startip, net_endip, hhid, serviceid, userid, create_time, update_time,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL,IPTRANSID, INTERNET_STARTIP, INTERNET_ENDIP, NET_STARTIP, NET_ENDIP, HHID, SERVICEID, USERID, CREATE_TIME, UPDATE_TIME,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR from idc_isms_base_service_iptrans where serviceId = p_serviceId;
                       --虚拟主机
                       insert into IDC_HIST_BASE_SERVICE_VIRTUAL
                         (HISTID,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID from IDC_ISMS_BASE_SERVICE_VIRTUAL where serviceId = p_serviceId;
                       --占用机房
                       insert into idc_hist_base_service_hh
                         (histid, hhid, houseid,NODENO, distributetime, bandwidth, serviceid, userid, create_time, update_time,CREATE_USERID)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL, hhid, houseid,NODENO, distributetime, bandwidth, serviceid, userid, create_time, update_time,CREATE_USERID from idc_isms_base_service_hh where serviceId = p_serviceId;
                       --域名
                       insert into idc_hist_base_service_domain
                         (histid, domainid, domainname, serviceid, userid, create_time, update_time,CREATE_USER_ID)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL,domainid, domainname, serviceid, userid, create_time, update_time,CREATE_USER_ID from idc_isms_base_service_domain where serviceId = p_serviceId;
                       --服务
                       insert into idc_hist_base_user_service
                         (histid, serviceid, servicecontent,SERVICETYPE, regid, setmode,BUSINESS, userid, create_time, update_time,CREATE_USERID)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL,serviceid, servicecontent,SERVICETYPE, regid, setmode,BUSINESS, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_service where serviceId = p_serviceId;
                       --end*/
                         update idc_isms_base_service_domain a set a.del_flag = 1 where a.serviceid = v_serviceId;
                         update idc_isms_base_service_hh a set a.del_flag = 1 where a.serviceid = v_serviceId;
                         update idc_isms_base_service_iptrans a set a.del_flag = 1 where a.serviceid = v_serviceId;
                         update idc_isms_base_service_virtual a set a.del_flag = 1 where a.serviceid = v_serviceId;
                         update idc_isms_base_user_service a set a.del_flag = 1 where a.serviceid = v_serviceId;
                      end loop;
                      close v_serviceIdCur;
                 exception
                 WHEN OTHERS THEN
                      ROLLBACK;
                      v_out_success := 0;
                      RETURN;
                 end;
                 commit;
                 v_out_success:=1;
             end;

             procedure del_user_information(
                  p_userId in varchar2,
                  --出参
                  v_out_success out number
             ) as
              v_idcid idc_isms_base_idc.idcid%type;
              v_czlx idc_isms_base_user.czlx%type;
              v_userId idc_isms_base_user.userid%type;
              v_userIdCur sys_refcursor;
              v_sql varchar2(1600);
              Begin
                   begin
                         if (p_userId is null) then
                           v_sql := 'select USERID from IDC_ISMS_BASE_USER where DEAL_FLAG != 1';
                         else
                           v_sql := 'select USERID from IDC_ISMS_BASE_USER where USERID in (' || p_userId || ')';
                         end if;
                         open v_userIdCur for v_sql;
                         loop
                           fetch v_userIdCur into v_userId;
                           exit when v_userIdCur%notfound;
                           select czlx into v_czlx from idc_isms_base_user where userid = v_userId;
                           if (v_czlx = 2) then
                               select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid = v_userId);
                               insert into idc_isms_base_delete(delid,del_type,idcid,userid)
                               values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userId);
                           end if;

                         /*--添加历史记录start

                         --提供互联网应用服务用户begin

                         --ip地址段
                         insert into idc_hist_base_service_iptrans
                           (histid, iptransid, internet_startip, internet_endip, net_startip, net_endip, hhid, serviceid, userid, create_time, update_time,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL,IPTRANSID, INTERNET_STARTIP, INTERNET_ENDIP, NET_STARTIP, NET_ENDIP, HHID, SERVICEID, USERID, CREATE_TIME, UPDATE_TIME,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR from idc_isms_base_service_iptrans where userid = p_userId;
                         --虚拟主机
                         insert into IDC_HIST_BASE_SERVICE_VIRTUAL
                           (HISTID,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID from IDC_ISMS_BASE_SERVICE_VIRTUAL where userid = p_userId;
                         --占用机房对应的机房及机架
                         insert into idc_hist_base_service_hh_frame(HHID,HOUSEID,FRAMEID)
                         select HHID,HOUSEID,FRAMEID from idc_isms_base_service_hh_frame where hhid in (select hhid from idc_isms_base_service_hh where userid = p_userId);
                         --占用机房
                         insert into idc_hist_base_service_hh
                           (histid, hhid, houseid,NODENO, distributetime, bandwidth, serviceid, userid, create_time, update_time,CREATE_USERID)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL, hhid, houseid,NODENO, distributetime, bandwidth, serviceid, userid, create_time, update_time,CREATE_USERID from idc_isms_base_service_hh where userid = p_userId;
                         --域名
                         insert into idc_hist_base_service_domain
                           (histid, domainid, domainname, serviceid, userid, create_time, update_time,CREATE_USER_ID)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL,domainid, domainname, serviceid, userid, create_time, update_time,CREATE_USER_ID from idc_isms_base_service_domain where userid = p_userId;
                         --服务
                         insert into idc_hist_base_user_service
                           (histid, serviceid, servicecontent,SERVICETYPE, regid, setmode,BUSINESS, userid, create_time, update_time,CREATE_USERID)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL,serviceid, servicecontent,SERVICETYPE, regid, setmode,BUSINESS, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_service where userid = p_userId;
                         --提供互联网应用服务用户end

                         --其它用户begin
                         --ip地址段
                         insert into idc_hist_base_user_hh_ipseg
                           (histid, ipsegid, startip, endip, hhid, userid, create_time, update_time,CREATE_USERID)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL,ipsegid, startip, endip, hhid, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_hh_ipseg where userid = p_userId;
                         --占用机房对应的机房及机架
                         insert into idc_hist_base_user_hh_frame (hhid,houseid,frameid)
                         select hhid,houseid,frameid from idc_isms_base_user_hh_frame where hhid in (select hhid from idc_isms_base_user_hh where userid = p_userId);
                         --占用机房
                         insert into idc_hist_base_user_hh
                          (histid, hhid, houseid, distributetime, bandwidth, userid, create_time, update_time,CREATE_USERID)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL, hhid, houseid, distributetime, bandwidth, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_hh where userid = p_userId;
                         --其它用户end

                         --用户
                         insert into idc_hist_base_user
                           (histid, userid, jyzid, nature, unitname, unitnature, idtype, idnumber, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, unitadd, zipcode, registertime, create_time, update_time, create_userid,USERCODE,SERVERREGISTERTIME)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL, userid, jyzid, nature, unitname, unitnature, idtype, idnumber, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, unitadd, zipcode, registertime, create_time, update_time, create_userid,USERCODE,SERVERREGISTERTIME from idc_isms_base_user where userid = p_userId;
                         --end*/
                         --删除用户服务信息
                         delete from idc_isms_base_service_iptrans a where a.userid = v_userId;
                         delete from idc_isms_base_service_virtual a  where a.userid = v_userId;
                         --delete idc_isms_base_service_hh_frame where hhid in (select hhid from idc_isms_base_service_hh where userid = p_userId);
                         delete from idc_isms_base_service_hh a where a.userid = v_userId;
                         delete from idc_isms_base_service_domain a where a.userid = v_userId;
                         delete from idc_isms_base_user_service a where a.userid = v_userId;
                         --删除用户占用机房信息
                         delete from idc_isms_base_user_hh_ipseg a where a.userid = v_userId;
                         --delete idc_isms_base_user_hh_frame where hhid in (select hhid from idc_isms_base_user_hh where userid = p_userId);
                         delete from idc_isms_base_user_hh a where a.userid = v_userId;
                         --删除用户机架信息
                         delete from idc_isms_base_user_frame where unitname =(select unitname from idc_isms_base_user where userid = v_userId);
                         --删除用户信息
                         delete from idc_isms_base_user a where a.userid = v_userId;
                       end loop;
                       close v_userIdCur;
                   --exception
                     --when NO_DATA_FOUND THEN
                          --v_czlx := 0;

                  exception
                   WHEN OTHERS THEN
                       ROLLBACK;
                        v_out_success := 0;
                        RETURN;

                  end;
                  commit;
                  v_out_success:=1;
               end;

             procedure delete_user_information(
                  p_userId in varchar2,
                  --出参
                  v_out_success out number
             ) as
              v_idcid idc_isms_base_idc.idcid%type;
              v_czlx idc_isms_base_user.czlx%type;
              v_userId idc_isms_base_user.userid%type;
              v_userIdCur sys_refcursor;
              v_sql varchar2(1600);
              Begin
                   begin
                         if (p_userId is null) then
                           v_sql := 'select USERID from IDC_ISMS_BASE_USER where DEAL_FLAG != 1';
                         else
                           v_sql := 'select USERID from IDC_ISMS_BASE_USER where USERID in (' || p_userId || ')';
                         end if;

                         open v_userIdCur for v_sql;
                         loop
                           fetch v_userIdCur into v_userId;
                           exit when v_userIdCur%notfound;
                           select czlx into v_czlx from idc_isms_base_user where userid = v_userId;
                           if (v_czlx = 2) then
                               select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid = v_userId);
                               insert into idc_isms_base_delete(delid,del_type,idcid,userid)
                               values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userId);
                           end if;

                         /*--添加历史记录start

                         --提供互联网应用服务用户begin

                         --ip地址段
                         insert into idc_hist_base_service_iptrans
                           (histid, iptransid, internet_startip, internet_endip, net_startip, net_endip, hhid, serviceid, userid, create_time, update_time,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL,IPTRANSID, INTERNET_STARTIP, INTERNET_ENDIP, NET_STARTIP, NET_ENDIP, HHID, SERVICEID, USERID, CREATE_TIME, UPDATE_TIME,CREATE_USERID,INTERNET_STARTIPSTR,INTERNET_ENDIPSTR,NET_STARTIPSTR,NET_ENDIPSTR from idc_isms_base_service_iptrans where userid = p_userId;
                         --虚拟主机
                         insert into IDC_HIST_BASE_SERVICE_VIRTUAL
                           (HISTID,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL,VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,CREATE_TIME,UPDATE_TIME,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CREATE_USERID from IDC_ISMS_BASE_SERVICE_VIRTUAL where userid = p_userId;
                         --占用机房对应的机房及机架
                         insert into idc_hist_base_service_hh_frame(HHID,HOUSEID,FRAMEID)
                         select HHID,HOUSEID,FRAMEID from idc_isms_base_service_hh_frame where hhid in (select hhid from idc_isms_base_service_hh where userid = p_userId);
                         --占用机房
                         insert into idc_hist_base_service_hh
                           (histid, hhid, houseid,NODENO, distributetime, bandwidth, serviceid, userid, create_time, update_time,CREATE_USERID)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL, hhid, houseid,NODENO, distributetime, bandwidth, serviceid, userid, create_time, update_time,CREATE_USERID from idc_isms_base_service_hh where userid = p_userId;
                         --域名
                         insert into idc_hist_base_service_domain
                           (histid, domainid, domainname, serviceid, userid, create_time, update_time,CREATE_USER_ID)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL,domainid, domainname, serviceid, userid, create_time, update_time,CREATE_USER_ID from idc_isms_base_service_domain where userid = p_userId;
                         --服务
                         insert into idc_hist_base_user_service
                           (histid, serviceid, servicecontent,SERVICETYPE, regid, setmode,BUSINESS, userid, create_time, update_time,CREATE_USERID)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL,serviceid, servicecontent,SERVICETYPE, regid, setmode,BUSINESS, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_service where userid = p_userId;
                         --提供互联网应用服务用户end

                         --其它用户begin
                         --ip地址段
                         insert into idc_hist_base_user_hh_ipseg
                           (histid, ipsegid, startip, endip, hhid, userid, create_time, update_time,CREATE_USERID)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL,ipsegid, startip, endip, hhid, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_hh_ipseg where userid = p_userId;
                         --占用机房对应的机房及机架
                         insert into idc_hist_base_user_hh_frame (hhid,houseid,frameid)
                         select hhid,houseid,frameid from idc_isms_base_user_hh_frame where hhid in (select hhid from idc_isms_base_user_hh where userid = p_userId);
                         --占用机房
                         insert into idc_hist_base_user_hh
                          (histid, hhid, houseid, distributetime, bandwidth, userid, create_time, update_time,CREATE_USERID)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL, hhid, houseid, distributetime, bandwidth, userid, create_time, update_time,CREATE_USERID from idc_isms_base_user_hh where userid = p_userId;
                         --其它用户end

                         --用户
                         insert into idc_hist_base_user
                           (histid, userid, jyzid, nature, unitname, unitnature, idtype, idnumber, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, unitadd, zipcode, registertime, create_time, update_time, create_userid,USERCODE,SERVERREGISTERTIME)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL, userid, jyzid, nature, unitname, unitnature, idtype, idnumber, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, unitadd, zipcode, registertime, create_time, update_time, create_userid,USERCODE,SERVERREGISTERTIME from idc_isms_base_user where userid = p_userId;
                         --end*/
                         --删除用户服务信息
                         update idc_isms_base_service_iptrans a set a.del_flag = 1 where a.userid = v_userId;
                         update idc_isms_base_service_virtual a set a.del_flag = 1 where a.userid = v_userId;
                         --delete idc_isms_base_service_hh_frame where hhid in (select hhid from idc_isms_base_service_hh where userid = p_userId);
                         update idc_isms_base_service_hh a set a.del_flag = 1 where a.userid = v_userId;
                         update idc_isms_base_service_domain a set a.del_flag = 1 where a.userid = v_userId;
                         update idc_isms_base_user_service a set a.del_flag = 1 where a.userid = v_userId;
                         --删除用户占用机房信息
                         update idc_isms_base_user_hh_ipseg a set a.del_flag = 1 where a.userid = v_userId;
                         --delete idc_isms_base_user_hh_frame where hhid in (select hhid from idc_isms_base_user_hh where userid = p_userId);
                         update idc_isms_base_user_hh a set a.del_flag = 1 where a.userid = v_userId;
                         --删除用户信息
                         update idc_isms_base_user a set a.del_flag = 1 where a.userid = v_userId;
                       end loop;
                       close v_userIdCur;
                   --exception
                     --when NO_DATA_FOUND THEN
                          --v_czlx := 0;

                  exception
                   WHEN OTHERS THEN
                       ROLLBACK;
                        v_out_success := 0;
                        RETURN;

                  end;
                  commit;
                  v_out_success:=1;
               end;

       procedure delete_user_information(
          p_userId in varchar2,
          p_temp in number,
          --出参
          v_out_success out number
       )as

        v_userId idc_isms_base_user.userid%type;
        v_userIdCur sys_refcursor;
        v_sql varchar2(1600);
        Begin
             begin
                 if (p_userId is null) then
                   v_sql := 'select USERID from IDC_ISMS_BASE_USER where DEAL_FLAG != 1';
                 else
                   v_sql := 'select USERID from IDC_ISMS_BASE_USER where USERID in (' || p_userId || ')';
                 end if;
                 open v_userIdCur for v_sql;
                 loop
                   fetch v_userIdCur into v_userId;
                   exit when v_userIdCur%notfound;
                   --删除用户服务信息
                   update idc_isms_base_service_iptrans a set a.del_flag = 1 where a.userid = v_userId;
                   update idc_isms_base_service_virtual a set a.del_flag = 1 where a.userid = v_userId;
                   --delete idc_isms_base_service_hh_frame where hhid in (select hhid from idc_isms_base_service_hh where userid = p_userId);
                   update idc_isms_base_service_hh a set a.del_flag = 1 where a.userid = v_userId;
                   update idc_isms_base_service_domain a set a.del_flag = 1 where a.userid = v_userId;
                   update idc_isms_base_user_service a set a.del_flag = 1 where a.userid = v_userId;
                   --删除用户占用机房信息
                   update idc_isms_base_user_hh_ipseg a set a.del_flag = 1 where a.userid = v_userId;
                   --delete idc_isms_base_user_hh_frame where hhid in (select hhid from idc_isms_base_user_hh where userid = p_userId);
                   update idc_isms_base_user_hh a set a.del_flag = 1 where a.userid = v_userId;
                   --删除用户信息
                   update idc_isms_base_user a set a.del_flag = 1 where a.userid = v_userId;
               end loop;
               close v_userIdCur;
            exception
             WHEN OTHERS THEN
             ROLLBACK;
              v_out_success := 0;
              RETURN;
            end;
            commit;
            v_out_success:=1;
       END;

     procedure delete_user_information_nature(

                  p_nature in number,
                  --出参
                  v_out_success out number
             ) as
              v_idcid idc_isms_base_idc.idcid%type;
              v_czlx idc_isms_base_user.czlx%type;
              v_userId idc_isms_base_user.userid%type;
              v_userIdCur sys_refcursor;
              v_sql varchar2(1600);
              Begin
                   begin
                         v_sql := 'select USERID from IDC_ISMS_BASE_USER where DEAL_FLAG != 1';
                         if (p_nature is not null) then
                           v_sql := v_sql || ' and NATURE = ' || p_nature;
                         end if;
                         open v_userIdCur for v_sql;
                         loop
                           fetch v_userIdCur into v_userId;
                           exit when v_userIdCur%notfound;
                           select czlx into v_czlx from idc_isms_base_user where userid = v_userId;
                           if (v_czlx = 2) then
                               select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid = v_userId);
                               insert into idc_isms_base_delete(delid,del_type,idcid,userid)
                               values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userId);
                           end if;
                         --删除用户服务信息
                         update idc_isms_base_service_iptrans a set a.del_flag = 1 where a.userid = v_userId;
                         update idc_isms_base_service_virtual a set a.del_flag = 1 where a.userid = v_userId;
                         --delete idc_isms_base_service_hh_frame where hhid in (select hhid from idc_isms_base_service_hh where userid = p_userId);
                         update idc_isms_base_service_hh a set a.del_flag = 1 where a.userid = v_userId;
                         update idc_isms_base_service_domain a set a.del_flag = 1 where a.userid = v_userId;
                         update idc_isms_base_user_service a set a.del_flag = 1 where a.userid = v_userId;
                         --删除用户占用机房信息
                         update idc_isms_base_user_hh_ipseg a set a.del_flag = 1 where a.userid = v_userId;
                         --delete idc_isms_base_user_hh_frame where hhid in (select hhid from idc_isms_base_user_hh where userid = p_userId);
                         update idc_isms_base_user_hh a set a.del_flag = 1 where a.userid = v_userId;
                         --删除用户信息
                         update idc_isms_base_user a set a.del_flag = 1 where a.userid = v_userId;
                       end loop;
                       close v_userIdCur;
                   --exception
                     --when NO_DATA_FOUND THEN
                          --v_czlx := 0;

                  exception
                   WHEN OTHERS THEN
                       ROLLBACK;
                        v_out_success := 0;
                        RETURN;

                  end;
                  v_out_success:=1;
               end;


        procedure del_user_information_nature(
                  p_nature in number,
                  --出参
                  v_out_success out number
             ) as
               v_idcid idc_isms_base_idc.idcid%type;
              v_czlx idc_isms_base_user.czlx%type;
              v_userId idc_isms_base_user.userid%type;
              v_userIdCur sys_refcursor;
              v_sql varchar2(1600);
              Begin
                   begin
                         v_sql := 'select USERID from IDC_ISMS_BASE_USER where DEAL_FLAG != 1';
                         if (p_nature is not null) then
                         v_sql := v_sql || ' and NATURE = ' || p_nature;
                         end if;
                         open v_userIdCur for v_sql;
                         loop
                           fetch v_userIdCur into v_userId;
                           exit when v_userIdCur%notfound;
                           select czlx into v_czlx from idc_isms_base_user where userid = v_userId;
                           if (v_czlx = 2) then
                               select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid = v_userId);
                               insert into idc_isms_base_delete(delid,del_type,idcid,userid)
                               values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userId);
                           end if;
                         --删除用户服务信息
                         delete from idc_isms_base_service_iptrans a where a.userid = v_userId;
                         delete from idc_isms_base_service_virtual a  where a.userid = v_userId;
                         --delete idc_isms_base_service_hh_frame where hhid in (select hhid from idc_isms_base_service_hh where userid = p_userId);
                         delete from idc_isms_base_service_hh a where a.userid = v_userId;
                         delete from idc_isms_base_service_domain a where a.userid = v_userId;
                         delete from idc_isms_base_user_service a where a.userid = v_userId;
                         --删除用户占用机房信息
                         delete from idc_isms_base_user_hh_ipseg a where a.userid = v_userId;
                         --delete idc_isms_base_user_hh_frame where hhid in (select hhid from idc_isms_base_user_hh where userid = p_userId);
                         delete from idc_isms_base_user_hh a where a.userid = v_userId;
                         --删除用户信息
                         delete from idc_isms_base_user a where a.userid = v_userId;
                       end loop;
                       close v_userIdCur;
                   --exception
                     --when NO_DATA_FOUND THEN
                          --v_czlx := 0;

                  exception
                   WHEN OTHERS THEN
                       ROLLBACK;
                        v_out_success := 0;
                        RETURN;

                  end;
                  v_out_success:=1;
               end;


    --增加其它用户占用机房信息
    procedure insert_user_hh_information(
             p_userId in number,
             p_houseId in number,
             p_distributeTime in varchar2,
             p_bandWidth in number,
             p_opeType in number,
             p_dealFlag in number,
             p_createUserId in number,
             p_frameIds in varchar2,
             p_areaCode in varchar2,
             p_hhId out number
   )as
          v_hhId number;
        --  cursor frameIds_cur is select * from table(split_str(p_frameIds,','));
       --   perRow frameIds_cur%Rowtype;

     BEGIN
          select seq_isms_base_user_hhid.nextval into v_hhId from dual;
          p_hhId := v_hhId;
          insert into idc_isms_base_user_hh(hhid,userid,houseid,distributetime,bandwidth,czlx,deal_flag,create_time,create_userid,subordinateunit_areacode)
                       values(v_hhId,p_userId,p_houseId,p_distributeTime,p_bandWidth,p_opeType,p_dealFlag,sysdate,p_createUserId,p_areaCode);
        -- for perRow in frameIds_cur loop
        --   insert into idc_isms_base_user_hh_frame(hhid,houseid,frameid)
        --               values(v_hhId,p_houseId,perRow.Column_Value);
       --  end loop;
     END;

    --修改其它用户占用机房信息
    procedure update_user_hh_information(
             p_hhId in number,
             p_houseId in number,
             p_distributeTime in varchar2,
             p_bandWidth in number,
             p_frameIds in varchar2,
             p_areaCode in varchar2
   )as

           cursor frameIds_cur is select * from table(split_str(p_frameIds,','));
           perRow frameIds_cur%Rowtype;

     BEGIN
          update idc_isms_base_user_hh
             set houseid=p_houseId,
                 distributetime=p_distributeTime,
                 bandwidth=p_bandWidth,
                 update_time=sysdate,
                 DEAL_FLAG=0,
                 subordinateunit_areacode=p_areaCode
           where hhid=p_hhId;

           if (p_frameIds is not null) then
             delete idc_isms_base_user_hh_frame where hhid=p_hhId;
             for perRow in frameIds_cur loop
               insert into idc_isms_base_user_hh_frame(hhid,houseid,frameid)
                           values(p_hhId,p_houseId,perRow.Column_Value);
             end loop;
           end if;
     END;

   procedure insert_service_hh_frame_info(
            p_houseId in number,
            p_frameIds in varchar2,
            p_unitName in varchar2
   ) as
      cursor frameIds_cur is select * from table(split_str(p_frameids, ','));
      perRow frameIds_cur%RowType;
   begin
       for perRow in frameIds_cur loop
         if(perRow.Column_Value is not null) then
           insert into IDC_ISMS_BASE_USER_FRAME(id,houseid,frameid,unitName) values(SEQ_ISMS_BASE_USER_FRAMEID.NEXTVAL,p_houseId,perRow.Column_Value, p_unitName);
         end if;
       end loop;
   end;

   --增加服务用户占用机房信息
   procedure insert_service_hh_information(
             p_userId in number,
             p_serviceId in number,
             p_houseId in number,
             --p_nodeNo in varchar2,
             p_distributeTime in varchar2,
             p_bandWidth in number,
             p_opeType in number,
             p_dealFlag in number,
             p_createUserId in number,
             p_frameIds in varchar2,
             p_hhId out number,
             p_areaCode in varchar2
             --p_business in number
   )as
          v_hhId number;
          v_business number;
          cursor frameIds_cur is select * from table(split_str(p_frameIds,','));
          perRow frameIds_cur%Rowtype;

     BEGIN
          select seq_isms_base_service_hhid.nextval into v_hhId from dual;
          p_hhId := v_hhId;
          insert into IDC_ISMS_BASE_SERVICE_HH(hhid,userid,SERVICEID,houseid,distributetime,bandwidth,czlx,deal_flag,create_time,create_userid,Subordinateunit_Areacode)
                       values(v_hhId,p_userId, p_serviceId,p_houseId,p_distributeTime,p_bandWidth,p_opeType,p_dealFlag,sysdate,p_createUserId,p_areaCode);
          select t.business into v_business from idc_isms_base_user_service t where t.serviceid = p_serviceId;
          if (v_business = 1) then
             for perRow in frameIds_cur loop
               if(perRow.Column_Value is not null) then
                 insert into IDC_ISMS_BASE_SERVICE_HH_FRAME(id,hhid,houseid,frameid) values(seq_isms_base_service_hh_frame.nextval,v_hhId,p_houseId,perRow.Column_Value);
               end if;
             end loop;
          end if;
     END;

    --修改服务用户占用机房信息
    procedure update_service_hh_information(
             p_hhId in number,
             p_houseId in number,
             p_distributeTime in varchar2,
             p_bandWidth in number,
             p_frameIds in varchar2
   )as

           cursor frameIds_cur is select * from table(split_str(p_frameIds,','));
           perRow frameIds_cur%Rowtype;

     BEGIN
          update IDC_ISMS_BASE_SERVICE_HH
             set houseid=p_houseId,
                 distributetime=p_distributeTime,
                 bandwidth=p_bandWidth,
                 update_time=sysdate,
                 DEAL_FLAG = 0
           where hhid=p_hhId;

           if (p_frameIds is not null) then
             delete IDC_ISMS_BASE_SERVICE_HH_FRAME where hhid=p_hhId;
             for perRow in frameIds_cur loop
               insert into IDC_ISMS_BASE_SERVICE_HH_FRAME(id,hhid,houseid,frameid) values(seq_isms_base_service_hh_frame.nextval,p_hhId,p_houseId,perRow.Column_Value);
             end loop;
           end if;
     END;

     --服务占用机房虚拟主机
     procedure list_service_hh_virtual_info(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_hhID in number,
            p_virtualNo in varchar2,
            p_name in varchar2,
            p_status in number,
            p_type in number,
            p_delFlag in number
         ) is
             --定义
             v_field     varchar2(2000); --字段
             v_innersql  varchar2(2000); --内部语句，完整的查询sql
             v_order     varchar2(500); --内部排序语句
             v_condition varchar2(2000) := ''; --条件语句
             v_count     varchar2(2000); --统计记录总数语句
             v_sql       varchar2(2000); --查询语句
             v_s         number(10); --开始记录
             v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from IDC_ISMS_BASE_SERVICE_VIRTUAL where 1 = 1 ';
            v_field    := ' VIRTUALID,HHID,SERVICEID,USERID,VIRTUALHOST_NAME,VIRTUALHOST_STATE,VIRTUALHOST_TYPE,NETWORK_ADDRESS,VIRTUALHOST_NO,MGN_ADDRESS,CZLX,DEAL_FLAG,CREATE_TIME,UPDATE_TIME,del_flag ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' userid DESC';
            end if;
            --条件语句
            if p_hhID > 0 then
               v_condition := v_condition || ' and HHID  = ' || p_hhID;
            end if;
            if (p_virtualNo is not null) then
               v_condition := v_condition || ' and VIRTUALHOST_NO like ''%' || p_virtualNo || '%''';
            end if;
            if (p_name is not null) then
               v_condition := v_condition || ' and VIRTUALHOST_NAME like ''%' || p_name || '%''';
            end if;
            if p_status >= 0 then
               v_condition := v_condition || ' and VIRTUALHOST_STATE  = ' || p_status;
            end if;
            if p_type >= 0 then
               v_condition := v_condition || ' and VIRTUALHOST_TYPE  = ' || p_type;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and DEL_FLAG = ' || p_delFlag;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

          --还原其它用户-占用机房-IP地址段
          procedure recover_HHIPSeg_information(
            p_ipsegId in varchar2,
            --出参
            v_out_success out number
          ) as

          v_ipsegId idc_isms_base_user_hh_ipseg.ipsegid%type;
          var_out t_ret_table;

          BEGIN
            begin
              var_out := split_str(p_ipsegId, ',');
              for i in 1..var_out.count loop
                v_ipsegId := var_out(i);
                update idc_isms_base_user_hh_ipseg a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.ipsegid = v_ipsegId;
              end loop;
              exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 2;
                    RETURN;
             end;
             commit;
             v_out_success := 1;
          END;

          --还原其它用户-占用机房
          procedure recover_user_hh_information(
            p_hhId in varchar2,
            --出参
            v_out_success out number
          ) as

          v_hhId idc_isms_base_user_hh.hhid%type;
          var_out t_ret_table;

          BEGIN
            begin
              var_out := split_str(p_hhId, ',');
              for i in 1..var_out.count loop
                v_hhId := var_out(i);
                update idc_isms_base_user_hh a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.hhid = v_hhId;
              end loop;
              exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 2;
                    RETURN;
             end;
             commit;
             v_out_success := 1;
          END;

          --还原IP地址转换
          procedure recover_service_hh_iptrans(
            p_ipTransId in varchar2,
            --出参
            v_out_success out number
          ) as

          v_ipTransId idc_isms_base_service_iptrans.iptransid%type;
          var_out t_ret_table;

          BEGIN
            begin
              var_out := split_str(p_ipTransId, ',');
              for i in 1..var_out.count loop
                v_ipTransId := var_out(i);
                update idc_isms_base_service_iptrans a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.iptransid = v_ipTransId;
              end loop;
              exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 2;
                    RETURN;
             end;
             commit;
             v_out_success := 1;
          END;

           --还原虚拟主机
          procedure recover_virtual_host(
            p_virtualId in varchar2,
            --出参
            v_out_success out number
          ) as

          v_virtualHostCount number := 0;
          v_virtualId idc_isms_base_service_virtual.virtualid%type;
          v_virtualNo idc_isms_base_service_virtual.virtualhost_no%type;
          v_virtualName idc_isms_base_service_virtual.virtualhost_name%type;
          var_out t_ret_table;

          BEGIN
            begin
              var_out := split_str(p_virtualId, ',');
              for i in 1..var_out.count loop
                v_virtualId := var_out(i);
                select a.virtualhost_no,a.virtualhost_name into v_virtualNo,v_virtualName from idc_isms_base_service_virtual a where a.virtualid = v_virtualId;
                select count(1) into v_virtualHostCount from idc_isms_base_service_virtual a where (a.virtualhost_no = v_virtualNo or a.virtualhost_name = v_virtualName) and a.del_flag = 0;
                if v_virtualHostCount > 0 then
                  v_out_success := 0;
                else
                  update idc_isms_base_service_virtual a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.virtualid = v_virtualId;
                end if;

              end loop;
              exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 2;
                    RETURN;
             end;
             commit;
             v_out_success := 1;
          END;

          --还原服务-占用机房
          procedure recover_service_hh(
            p_hhId in varchar2,
            --出参
            v_out_success out number
          ) as

          v_hhId idc_isms_base_service_hh.hhid%type;
          var_out t_ret_table;

          BEGIN
            begin
              var_out := split_str(p_hhId, ',');
              for i in 1..var_out.count loop
                v_hhId := var_out(i);
                update idc_isms_base_service_hh a set a.del_flag = 0,a.czlx =1,a.deal_flag = 0 where a.hhid = v_hhId;
              end loop;
              exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 2;
                    RETURN;
             end;
             commit;
             v_out_success := 1;
          END;

          --还原服务-域名
          procedure recover_service_domain(
            p_domainId in varchar2,
            --出参
            v_out_success out number
          ) as

          v_domainCount number := 0;
          v_domainId idc_isms_base_service_domain.domainid%type;
          v_domainName idc_isms_base_service_domain.domainname%type;
          var_out t_ret_table;

          BEGIN
            begin
              var_out := split_str(p_domainId, ',');
              for i in 1..var_out.count loop
                v_domainId := var_out(i);
                select a.domainname into v_domainName from idc_isms_base_service_domain a where a.domainid = v_domainId;
                select count(1) into v_domainCount from idc_isms_base_service_domain a where a.domainname = v_domainName and a.del_flag = 0;
                if v_domainCount > 0 then
                  v_out_success := 0;
                else
                  update idc_isms_base_service_domain a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.domainid = v_domainId;
                end if;
              end loop;
              exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 2;
                    RETURN;
             end;
             commit;
             v_out_success := 1;
          END;

           --还原服务
          procedure recover_user_service(
            p_serviceId in varchar2,
            --出参
            v_out_success out number
          ) as

          v_serviceId idc_isms_base_user_service.serviceid%type;
          var_out t_ret_table;

          BEGIN
            begin
              var_out := split_str(p_serviceId, ',');
              for i in 1..var_out.count loop
                v_serviceId := var_out(i);
                update idc_isms_base_user_service a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.serviceid = v_serviceId;
              end loop;
              exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 2;
                    RETURN;
             end;
             commit;
             v_out_success := 1;
          END;

           --还原用户信息
            procedure recover_user_information(
              p_userId in varchar2,
              --出参
              v_out_success out number
            ) as

            v_userCount number := 0;
            v_idcCount number := 0;
            v_jyzId idc_isms_base_user.jyzid%type;
            v_idcid idc_isms_base_idc.idcid%type;
            v_idcName idc_isms_base_idc.idcname%type;
            v_idcDelFlag idc_isms_base_idc.del_flag%type;
            v_userId idc_isms_base_user.userid%type;
            v_userCode idc_isms_base_user.usercode%type;
            v_unitName idc_isms_base_user.unitname%type;
            var_out t_ret_table;

            BEGIN
              begin
                var_out := split_str(p_userId, ',');
                for i in 1..var_out.count loop
                  v_userId := var_out(i);
                  select a.jyzid,a.usercode,a.unitname into v_jyzId,v_userCode,v_unitName from idc_isms_base_user a where a.userid = v_userId;
                  select count(1) into v_userCount from idc_isms_base_user a where (a.usercode = v_userCode or a.unitname = v_unitName) and a.del_flag = 0;
                  select a.idcid,a.idcname,a.del_flag into v_idcid,v_idcName,v_idcDelFlag from idc_isms_base_idc a where a.jyzid = v_jyzId;
                  if v_idcDelFlag = 1 then
                     select count(1) into v_idcCount from idc_isms_base_idc a where (a.idcid = v_idcid or a.idcname = v_idcName) and a.del_flag = 0;
                  end if;
                  if (v_userCount > 0 or v_idcCount > 0) then
                    v_out_success := 0;
                    return;
                  else
                    --还原经营者信息
                    if v_idcDelFlag = 1 then
                      update idc_isms_base_idc a set a.del_flag = 0 where a.jyzid = v_jyzId;
                    end if;
                    --还原用户信息
                    update idc_isms_base_user a set a.del_flag = 0 where a.userid = v_userId;
                  end if;
                end loop;
                exception
                 WHEN OTHERS THEN
                      ROLLBACK;
                      v_out_success := 2;
                      RETURN;
               end;
               commit;
               v_out_success := 1;
            END;

    procedure recover_user_information_new(
                  p_userId in varchar2,
                  --出参
                  v_out_success out number
             ) as
              v_idcid idc_isms_base_idc.idcid%type;
              v_czlx idc_isms_base_user.czlx%type;
              v_userId idc_isms_base_user.userid%type;
              v_userIdCur sys_refcursor;
              v_sql varchar2(1600);
              Begin
                   begin
                         if (p_userId is null) then
                           v_sql := 'select USERID from IDC_ISMS_BASE_USER where DEAL_FLAG != 1';
                         else
                           v_sql := 'select USERID from IDC_ISMS_BASE_USER where USERID in (' || p_userId || ')';
                         end if;

                         open v_userIdCur for v_sql;
                         loop
                           fetch v_userIdCur into v_userId;
                           exit when v_userIdCur%notfound;
                           select czlx into v_czlx from idc_isms_base_user where userid = v_userId;
                           if (v_czlx = 2) then
                               select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid = v_userId);
                               insert into idc_isms_base_delete(delid,del_type,idcid,userid)
                               values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userId);
                           end if;
                         update idc_isms_base_service_iptrans a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         update idc_isms_base_service_virtual a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         update idc_isms_base_service_hh a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         update idc_isms_base_service_domain a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         update idc_isms_base_user_service a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         --恢复用户占用机房信息
                         update idc_isms_base_user_hh_ipseg a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         --delete idc_isms_base_user_hh_frame where hhid in (select hhid from idc_isms_base_user_hh where userid = p_userId);
                         update idc_isms_base_user_hh a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         --恢复用户信息
                         update idc_isms_base_user a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                       end loop;
                       close v_userIdCur;
                   --exception
                     --when NO_DATA_FOUND THEN
                          --v_czlx := 0;

                  exception
                   WHEN OTHERS THEN
                       ROLLBACK;
                        v_out_success := 0;
                        RETURN;

                  end;
                  commit;
                  v_out_success:=1;
               end;
               procedure updateStatus_user_information(
                  p_userId in varchar2,
                  --出参
                  v_out_success out number
             ) as
              v_idcid idc_isms_base_idc.idcid%type;
              v_czlx idc_isms_base_user.czlx%type;
              v_userId idc_isms_base_user.userid%type;
              v_userIdCur sys_refcursor;
              v_sql varchar2(1600);
              Begin
                   begin
                         v_sql := 'select USERID from IDC_ISMS_BASE_USER where USERID in (' || p_userId || ')';
                         open v_userIdCur for v_sql;
                         loop
                           fetch v_userIdCur into v_userId;
                           exit when v_userIdCur%notfound;

                         update idc_isms_base_service_iptrans a set a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         update idc_isms_base_service_virtual a set a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         update idc_isms_base_service_hh a set a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         update idc_isms_base_service_domain a set a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         update idc_isms_base_user_service a set a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         --更改用户占用机房信息
                         update idc_isms_base_user_hh_ipseg a set a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         update idc_isms_base_user_hh a set a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                         --更改用户信息
                         update idc_isms_base_user a set a.czlx=1,a.deal_flag=0 where a.userid = v_userId;
                       end loop;
                       close v_userIdCur;

                  exception
                   WHEN OTHERS THEN
                       ROLLBACK;
                        v_out_success := 0;
                        RETURN;

                  end;
                  commit;
                  v_out_success:=1;
               end;

    procedure update_service_ip_information(
             p_hhId               in number,
             p_houseId            in number,
             p_distributeTime     in varchar2,
             p_bandWidth          in number,
             p_iptransId          in number,
             p_selIpTrans         in number,
             p_internetStartIP    in varchar2,
             p_internetStartIPStr in varchar2,
             p_internetEndIP      in varchar2,
             p_internetEndIPStr   in varchar2,
             p_netStartIP         in varchar2,
             p_netStartIPStr      in varchar2,
             p_netEndIP           in varchar2,
             p_netEndIPStr        in varchar2
   ) is
        /*cursor frameIds_cur is select * from table(split_str(p_frameIds,','));
        perRow frameIds_cur%Rowtype;*/
   begin

        update IDC_ISMS_BASE_SERVICE_HH
             set houseid=p_houseId,
                 distributetime=p_distributeTime,
                 bandwidth=p_bandWidth,
                 update_time=sysdate,
                 DEAL_FLAG = 0
           where hhid=p_hhId;
         /*
        if (p_frameIds is not null) then
             delete IDC_ISMS_BASE_SERVICE_HH_FRAME where hhid=p_hhId;
             for perRow in frameIds_cur loop
               insert into IDC_ISMS_BASE_SERVICE_HH_FRAME(hhid,houseid,frameid)
                           values(p_hhId,p_houseId,perRow.Column_Value);
             end loop;
           end if;*/
       update IDC_ISMS_BASE_SERVICE_IPTRANS
            set HHID = p_hhId,
                SELIPTRANS = p_selIpTrans,
                INTERNET_STARTIP = p_internetStartIP,
                INTERNET_STARTIPSTR = p_internetStartIPStr,
                INTERNET_ENDIP = p_internetEndIP,
                INTERNET_ENDIPSTR = p_internetEndIPStr,
                NET_STARTIP = p_netStartIP,
                NET_STARTIPSTR = p_netStartIPStr,
                NET_ENDIP = p_netEndIP,
                NET_ENDIPSTR = p_netEndIPStr,
                UPDATE_TIME = sysdate,
                DEAL_FLAG = 0
            where iptransid = p_iptransId;
   end;

   procedure update_user_ip_information(
             p_hhId               in number,
             p_houseId            in number,
             p_distributeTime     in varchar2,
             p_bandWidth          in number,
             p_ipsegId            in number,
             p_selIpTrans         in number,
             p_startIP            in varchar2,
             p_startIPStr         in varchar2,
             p_endIP              in varchar2,
             p_endIPStr           in varchar2
   ) is
   begin
        update IDC_ISMS_BASE_USER_HH
             set houseid=p_houseId,
                 distributetime=p_distributeTime,
                 bandwidth=p_bandWidth,
                 update_time=sysdate,
                 DEAL_FLAG = 0
           where hhid=p_hhId;
        update IDC_ISMS_BASE_USER_HH_IPSEG
            set SELIPTRANS = p_selIpTrans,
                STARTIP = p_startIP,
                STARTIPSTR = p_startIPStr,
                ENDIP = p_endIP,
                ENDIPSTR = p_endIPStr,
                UPDATE_TIME = sysdate,
                DEAL_FLAG = 0
            where IPSEGID = p_ipsegid;
   end;

   -- 修改虚拟主机信息
   procedure update_virtual_host_infor(
             p_hhId                 in number,
             p_houseId              in number,
             p_distributeTime       in varchar2,
             p_bandWidth            in number,
             p_virtualId            in number,
             p_virtualNo            in varchar2,
             p_virtualhostName      in varchar2,
             p_networkAddress       in varchar2,
             p_virtualhostState     in number,
             p_virtualhostType      in number,
             p_mgnAddress           in varchar2,
             p_userId               in number
   ) is
        /*cursor frameIds_cur is select * from table(split_str(p_frameIds,','));
        perRow frameIds_cur%Rowtype;*/
   begin
        /*update IDC_ISMS_BASE_SERVICE_HH
           set houseid=p_houseId,
               distributetime=p_distributeTime,
               bandwidth=p_bandWidth,
               update_time=sysdate,
               DEAL_FLAG = 0
         where hhid=p_hhId;

       if (p_frameIds is not null) then
           delete IDC_ISMS_BASE_SERVICE_HH_FRAME where hhid=p_hhId;
               for perRow in frameIds_cur loop
               insert into IDC_ISMS_BASE_SERVICE_HH_FRAME(hhid,houseid,frameid)
                      values(p_hhId,p_houseId,perRow.Column_Value);
             end loop;
          end if;*/
        update IDC_ISMS_BASE_SERVICE_VIRTUAL
            set houseid = p_houseId,
                USERID = p_userId,
                VIRTUALHOST_NO = p_virtualNo,
                VIRTUALHOST_NAME = p_virtualhostName,
                NETWORK_ADDRESS = p_networkAddress,
                VIRTUALHOST_STATE = p_virtualhostState,
                VIRTUALHOST_TYPE = p_virtualhostType,
                MGN_ADDRESS = p_mgnAddress,
                UPDATE_TIME = sysdate,
                DEAL_FLAG = 0
          where virtualId = p_virtualId;
   end;

   procedure update_service_hh_frame_infor(
             p_houseId              in number,
             p_frameId              in number,
             p_hhId                 in number,
             p_id                   in number
   ) as
   begin
        update idc_isms_base_service_hh_frame
        set hhid = p_hhId, frameId = p_frameId, houseId = p_houseId
        where id = p_id;
        commit;
   end;

    --修改其它用户占用机房信息
    procedure update_imp_user_hh_information(
             p_userId in number,
             p_houseId in number,
             p_distributeTime in varchar2,
             p_bandWidth in number,
             p_opeType in number,
             p_dealFlag in number,
             p_createUserId in number
   )as
        v_Count number:= 0;
        v_hhId number;
     BEGIN
        select count(1) into v_Count from idc_isms_base_user_hh where userid=p_userId and houseid=p_houseId and del_flag=0;
        if (v_Count > 0) then
          update idc_isms_base_user_hh
             set distributetime=p_distributeTime,
                 bandwidth=p_bandWidth,
                 update_time=sysdate
             where userid=p_userId and houseid=p_houseId;
        else
          select seq_isms_base_user_hhid.nextval into v_hhId from dual;

          insert into idc_isms_base_user_hh(hhid,userid,houseid,distributetime,bandwidth,czlx,deal_flag,create_time,create_userid)
                 values(v_hhId,p_userId,p_houseId,p_distributeTime,p_bandWidth,p_opeType,p_dealFlag,sysdate,p_createUserId);
        end if;
     END;

    procedure update_imp_user_service(
             p_userId in number,
             p_serviceContent in varchar2,
             p_regId in varchar2,
             p_serviceType in number,
             p_setmode in number,
             p_business in number,
             p_opeType in number,
             p_dealFlag in number,
             p_createUserId in number
   )as
        v_Count number:= 0;
        v_serviceId number;
     BEGIN
        select count(1) into v_Count from idc_isms_base_user_service where regid=p_regId and del_flag=0;
        if (v_Count > 0) then
          update idc_isms_base_user_service
             set servicecontent=p_serviceContent,
                 setmode=p_setmode,
                 servicetype=p_serviceType,
                 business=p_business,
                 update_time=sysdate
             where regid=p_regId;
        else
          select seq_isms_base_user_serviceid.nextval into v_serviceId from dual;
          insert into idc_isms_base_user_service(serviceid, userid, servicecontent, regid, setmode, czlx, deal_flag,create_time,create_userid, servicetype, business)
          values(v_serviceId,p_userId,p_serviceContent,p_regId,p_setmode,p_opeType,p_dealFlag,sysdate,p_createUserId,p_serviceType,p_business);
        end if;
     END;


    procedure update_imp_service_hh(
             p_houseId in number,
             p_serviceId in varchar2,
             p_userId in varchar2,
             p_distributeTime in varchar2,
             p_bandWidth in number,
             p_opeType in number,
             p_dealFlag in number,
             p_createUserId in number,
             p_areaCode in varchar2
   )  as
        v_Count number:= 0;
        v_hhId number;
     BEGIN
        select count(1) into v_Count from idc_isms_base_service_hh where serviceid=p_serviceId and houseid=p_houseId and subordinateunit_areacode=p_areaCode and del_flag=0;
        if (v_Count > 0) then
          update idc_isms_base_service_hh
             set distributetime=p_distributeTime,
                 bandwidth=p_bandWidth,
                 update_time=sysdate
                 where serviceid=p_serviceId and houseid=p_houseId and subordinateunit_areacode=p_areaCode;
        else
          select seq_isms_base_service_hhid.nextval into v_hhId from dual;
          insert into IDC_ISMS_BASE_SERVICE_HH(hhid,userid,SERVICEID,houseid,distributetime,bandwidth,czlx,deal_flag,create_time,create_userid,subordinateunit_areacode)
          values(v_hhId,p_userId,p_serviceId,p_houseId,p_distributeTime,p_bandWidth,p_opeType,p_dealFlag,sysdate,p_createUserId,p_areaCode);
        end if;
     END;

  procedure update_user_deal_flag(
            p_userCode in varchar2,
            --出参
            v_out_success out number
  )as
        v_userid number;
     BEGIN
        select userid into v_userid from idc_isms_base_user where usercode=p_userCode;
        update idc_isms_base_user set deal_flag = 1 where userid=v_userid and del_flag=0;
        --其它用户
        update idc_isms_base_user_hh set deal_flag = 1 where userid=v_userid and del_flag=0;
        update idc_isms_base_user_hh_ipseg set deal_flag = 1 where userid=v_userid and del_flag=0;
        --提供互联网服务用户
        update idc_isms_base_user_service set deal_flag = 1 where userid=v_userid and del_flag=0;
        update idc_isms_base_service_hh set deal_flag = 1 where userid=v_userid and del_flag=0;
        update idc_isms_base_service_iptrans set deal_flag = 1 where userid=v_userid and del_flag=0;
        update idc_isms_base_service_domain set deal_flag = 1 where userid=v_userid and del_flag=0;
        update idc_isms_base_service_virtual set deal_flag = 1 where userid=v_userid and del_flag=0;

     END;

     procedure delete_user_infor_nocommit(
                  p_userId in varchar2,
                  --出参
                  v_out_success out number
             ) as
              v_idcid idc_isms_base_idc.idcid%type;
              v_czlx idc_isms_base_user.czlx%type;
              v_userId idc_isms_base_user.userid%type;
              v_userIdCur sys_refcursor;
              v_sql varchar2(100);
              Begin
                   begin
                         if (p_userId is null) then
                           v_sql := 'select USERID from IDC_ISMS_BASE_USER where DEAL_FLAG != 1';
                         else
                           v_sql := 'select USERID from IDC_ISMS_BASE_USER where USERID in (' || p_userId || ')';
                         end if;
                         open v_userIdCur for v_sql;
                         loop
                           fetch v_userIdCur into v_userId;
                           exit when v_userIdCur%notfound;
                           select czlx into v_czlx from idc_isms_base_user where userid = v_userId;
                           if (v_czlx = 2) then
                               select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid = v_userId);
                               insert into idc_isms_base_delete(delid,del_type,idcid,userid)
                               values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userId);
                           end if;

                         --删除用户服务信息
                         update idc_isms_base_service_iptrans a set a.del_flag = 1 where a.userid = v_userId;
                         update idc_isms_base_service_virtual a set a.del_flag = 1 where a.userid = v_userId;
                         --delete idc_isms_base_service_hh_frame where hhid in (select hhid from idc_isms_base_service_hh where userid = p_userId);
                         update idc_isms_base_service_hh a set a.del_flag = 1 where a.userid = v_userId;
                         update idc_isms_base_service_domain a set a.del_flag = 1 where a.userid = v_userId;
                         update idc_isms_base_user_service a set a.del_flag = 1 where a.userid = v_userId;
                         --删除用户占用机房信息
                         update idc_isms_base_user_hh_ipseg a set a.del_flag = 1 where a.userid = v_userId;
                         --delete idc_isms_base_user_hh_frame where hhid in (select hhid from idc_isms_base_user_hh where userid = p_userId);
                         update idc_isms_base_user_hh a set a.del_flag = 1 where a.userid = v_userId;
                         --删除用户信息
                         update idc_isms_base_user a set a.del_flag = 1 where a.userid = v_userId;
                       end loop;
                       close v_userIdCur;

                  exception
                   WHEN OTHERS THEN
                       ROLLBACK;
                        v_out_success := 0;
                        RETURN;

                  end;
                  v_out_success:=1;
               end;

       procedure delete_user_hh_infor_nocommit(
            p_hhId in varchar2,
            --出参
            v_out_success out number
         ) as
          v_idcid idc_isms_base_idc.idcid%type;
          v_userid idc_isms_base_user_hh.userid%type;
          v_czlx idc_isms_base_user_hh.czlx%type;
          v_hhId idc_isms_base_user_hh.hhid%type;
          v_hhIdCur sys_refcursor;
          v_sql varchar2(100);
          Begin
               begin
                    if (p_hhId is null) then
                      v_sql := 'select HHID from IDC_ISMS_BASE_USER_HH where DEAL_FLAG != 1';
                    else
                      v_sql := 'select HHID from IDC_ISMS_BASE_USER_HH where HHID in (' || p_hhId || ')';
                    end if;
                    open v_hhIdCur for v_sql;
                    loop
                      fetch v_hhIdCur into v_hhId;
                      exit when v_hhIdCur%notfound;
                      select czlx into v_czlx from idc_isms_base_user_hh a where a.hhid = v_hhId;
                      if (v_czlx = 2) then
                          select userid into v_userid from idc_isms_base_user_hh where hhid = v_hhId;
                          select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid = v_userid);
                          insert into idc_isms_base_delete(delid,del_type,idcid,userid,userhhid)
                                 values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userid,v_hhId);
                      end if;
                      update idc_isms_base_user_hh_ipseg a set a.del_flag = 1 where a.hhid = v_hhId;
                      update idc_isms_base_user_hh a set a.del_flag = 1 where a.hhid = v_hhId;
                  end loop;
                  close v_hhIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               v_out_success:=1;
           end;

       procedure delete_service_infor_nocommit(
                p_serviceId in varchar2,
                --出参
                v_out_success out number
           ) as
             v_idcid idc_isms_base_idc.idcid%type;
             v_userid idc_isms_base_user_service.userid%type;
             v_czlx idc_isms_base_user_service.czlx%type;
             v_serviceId idc_isms_base_user_service.serviceid%type;
             v_serviceIdCur sys_refcursor;
             v_sql varchar2(100);
            Begin
                 begin
                      if(p_serviceId is null) then
                        v_sql := 'select SERVICEID from IDC_ISMS_BASE_USER_SERVICE where DEAL_FLAG != 1';
                      else
                        v_sql := 'select SERVICEID from IDC_ISMS_BASE_USER_SERVICE where SERVICEID in (' || p_serviceId || ')';
                      end if;
                      open v_serviceIdCur for v_sql;
                      loop
                        fetch v_serviceIdCur into v_serviceId;
                        exit when v_serviceIdCur%notfound;
                         select czlx into v_czlx from idc_isms_base_user_service where serviceid = v_serviceId;
                         if (v_czlx = 2) then
                           select userid into v_userid from idc_isms_base_user_service where serviceid = v_serviceId;
                           select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_user where userid=v_userid);
                             insert into idc_isms_base_delete(delid,del_type,idcid,userid,serviceid)
                             values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userid,v_serviceId);
                         end if;
                         update idc_isms_base_service_domain a set a.del_flag = 1 where a.serviceid = v_serviceId;
                         update idc_isms_base_service_hh a set a.del_flag = 1 where a.serviceid = v_serviceId;
                         update idc_isms_base_service_iptrans a set a.del_flag = 1 where a.serviceid = v_serviceId;
                         update idc_isms_base_service_virtual a set a.del_flag = 1 where a.serviceid = v_serviceId;
                         update idc_isms_base_user_service a set a.del_flag = 1 where a.serviceid = v_serviceId;
                      end loop;
                      close v_serviceIdCur;
                 exception
                 WHEN OTHERS THEN
                      ROLLBACK;
                      v_out_success := 0;
                      RETURN;
                 end;
                 v_out_success:=1;
             end;


         procedure delete_service_hh_nocommit(
                p_hhId   in varchar2,
                --出参
                v_out_success    out number
           ) as
            --v_count number(5);
            v_idcid idc_isms_base_idc.idcid%type;
            v_userid idc_isms_base_user_service.userid%type;
            v_serviceid idc_isms_base_service_hh.serviceid%type;
            v_czlx idc_isms_base_service_hh.czlx%type;
            v_hhId idc_isms_base_service_hh.hhid%type;
            v_hhIdCur Sys_Refcursor;
            v_sql varchar2(100);
          Begin
               begin
                    if (p_hhId is null) then
                      v_sql := 'select HHID from IDC_ISMS_BASE_SERVICE_HH where DEAL_FLAG != 1';
                    else
                      v_sql := 'select HHID from IDC_ISMS_BASE_SERVICE_HH where HHID in (' || p_hhId ||')';
                    end if;
                    open v_hhIdCur for v_sql;
                    loop
                      fetch v_hhIdCur into v_hhId;
                      exit when v_hhIdCur%notfound;
                      select czlx into v_czlx from idc_isms_base_service_hh where hhid = v_hhId;
                      if (v_czlx = 2) then
                          select serviceid into v_serviceid from idc_isms_base_service_hh where hhid = v_hhId;
                          select userid into v_userid from idc_isms_base_user_service where serviceid = v_serviceid;
                          select idcid into v_idcid from idc_isms_base_idc where jyzid in (select jyzid from idc_isms_base_user where userid=v_userid);
                          insert into idc_isms_base_delete(delid,del_type,idcid,userid,serviceid,servicehhid)
                                 values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userid,v_serviceid,v_hhId);
                      end if;
                      update idc_isms_base_service_iptrans a set a.del_flag = 1 where a.hhid = v_hhId;
                      update IDC_ISMS_BASE_SERVICE_VIRTUAL a set a.del_flag = 1 where a.hhid = v_hhId;
                      --delete idc_isms_base_service_hh_frame where hhid = p_hhId;
                      update idc_isms_base_service_hh a set a.del_flag = 1 where a.hhid = v_hhId;
                  end loop;
                  close v_hhIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               v_out_success:=1;
           end;

         procedure delete_service_vir_nocommit(
            p_virtualId in varchar2,
            --出参
            v_out_success out number
         ) as

          v_idcid  idc_isms_base_idc.idcid%type;
          v_userId idc_isms_base_service_virtual.userid%type;
          v_serviceId idc_isms_base_service_virtual.serviceid%type;
          v_HHId idc_isms_base_service_virtual.hhid%type;
          v_czlx idc_isms_base_service_virtual.czlx%type;
          v_virtualId idc_isms_base_service_virtual.virtualid%type;
          v_virtualIdCur sys_refcursor;
          v_sql varchar2(100);
          Begin
               begin
                    if (p_virtualId is null) then
                      v_sql := 'select VIRTUALID from IDC_ISMS_BASE_SERVICE_VIRTUAL where DEAL_FLAG != 1';
                    else
                      v_sql := 'select VIRTUALID from IDC_ISMS_BASE_SERVICE_VIRTUAL where VIRTUALID in (' || p_virtualId || ')';
                    end if;
                    open v_virtualIdCur for v_sql;
                    loop
                      fetch v_virtualIdCur into v_virtualId;
                      exit when v_virtualIdCur%notfound;
                      select czlx into v_czlx from idc_isms_base_service_virtual where VIRTUALID = v_virtualId;
                      if (v_czlx = 2) then
                         select HHID,SERVICEID,USERID into v_HHId,v_serviceId,v_userId from idc_isms_base_service_virtual where VIRTUALID = v_virtualId;
                         select IDCID into v_idcid from idc_isms_base_idc where JYZID = (select JYZID from idc_isms_base_user where userid = v_userId);
                         insert into idc_isms_base_delete(delid,del_type,idcid,USERID,SERVICEID,SERVICEHHID,VIRTUALID)
                         values(SEQ_IDC_ISMS_BASE_DELID.Nextval,3,v_idcid,v_userId,v_serviceId,v_HHId,v_virtualId);
                      end if;
                      update IDC_ISMS_BASE_SERVICE_VIRTUAL a set a.del_flag = 1 where a.VIRTUALID = v_virtualId;
                   end loop;
                   close v_virtualIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               v_out_success:=1;
            end;


          procedure delete_user_hh_ipseg_nocommit(
               p_ipsegId in varchar2,
               v_out_success out number
          )as
               v_idcId idc_isms_base_idc.idcid%type;
               v_userId idc_isms_base_user_hh_ipseg.userid%type;
               v_userHHId idc_isms_base_user_hh_ipseg.hhid%type;
               v_ipsegId idc_isms_base_user_hh_ipseg.ipsegid%type;
               v_opeType idc_isms_base_user_hh_ipseg.czlx%type;
               v_ipsegIdCur sys_refcursor;
               v_sql varchar2(100);
          BEGIN
            begin
                if (p_ipsegId is null) then
                  v_sql := 'select IPSEGID from IDC_ISMS_BASE_USER_HH_IPSEG where DEAL_FLAG != 1';
                else
                  v_sql := 'select IPSEGID from IDC_ISMS_BASE_USER_HH_IPSEG where IPSEGID in (' || p_ipsegId || ')';
                end if;
                open v_ipsegIdCur for v_sql;
                loop
                  fetch v_ipsegIdCur into v_ipsegId;
                  exit when v_ipsegIdCur%notfound;
                  select a.czlx,a.userid,a.hhid into v_opeType,v_userId,v_userHHId from idc_isms_base_user_hh_ipseg a where a.IPSEGID = v_ipsegId;
                  update idc_isms_base_user_hh_ipseg a set a.del_flag = 1 where a.IPSEGID = v_ipsegId;
               end loop;
               close v_ipsegIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
            end;
             v_out_success := 1;
          END;

    -- 处理用户表的地址，讲unitAdd字段转化为省份code，省份name，市code，市name，县code，县name，详细地址
    procedure processUnitAdd as
      errorTableNum number;
      v_userCount number;
      v_sql varchar2(3000);
      v_unitAddProvinceCode varchar2(32);
      v_unitAddProvinceName varchar2(32);
      v_unitAddCityCode varchar2(32);
      v_unitAddCityName varchar2(32);
      v_unitAddAreaCode varchar2(32);
      v_unitAddAreaName varchar2(32);
      v_unitAddOtherName varchar2(128);
      v_unitAdd varchar2(128);
      location_unitAddProvinceName number := 0;
      location_unitAddCityName number := 0;
      location_unitAddAreaName number := 0;
      index_user_record IDC_ISMS_BASE_USER%rowtype;
      cursor getAllRecordCursor is
        select *
        from IDC_ISMS_BASE_USER;
    begin
      select count(1) into errorTableNum from all_tables where table_name = 'IDC_ISMS_BASE_USER_ERROR_LOG' and owner = 'CU_V3';
      if errorTableNum = 0 then -- 创建表
        execute immediate 'create table IDC_ISMS_BASE_USER_ERROR_LOG(USERID number, UNITADD varchar2(128), ERROR_DETAIL varchar2(128))';
        commit;
      end if;
      if errorTableNum = 1 then -- 清表
        execute immediate 'truncate table IDC_ISMS_BASE_USER_ERROR_LOG';
        commit;
      end if;
      select count(1) into v_userCount from IDC_ISMS_BASE_USER;
      open getAllRecordCursor;
      if v_userCount <> 0 then
        loop
          fetch getAllRecordCursor into index_user_record;
          exit when getAllRecordCursor%notfound;
          v_unitAdd := index_user_record.unitAdd;
          if v_unitAdd is null then -- 记录地址为空的用户
            execute immediate 'insert into IDC_ISMS_BASE_USER_ERROR_LOG(userId, error_detail) values (' || index_user_record.userId || ', ''' || '地址为空' || ''')';
          else
            -- v_unitAdd -- 这个是我拿到的地址，我要判断是不是以北京市，天津市，上海市，重庆市开头的，用下面的if可以吗？
            if instr(v_unitAdd, '北京市') = 1 or instr(v_unitAdd, '天津市') = 1 or instr(v_unitAdd, '上海市') = 1 or instr(v_unitAdd, '重庆市') = 1 then
              v_unitAddProvinceName := substr(v_unitAdd, 1, 3);
              getAddCodeByAddName(v_unitAddProvinceName, v_unitAddProvinceCode);
              if instr(v_unitAdd, '区', 4) = 0 then -- 没有区，写入错误日志
                execute immediate 'insert into IDC_ISMS_BASE_USER_ERROR_LOG(userId, unitAdd, error_detail) values (' || index_user_record.userId || ', ''' || v_unitAdd || ''', ''' || '没有区' ||''')';
              else -- 截取区
                location_unitAddAreaName := instr(v_unitAdd, '区', 4);
                v_unitAddAreaName := substr(v_unitAdd, 4, location_unitAddAreaName - 3);
                getAddCodeByAddName(v_unitAddAreaName, v_unitAddAreaCode);
                if v_unitAddAreaCode = '' then
                  execute immediate 'insert into IDC_ISMS_BASE_USER_ERROR_LOG(userId, unitAdd, error_detail) values (' || index_user_record.userId || ', ''' || '区名称不存在' ||''')';
                else
                  v_unitAddOtherName := substr(v_unitAdd, location_unitAddAreaName + 1);
                  execute immediate 'update idc_isms_base_user set UNITADDPROVINCEC=''' || v_unitAddProvinceCode || ''',UNITADDPROVINCEN=''' || v_unitAddProvinceName || ''',UNITADDAREAC=''' || v_unitAddAreaCode || ''',UNITADDAREAN=''' || v_unitAddAreaName || ''' where userId=' || index_user_record.userId;
                end if;
              end if;
            else
              if instr(v_unitAdd, '省') = 0 and instr(v_unitAdd, '自治区') = 0 then -- 没有省份和自治区
                -- v_sql = 'insert into IDC_ISMS_BASE_USER_ERROR_LOG(userId, unitAdd, error_detail) values (' || index_user_record.userId || ', ''' || ''', ''' || v_unitAdd || ''', ''' || '没有省份或者自治区' || ''')';
                execute immediate 'insert into IDC_ISMS_BASE_USER_ERROR_LOG(userId, unitAdd, error_detail) values (' || index_user_record.userId || ', ''' || v_unitAdd || ''', ''' || '没有省份或者自治区' || ''')';
              else
                if instr(v_unitAdd, '省') <> 0 then
                  location_unitAddProvinceName := instr(v_unitAdd, '省');
                else
                  location_unitAddProvinceName := instr(v_unitAdd, '自治区');
                end if;
                v_unitAddProvinceName := substr(v_unitAdd, 1, location_unitAddProvinceName);
                getAddCodeByAddName(v_unitAddProvinceName, v_unitAddProvinceCode);
                if v_unitAddCityCode = '' then
                  execute immediate 'insert into IDC_ISMS_BASE_USER_ERROR_LOG(userId, unitAdd, error_detail) values (' || index_user_record.userId || ', ''' || ''', ''' || v_unitAdd || ''', ''' || '省份或者自治区不存在' ||''')';
                else
                  v_unitAddOtherName := substr(v_unitAdd, location_unitAddProvinceName + 1);
                  if instr(v_unitAddOtherName, '市') = 0 and instr(v_unitAddOtherName, '省直辖行政单位') = 0 and instr(v_unitAddOtherName, '自治州') = 0 and instr(v_unitAddOtherName, '地区') = 0 and instr(v_unitAddOtherName, '盟') = 0 then
                    execute immediate 'insert into idc_isms_base_user_erro_log(userId, unitAdd, error_detail) values (' || index_user_record.userId || ', ''' || ''', ''' || v_unitAdd || ''', ''' || '没有市或者省直辖行政单位或者自治州或者地区或者盟' || ''')';
                  else
                    if instr(v_unitAddOtherName, '市') <> 0 then
                      location_unitAddCityName := instr(v_unitAdd, '市');
                    elsif instr(v_unitAddOtherName, '省直辖行政单位') <> 0 then
                      location_unitAddCityName := instr(v_unitAdd, '省直辖行政单位');
                    elsif instr(v_unitAddOtherName, '自治州') <> 0 then
                      location_unitAddCityName := instr(v_unitAdd, '自治州');
                    elsif instr(v_unitAddOtherName, '地区') <> 0 then
                      location_unitAddCityName := instr(v_unitAdd, '地区');
                    elsif instr(v_unitAddOtherName, '盟') <> 0 then
                      location_unitAddCityName := instr(v_unitAdd, '盟');
                    end if;
                    v_unitAddCityName := substr(v_unitAdd, location_unitAddProvinceName + 1, location_unitAddCityName - location_unitAddProvinceName);
                    getAddCodeByAddName(v_unitAddCityName, v_unitAddCityCode);
                    v_unitAddOtherName := substr(v_unitAdd, location_unitAddCityName + 1);
                    if v_unitAddCityCode = '' then
                      execute immediate 'insert into idc_isms_base_user_erro_log(userId, unitAdd, error_detail) values (' || index_user_record.userId || ', ''' || ''', ''' || v_unitAdd || ''', ''' || '市或者省直辖行政单位或者自治州或者地区或者盟不存在' ||''')';
                    else
                      if (v_unitAddProvinceName = '甘肃省' and v_unitAddCityName = '嘉峪关市') or
                         (v_unitAddProvinceName = '广东省' and v_unitAddCityName = '东莞市') or
                         (v_unitAddProvinceName = '广东省' and v_unitAddCityName = '中山市') or
                         (v_unitAddProvinceName = '海南省' and v_unitAddCityName = '三沙市') or
                         (v_unitAddProvinceName = '海南省' and v_unitAddCityName = '儋州市') then
                        execute immediate 'update idc_isms_base_user set UNITADD = ''' || v_unitAddOtherName || ''', UNITADDPROVINCEC=''' || v_unitAddProvinceCode || ''',UNITADDPROVINCEN=''' || v_unitAddProvinceName || ''',UNITADDCITYC=''' || v_unitAddCityCode || ''',UNITADDCITYN=''' || v_unitAddCityName || ''' where userId=' || index_user_record.userId;
                      else
                        if instr(v_unitAddOtherName, '区') = 0 and
                           instr(v_unitAddOtherName, '市') = 0 and
                           instr(v_unitAddOtherName, '县') = 0 and
                           instr(v_unitAddOtherName, '旗') = 0 then
                          execute immediate 'insert into IDC_ISMS_BASE_USER_ERROR_LOG(userId, unitAdd, error_detail) values (' || index_user_record.userId || ', ''' || v_unitAdd || ''', ''' || '没有区或者市或者县或者旗' ||''')';
                        else
                          if instr(v_unitAddOtherName, '区') <> 0 then
                            location_unitAddAreaName := instr(v_unitAdd, '区', location_unitAddCityName + 1);
                          elsif instr(v_unitAddOtherName, '市') <> 0 then
                            location_unitAddAreaName := instr(v_unitAdd, '市', location_unitAddCityName + 1);
                          elsif instr(v_unitAddOtherName, '县') <> 0 then
                            location_unitAddAreaName := instr(v_unitAdd, '县', location_unitAddCityName + 1);
                          elsif instr(v_unitAddOtherName, '旗') <> 0 then
                            location_unitAddAreaName := instr(v_unitAdd, '旗', location_unitAddCityName + 1);
                          end if;
                          v_unitAddAreaName := substr(v_unitAdd, location_unitAddCityName + 1, location_unitAddAreaName - location_unitAddCityName);
                          v_unitAddOtherName := substr(v_unitAdd, location_unitAddCityName + 1);
                          getAddCodeByAddName(v_unitAddAreaName, v_unitAddAreaCode);
                          if v_unitAddAreaCode = '' then
                            execute immediate 'insert into IDC_ISMS_BASE_USER_ERROR_LOG(userId, unitAdd, error_detail) values (' || index_user_record.userId || ', ''' || ''', ''' || v_unitAdd || ''', ''' || '市或者省直辖行政单位或者自治州或者地区或者盟不存在' ||''')';
                          else
                            execute immediate 'update idc_isms_base_user set UNITADD=''' || v_unitAddOtherName || ''', UNITADDPROVINCEC=''' || v_unitAddProvinceCode || ''',UNITADDPROVINCEN=''' || v_unitAddProvinceName || ''',UNITADDCITYC=''' || v_unitAddCityCode || ''',UNITADDCITYN=''' || v_unitAddCityName ||''',UNITADDAREAC=''' || v_unitAddAreaCode || ''',UNITADDAREAN=''' || v_unitAddAreaName || ''' where userId=' || index_user_record.userId;
                          end if;
                        end if;
                      end if;
                    end if;
                  end if;
                end if;
              end if;
            end if;
          end if;
        end loop;
      end if;
      commit;
    end;

    -- 通过地址的name获取地址的code
    procedure getAddCodeByAddName(
      p_unitAddAreaName in varchar2,
      p_result out varchar2
    ) as
      v_sql varchar2(128);
      index_record idc_jcdm_xzqydm%rowtype;
      cursor v_cursor is
      select *
      from IDC_JCDM_XZQYDM
      where MC = p_unitAddAreaName;
    begin
      open v_cursor;
      fetch v_cursor into index_record;
      if v_cursor%FOUND then
        p_result := index_record.code;
      else
        p_result := '';
      end if;
    end;

    -- SERVICE_HH_FRAME中间表转化为USER_FRAME中间表
    procedure convServiceHHFrameToUserFrame as
    type UserFrameRecord is record(
      id number,
      houseId number,
      frameId number,
      unitName varchar2(128)
    );
    serviceHHFrameRowRecord UserFrameRecord;
    v_count number;
    -- serviceHHFrameRowRecord UserFrameRecord%type;
    cursor getServiceHHFrameCursor is
      select hf.id, hf.houseid, hf.frameid, (
        select u.unitName from idc_isms_base_user u where u.userid = h.userid
      ) unitName
      from idc_isms_base_service_hh_frame hf, idc_isms_base_user_hh h
      where hf.hhid = h.hhid;
    begin
      open getServiceHHFrameCursor;
      select count(1) into v_count from (
        select (
          select u.unitName from idc_isms_base_user u where u.userid = h.userid
        ) unitName, hf.houseid, hf.frameid, hf.id
        from idc_isms_base_service_hh_frame hf, idc_isms_base_user_hh h
        where hf.hhid = h.hhid
      );
      if v_count <> 0 then
        loop
          fetch getServiceHHFrameCursor into serviceHHFrameRowRecord;
          exit when getServiceHHFrameCursor%Notfound;
          insert into idc_isms_base_user_frame (id, houseId, frameid, unitName)
          values (serviceHHFrameRowRecord.id, serviceHHFrameRowRecord.houseId, serviceHHFrameRowRecord.frameId, serviceHHFrameRowRecord.unitName);
        end loop;
      end if;
      commit;
    end;

end IDC_ISMS_BASE_USER_MANAGE;
/
