CREATE package body idc_isms_command_level is

  --处理有优先级高的指令
  procedure dealCommandWithLevel (
       p_commandId           in  number,          --指令id
       p_subType             in   number,         --规则类型
       p_valueStart          in   varchar2,       --规则起始值
       p_valueStartStr       in   varchar2,       --ip规则时，表示起始ip地址的十进制数据
       p_valueEndStr         in   varchar2,       --ip规则时，表示结束ip地址的十进制数据
       p_commandLevel        in   number,         --指令优先级
       p_commandType         in   number,         --信息安全管理指令类型；1—监测指令、2—过滤指令
       p_type                in   number,         --指令类容类型(违法违规网站列表、免过滤网站列表必填)
       p_contents            in   varchar2,       --指令内容 (违法违规网站列表、免过滤网站列表必填)
       p_ip_str              in   varchar2,       --ip地址时，传入此ip地址转换后的十进制数据，支持IPv6
       --出参
       v_unbund_flag         out  number,         --解绑策略的输出标志
       v_out_success         out number
     ) as
  begin
     --免过滤网站列表指令的处理
     if (p_type is not null) then
        dealNoFilterWithLevel(p_type,p_contents,p_ip_str,v_unbund_flag,v_out_success);
     end if;
     --违法信息过滤指令的处理
     if (p_commandType = 2) then
        dealFilterWithLevel(
                       p_commandId,
                       p_subType,
                       p_valueStart,
                       p_valueStartStr,
                       p_valueEndStr,
                       p_commandLevel,
                       v_unbund_flag,
                       v_out_success);
     elsif (p_commandType = 1) then
     --违法信息监测指令的处理
        dealMonitorWithLevel(
                       p_commandId,
                       p_subType,
                       p_valueStart,
                       p_valueStartStr,
                       p_valueEndStr,
                       p_commandLevel,
                       v_unbund_flag,
                       v_out_success);
     end if;
  end;

  procedure dealFilterWithLevel (
       p_cmdId               in   number,
       p_subType             in   number,
       p_valueStart          in   varchar2,
       p_valueStartStr       in   varchar2,
       p_valueEndStr         in   varchar2,
       p_commandLevel        in   number,
       v_unbund_flag         out  number,
       v_out_success         out  number
    ) as
  v_count         number := 0;
  begin
     v_unbund_flag := 0;
     --判断规则是否在免过滤网站列表中
		 judgeExists(2, 1, p_subType, p_valueStart, p_valueStartStr, p_valueEndStr, v_count);
     --在免过滤网站列表中时
     if (v_count > 0) then
        --返回标志，后续将此规则不写入idc_isms_monitor_policy和下发给EU
        v_unbund_flag := 1;
        v_out_success := 1;
        --更新策略表相关表的状态为“存在优先级高的指令”
        --updatePolicyState(p_cmdId, 2, p_subType, p_valueStart, p_valueStartStr, p_valueEndStr, v_out_success);
     --不在免过滤网站列表中时
     else
        --管局下发过滤指令的处理
        if (p_cmdId is not null) then
           --判断同规则的ISMS自建的策略是否存在
				   judgeExists(2, 2, p_subType, p_valueStart, p_valueStartStr, p_valueEndStr, v_count);
           if (v_count > 0) then
              --解绑此规则的策略
					    unbundPolicy(p_cmdId, 2, p_subType, p_valueStart, p_valueStartStr, p_valueEndStr, p_commandLevel, v_out_success);
           end if;
           --解绑同规则的监测指令
           unbundPolicy(p_cmdId, 1, p_subType, p_valueStart, p_valueStartStr, p_valueEndStr, p_commandLevel, v_out_success);
        --ISMS系统过滤指令的处理
        else
           unbundPolicy(p_cmdId, 2, p_subType, p_valueStart, p_valueStartStr, p_valueEndStr, p_commandLevel, v_out_success);
        end if;
     end if;
  end;

  --违法信息监测指令优先级的处理
  procedure dealMonitorWithLevel (
       p_cmdId               in   number,
       p_subType             in   number,
       p_valueStart          in   varchar2,
       p_valueStartStr       in   varchar2,
       p_valueEndStr         in   varchar2,
       p_commandLevel        in   number,
       v_unbund_flag         out  number,
       v_out_success         out  number
    ) as
      v_count         number := 0;
  begin
      v_unbund_flag := 0;
      --判断规则是否在过滤规则中
      judgeExists(2, 2, p_subType, p_valueStart, p_valueStartStr, p_valueEndStr, v_count);
      --在过滤规则中
      if (v_count > 0) then
         --返回标志，后续将此规则不写入idc_isms_monitor_policy和下发给EU
         v_unbund_flag := 1;
         v_out_success := 1;
         --更新策略表相关表的状态为“存在优先级高的指令”
         --updatePolicyState(p_cmdId, 1, p_subType, p_valueStart, p_valueStartStr, p_valueEndStr, v_out_success);
      --不在过滤规则中
      else
         --管局下发过滤指令的处理
        if (p_cmdId is not null) then
           --判断同规则的ISMS自建的策略是否存在
           judgeExists(1, 2, p_subType, p_valueStart, p_valueStartStr, p_valueEndStr, v_count);
           if (v_count > 0) then
              --解绑此规则的策略
              unbundPolicy(p_cmdId, 1, p_subType, p_valueStart, p_valueStartStr, p_valueEndStr, p_commandLevel, v_out_success);
           end if;
        --ISMS系统过滤指令的处理
        else
           unbundPolicy(p_cmdId, 1, p_subType, p_valueStart, p_valueStartStr, p_valueEndStr, p_commandLevel, v_out_success);
        end if;
      end if;
  end;

  --免过滤网站列表指令优先级的处理
  procedure dealNoFilterWithLevel (
       p_type            in number,   --指令类容类型(违法违规网站列表、免过滤网站列表必填)
       p_contents        in varchar2, --指令内容 (违法违规网站列表、免过滤网站列表必填)
       p_ip_str          in varchar2, --ip地址时，传入此ip地址转换后的十进制数据，支持IPv6
       --出参
       v_unbund_flag     out  number, --解绑策略的输出标志
       v_out_success     out number
     ) as
     v_count         number := 0;
     v_func_ret      number := 0;
     v_commandid     number := 0;
     v_message_no    number := 0;
     v_cursor        sys_refcursor;
  begin
     v_unbund_flag := 0;
     if (p_type is not null) then
        if (p_contents is not null) then
           --判断其内容是否在违法违规网站列表中
           select count(1) into v_count from idc_isms_cmd_black_list t
           where t.operationtype != 1 and
                 t.delete_flag != 1 and
                 t.commandtype = p_type and
                 t.content = p_contents;
           if (v_count > 0) then
             v_unbund_flag := 1;
           else
              --域名
              if (p_type = 1) then
                 select count(1) into v_count from idc_isms_monitor_policy_rule rule
                 where rule.subtype = 1 and rule.valuestart = p_contents;
                 --解绑所有域名过滤规则
                 open v_cursor for
                 select commandid,message_no into v_commandid,v_message_no
                 from idc_isms_monitor_policy policy
                 where policy.operatetype != 3 and
                       policy.commandid in (
                         select t.commandid from idc_isms_monitor_policy_rule t
                         where t.subtype = 1 and
                               t.valuestart = p_contents
                 );
                 loop
                       fetch v_cursor into v_commandid,v_message_no;
                       exit when v_cursor%notfound;
                       v_func_ret := PKG_IDCCONFIG.DeleteIDCISMS_Policy(v_commandid,v_message_no,-1);
                 end loop;
                 close v_cursor;
                 --更新策略相关表的策略状态为“存在优先级高的指令”
                 --update idc_isms_monitor_policy policy set policy.policy_state = 2 where policy.commandid = v_commandid;
              end if;
              --ip
              if (p_type = 2) then
                 select count(1) into v_count from idc_isms_monitor_policy_rule rule
                 where rule.subtype = 5 and p_ip_str >= rule.valuestartstr and p_ip_str <= rule.valueendstr;
                 --解绑所有ip过滤规则
                 open v_cursor for
                 select commandid,message_no into v_commandid,v_message_no
                 from idc_isms_monitor_policy policy
                 where policy.operatetype != 3 and
                       policy.commandid in (
                         select t.commandid from idc_isms_monitor_policy_rule t
                         where t.subtype = 5 and
                               p_ip_str >= t.valuestartstr and
                               p_ip_str <= t.valueendstr
                 );
                 loop
                       fetch v_cursor into v_commandid,v_message_no;
                       exit when v_cursor%notfound;
                       v_func_ret := PKG_IDCCONFIG.DeleteIDCISMS_Policy(v_commandid,v_message_no,-1);
                 end loop;
                 close v_cursor;
                 --更新策略相关表的策略状态为“存在优先级高的指令”
                 --update idc_isms_monitor_policy policy set policy.policy_state = 2 where policy.commandid = v_commandid;
              end if;
           end if;
        end if;
     end if;
     commit;
     v_out_success := 1;
     exception when others then
        v_out_success := 0;
        rollback;
        raise;
  end;

  procedure judgeExists(
	     p_cmdType	           in   number,
	     p_type				         in   number,--免过滤指令idc_isms_cmd_no_filter(1)或策略表idc_isms_monitor_policy(2)的标志
	     p_subType             in   number,
       p_valueStart          in   varchar2,
       p_valueStartStr       in   varchar2,
       p_valueEndStr         in   varchar2,
	     v_out_count	         out  number
  ) as
  v_temp varchar2(2000);
  v_index number;
  begin
    v_out_count := 0;
    if (p_subType = 4 or p_subType = 5) then
      if (p_type = 1) then
        select count(1) into v_out_count from idc_isms_cmd_no_filter filter
        where filter.operationtype != 1 and
              filter.delete_flag != 1 and
            --filter.commandtype = 2 and
            filter.content >= p_valueStartStr and
            filter.content <= p_valueEndStr;
      elsif (p_type = 2) then
        select count(1) into v_out_count from idc_isms_monitor_policy policy
        where policy.command_type = p_cmdType and
            policy.operatetype != 3 and
            policy.smms_cmdid is null and
            policy.commandid in (
            select t.commandid from idc_isms_monitor_policy_rule t
            where (t.subtype = p_subType) and
                (p_valueStartStr >= t.valuestartstr and p_valueStartStr <= t.valueendstr) or
                (p_valueEndStr   >= t.valuestartstr and p_valueEndStr   <= t.valueendstr) or
                (p_valueStartStr >= t.valuestartstr and p_valueEndStr   <= t.valueendstr)
        );
      end if;
    elsif (p_subType = 1) then
      if (p_type = 1) then
        select count(1) into v_out_count from idc_isms_cmd_no_filter filter
        where filter.operationtype != 1 and
              filter.delete_flag != 1 and
            --filter.commandtype = 1 and
            filter.content = p_valueStart;
      elsif (p_type = 2) then
        select count(1) into v_out_count from idc_isms_monitor_policy policy
        where policy.command_type = p_cmdType and
            policy.operatetype != 3 and
            policy.smms_cmdid is null and
            policy.commandid in (
            select t.commandid from idc_isms_monitor_policy_rule t
            where (t.subtype = p_subType) and
                t.valuestart = p_valueStart
        );
      end if;
    elsif (p_subType = 2) then
      v_index := instr(p_valueStart,':');
      if (v_index > 0) then
         v_temp := substr(p_valueStart,instr(p_valueStart,':') + 3, length(p_valueStart));
      else
         v_temp := p_valueStart;
      end if;
      if (p_type = 1) then
        select count(1) into v_out_count from idc_isms_cmd_no_filter filter
        where filter.operationtype != 1 and
              filter.delete_flag != 1 and
            --filter.commandtype = 1 and
            filter.content like '%' || v_temp || '%';
      elsif (p_type = 2) then
        select count(1) into v_out_count from idc_isms_monitor_policy policy
        where policy.command_type = p_cmdType and
            policy.operatetype != 3 and
            policy.smms_cmdid is null and
            policy.commandid in (
            select t.commandid from idc_isms_monitor_policy_rule t
            where (t.subtype = p_subType) and
                t.valuestart = p_valueStart
        );
      end if;
    end if;
  end;

  procedure updatePolicyState(
	     p_cmdId               in   number,
	     p_cmdType			       in   number,
       p_subType             in   number,
       p_valueStart          in   varchar2,
       p_valueStartStr       in   varchar2,
       p_valueEndStr         in   varchar2,
       v_out_success         out  number
  ) as
	  v_cursor 	      sys_refcursor;
	  v_commandid     number := 0;
    begin
      if (p_cmdId is not null) then
        if (p_subType = 4 or p_subType = 5) then
          open v_cursor for
          select manage.commandid
          from idc_isms_cmd_idc_manage manage
          where manage.operation_type != 1 and
              manage.cmd_type = p_cmdType and
              manage.commandid in (
               select t.commandid from idc_isms_cmd_idcmng_rule t
               where t.subtype = p_subType and
                   (p_valueStartStr >= t.valuestartstr and p_valueStartStr <= t.valueendstr) or
                   (p_valueEndStr   >= t.valuestartstr and p_valueEndStr   <= t.valueendstr) or
                   (p_valueStartStr >= t.valuestartstr and p_valueEndStr   <= t.valueendstr)
          );
        else
          open v_cursor for
          select manage.commandid
          from idc_isms_cmd_idc_manage manage
          where manage.operation_type != 1 and
              manage.cmd_type = p_cmdType and
              manage.commandid in (
               select t.commandid from idc_isms_cmd_idcmng_rule t
               where t.subtype = p_subType and
                     t.valuestart = p_valueStart
          );
        end if;
        loop
            fetch v_cursor into v_commandid;
            exit when v_cursor%notfound;
            update idc_isms_cmd_idc_manage manage set manage.policy_state = 2
            where manage.commandid = v_commandid;
        end loop;
        close v_cursor;
      else
        if (p_subType = 4 or p_subType = 5) then
          open v_cursor for
          select commandid
          from idc_isms_monitor_policy policy
          where policy.command_type = p_cmdType and
              policy.operatetype != 3 and
              policy.smms_cmdid is null and
              policy.commandid in (
              select t.commandid from idc_isms_monitor_policy_rule t
              where (t.subtype = p_subType) and
                    (p_valueStartStr >= t.valuestartstr and p_valueStartStr <= t.valueendstr) or
                    (p_valueEndStr   >= t.valuestartstr and p_valueEndStr   <= t.valueendstr) or
                    (p_valueStartStr >= t.valuestartstr and p_valueEndStr   <= t.valueendstr)
           );
        else
          open v_cursor for
          select commandid
          from idc_isms_monitor_policy policy
          where policy.command_type = p_cmdType and
              policy.operatetype != 3 and
              policy.smms_cmdid is null and
              policy.commandid in (
              select t.commandid from idc_isms_monitor_policy_rule t
              where (t.subtype = p_subType) and
                    t.valuestart = p_valueStart
           );
        end if;
        loop
            fetch v_cursor into v_commandid;
            exit when v_cursor%notfound;
            update idc_isms_monitor_policy policy set policy.policy_state = 2
            where policy.commandid = v_commandid;
        end loop;
        close v_cursor;
       end if;
       commit;
       v_out_success := 1;
       exception when others then
        v_out_success := 0;
        rollback;
        raise;
    end;

    procedure unbundPolicy(
	     p_cmdId			         in   number,
	     p_cmdType			       in   number,
       p_subType             in   number,
       p_valueStart          in   varchar2,
       p_valueStartStr       in   varchar2,
       p_valueEndStr         in   varchar2,
       p_commandLevel        in   number,
       v_out_success         out  number
    ) as
      v_cursor 	      sys_refcursor;
      v_cursor_bund   sys_refcursor;
      v_commandid		  number := 0;
      v_message_no    number := 0;
      v_commandLevel	number;
      v_func_ret      number;
    begin
      if (p_subType = 4 or p_subType = 5) then
        open v_cursor for
        select commandid,message_no,policy.policy_level
        from idc_isms_monitor_policy policy
        where policy.command_type = p_cmdType and
            policy.operatetype != 3 and
            --policy.smms_cmdid is null and
            policy.commandid in (
            select t.commandid from idc_isms_monitor_policy_rule t
            where (t.subtype = p_subType) and
                  (p_valueStartStr >= t.valuestartstr and p_valueStartStr <= t.valueendstr) or
                  (p_valueEndStr   >= t.valuestartstr and p_valueEndStr   <= t.valueendstr) or
                  (p_valueStartStr >= t.valuestartstr and p_valueEndStr   <= t.valueendstr)
         );
      else
        open v_cursor for
        select commandid,message_no,policy.policy_level
        from idc_isms_monitor_policy policy
        where policy.command_type = p_cmdType and
            policy.operatetype != 3 and
            --policy.smms_cmdid is null and
            policy.commandid in (
            select t.commandid from idc_isms_monitor_policy_rule t
            where (t.subtype = p_subType) and
                   t.valuestart = p_valueStart
         );
      end if;
      if (p_cmdId is not null) then
        loop
           fetch v_cursor into v_commandid, v_message_no, v_commandLevel;
           exit when v_cursor%notfound;
           v_func_ret := PKG_IDCCONFIG.DeleteIDCISMS_Policy(v_commandid,v_message_no,-1);
           --更新策略表idc_isms_monitor_policy的POLICY_STATE状态为“存在优先级高的指令”
           --update idc_isms_monitor_policy policy set policy.policy_state = 2 where policy.commandid = v_commandid;
        end loop;
        close v_cursor;
      else
        loop
            fetch v_cursor into v_commandid, v_message_no, v_commandLevel;
            exit when v_cursor%notfound;
            if (v_commandLevel is not null) then
             --优先级高低判断，值越小，优先级越高
             if (v_commandLevel > p_commandLevel) then
              if (p_subType = 4 or p_subType = 5) then
                --解绑此规则的策略
                open v_cursor_bund for
                select commandid,message_no
                from idc_isms_monitor_policy policy
                where policy.command_type = p_cmdType and
                    policy.operatetype != 3 and
                    policy.smms_cmdid is null and
                    policy.commandid in (
                    select t.commandid from idc_isms_monitor_policy_rule t
                    where (t.subtype = p_subType) and
                        (p_valueStartStr >= t.valuestartstr and p_valueStartStr <= t.valueendstr) or
                        (p_valueEndStr   >= t.valuestartstr and p_valueEndStr   <= t.valueendstr) or
                        (p_valueStartStr >= t.valuestartstr and p_valueEndStr   <= t.valueendstr)
                 );
              else
                --解绑此规则的策略
                open v_cursor_bund for
                select commandid,message_no
                from idc_isms_monitor_policy policy
                where policy.command_type = p_cmdType and
                    policy.operatetype != 3 and
                    policy.smms_cmdid is null and
                    policy.commandid in (
                    select t.commandid from idc_isms_monitor_policy_rule t
                    where (t.subtype = p_subType) and
                         t.valuestart = p_valueStart
                 );
              end if;
              loop
                 fetch v_cursor_bund into v_commandid,v_message_no;
                 exit when v_cursor_bund%notfound;
                 v_func_ret := PKG_IDCCONFIG.DeleteIDCISMS_Policy(v_commandid,v_message_no,-1);
                 --更新策略表idc_isms_monitor_policy的POLICY_STATE状态为“存在优先级高的指令”
                 --update idc_isms_monitor_policy policy set policy.policy_state = 2 where policy.commandid = v_commandid;
              end loop;
              close v_cursor_bund;
             end if;
            end if;
          end loop;
        close v_cursor;
      end if;
      commit;
      v_out_success := 1;
      exception when others then
        v_out_success := 0;
        rollback;
        raise;
    end;

end idc_isms_command_level;

/
