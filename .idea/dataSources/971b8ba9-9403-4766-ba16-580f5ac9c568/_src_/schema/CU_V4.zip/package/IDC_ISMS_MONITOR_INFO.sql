CREATE package IDC_ISMS_MONITOR_INFO is

  --监控入口
  procedure monitor_base_main;

  --经营者
  procedure monitor_base_idc;

  --机房
  procedure monitor_base_house_new;
  --机房
  procedure monitor_base_house;

  --用户
  procedure monitor_base_user;

  --服务查看
  procedure monitor_base_service;

 --经营者
  procedure monitor_base_idc_new;

  --用户
  procedure monitor_base_user_new;

  --服务查看
  procedure monitor_base_service_new;
  --占用机房查看（互联网用户）
  procedure monitor_base_service_hh;

  procedure monitor_base_user_hh_new;
  --占用机房查看（其他用户）
  procedure monitor_base_user_hh;

  --更新
  procedure update_info(
             table_name in varchar2,
             id_name in varchar2,
             id_val in number,
             field_val in varchar2

  );

end IDC_ISMS_MONITOR_INFO;
/
CREATE package body IDC_ISMS_MONITOR_INFO is

     --监控入口
     procedure monitor_base_main
     as
     BEGIN
        monitor_base_idc_new;
        monitor_base_house_new;
        monitor_base_user_new;
        monitor_base_service_new;
        monitor_base_user_hh_new;
        --去掉
        --monitor_base_service_hh;
        --monitor_base_user_hh;
        commit;
     END;
--经营者 by 董博野
     procedure monitor_base_idc_new
     as
        v_idcSql varchar2(4000);
        v_jyzid idc_isms_base_idc.JYZID%type;
        v_idcCur sys_refcursor;
     BEGIN
       begin
            v_idcSql := '(select JYZID from idc_isms_base_idc where JYZID not in (select JYZID from idc_isms_base_house where del_flag = 0) and del_flag = 0
                             union
                        select JYZID from idc_isms_base_idc where JYZID not in (select JYZID from idc_isms_base_user where del_flag = 0) and del_flag = 0)
                             union
                        (select JYZID from idc_isms_base_house where HOUSEID not in (select HOUSEID from idc_isms_base_house_gateway where del_flag = 0) and del_flag = 0
                             union
                        select JYZID from idc_isms_base_house where HOUSEID not in (select HOUSEID from idc_isms_base_house_ipseg_view where del_flag = 0) and del_flag = 0
                             union
                        select JYZID from idc_isms_base_house where HOUSEID not in (select HOUSEID from idc_isms_base_house_frame where del_flag = 0) and del_flag = 0 and identify <> 1)
                                   union
                        (select JYZID from idc_isms_base_user where USERID not in (select USERID from idc_isms_base_user_service where del_flag = 0) and NATURE = 1 and del_flag = 0
                             union
                        select JYZID from idc_isms_base_user where USERID not in (select USERID from idc_isms_base_user_hh where del_flag = 0) and del_flag = 0
                        )
                             union
                        select JYZID from idc_isms_base_user where USERID in (select USERID from idc_isms_base_user_service s where userid not in (select userid from idc_isms_base_service_virtual where del_flag = 0) and del_flag = 0 and s.setmode = 1)
                             union
                        select JYZID from idc_isms_base_user where USERID in (select distinct userid from idc_isms_base_user_hh t where houseid not in (select houseid from idc_isms_base_house_ipseg_view v where v.iptype != 2 and del_flag = 0 and v.userid = t.userid) and del_flag = 0)
                        union
                        select JYZID from idc_isms_base_user where USERID in (
                           select
                              s.userid
                            from idc_isms_base_user_service s
                            join idc_isms_base_user_hh h on s.userid = h.userid
                            where s.setmode != 0 and s.del_flag = 0 and s.business = 1 and h.houseid not in (
                                  select houseid from idc_isms_base_user_frame_view v where v.userid = s.userid group by v.houseid
                            ) and h.houseid not in (select houseid from idc_isms_base_house house where house.identify = 1)
                            group by s.userid
                          )
                        ';
         open v_idcCur for v_idcSql;
         loop
             fetch v_idcCur into v_jyzid;
             exit when v_idcCur%notfound;
             --update_info('idc_isms_base_idc','JYZID',v_jyzid,'否');
             update idc_isms_base_idc set INFO_COMPLETE = '否'
             where del_flag = 0 and JYZID = v_jyzid and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '否'));
         end loop;
         close v_idcCur;
         v_idcSql := 'select JYZID from idc_isms_base_idc
                          minus
                      select JYZID from (' || v_idcSql || ')';
         open v_idcCur for v_idcSql;
         loop
             fetch v_idcCur into v_jyzid;
             exit when v_idcCur%notfound;
             --update_info('idc_isms_base_idc','JYZID',v_jyzid,'是');
             update idc_isms_base_idc set INFO_COMPLETE = '是'
             where del_flag = 0 and JYZID = v_jyzid and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '是'));
         end loop;
         close v_idcCur;
       end;
     END;

     --经营者
     procedure monitor_base_idc
     as
        v_idcSql varchar2(4000);
        v_jyzid idc_isms_base_idc.JYZID%type;
        v_idcCur sys_refcursor;
     BEGIN
       begin
            v_idcSql := '(select JYZID from idc_isms_base_idc where JYZID not in (select JYZID from idc_isms_base_house where del_flag = 0) and del_flag = 0
                                     union
                              select JYZID from idc_isms_base_idc where JYZID not in (select JYZID from idc_isms_base_user where del_flag = 0) and del_flag = 0)
                                     union
                              (select JYZID from idc_isms_base_house where HOUSEID not in (select HOUSEID from idc_isms_base_house_gateway where del_flag = 0) and del_flag = 0
                                     union
                              select JYZID from idc_isms_base_house where HOUSEID not in (select HOUSEID from idc_isms_base_house_ipseg_view where del_flag = 0) and del_flag = 0
                                     union
                              select JYZID from idc_isms_base_house where HOUSEID not in (select HOUSEID from idc_isms_base_house_frame where del_flag = 0) and del_flag = 0)
                                           union
                             (select JYZID from idc_isms_base_user where USERID not in (select USERID from idc_isms_base_user_service where del_flag = 0) and NATURE = 1 and del_flag = 0
                                     union
                              select JYZID from idc_isms_base_user where USERID not in (select USERID from idc_isms_base_user_hh where del_flag = 0) and NATURE = 2 and del_flag = 0)
                                     union
                              select JYZID from idc_isms_base_user where USERID in (select USERID from idc_isms_base_user_service where SERVICEID not in (select SERVICEID from idc_isms_base_service_domain where del_flag = 0) and del_flag = 0 and servicetype = 1
                                                                                           union
                                                                                    select USERID from idc_isms_base_user_service where SERVICEID not in (select SERVICEID from idc_isms_base_service_hh where del_flag = 0) and del_flag = 0
                                                                                   )
                                          union
                              select JYZID from idc_isms_base_user where USERID in (select USERID from idc_isms_base_service_hh where HHID not in (select HHID from idc_isms_base_service_iptrans where del_flag = 0) and del_flag = 0)
                                          union
                              select JYZID from idc_isms_base_user where USERID in (select USERID from idc_isms_base_user_hh where HHID not in (select HHID from idc_isms_base_user_hh_ipseg where del_flag = 0) and del_flag = 0)';
         open v_idcCur for v_idcSql;
         loop
             fetch v_idcCur into v_jyzid;
             exit when v_idcCur%notfound;
             --update_info('idc_isms_base_idc','JYZID',v_jyzid,'否');
             update idc_isms_base_idc set INFO_COMPLETE = '否'
             where del_flag = 0 and JYZID = v_jyzid and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '否'));
         end loop;
         close v_idcCur;
         v_idcSql := 'select JYZID from idc_isms_base_idc
                          minus
                      select JYZID from (' || v_idcSql || ')';
         open v_idcCur for v_idcSql;
         loop
             fetch v_idcCur into v_jyzid;
             exit when v_idcCur%notfound;
             --update_info('idc_isms_base_idc','JYZID',v_jyzid,'是');
             update idc_isms_base_idc set INFO_COMPLETE = '是'
             where del_flag = 0 and JYZID = v_jyzid and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '是'));
         end loop;
         close v_idcCur;
       end;
     END;

    procedure monitor_base_house_new
     as
        v_houseSql varchar2(1000);
        v_houseId idc_isms_base_house.houseid%type;
        v_houseCur sys_refcursor;
     BEGIN
        begin
           v_houseSql := 'select HOUSEID from idc_isms_base_house where HOUSEID not in (select HOUSEID from idc_isms_base_house_gateway where del_flag = 0) and del_flag = 0
                          union
                          select HOUSEID from idc_isms_base_house where HOUSEID not in (select HOUSEID from idc_isms_base_house_ipseg_view where del_flag = 0) and del_flag = 0
                          union
                          select HOUSEID from idc_isms_base_house where HOUSEID not in (select HOUSEID from idc_isms_base_house_frame where del_flag = 0) and del_flag = 0 and IDENTIFY = 2
                          ';
          open v_houseCur for v_houseSql;
          loop
              fetch v_houseCur into v_houseId;
              exit when v_houseCur%notfound;
              --update_info('idc_isms_base_house','HOUSEID',v_houseId,'否');
              update idc_isms_base_house set INFO_COMPLETE = '否'
              where del_flag = 0 and HOUSEID = v_houseId and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '否'));
          end loop;
          close v_houseCur;
          v_houseSql := 'select HOUSEID from idc_isms_base_house
                             minus
                         select HOUSEID from (' || v_houseSql || ')';
          open v_houseCur for v_houseSql;
          loop
              fetch v_houseCur into v_houseId;
              exit when v_houseCur%notfound;
              --update_info('idc_isms_base_house','HOUSEID',v_houseId,'是');
              update idc_isms_base_house set INFO_COMPLETE = '是'
              where del_flag = 0 and HOUSEID = v_houseId and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '是'));
          end loop;
          close v_houseCur;
       end;
     END;

     --机房--keeping
    procedure monitor_base_house
     as
        v_houseSql varchar2(1000);
        v_houseId idc_isms_base_house.houseid%type;
        v_houseCur sys_refcursor;
     BEGIN
        begin
           v_houseSql := 'select HOUSEID from idc_isms_base_house where HOUSEID not in (select HOUSEID from idc_isms_base_house_gateway where del_flag = 0) and del_flag = 0
                          union
                          select HOUSEID from idc_isms_base_house where HOUSEID not in (select HOUSEID from idc_isms_base_house_ipseg where del_flag = 0) and del_flag = 0
                          union
                          select HOUSEID from idc_isms_base_house where HOUSEID not in (select HOUSEID from idc_isms_base_house_frame where del_flag = 0) and del_flag = 0';
          open v_houseCur for v_houseSql;
          loop
              fetch v_houseCur into v_houseId;
              exit when v_houseCur%notfound;
              --update_info('idc_isms_base_house','HOUSEID',v_houseId,'否');
              update idc_isms_base_house set INFO_COMPLETE = '否'
              where del_flag = 0 and HOUSEID = v_houseId and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '否'));
          end loop;
          close v_houseCur;
          v_houseSql := 'select HOUSEID from idc_isms_base_house
                             minus
                         select HOUSEID from (' || v_houseSql || ')';
          open v_houseCur for v_houseSql;
          loop
              fetch v_houseCur into v_houseId;
              exit when v_houseCur%notfound;
              --update_info('idc_isms_base_house','HOUSEID',v_houseId,'是');
              update idc_isms_base_house set INFO_COMPLETE = '是'
              where del_flag = 0 and HOUSEID = v_houseId and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '是'));
          end loop;
          close v_houseCur;
       end;
     END;

 --用户 by 董博野
     procedure monitor_base_user_new
     as
            v_userSql varchar2(4000);
            v_userId idc_isms_base_user.userid%type;
            v_userCur sys_refcursor;
     BEGIN
       begin
          v_userSql := '(select USERID from idc_isms_base_user where USERID not in (select USERID from idc_isms_base_user_service where del_flag = 0) and NATURE = 1 and del_flag = 0
                         union
                         select USERID from idc_isms_base_user where USERID not in (select USERID from idc_isms_base_user_hh where del_flag = 0) and del_flag = 0
                         )
                         union
                         (select USERID from idc_isms_base_user_service s where userid not in (select userid from idc_isms_base_service_virtual where del_flag = 0) and del_flag = 0 and s.setmode = 1)
                         union
                         select distinct userid from idc_isms_base_user_hh t where houseid not in (select houseid from idc_isms_base_house_ipseg_view v where v.iptype != 2 and del_flag = 0 and v.userid = t.userid) and del_flag = 0
                         union
                             (
                               select
                                  s.userid
                                from idc_isms_base_user_service s
                                join idc_isms_base_user_hh h on s.userid = h.userid
                                where s.setmode != 0 and s.del_flag = 0 and s.business = 1 and h.del_flag=0 and h.houseid not in (
                                      select houseid from idc_isms_base_user_frame_view v where v.userid = s.userid group by v.houseid
                                ) and h.houseid not in (select houseid from idc_isms_base_house house where house.identify = 1)
                                and s.userid not in (select userid from idc_isms_base_user_frame_view)
                                group by s.userid
                                union
                                select s.userid
                                from idc_isms_base_user_service s
                                join idc_isms_base_user_hh h on s.userid = h.userid
                                where s.setmode != 0 and s.del_flag = 0 and s.business = 1 and h.del_flag=0
                                and s.userid not in (
                                      select s.userid
                                      from idc_isms_base_user_service s
                                      join idc_isms_base_user_hh h on s.userid = h.userid
                                      where s.setmode != 0 and s.del_flag = 0 and s.business = 1 and h.del_flag=0
                                      and h.houseid not in (select houseid from idc_isms_base_house house where house.identify = 1)
                                )
                              )
                         ';
          open v_userCur for v_userSql;
          loop
              fetch v_userCur into v_userId;
              exit when v_userCur%notfound;
              --update_info('idc_isms_base_user','USERID',v_userId,'否');
              update idc_isms_base_user set INFO_COMPLETE = '否'
              where del_flag = 0 and USERID = v_userId and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '否'));
          end loop;
          close v_userCur;
          v_userSql := 'select USERID from idc_isms_base_user
                             minus
                        select USERID from (' || v_userSql || ')';
          open v_userCur for v_userSql;
          loop
              fetch v_userCur into v_userId;
              exit when v_userCur%notfound;
              --update_info('idc_isms_base_user','USERID',v_userId,'是');
              update idc_isms_base_user set INFO_COMPLETE = '是'
               where del_flag = 0 and USERID = v_userId and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '是'));
          end loop;
          close v_userCur;
        end;
     END;
     --用户
     procedure monitor_base_user
     as
            v_userSql varchar2(2000);
            v_userId idc_isms_base_user.userid%type;
            v_userCur sys_refcursor;
     BEGIN
       begin
          v_userSql := '(select USERID from idc_isms_base_user where USERID not in (select USERID from idc_isms_base_user_service where del_flag = 0) and NATURE = 1 and del_flag = 0
                         union
                         select USERID from idc_isms_base_user where USERID not in (select USERID from idc_isms_base_user_hh where del_flag = 0) and NATURE = 2 and del_flag = 0)
                         union
                         (select USERID from idc_isms_base_user_service where SERVICEID not in (select SERVICEID from idc_isms_base_service_domain where del_flag = 0) and del_flag = 0 and servicetype = 1
                                 union
                          select USERID from idc_isms_base_user_service where SERVICEID not in (select SERVICEID from idc_isms_base_service_hh where del_flag = 0) and del_flag = 0)
                                 union
                          select USERID from idc_isms_base_service_hh where HHID not in (select HHID from idc_isms_base_service_iptrans where del_flag = 0) and del_flag = 0
                                 union
                          select USERID from idc_isms_base_user_hh where HHID not in (select HHID from idc_isms_base_user_hh_ipseg where del_flag = 0) and del_flag = 0';
          open v_userCur for v_userSql;
          loop
              fetch v_userCur into v_userId;
              exit when v_userCur%notfound;
              --update_info('idc_isms_base_user','USERID',v_userId,'否');
              update idc_isms_base_user set INFO_COMPLETE = '否'
              where del_flag = 0 and USERID = v_userId and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '否'));
          end loop;
          close v_userCur;
          v_userSql := 'select USERID from idc_isms_base_user
                             minus
                        select USERID from (' || v_userSql || ')';
          open v_userCur for v_userSql;
          loop
              fetch v_userCur into v_userId;
              exit when v_userCur%notfound;
              --update_info('idc_isms_base_user','USERID',v_userId,'是');
              update idc_isms_base_user set INFO_COMPLETE = '是'
               where del_flag = 0 and USERID = v_userId and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '是'));
          end loop;
          close v_userCur;
        end;
     END;
 --服务查看 by 董博野
     procedure monitor_base_service_new
     as
            v_serviceSql varchar2(4000);
            v_serviceId idc_isms_base_user_service.serviceid%type;
            v_serviceCur sys_refcursor;
     BEGIN
        begin
            /*v_serviceSql := 'select SERVICEID from idc_isms_base_user_service where SERVICEID not in (select SERVICEID from idc_isms_base_service_domain where del_flag = 0) and del_flag = 0 and servicetype = 1
                             union
                             (select SERVICEID from idc_isms_base_user_service s where USERID not in (select userid from idc_isms_base_service_virtual where del_flag = 0) and del_flag = 0 and s.setmode = 1)
                             union
                             (select SERVICEID from idc_isms_base_user_service s where USERID not in (select userid from idc_isms_base_user_hh where del_flag = 0) and del_flag = 0 and s.setmode != 0)
                             ';*/
            v_serviceSql := '(select SERVICEID from idc_isms_base_user_service s where USERID not in (select userid from idc_isms_base_service_virtual where del_flag = 0) and del_flag = 0 and s.setmode = 1)
                             union
                             (select SERVICEID from idc_isms_base_user_service s where USERID not in (select userid from idc_isms_base_user_hh where del_flag = 0) and del_flag = 0 and s.setmode != 0)
                             union
                             (
                               select
                                  s.serviceid
                                from idc_isms_base_user_service s
                                join idc_isms_base_user_hh h on s.userid = h.userid
                                where s.setmode != 0 and s.del_flag = 0 and s.business = 1 and h.houseid not in (
                                      select houseid from idc_isms_base_user_frame_view v where v.userid = s.userid group by v.houseid
                                ) and h.houseid not in (select houseid from idc_isms_base_house house where house.identify = 1)
                                group by s.serviceid
                              )
                             ';
            open v_serviceCur for v_serviceSql;
            loop
                fetch v_serviceCur into v_serviceId;
                exit when v_serviceCur%notfound;
                --update_info('idc_isms_base_user_service','SERVICEID',v_serviceId,'否');
                update idc_isms_base_user_service set INFO_COMPLETE = '否'
                where del_flag = 0 and SERVICEID = v_serviceId and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '否'));
            end loop;
            close v_serviceCur;
            v_serviceSql := 'select SERVICEID from idc_isms_base_user_service
                                  minus
                             select SERVICEID from (' || v_serviceSql || ')';
            open v_serviceCur for v_serviceSql;
            loop
                fetch v_serviceCur into v_serviceId;
                exit when v_serviceCur%notfound;
                --update_info('idc_isms_base_user_service','SERVICEID',v_serviceId,'是');
                update idc_isms_base_user_service set INFO_COMPLETE = '是'
                where del_flag = 0 and SERVICEID = v_serviceId and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '是'));
            end loop;
            close v_serviceCur;
         end;
     END;

     --服务查看
     procedure monitor_base_service
     as
            v_serviceSql varchar2(1000);
            v_serviceId idc_isms_base_user_service.serviceid%type;
            v_serviceCur sys_refcursor;
     BEGIN
        begin
            /*v_serviceSql := '(select SERVICEID from idc_isms_base_user_service where SERVICEID not in (select SERVICEID from idc_isms_base_service_domain where del_flag = 0) and del_flag = 0
                              union
                              select SERVICEID from idc_isms_base_user_service where SERVICEID not in (select SERVICEID from idc_isms_base_service_hh where del_flag = 0) and del_flag = 0)
                              union
                              select SERVICEID from idc_isms_base_service_hh where HHID not in (select HHID from idc_isms_base_service_iptrans where del_flag = 0) and del_flag = 0';*/
            v_serviceSql := '(select SERVICEID from idc_isms_base_user_service where SERVICEID not in (select SERVICEID from idc_isms_base_service_domain where del_flag = 0) and del_flag = 0 and servicetype = 1
                              union
                              select SERVICEID from idc_isms_base_user_service where SERVICEID not in (select SERVICEID from idc_isms_base_service_hh where del_flag = 0) and del_flag = 0)
                              union
                              select SERVICEID from idc_isms_base_service_hh where HHID not in (select HHID from idc_isms_base_service_iptrans where del_flag = 0) and del_flag = 0';
            open v_serviceCur for v_serviceSql;
            loop
                fetch v_serviceCur into v_serviceId;
                exit when v_serviceCur%notfound;
                --update_info('idc_isms_base_user_service','SERVICEID',v_serviceId,'否');
                update idc_isms_base_user_service set INFO_COMPLETE = '否'
                where del_flag = 0 and SERVICEID = v_serviceId and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '否'));
            end loop;
            close v_serviceCur;
            v_serviceSql := 'select SERVICEID from idc_isms_base_user_service
                                  minus
                             select SERVICEID from (' || v_serviceSql || ')';
            open v_serviceCur for v_serviceSql;
            loop
                fetch v_serviceCur into v_serviceId;
                exit when v_serviceCur%notfound;
                --update_info('idc_isms_base_user_service','SERVICEID',v_serviceId,'是');
                update idc_isms_base_user_service set INFO_COMPLETE = '是'
                where del_flag = 0 and SERVICEID = v_serviceId and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '是'));
            end loop;
            close v_serviceCur;
         end;
     END;


     --占用机房查看（互联网用户）
     procedure monitor_base_service_hh
     as
            v_serviceHHSql varchar2(1000);
            v_serviceHHID idc_isms_base_service_hh.hhid%type;
            v_serviceHHCur sys_refcursor;
     BEGIN
         begin
            v_serviceHHSql := 'select HHID from idc_isms_base_service_hh where HHID not in (select HHID from idc_isms_base_service_iptrans where del_flag = 0) and del_flag = 0';
            open v_serviceHHCur for v_serviceHHSql;
            loop
                fetch v_serviceHHCur into v_serviceHHID;
                exit when v_serviceHHCur%notfound;
                --update_info('idc_isms_base_service_hh','HHID',v_serviceHHID,'否');
                update idc_isms_base_service_hh set INFO_COMPLETE = '否'
                where del_flag = 0 and HHID = v_serviceHHID and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '否'));
            end loop;
            close v_serviceHHCur;
            v_serviceHHSql := 'select HHID from idc_isms_base_service_hh
                                      minus
                               select HHID from (' || v_serviceHHSql || ')';
            open v_serviceHHCur for v_serviceHHSql;
            loop
                fetch v_serviceHHCur into v_serviceHHID;
                exit when v_serviceHHCur%notfound;
                --update_info('idc_isms_base_service_hh','HHID',v_serviceHHID,'是');
                update idc_isms_base_service_hh set INFO_COMPLETE = '是'
                where del_flag = 0 and HHID = v_serviceHHID and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '是'));
            end loop;
            close v_serviceHHCur;
         end;
     END;

     procedure monitor_base_user_hh_new
     as
            v_userHHSql varchar2(500) := '';
            v_userHHID idc_isms_base_user_hh.hhid%type;
            v_userHHCur sys_refcursor;
     BEGIN
       begin
            v_userHHSql := 'select hhid from idc_isms_base_user_hh t where houseid not in (select houseid from idc_isms_base_house_ipseg_view v where v.iptype != 2 and del_flag = 0 and v.userid = t.userid) and del_flag = 0';
            open v_userHHCur for v_userHHSql;
            loop
               fetch v_userHHCur into v_userHHID;
               exit when v_userHHCur%notfound;
               --update_info('idc_isms_base_user_hh','HHID',v_userHHID,'否');
               update idc_isms_base_user_hh set INFO_COMPLETE = '否'
               where del_flag = 0 and HHID = v_userHHID and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '否'));
            end loop;
            close v_userHHCur;
            v_userHHSql := 'select HHID from idc_isms_base_user_hh
                                    minus
                            select HHID from (' || v_userHHSql || ')';
            open v_userHHCur for v_userHHSql;
            loop
                fetch v_userHHCur into v_userHHID;
                exit when v_userHHCur%notfound;
                --update_info('idc_isms_base_user_hh','HHID',v_userHHID,'是');
                update idc_isms_base_user_hh set INFO_COMPLETE = '是'
                where del_flag = 0 and HHID = v_userHHID and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '是'));
            end loop;
            close v_userHHCur;
        end;
     END;

     --占用机房查看（其他用户）
     procedure monitor_base_user_hh
     as
            v_userHHSql varchar2(500) := '';
            v_userHHID idc_isms_base_user_hh.hhid%type;
            v_userHHCur sys_refcursor;
     BEGIN
       begin
            v_userHHSql := 'select HHID from idc_isms_base_user_hh where HHID not in (select HHID from idc_isms_base_user_hh_ipseg where del_flag = 0) and del_flag = 0';
            open v_userHHCur for v_userHHSql;
            loop
               fetch v_userHHCur into v_userHHID;
               exit when v_userHHCur%notfound;
               --update_info('idc_isms_base_user_hh','HHID',v_userHHID,'否');
               update idc_isms_base_user_hh set INFO_COMPLETE = '否'
               where del_flag = 0 and HHID = v_userHHID and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '否'));
            end loop;
            close v_userHHCur;
            v_userHHSql := 'select HHID from idc_isms_base_user_hh
                                    minus
                            select HHID from (' || v_userHHSql || ')';
            open v_userHHCur for v_userHHSql;
            loop
                fetch v_userHHCur into v_userHHID;
                exit when v_userHHCur%notfound;
                --update_info('idc_isms_base_user_hh','HHID',v_userHHID,'是');
                update idc_isms_base_user_hh set INFO_COMPLETE = '是'
                where del_flag = 0 and HHID = v_userHHID and ((INFO_COMPLETE is null) or (INFO_COMPLETE is not null and INFO_COMPLETE != '是'));
            end loop;
            close v_userHHCur;
        end;
     END;

     --更新
     procedure update_info(
            table_name in varchar2,
            id_name in varchar2,
            id_val in number,
            field_val in varchar2
     )as
            update_sql varchar2(100);
            info_completeSql varchar2(100);
            v_infoComplete varchar2(5);
     BEGIN
          info_completeSql := 'select INFO_COMPLETE from ' || table_name || ' where ' || id_name || ' = ' || id_val;
          execute immediate info_completeSql into v_infoComplete;
          if ((v_infoComplete is null) or (v_infoComplete is not null and v_infoComplete != field_val)) then
             update_sql := 'update ' || table_name || ' set INFO_COMPLETE = ''' || field_val || '''' || ' where del_flag = 0 and ' || id_name || ' = ' || id_val;
             execute immediate update_sql;
          end if;
          exception
             WHEN OTHERS THEN
               ROLLBACK;
               RETURN;

          commit;
     END;

end IDC_ISMS_MONITOR_INFO;
/
