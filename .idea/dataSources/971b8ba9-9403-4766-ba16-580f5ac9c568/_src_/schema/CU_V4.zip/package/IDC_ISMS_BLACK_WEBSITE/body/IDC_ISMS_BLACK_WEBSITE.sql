CREATE package body IDC_ISMS_BLACK_WEBSITE is


   --添加违法网站
   procedure addBlackWebsite(
             p_idcId in varchar2,
             p_content in varchar2, --ip或域名
             p_websiteType in number,
             p_levelDecimal in number,
             p_createUserId in number,
             p_userName in varchar2,
             p_result out number,
             p_blackId out number
   )as
             v_blackId number;
             v_out_policy_success number;
             v_out_cmdid number;
             v_out_rule_add_domain_success number;
             v_out_rule_add_ip_success number;
             v_effecttime date;
             v_effecttimeStr varchar2(60);
             v_expiredtime date;
             v_expiredtimeStr varchar2(60);
             v_commandType number;
             v_blockLog number;
             v_switch idc_jcdm_jkcs.cs_key%type;
             --v_policyLevelSwitch idc_jcdm_jkcs.cs_key%type;
   BEGIN
       begin
           --添加违法信息
           select SEQ_IDC_ISMS_SITE_BLACK_ID.nextval into v_blackId from dual;
           p_blackId := v_blackId;
           insert into IDC_ISMS_CMD_BLACK_LIST(BLACK_ID,COMMANDID,IDCID,CONTENT,CREATE_USER_ID,COMMANDTYPE,LEVEL_DECIMAL)
                  values(v_blackId,0,p_idcId,p_content,p_createUserId,p_websiteType,p_levelDecimal);
           --根据处置开关与否添加处置策略
           /*select trim(t.cs_key) into v_switch from idc_jcdm_jkcs t
           where t.model_type = 0 and t.type = 'dis_deal_switch' and t.sfyx = 1;
           --如果优先级开关关闭,下发违法违规网站指令
           if (v_switch = 'true') then
               select sysdate,sysdate + interval '1' year into v_effecttime,v_expiredtime from dual;
               /*if v_policyLevelSwitch = 'false' then
                     v_commandType := 6;
                     v_effecttimeStr:= to_char(v_effecttime,'yyyy-mm-dd hh24:mi:ss');
                     v_expiredtimeStr := to_char(v_expiredtime,'yyyy-mm-dd hh24:mi:ss');
                     v_blockLog := 1;
               else
                     v_commandType := 2;
                     v_effecttimeStr:= to_char(v_effecttime,'yyyy-mm-dd hh24:mi:ss');
                     v_expiredtimeStr := to_char(v_expiredtime,'yyyy-mm-dd hh24:mi:ss');
                     v_blockLog := 1;

               end if;
               v_commandType := 6;
               v_effecttimeStr:= to_char(v_effecttime,'yyyy-mm-dd hh24:mi:ss');
               v_expiredtimeStr := to_char(v_expiredtime,'yyyy-mm-dd hh24:mi:ss');
               v_blockLog := 1;
               --添加策略
               IDC_ISMS_AUTO_MONITOR_MANAGE.saveMonitorPolicy(v_commandType,
                                                              v_blockLog,
                                                              v_blockLog,
                                                              1,
                                                              v_effecttimeStr,
                                                              v_expiredtimeStr,
                                                              0,
                                                              p_userName,
                                                              p_levelDecimal,
                                                              v_out_policy_success,
                                                              v_out_cmdid);
              --添加规则
              if v_out_policy_success = 1 then
                 if p_websiteType = 1 then
                    idc_isms_auto_monitor_manage.AddIdcmngRule(1,p_content,null,null,v_out_cmdid,v_out_rule_add_domain_success);--域名过滤
                 end if;
                 if p_websiteType = 2 then
                    idc_isms_auto_monitor_manage.AddIdcmngRule(5,p_content,p_content,null,v_out_cmdid,v_out_rule_add_ip_success);--ip过滤
                 end if;
              end if;
           end if;*/
          exception
          WHEN OTHERS THEN
              ROLLBACK;
              p_result := 0;
              RETURN;
       end;
       commit;
       p_result := 1;
   END;

    --删除违法网站同时删除添加是添加的过滤策略
    procedure deleteBlackWebsite(
        p_blackId number,
        p_content in varchar2,
        p_result out number
   )as
        v_cursor 	 sys_refcursor;
        v_commandid		  number := 0;
        v_message_no    number := 0;
         v_func_ret      number;
   BEGIN
         begin
         update IDC_ISMS_CMD_BLACK_LIST set DELETE_FLAG = 1 where BLACK_ID = p_blackId;
         --解绑此规则的策略
         open v_cursor for
              select commandid,message_no from idc_isms_monitor_policy policy where policy.command_type = 6 and
              policy.operatetype != 3 and policy.commandid in (select t.commandid from idc_isms_monitor_policy_rule t
              where (t.subtype = 1 or t.subtype =2 or t.subtype = 4 or t.subtype = 5) and t.valuestart = p_content);
         loop
              fetch v_cursor into  v_commandid, v_message_no;
              exit when v_cursor%notfound;
              v_func_ret := PKG_IDCCONFIG.DeleteIDCISMS_Policy(v_commandid,v_message_no,-1);
         end loop;
         close v_cursor;
         exception
          WHEN OTHERS THEN
              ROLLBACK;
              p_result := 0;
              RETURN;
         end;
         commit;
         p_result := 1;
    END;

      --添加免过滤网站同时删除已存在的过滤策略
     procedure addWebSiteNoFilter(
             p_idcId in varchar2,
             p_content in varchar2, --ip或域名
             p_createUserId in number,
             p_userName in varchar2,
             p_websiteType in number,
             p_levelDecimal in number,
             p_result out number,
             p_filterId out number
    )as
             v_filterId number;
             v_out_policy_success number;
             v_out_cmdid number;
             --v_cursor 	 sys_refcursor;
             --v_commandid		  number := 0;
             --v_message_no    number := 0;
             --v_func_ret      number;
             v_effecttime date;
             v_effecttimeStr varchar2(60);
             v_expiredtime date;
             v_expiredtimeStr varchar2(60);
             v_out_rule_add_domain_success number;
             v_out_rule_add_ip_success number;
             v_switch idc_jcdm_jkcs.cs_key%type;
             --v_policyLevelSwitch idc_jcdm_jkcs.cs_key%type;

    BEGIN
            begin
            select SEQ_IDC_ISMS_SITE_NO_FILTER_ID.nextval into v_filterId from dual;
            p_filterId := v_filterId;
            insert into IDC_ISMS_CMD_NO_FILTER(FILTER_ID,COMMANDID,IDCID,CONTENT,CREATE_USER_ID,COMMANDTYPE,LEVEL_DECIMAL)
		               values (v_filterId,0,p_idcId,p_content,p_createUserId,p_websiteType,p_levelDecimal);
            /*select trim(t.cs_key) into v_policyLevelSwitch from idc_jcdm_jkcs t
            where t.model_type = 0 and t.type = 'policy_level_enabled' and t.sfyx = 1;
           if v_policyLevelSwitch = 'true' then
                 ----解绑此白名单之前绑定的过滤策略
            open v_cursor for
              select commandid,message_no from idc_isms_monitor_policy policy where policy.command_type = 2 and
              policy.operatetype != 3 and policy.commandid in (select t.commandid from idc_isms_monitor_policy_rule t
              where (t.subtype = 1 or t.subtype =2 or t.subtype = 4 or t.subtype = 5) and t.valuestart = p_content);
            loop
              fetch v_cursor into  v_commandid, v_message_no;
              exit when v_cursor%notfound;
              v_func_ret := PKG_IDCCONFIG.DeleteIDCISMS_Policy(v_commandid,v_message_no,-1);
            end loop;
                close v_cursor;
            else
              --如果优先级开关关闭,下发免过滤网站指令
              select sysdate,sysdate + interval '1' year into v_effecttime,v_expiredtime from dual;
              v_effecttimeStr:= to_char(v_effecttime,'yyyy-mm-dd hh24:mi:ss');
              v_expiredtimeStr := to_char(v_expiredtime,'yyyy-mm-dd hh24:mi:ss');
               --添加策略
               IDC_ISMS_AUTO_MONITOR_MANAGE.saveMonitorPolicy(5,
                                                              1,
                                                              1,
                                                              1,
                                                              v_effecttimeStr,
                                                              v_expiredtimeStr,
                                                              0,
                                                              p_userName,
                                                              p_levelDecimal,
                                                              v_out_policy_success,
                                                              v_out_cmdid);
              --添加规则
              if v_out_policy_success = 1 then
                 if p_websiteType = 1 then
                    idc_isms_auto_monitor_manage.AddIdcmngRule(1,p_content,null,null,v_out_cmdid,v_out_rule_add_domain_success);--域名过滤
                 end if;
                 if p_websiteType = 2 then
                    idc_isms_auto_monitor_manage.AddIdcmngRule(5,p_content,p_content,null,v_out_cmdid,v_out_rule_add_ip_success);--ip过滤
                 end if;
              end if;
            end if;*/
            --根据处置开关与否添加处置策略
            /*select trim(t.cs_key) into v_switch from idc_jcdm_jkcs t
            where t.model_type = 0 and t.type = 'dis_deal_switch' and t.sfyx = 1;
            if (v_switch = 'true') then
                select sysdate,sysdate + interval '1' year into v_effecttime,v_expiredtime from dual;
                v_effecttimeStr:= to_char(v_effecttime,'yyyy-mm-dd hh24:mi:ss');
                v_expiredtimeStr := to_char(v_expiredtime,'yyyy-mm-dd hh24:mi:ss');
                --添加策略
                IDC_ISMS_AUTO_MONITOR_MANAGE.saveMonitorPolicy(5,
                                                                0,
                                                                0,
                                                                1,
                                                                v_effecttimeStr,
                                                                v_expiredtimeStr,
                                                                0,
                                                                p_userName,
                                                                p_levelDecimal,
                                                                v_out_policy_success,
                                                                v_out_cmdid);
                --添加规则
                if v_out_policy_success = 1 then
                   if p_websiteType = 1 then
                      idc_isms_auto_monitor_manage.AddIdcmngRule(1,p_content,null,null,v_out_cmdid,v_out_rule_add_domain_success);--域名过滤
                   end if;
                   if p_websiteType = 2 then
                      idc_isms_auto_monitor_manage.AddIdcmngRule(5,p_content,p_content,null,v_out_cmdid,v_out_rule_add_ip_success);--ip过滤
                   end if;
                end if;
            end if;*/
         exception
          WHEN OTHERS THEN
              ROLLBACK;
              p_result := 0;
              RETURN;
         end;
         commit;
         p_result := 1;
    END;

 --删除免过滤网站列表 同时判断要不要删除信安策略
   procedure deleteWebsiteNoFilter(
             p_filterId number,
             p_content in varchar2,
             p_result out number
   )as
        v_cursor 	 sys_refcursor;
        v_commandid		  number := 0;
        v_message_no    number := 0;
        v_func_ret      number;
   BEGIN
         begin
         update IDC_ISMS_CMD_NO_FILTER set DELETE_FLAG = 1 where FILTER_ID = p_filterId;
         --解绑此规则的策略
         open v_cursor for
              select commandid,message_no from idc_isms_monitor_policy policy where policy.command_type = 5 and
              policy.operatetype != 3 and policy.commandid in (select t.commandid from idc_isms_monitor_policy_rule t
              where (t.subtype = 1 or t.subtype =2 or t.subtype = 4 or t.subtype = 5) and t.valuestart = p_content);
         loop
              fetch v_cursor into  v_commandid, v_message_no;
              exit when v_cursor%notfound;
              v_func_ret := PKG_IDCCONFIG.DeleteIDCISMS_Policy(v_commandid,v_message_no,-1);
         end loop;
         close v_cursor;
         exception
          WHEN OTHERS THEN
              ROLLBACK;
              p_result := 0;
              RETURN;
         end;
         commit;
         p_result := 1;
    END;
end IDC_ISMS_BLACK_WEBSITE;
/
