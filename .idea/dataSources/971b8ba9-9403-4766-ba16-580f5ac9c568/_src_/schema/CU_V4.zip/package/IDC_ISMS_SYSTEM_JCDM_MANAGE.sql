CREATE package IDC_ISMS_SYSTEM_JCDM_MANAGE is

procedure list_basx(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,
                          p_name in varchar2
                          );

procedure list_dllx(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,
                          p_name in varchar2
                          );

procedure list_dwsx(   p_ispaging in number,
                              pageindex in number,
                              pagesize in number,
                              p_iscount in number,
                              sortName in varchar2,
                              orderItem in varchar2,
                              p_cursor out sys_refcursor,
                              p_recordcount out number,
                              p_name in varchar2
                              );

procedure list_fwnr(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_fl in number,
                      p_name in varchar2
                      );

procedure list_gzlx(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_name in varchar2
                      );

procedure list_jfxz(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_name in varchar2
                      );

procedure list_jrfs(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_name in varchar2
                      );

procedure list_wfwgqk(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_name in varchar2
                      );

procedure list_zjlx(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_name in varchar2
                      );

end IDC_ISMS_SYSTEM_JCDM_MANAGE;

/
CREATE package body IDC_ISMS_SYSTEM_JCDM_MANAGE is

procedure list_basx(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,
                          p_name in varchar2
                          )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_JCDM_BASX ';
      v_field    := ' mc,id,bz ';

      --条件语句
      v_condition := ' where sfyx=1 ';
      if(p_name  is not null ) then
          v_condition := v_condition || '  and mc like ''%' || p_name || '%''';
      end if;
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;

procedure list_dllx(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,
                          p_name in varchar2
                          )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_JCDM_DLLX ';
      v_field    := ' mc,id,bz ';

      --条件语句
      v_condition := ' where sfyx=1 ';
      if(p_name  is not null ) then
          v_condition := v_condition || '  and mc like ''%' || p_name || '%''';
      end if;
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;

procedure list_dwsx(   p_ispaging in number,
                              pageindex in number,
                              pagesize in number,
                              p_iscount in number,
                              sortName in varchar2,
                              orderItem in varchar2,
                              p_cursor out sys_refcursor,
                              p_recordcount out number,
                              p_name in varchar2
                              )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_JCDM_DWSX ';
      v_field    := ' mc,id,bz ';

      --条件语句
      v_condition := ' where sfyx = 1 ';
      if(p_name  is not null ) then
          v_condition := v_condition || '  and mc like''%' || p_name || '%''';
      end if;
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;

procedure list_fwnr(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_fl in number,
                      p_name in varchar2
                      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_JCDM_FWNR ';
      v_field    := ' mc,bz,id,fl ';

      --条件语句
      v_condition := ' where sfyx=1 ';

      if (p_fl >= 0) then
        v_condition := v_condition || '  and fl = ' || p_fl;
      end if;
      if(p_name  is not null ) then
          v_condition := v_condition || '  and mc like''%' || p_name || '%''';
      end if;

      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;

procedure list_gzlx(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_name in varchar2
                      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_JCDM_GZLX ';
      v_field    := ' mc,bz,id ';

      --条件语句
      v_condition := ' where sfyx=1 ';
      if(p_name  is not null ) then
          v_condition := v_condition || '  and mc like''%' || p_name || '%''';
      end if;
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;
procedure list_jfxz(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,
                          p_name in varchar2
                          )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_JCDM_JFXZ ';
      v_field    := ' mc,id,bz ';

      --条件语句
      v_condition := ' where sfyx=1 ';
      if(p_name  is not null ) then
          v_condition := v_condition || '  and mc like''%' || p_name || '%''';
      end if;
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;
procedure list_jrfs(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,
                          p_name in varchar2
                          )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_JCDM_JRFS ';
      v_field    := ' mc,id,bz ';

      --条件语句
      v_condition := ' where sfyx=1 ';
      if(p_name  is not null ) then
          v_condition := v_condition || '  and mc like''%' || p_name || '%''';
      end if;
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;
procedure list_wfwgqk(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,
                          p_name in varchar2
                          )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_JCDM_WFWGQK ';
      v_field    := ' mc,id,bz ';

      --条件语句
      v_condition := ' where sfyx=1 ';
      if(p_name  is not null ) then
          v_condition := v_condition || '  and mc like''%' || p_name || '%''';
      end if;
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;
procedure list_zjlx(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,
                          p_name in varchar2
                          )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500) := ''; --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_JCDM_ZJLX ';
      v_field    := ' mc,id,bz ';

      --条件语句
      v_condition := ' where sfyx=1 ';
      if(p_name  is not null ) then
          v_condition := v_condition || '  and mc like''%' || p_name || '%''';
      end if;
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      if (sortName is not null) then
         v_order := ' order by ' || sortName || '  ' || orderItem;
      end if;
      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;

end IDC_ISMS_SYSTEM_JCDM_MANAGE;

/
