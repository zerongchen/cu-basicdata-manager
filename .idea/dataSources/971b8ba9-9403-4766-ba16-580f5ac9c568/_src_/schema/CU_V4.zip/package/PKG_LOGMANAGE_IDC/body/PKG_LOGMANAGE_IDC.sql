CREATE package body PKG_LOGMANAGE_IDC is


    ---分页获取操作日志
FUNCTION GetOperLogList(
                            pagesize      NUMBER,
                            pageindex     NUMBER,
                            p_username    VARCHAR2,
                            p_type        NUMBER,
                            p_code        NUMBER,
                            p_clogtype    NUMBER,
                            p_starttime   VARCHAR2,
                            p_endtime     VARCHAR2,
                            p_userid      NUMBER,
                            --出参
                            p_cursor          OUT C_CURSOR,
                            v_out_recordcount OUT NUMBER) RETURN INTEGER AS

  nBegin NUMBER;
  nEnd NUMBER;
  v_sqlWhere VARCHAR2(1000);
  v_starttime NUMBER(10);
  v_endtime NUMBER(10);
BEGIN

  nBegin := (pageindex - 1) * pagesize + 1;
  nEnd := pageindex * pagesize;


   IF p_type <>-1 THEN
      v_sqlWhere := v_sqlWhere || ' and a.op_type = ' || p_type || '';
   END IF;

    IF p_code <>-1 THEN
      v_sqlWhere := v_sqlWhere || ' and a.op_code = ' || p_code || '';
   END IF;

   IF p_clogtype <>-1 THEN
      v_sqlWhere := v_sqlWhere || ' and c.clogtype = ' || p_clogtype || '';
   END IF;

   IF p_userid <>-1 THEN
      v_sqlWhere := v_sqlWhere || ' and a.create_oper = ' || p_userid || '';
   END IF;

   IF length(p_username) >0 THEN
      v_sqlWhere := v_sqlWhere || ' and d.username like ''%' || p_username || '%''';
   END IF;

   IF length(p_starttime) >0 THEN
      v_starttime:=date2time_t(to_date(p_starttime,'yyyy-mm-dd hh:mi:ss'));
      v_sqlWhere := v_sqlWhere || ' and date2time_t(a.create_time) >= ' || v_starttime || '';
   END IF;

   IF length(p_endtime) >0 THEN
      v_endtime:=date2time_t(to_date(p_endtime,'yyyy-mm-dd hh:mi:ss')+1);
      v_sqlWhere := v_sqlWhere || ' and date2time_t(a.create_time) <= ' || v_endtime || '';
   END IF;


   EXECUTE IMMEDIATE 'SELECT  count(1) FROM
                       useroperatelog a LEFT JOIN dic_clog_define c ON a.op_code=c.op_code LEFT JOIN WEB_OPERATOR_INFO d ON a.create_oper=d.userid  where 1=1'|| v_sqlWhere INTO v_out_recordcount;


   OPEN p_cursor FOR
       ' SELECT * FROM
                (SELECT  rownum as RN,t.* FROM
                  (
                       SELECT  a.*, c.op_modulename,c.clogtype,d.username FROM
                       useroperatelog a
                       LEFT JOIN dic_clog_define c ON a.op_code=c.op_code
                       LEFT JOIN WEB_OPERATOR_INFO d ON a.create_oper=d.userid
                       WHERE 1=1 ' || v_sqlWhere || '
                       ORDER BY a.create_time desc
                  )t
                 ) b
                WHERE b.RN >= ' || nBegin || ' AND b.RN <= ' || nEnd;
       RETURN SUCC_CODE;

   EXCEPTION
    WHEN OTHERS THEN
      RAISE;
END;


    ---分页获取登陆日志
FUNCTION GetLoginLogList(
                            pagesize      NUMBER,
                            pageindex     NUMBER,
                            p_username    VARCHAR2,
                            p_loginip     VARCHAR2,
                            p_flag        NUMBER,
                            p_status      NUMBER,
                            p_starttime   VARCHAR2,
                            p_endtime     VARCHAR2,
                            p_systemid    NUMBER,
                            p_userid      NUMBER,
                            --出参
                            p_cursor          OUT C_CURSOR,
                            v_out_recordcount OUT NUMBER) RETURN INTEGER AS

  nBegin NUMBER;
  nEnd NUMBER;
  v_sqlWhere VARCHAR2(1000);
  v_starttime NUMBER(10);
  v_endtime NUMBER(10);
BEGIN

  nBegin := (pageindex - 1) * pagesize + 1;
  nEnd := pageindex * pagesize;


   IF length(p_username) >0 THEN
      v_sqlWhere := v_sqlWhere || ' and a.username like ''%' || p_username || '%''';
   END IF;

   IF length(p_loginip) >0 THEN
      v_sqlWhere := v_sqlWhere || ' and a.loginip =''' || p_loginip || '''';
   END IF;

    IF p_flag <>-1 THEN
      v_sqlWhere := v_sqlWhere || ' and a.flag = ' || p_flag || '';
   END IF;

   IF p_status <>-1 THEN
      v_sqlWhere := v_sqlWhere || ' and a.status = ' || p_status || '';
   END IF;

   IF length(p_starttime) >0 THEN
      v_starttime:=date2time_t(to_date(p_starttime,'yyyy-mm-dd hh:mi:ss'));
      v_sqlWhere := v_sqlWhere || ' and date2time_t(a.logintime) >= ' || v_starttime || '';
   END IF;

    IF length(p_endtime) >0 THEN
      v_endtime:=date2time_t(to_date(p_endtime,'yyyy-mm-dd hh:mi:ss')+1);
      v_sqlWhere := v_sqlWhere || ' and date2time_t(a.logintime) <= ' || v_endtime || '';
   END IF;

   IF p_systemid <>-1 THEN
      v_sqlWhere := v_sqlWhere || ' and a.systemid = ' || p_systemid || '';
   END IF;

   IF p_userid <>-1 THEN
      v_sqlWhere := v_sqlWhere || ' and a.userid = ' || p_userid || '';
   END IF;


   EXECUTE IMMEDIATE 'SELECT  count(1) FROM web_login_log a  where 1=1'|| v_sqlWhere INTO v_out_recordcount;


   OPEN p_cursor FOR
       ' SELECT * FROM
                (SELECT  rownum as RN,t.* FROM
                  (
                       SELECT  a.* from web_login_log a
                        WHERE 1=1 ' || v_sqlWhere || '
                       ORDER BY a.logintime desc
                  )t
                 ) b
                WHERE b.RN >= ' || nBegin || ' AND b.RN <= ' || nEnd;
       RETURN SUCC_CODE;

   EXCEPTION
    WHEN OTHERS THEN
      RAISE;
END;

--操作恢复
FUNCTION OperUndo(
    p_logid NUMBER,
    p_operid NUMBER
) RETURN INTEGER
AS
  n_op_code NUMBER(5);
  n_dataid NUMBER(10);
BEGIN
  SELECT op_code, dataid INTO  n_op_code, n_dataid FROM useroperatelog WHERE logid=p_logid;

  RETURN OperUndoById(n_dataid,n_op_code,p_operid);

   EXCEPTION
    WHEN OTHERS THEN
      RAISE;
END;

--操作恢复按信息ID
FUNCTION OperUndoById(
    p_dataid NUMBER,
    p_op_code NUMBER,
    p_operid NUMBER
) RETURN INTEGER
AS
  v_table_name VARCHAR2(60);
  v_id1name VARCHAR2(50);
  v_msgtype VARCHAR2(50);
  n_message_no NUMBER(10);
  v_sql VARCHAR2(3000);
  v_seqno NUMBER(10);
  v_houseid VARCHAR2(60);
  v_count number := 0;
BEGIN
  SELECT recid1_name,recid2_name, table_name INTO v_id1name,v_msgtype,v_table_name FROM dic_clog_define WHERE op_code=p_op_code;

  v_seqno := PKG_DPICONFIG.MessageSequenceNo(to_number(v_msgtype));

  v_sql := 'UPDATE '|| v_table_name ||' SET operatetype=1, message_sequenceno='||v_seqno||' WHERE '|| v_id1name ||' = '|| p_dataid;
  EXECUTE IMMEDIATE v_sql;

  IF p_op_code = 20029 THEN
    select count(1) into v_count from idc_isms_cfg_houseip_ip WHERE seq_id=p_dataid;
    if (v_count > 0) then
       SELECT house_id INTO v_houseid FROM idc_isms_cfg_houseip_ip WHERE seq_id=p_dataid;
    end if;
    select count(1) into v_count from idc_isms_cfg_houseip WHERE house_id=v_houseid;
    if (v_count > 0) then
       SELECT message_no INTO n_message_no FROM idc_isms_cfg_houseip WHERE house_id=v_houseid;
    end if;
    UPDATE idc_isms_cfg_houseip SET message_sequenceno=v_seqno WHERE house_id=v_houseid;
  ELSE
    v_sql := 'select message_no from '|| v_table_name ||' where '|| v_id1name ||' = '|| p_dataid;
    EXECUTE IMMEDIATE v_sql INTO n_message_no;

    v_sql := 'UPDATE dpi_v1_cfg_messageno SET opertype=1 WHERE message_no='||n_message_no||' and message_type='||v_msgtype;
    EXECUTE IMMEDIATE v_sql;
  END IF;
  --删除旧策略下发状态
  delete from DPI_V1_POLICY_STATUS where message_type=v_msgtype and dev_type=1 and message_no=n_message_no;

  dpi_setclog(p_op_code,1,n_message_no,v_seqno,p_operid);
  dpi_setuserlog(p_op_code,8,p_dataid,'','',p_operid);

  COMMIT;

  RETURN SUCC_CODE;

   EXCEPTION WHEN OTHERS THEN
      RAISE;
END;

--策略重发操作
FUNCTION PolicyResend(
    p_dataid NUMBER,
    p_op_code NUMBER,
    p_operid NUMBER
) RETURN INTEGER
AS
  v_table_name VARCHAR2(60);
  v_id1name VARCHAR2(50);
  v_msgtype VARCHAR2(50);
  n_message_no NUMBER(10);
  v_sql VARCHAR2(3000);
  v_seqno NUMBER(10);
  v_houseid VARCHAR2(60);
BEGIN
  SELECT recid1_name,recid2_name, table_name INTO v_id1name,v_msgtype,v_table_name FROM dic_clog_define WHERE op_code=p_op_code;
  dbms_output.put_line('v_msgtype:' || v_msgtype);
  v_seqno := PKG_DPICONFIG.MessageSequenceNo(to_number(v_msgtype));

  v_sql := 'UPDATE '|| v_table_name ||' SET operatetype=1, message_sequenceno='||v_seqno||' WHERE '|| v_id1name ||' = '|| p_dataid;
  dbms_output.put_line('v_sql:' || v_sql);
  EXECUTE IMMEDIATE v_sql;

  IF p_op_code = 20029 THEN
    SELECT house_id INTO v_houseid FROM idc_isms_cfg_houseip_ip WHERE seq_id=p_dataid;
    SELECT message_no INTO n_message_no FROM idc_isms_cfg_houseip WHERE house_id=v_houseid;
    UPDATE idc_isms_cfg_houseip SET message_sequenceno=v_seqno WHERE house_id=v_houseid;
  ELSE
    v_sql := 'select message_no from '|| v_table_name ||' where '|| v_id1name ||' = '|| p_dataid;
    EXECUTE IMMEDIATE v_sql INTO n_message_no;

  END IF;

  --删除旧策略下发状态
  delete from DPI_V1_POLICY_STATUS where message_type=v_msgtype and dev_type=1 and message_no=n_message_no;

  dpi_setclog(p_op_code,1,n_message_no,v_seqno,p_operid);

  dpi_setuserlog(p_op_code,1,p_dataid,'','',p_operid);

  COMMIT;

  RETURN SUCC_CODE;

   EXCEPTION
    WHEN OTHERS THEN
      return 1;
      RAISE;
END;

--流量镜像策略重发
FUNCTION PolicyMirrorResend(
    p_dataid NUMBER,
    p_op_code NUMBER
) RETURN INTEGER
AS
  v_table_name VARCHAR2(60);
  v_id1name VARCHAR2(50);
  v_msgtype VARCHAR2(50);
  v_sql VARCHAR2(3000);
  v_seqno NUMBER(10);
BEGIN
  SELECT recid1_name,recid2_name, table_name INTO v_id1name,v_msgtype,v_table_name FROM dic_clog_define WHERE op_code=p_op_code;
  dbms_output.put_line('v_msgtype:' || v_msgtype);
  v_seqno := PKG_DPICONFIG.MessageSequenceNo(to_number(v_msgtype));

  v_sql := 'UPDATE '|| v_table_name ||' SET operatetype=1, message_sequenceno='||v_seqno||' WHERE '|| v_id1name ||' = '|| p_dataid;
  dbms_output.put_line('v_sql:' || v_sql);
  EXECUTE IMMEDIATE v_sql;
  COMMIT;

  RETURN SUCC_CODE;

   EXCEPTION
    WHEN OTHERS THEN
      return 1;
      RAISE;
END;



--部分设备策略重发操作
FUNCTION PolicyResendPart(
    p_dataid in NUMBER,
    p_op_code in NUMBER,
    p_operid in NUMBER,
    v_msgtype out NUMBER,
    n_message_no out NUMBER,
    p_logid  out number
) RETURN INTEGER
AS
  v_table_name VARCHAR2(60);
  v_id1name VARCHAR2(50);
  v_sql VARCHAR2(3000);
  v_seqno NUMBER(10);
  v_houseid VARCHAR2(60);
BEGIN
  SELECT recid1_name,to_number(recid2_name), table_name INTO v_id1name,v_msgtype,v_table_name FROM dic_clog_define WHERE op_code=p_op_code;

  v_seqno := PKG_DPICONFIG.MessageSequenceNo(v_msgtype);

  v_sql := 'UPDATE '|| v_table_name ||' SET operatetype=1, message_sequenceno='||v_seqno||' WHERE '|| v_id1name ||' = '|| p_dataid;
  EXECUTE IMMEDIATE v_sql;

  IF p_op_code = 20029 THEN
    SELECT house_id INTO v_houseid FROM idc_isms_cfg_houseip_ip WHERE seq_id=p_dataid;
    SELECT message_no INTO n_message_no FROM idc_isms_cfg_houseip WHERE house_id=v_houseid;
    UPDATE idc_isms_cfg_houseip SET message_sequenceno=v_seqno WHERE house_id=v_houseid;
  ELSE
    v_sql := 'select message_no from '|| v_table_name ||' where '|| v_id1name ||' = '|| p_dataid;
    EXECUTE IMMEDIATE v_sql INTO n_message_no;

  END IF;

  p_logid:=dpi_setclog_new(p_op_code,1,n_message_no,v_seqno,0,p_operid);

  dpi_setuserlog(p_op_code,1,p_dataid,'','',p_operid);

  --外部提交
  --COMMIT;

  RETURN SUCC_CODE;

   EXCEPTION
    WHEN OTHERS THEN
      RAISE;
END;


--部分设备策略重发操作-添加重发设备
FUNCTION AddClogIp(
    p_msgtype NUMBER,
    p_msgno   NUMBER,
    p_logid NUMBER,
    p_ip VARCHAR2
) RETURN INTEGER
AS
BEGIN

  --删除旧策略下发状态
  delete from DPI_V1_POLICY_STATUS where message_type=p_msgtype and dev_type=1 and message_no=p_msgno and ip=p_ip;

  insert into DPI_V1_CLOG_IP (LOGID,DPI_IP) VALUES(p_logid,p_ip);

  --外部提交
  --COMMIT;

  RETURN SUCC_CODE;

   EXCEPTION
    WHEN OTHERS THEN
      RAISE;
END;

---分页获取策略下发状态
FUNCTION GetPolicyStatus(
                            pagesize      in NUMBER,
                            pageindex     in NUMBER,
                            p_dataid      in NUMBER,
                            p_op_code     in NUMBER,
                            p_status      in NUMBER,--0下发成功 1-下发失败
                            p_houseNo     VARCHAR2,
                            --出参
                            p_cursor          OUT C_CURSOR,
                            v_out_recordcount OUT NUMBER)
                            RETURN INTEGER AS

  nBegin NUMBER;
  nEnd NUMBER;
  v_table_name VARCHAR2(60);
  v_id1name VARCHAR2(50);
  v_msgtype NUMBER(10);
  v_message_no NUMBER(10);
  v_sql VARCHAR2(3000);
  v_sqlWhere1 VARCHAR2(1000);
  v_sqlWhere2 VARCHAR2(1000);
  v_houseid VARCHAR2(60);
BEGIN

  nBegin := (pageindex - 1) * pagesize + 1;
  nEnd := pageindex * pagesize;

  --获取msgtype 和 msgno
  SELECT recid1_name,to_number(recid2_name), table_name INTO v_id1name,v_msgtype,v_table_name FROM dic_clog_define WHERE op_code=p_op_code;
  IF p_op_code = 20029 THEN
    SELECT house_id INTO v_houseid FROM idc_isms_cfg_houseip_ip WHERE seq_id=p_dataid;
    SELECT message_no INTO v_message_no FROM idc_isms_cfg_houseip WHERE house_id=v_houseid;
  ELSE
     v_sql := 'select message_no from '|| v_table_name ||' where '|| v_id1name ||' = '|| p_dataid;
    EXECUTE IMMEDIATE v_sql INTO v_message_no;
  END IF;

  v_sqlWhere1:=' and message_type= ' || v_msgtype || ' and dev_type=1 and message_no= ' || v_message_no || '';

   IF p_status <>-1 THEN
      v_sqlWhere2 := v_sqlWhere2 || ' and status = ' || p_status || '';
   END IF;


   select count(*) INTO v_out_recordcount from dpi_v1_cfg_dpiinfo a  left join
   (select * from DPI_V1_POLICY_STATUS where
     message_type= v_msgtype and dev_type=1 and message_no= v_message_no) b
   on b.ip=a.dpi_ip ;

   if p_houseNo is not null then
      v_sql:= ' SELECT * FROM
                (SELECT  rownum as RN,t.* FROM
                  (
                       select * from(
                       select a.dpi_ip,a.dpi_dev_name,a.area_code,a.connectflag,'|| v_msgtype ||' as message_type,'|| v_message_no ||' as message_no,house_id,
                       case when  b.status is not null then b.status when  a.connectflag=1 then 3 else 2 end as status,
                       case when  b.createtime is null then sysdate else b.createtime end as createtime from dpi_v1_cfg_dpiinfo a
                       left join dpi_v1_cfg_dpiinfo_house t on a.dev_id = t.dev_id
                       left join
                       (select * from DPI_V1_POLICY_STATUS where 1=1 ' || v_sqlWhere1 || ' ) b
                       on b.ip=a.dpi_ip where a.operatetype<>3
                       )where 1=1 ' || v_sqlWhere2 || 'and house_id = '''|| p_houseNo || ''' order by status
                  )t
                 ) c
                WHERE c.RN >= ' || nBegin || ' AND c.RN <= ' || nEnd;
   else
      /*v_sql:= ' SELECT * FROM
                (SELECT  rownum as RN,t.* FROM
                  (
                       select * from(
                       select a.dpi_ip,a.dpi_dev_name,a.area_code,a.connectflag,'|| v_msgtype ||' as message_type,'|| v_message_no ||' as message_no,
                       case when  b.status is not null then b.status when a.connectflag=1 then 3 else 2 end as status,
                       case when  b.createtime is null then sysdate else b.createtime end as createtime from dpi_v1_cfg_dpiinfo a
                       left join
                       (select * from DPI_V1_POLICY_STATUS where 1=1 ' || v_sqlWhere1 || ' ) b
                       on b.ip=a.dpi_ip where a.operatetype<>3
                       )where 1=1 ' || v_sqlWhere2 || ' order by status
                  )t
                 ) c
                WHERE c.RN >= ' || nBegin || ' AND c.RN <= ' || nEnd;*/
      v_sql:= ' SELECT * FROM
                (SELECT  rownum as RN,t.* FROM
                  (
                       select * from(
                       select a.dpi_ip,a.dpi_dev_name,a.area_code,a.connectflag,'|| v_msgtype ||' as message_type,'|| v_message_no ||' as message_no,
                       case when  b.status is not null then b.status when a.connectflag=1 then 3 else 2 end as status,
                       max(b.createtime) as createtime
                       from dpi_v1_cfg_dpiinfo a
                       left join
                       (select * from DPI_V1_POLICY_STATUS where 1=1 ' || v_sqlWhere1 || ' ) b
                       on b.ip=a.dpi_ip where a.operatetype<>3
                       group by dpi_ip, dpi_dev_name, area_code, connectflag,status
                       )where 1=1 ' || v_sqlWhere2 || ' order by status
                  )t
                 ) c
                WHERE c.RN >= ' || nBegin || ' AND c.RN <= ' || nEnd;
   end if;


dbms_output.put_line('v_sql = '|| v_sql);
   OPEN p_cursor FOR
      v_sql;
       RETURN SUCC_CODE;

   EXCEPTION
    WHEN OTHERS THEN
      RAISE;
END;


---分页获取策略下发状态
FUNCTION GetMyPolicyStatus(
                            pagesize      in NUMBER,
                            pageindex     in NUMBER,
                            p_messageNo      in NUMBER,
                            p_messageType     in NUMBER,
                            p_status      in NUMBER,--0下发成功 1-下发失败
                            p_houseNo     VARCHAR2,
                            --出参
                            p_cursor          OUT C_CURSOR,
                            v_out_recordcount OUT NUMBER)
                            RETURN INTEGER AS

  nBegin NUMBER;
  nEnd NUMBER;
  v_sql VARCHAR2(3000);
  v_sqlWhere1 VARCHAR2(1000);
  v_sqlWhere2 VARCHAR2(1000);
BEGIN

  nBegin := (pageindex - 1) * pagesize + 1;
  nEnd := pageindex * pagesize;

  v_sqlWhere1:=' and message_type= ' || p_messageType || ' and dev_type=0 and message_no= ' || p_messageNo || '';

   IF p_status <>-1 THEN
      v_sqlWhere2 := v_sqlWhere2 || ' and status = ' || p_status || '';
   END IF;


   select count(*) INTO v_out_recordcount from dpi_v1_cfg_dpiinfo a  left join
   (select * from DPI_V1_POLICY_STATUS where
     message_type= p_messageType and dev_type=0 and message_no= p_messageNo) b
   on b.ip=a.dpi_ip ;

   if p_houseNo is not null then
      v_sql:= ' SELECT * FROM
                (SELECT  rownum as RN,t.* FROM
                  (
                       select * from(
                       select a.dpi_ip,a.dpi_dev_name,a.area_code,a.connectflag,'|| p_messageType ||' as message_type,'|| p_messageNo ||' as message_no,house_id,
                       case when  b.status is not null then b.status when  a.connectflag=1 then 3 else 2 end as status,
                       case when  b.createtime is null then sysdate else b.createtime end as createtime from dpi_v1_cfg_dpiinfo a
                       left join dpi_v1_cfg_dpiinfo_house t on a.dev_id = t.dev_id
                       left join
                       (select * from DPI_V1_POLICY_STATUS where 1=1 ' || v_sqlWhere1 || ' ) b
                       on b.ip=a.dpi_ip where a.operatetype<>3
                       )where 1=1 ' || v_sqlWhere2 || 'and house_id = '''|| p_houseNo || ''' order by status
                  )t
                 ) c
                WHERE c.RN >= ' || nBegin || ' AND c.RN <= ' || nEnd;
   else

      v_sql:= ' SELECT * FROM
                (SELECT  rownum as RN,t.* FROM
                  (
                       select * from(
                       select a.dpi_ip,a.dpi_dev_name,a.area_code,a.connectflag,'|| p_messageType ||' as message_type,'|| p_messageNo ||' as message_no,
                       case when  b.status is not null then b.status when a.connectflag=1 then 3 else 2 end as status,
                       max(b.createtime) as createtime
                       from dpi_v1_cfg_dpiinfo a
                       left join
                       (select * from DPI_V1_POLICY_STATUS where 1=1 ' || v_sqlWhere1 || ' ) b
                       on b.ip=a.dpi_ip where a.operatetype<>3
                       group by dpi_ip, dpi_dev_name, area_code, connectflag,status
                       )where 1=1 ' || v_sqlWhere2 || ' order by status
                  )t
                 ) c
                WHERE c.RN >= ' || nBegin || ' AND c.RN <= ' || nEnd;
   end if;


dbms_output.put_line('v_sql = '|| v_sql);
   OPEN p_cursor FOR
      v_sql;
       RETURN SUCC_CODE;

   EXCEPTION
    WHEN OTHERS THEN
      RAISE;
END;



--部分设备策略重发操作
FUNCTION PolicyMyResendPart(
    p_seqenceNo in NUMBER,
    p_messageNo  in NUMBER,
    p_messageType in NUMBER,
    p_op_code in NUMBER,
    p_operid in NUMBER,
    p_logid  out number
) RETURN INTEGER
AS
BEGIN
  p_logid:=dpi_setclog_new(p_op_code,1,p_messageNo,p_seqenceNo,0,p_operid);

  --外部提交
  --COMMIT;

  RETURN SUCC_CODE;

   EXCEPTION
    WHEN OTHERS THEN
      RAISE;
END;

end PKG_LOGMANAGE_IDC;
/
