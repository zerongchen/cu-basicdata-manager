CREATE TRIGGER CMD_ALARM_LOGQUERY_TRIGGER
AFTER INSERT
  ON IDC_ISMS_CMD_LOG_QUERY
FOR EACH ROW
  DECLARE
    v_cmd_name     varchar2(64) := '访问日志查询';
    v_houseid NUMBER:=0;
    v_house_id   VARCHAR2(100) := '0';
    v_house_idstr   VARCHAR2(100);
    v_house_cnt NUMBER;
BEGIN
    IF :NEW.COMMANDID > 0 THEN
    IF :NEW.HOUSEID IS NOT NULL THEN
       v_houseid := :NEW.HOUSEID;
    END IF;

    IF v_houseid > 0 THEN
           SELECT count(1) INTO v_house_cnt FROM idc_isms_base_house WHERE HOUSEID=v_houseid;
           IF v_house_cnt > 0 THEN
               SELECT HOUSEIDSTR INTO v_house_idstr FROM idc_isms_base_house WHERE HOUSEID=v_houseid;
               v_house_id := v_house_idstr;
           END IF;
    END IF;

  -- 插入告警信息
  INSERT INTO IDC_ISMS_ALARM_INFORMATION
    (ALARMID,
     SMMS_COMMANDID,
     ALARM_TYPE,
     ALARM_HOUSE,
     ALARM_LEVEL,
     ALARM_TIME,
     ALARM_MSG,
     ALARM_TARGET,
     SMMS_COMMAND_TYPE)
  VALUES
    (SEQ_IDC_ISMS_ALARM_INFORMATION.NEXTVAL,
     :NEW.COMMANDID,
     1,
     v_house_id,
     2,
     TO_CHAR(SYSDATE(), 'yyyy-MM-dd hh24:mi:ss'),
     '  ',
     1,
     6);
  -- 插入告警列表信息
  INSERT INTO IDC_ISMS_ALARM_INFOR_LIST
    (ID, ALARMID, ALARM_MSG, ALARM_TIME, STATUS,ALARM_TARGET)
  VALUES
    (SEQ_IDC_ISMS_ALARM_INFO_LIST.NEXTVAL,
     SEQ_IDC_ISMS_ALARM_INFORMATION.Currval,
     '管局下发' || v_cmd_name || '指令成功',
     TO_CHAR(SYSDATE(), 'yyyy-MM-dd hh24:mi:ss'),
     0,1);
    END IF;
END CMD_ALARM_LOGQUERY_TRIGGER;

-- 删除监控触发器
-- DROP TRIGGER CMD_ALARM_LOGQUERY_TRIGGER;
/
