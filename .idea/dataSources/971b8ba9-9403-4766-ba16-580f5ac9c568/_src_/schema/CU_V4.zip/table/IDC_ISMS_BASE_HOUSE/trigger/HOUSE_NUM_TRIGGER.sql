CREATE TRIGGER HOUSE_NUM_TRIGGER
AFTER INSERT OR UPDATE OR DELETE
  ON IDC_ISMS_BASE_HOUSE
FOR EACH ROW
  declare
  -- local variables here
  v_number      number(10);
  v_old         number(10);
  v_new         number(10);
begin
  select count(1) into v_number from idc_isms_base_idc t where t.del_flag = 0;
  if inserting then
     update idc_isms_base_idc idc set idc.housenumber = v_number + 1;
  elsif updating('del_flag') then
     v_old := :old.del_flag;
     v_new := :new.del_flag;
     if (v_old = 0 and v_new = 1) then
        update idc_isms_base_idc idc set idc.housenumber = idc.housenumber - 1;
     elsif (v_old = 1 and v_new = 0) then
        update idc_isms_base_idc idc set idc.housenumber = idc.housenumber + 1;
     end if;
  elsif deleting then
     update idc_isms_base_idc idc set idc.housenumber = v_number - 1;
  end if;
end house_num_trigger;
/
