CREATE TYPE ConcatObj force AS OBJECT
(
   fieldValue clob,
   separator VARCHAR2 (100)
)

/
