CREATE package idc_system_LOG_MANAGE is

-- 成功返回
SUCC_CODE CONSTANT NUMBER(5) := 0;

-- 游标类型
TYPE C_CURSOR IS REF CURSOR;

-- 数据库错误定义
ERROR_DATABASE CONSTANT NUMBER(5) := 10000;

-- 错误代码定义(11000 -- 11100)
ERROR_SERVER_EXIST NUMBER(5) := 11000;  -- server存在

    procedure list_actionLog(
          --入参，分页参数
          p_isPaging in number, --是否分页，如果不分页则返回全部数据
          p_pageIndex  in number, --页索引
          p_pageSize   in number, --页大小
          p_IsCount    in number,
          p_sortName   in VARCHAR2,
          p_sortOrder  in VARCHAR2,
          
          p_userId in number,
          p_userLevel in number,
          --输出
          p_cursor      out sys_refcursor,
          p_recordCount out number, --非空为错误信息
          --入参，查询参数

          p_username in VARCHAR2,
          p_actionType in number,
          p_startActionTime in varchar2,
          p_endActionTime in varchar2
    );

    procedure list_login_log(
          p_ispaging in number,--非空
          pageindex in number,--非空
          pagesize in number,--非空
          p_iscount in number,
          --搜索条件
          p_dlyh in varchar2,
          login_s_date in varchar2,
          login_e_date in varchar2,

          sortName in varchar2,--非空
          orderItem in varchar2,--非空

          p_userId in number,
          p_userLevel in number,
          
          p_cursor out sys_refcursor,
          p_recordcount out number
    );

    procedure list_dataLog(
           --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            
            p_userId in number,
            p_userLevel in number,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_username in VARCHAR2,
            p_actionType in number,
            p_startActionTime in varchar2,
            p_endActionTime in varchar2
    );



end idc_system_LOG_MANAGE;
/
CREATE package body idc_system_LOG_MANAGE is


       --查询操作日志
       procedure list_actionLog(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            p_userId in number,
            p_userLevel in number,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数

            p_username in VARCHAR2,
            p_actionType in number,
            p_startActionTime in varchar2,
            p_endActionTime in varchar2

         ) is

         --定义
         v_field     varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录

         begin
            
           
            v_field    := ' ACTION_LOG_ID, USERNAME, REALNAME, IP_ADDRESS, MODULE, ACTION_TYPE, ACTION_TIME, DESCRIPTION ';
            v_innersql := ' from ( select ' || v_field ||' from IDC_ISMS_SYSTEM_ACTION_LOG ';
            v_order := ' ORDER BY ' ||  p_sortName || ' ' ||  p_sortOrder;


            --条件语句
            v_condition := ' where 1 = 1 ';
            
            
            if ((p_userLevel is not null) and (p_userId is not null)) then
                case p_userLevel
                when 2 then--省管理员
                     if (p_username is not null) then
                        v_condition := v_condition || ' and USERNAME like ''%' || p_username || '%''';
                    end if;
                    if p_actionType >= 0 then
                       v_condition := v_condition || ' and ACTION_TYPE = ' || p_actionType;
                    end if;
                     if (p_startActionTime is not null) then
                       v_condition := v_condition || ' and ACTION_TIME >= to_date(''' || p_startActionTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
                    end if;
                    if (p_endActionTime is not null) then
                       v_condition := v_condition || ' and ACTION_TIME <= to_date(''' || p_endActionTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
                    end if;
                     v_condition := v_condition || ' and  USER_LEVEL =  ' || p_userLevel|| ' and USER_ID = '||p_userId 
                                 ||' union all ( select ' || v_field ||' from IDC_ISMS_SYSTEM_ACTION_LOG '|| v_condition  
                                 || ' and USER_LEVEL = 3 ) ) ';
                    
                when 3 then--地市管理员
                    if (p_username is not null) then
                        v_condition := v_condition || ' and USERNAME like ''%' || p_username || '%''';
                    end if;
                    if p_actionType >= 0 then
                       v_condition := v_condition || ' and ACTION_TYPE = ' || p_actionType;
                    end if;
                     if (p_startActionTime is not null) then
                       v_condition := v_condition || ' and ACTION_TIME >= to_date(''' || p_startActionTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
                    end if;
                    if (p_endActionTime is not null) then
                       v_condition := v_condition || ' and ACTION_TIME <= to_date(''' || p_endActionTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
                    end if;
                    v_condition := v_condition || ' and USER_LEVEL =  ' || p_userLevel|| ' and USER_ID = '|| p_userId  || ')';
                when 4 then --县级管理员
                     if (p_username is not null) then
                        v_condition := v_condition || ' and USERNAME like ''%' || p_username || '%''';
                    end if;
                    if p_actionType >= 0 then
                       v_condition := v_condition || ' and ACTION_TYPE = ' || p_actionType;
                    end if;
                     if (p_startActionTime is not null) then
                       v_condition := v_condition || ' and ACTION_TIME >= to_date(''' || p_startActionTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
                    end if;
                    if (p_endActionTime is not null) then
                       v_condition := v_condition || ' and ACTION_TIME <= to_date(''' || p_endActionTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
                    end if;
                     v_condition := v_condition || ' and USER_LEVEL =  ' || p_userLevel|| ' and USER_ID = '|| p_userId  ||')';
                else v_condition := v_condition || ')';
                 
                 end case;
            end if;
            
            
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
      end;

    --查询登录日志
    procedure list_login_log(
            p_ispaging in number,--非空
            pageindex in number,--非空
            pagesize in number,--非空
            p_iscount in number,
            --搜索条件
            p_dlyh in varchar2,
            login_s_date in varchar2,
            login_e_date in varchar2,

            sortName in varchar2,--非空
            orderItem in varchar2,--非空

            p_userId in number,
            p_userLevel in number,
            p_cursor out sys_refcursor,
            p_recordcount out number
        )is
            --定义
            v_field     varchar2(2000); --字段
            v_innersql  varchar2(2000); --内部语句，完整的查询sql
            v_order     varchar2(500); --内部排序语句
            v_condition varchar2(2000); --条件语句
            v_count     varchar2(2000); --统计记录总数语句
            v_sql       varchar2(2000); --查询语句
            v_s         number(10); --开始记录
            v_e         number(10); --结束记录
          begin

            p_recordcount := 0;
            --内部sql语句
            --v_innersql := ' from idc_isms_system_login_log ';
            v_field   := ' logid,dlyh,dlyhxm,dlsj,dlip,hostname,czlx ';
            v_innersql := ' from ( select ' || v_field ||' from idc_isms_system_login_log ';
            

            --条件语句
            v_condition :='where 1=1';
            
            if ((p_userLevel is not null) and (p_userId is not null)) then
                case p_userLevel
                when 2 then --省管理员
                    if(p_dlyh is not null ) then
                            v_condition := v_condition || '  and dlyh ='''|| p_dlyh || '''';
                    end if;

                    if(login_s_date is not null) then
                        v_condition := v_condition || ' and dlsj >= to_date(''' || login_s_date || ''',''yyyy-mm-dd hh24:mi:ss'') ';
                    end if;

                    if(login_e_date is not null) then
                        v_condition := v_condition || ' and dlsj <= to_date(''' || login_e_date || ''',''yyyy-mm-dd hh24:mi:ss'') ';
                    end if;
                    v_condition := v_condition || ' and  USER_LEVEL =  ' || p_userLevel|| ' and USER_ID = '||p_userId 
                                 ||' union all ( select ' || v_field ||' from idc_isms_system_login_log '|| v_condition  
                                 || ' and USER_LEVEL = 3 ) ) ';
                when 3 then--地市管理员
                     if(p_dlyh is not null ) then
                            v_condition := v_condition || '  and dlyh ='''|| p_dlyh || '''';
                    end if;

                    if(login_s_date is not null) then
                        v_condition := v_condition || ' and dlsj >= to_date(''' || login_s_date || ''',''yyyy-mm-dd hh24:mi:ss'') ';
                    end if;

                    if(login_e_date is not null) then
                        v_condition := v_condition || ' and dlsj <= to_date(''' || login_e_date || ''',''yyyy-mm-dd hh24:mi:ss'') ';
                    end if;
                    v_condition := v_condition || ' and USER_LEVEL =  ' || p_userLevel|| ' and USER_ID = '|| p_userId || ')';
                when 4 then --县级管理员
                     if(p_dlyh is not null ) then
                            v_condition := v_condition || '  and dlyh ='''|| p_dlyh || '''';
                    end if;

                    if(login_s_date is not null) then
                        v_condition := v_condition || ' and dlsj >= to_date(''' || login_s_date || ''',''yyyy-mm-dd hh24:mi:ss'') ';
                    end if;

                    if(login_e_date is not null) then
                        v_condition := v_condition || ' and dlsj <= to_date(''' || login_e_date || ''',''yyyy-mm-dd hh24:mi:ss'') ';
                    end if;
                    v_condition := v_condition || ' and USER_LEVEL =  ' || p_userLevel|| ' and USER_ID = '|| p_userId || ')';
                else v_condition := v_condition || ')';
                 end case;
            end if;
           

            v_count := 'select count(1) ' || v_innersql || v_condition;

            execute immediate v_count into p_recordcount;

            if p_iscount=1 then
            v_count := 'select count(1) ' || v_innersql || v_condition;
            execute immediate v_count into p_recordcount;
            end if;

            v_order := ' order by ' || sortName || '  ' || orderItem;

            if p_ispaging = 0 then
              begin
                v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
              end;
            else
              begin
                v_e := pageindex * pagesize;
                v_s := (pageindex - 1) * pagesize + 1;
                v_sql := 'select logid,dlyh,dlyhxm,dlip,dlsj,decode(czlx,1,''登录'',2,''退出'',3,''登录密码错误'',4,''该用户名不存在'') typeName,hostname from (select rownum my_rownum,my_table.* from(';
                v_sql := v_sql || ' select ' || v_field || v_innersql ||
                         v_condition || v_order;
                v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                         ' ) where my_rownum >= ' || v_s;
              end;
            end if;
            open p_cursor for v_sql;
        end;

       --查询数据日志
       procedure list_dataLog(
           --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            p_userId in number,
            p_userLevel in number,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_username in VARCHAR2,
            p_actionType in number,
            p_startActionTime in varchar2,
            p_endActionTime in varchar2

         ) is

         --定义
         v_field     varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录

         begin
            --内部sql语句
            v_field    := ' ID, USERNAME, REALNAME, IP_ADDRESS, MODULE_NAME, ACTION_TYPE, ACTION_TIME, DATA_ID, DESCRIPTION ';
            v_innersql := ' from ( select ' || v_field ||' from IDC_ISMS_SYSTEM_DATA_LOG ';

            if (p_sortName is not null) then
              if (p_sortOrder is not null) then
                v_order := ' ORDER BY ' ||  p_sortName || ' ' ||  p_sortOrder;
              else
                v_order := ' ORDER BY ' ||  p_sortName || ' DESC';
              end if;
            else
              v_order := ' ORDER BY ID DESC';
            end if;

            --条件语句
            v_condition := ' where 1 = 1 ';
            if ((p_userLevel is not null) and (p_userId is not null)) then
                case p_userLevel 
                when 2 then --省管理员
                    if (p_username is not null) then
                        v_condition := v_condition || ' and USERNAME like ''%' || p_username || '%''';
                    end if;
                    if p_actionType >= 0 then
                       v_condition := v_condition || ' and ACTION_TYPE = ' || p_actionType;
                    end if;
                     if (p_startActionTime is not null) then
                       v_condition := v_condition || ' and ACTION_TIME >= to_date(''' || p_startActionTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
                    end if;
                    if (p_endActionTime is not null) then
                       v_condition := v_condition || ' and ACTION_TIME <= to_date(''' || p_endActionTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
                    end if;    
                     v_condition := v_condition || ' and  USER_LEVEL =  ' || p_userLevel|| ' and USER_ID = '||p_userId 
                                 ||' union all ( select ' || v_field ||' from IDC_ISMS_SYSTEM_DATA_LOG '|| v_condition  
                                 || ' and USER_LEVEL = 3 ) ) ';
                when 3 then --地市管理员
                    if (p_username is not null) then
                        v_condition := v_condition || ' and USERNAME like ''%' || p_username || '%''';
                    end if;
                    if p_actionType >= 0 then
                       v_condition := v_condition || ' and ACTION_TYPE = ' || p_actionType;
                    end if;
                     if (p_startActionTime is not null) then
                       v_condition := v_condition || ' and ACTION_TIME >= to_date(''' || p_startActionTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
                    end if;
                    if (p_endActionTime is not null) then
                       v_condition := v_condition || ' and ACTION_TIME <= to_date(''' || p_endActionTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
                    end if; 
                
                    v_condition := v_condition || ' and USER_LEVEL =  ' || p_userLevel|| ' and USER_ID = '|| p_userId || ')';
                when 4 then --县级管理员
                    if (p_username is not null) then
                        v_condition := v_condition || ' and USERNAME like ''%' || p_username || '%''';
                    end if;
                    if p_actionType >= 0 then
                       v_condition := v_condition || ' and ACTION_TYPE = ' || p_actionType;
                    end if;
                     if (p_startActionTime is not null) then
                       v_condition := v_condition || ' and ACTION_TIME >= to_date(''' || p_startActionTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
                    end if;
                    if (p_endActionTime is not null) then
                       v_condition := v_condition || ' and ACTION_TIME <= to_date(''' || p_endActionTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
                    end if; 
                    v_condition := v_condition || ' and USER_LEVEL =  ' || p_userLevel|| ' and USER_ID = '|| p_userId || ')';
                else v_condition := v_condition || ')';
                 end case;
            end if;
            
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
               v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
            else
                begin
                    --只返回分页记录
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
      end;


end idc_system_LOG_MANAGE;
/
