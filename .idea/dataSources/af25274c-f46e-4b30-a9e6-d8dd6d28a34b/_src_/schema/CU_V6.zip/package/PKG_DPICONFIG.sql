CREATE package PKG_DPICONFIG is

 -- ?？????？
SUCC_CODE CONSTANT NUMBER(5) := 0;

-- ？?？？
TYPE C_CURSOR IS REF CURSOR;

-- ？?？？？??？
ERROR_DATABASE CONSTANT NUMBER(5) := 10000;

-- ?？??？??？(11000 -- 11100)
ERROR_SERVER_EXIST NUMBER(5) := 11000;  -- server?？
  -- Author  : ADMINISTRATOR
  -- Created : 2011-5-19 16:01:13
  -- Purpose :

ERROR_SERVER_NOTEXIST NUMBER(5) := 11001;  -- ???？?？??？

ERROR_EXCEPTION EXCEPTION;


  --?？essage Type？?η？估??？
  FUNCTION GetMessageTypeAll
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;

  --?？？SGNO
  FUNCTION GetMessageNoAll
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;

  --？???？?？SGNO
  FUNCTION GetMessageByTypeID
  (
    p_typeid   IN NUMBER,
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;
  --？？ ？???？？？?？？??？？？？？？？?
  FUNCTION GetMessageByTypeID
  (
    in_nTypeId        IN NUMBER,
    in_nSize          IN NUMBER,
    in_vWhere         IN VARCHAR2,--??？Сд
    in_nIsName        IN NUMBER,
    out_cursor        OUT C_CURSOR
  )RETURN INTEGER;

     --？??？?？？SGNO
  FUNCTION GetMessageByName
  (
    p_type    IN NUMBER,
    p_name    IN  VARCHAR2,
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;
  
  FUNCTION AddClogDefine(
    p_code                       IN NUMBER,
    p_modulename                 IN VARCHAR2,
    p_recid1                     IN VARCHAR2,
    p_recid2                     IN VARCHAR2,
    p_tablename                  IN VARCHAR2,
    p_flag                       IN NUMBER,
    p_clogtype                   IN NUMBER,
    p_oper                       IN NUMBER
  )
  RETURN INTEGER;
  
  FUNCTION DeleteClogDefine
  (
    p_code                    IN NUMBER,
    p_oper                    IN NUMBER
  )
  RETURN INTEGER;

    --？？MESSAGE_NO
  FUNCTION AddMessageNo
  (
    p_msgtype   IN NUMBER,
    p_msgname   IN VARCHAR2,
    p_msgno     OUT NUMBER
  )
  RETURN INTEGER;

   --？?？?？?？?？？?？?？??？？??？？？??
  FUNCTION MessageSequenceNoCommon
  (
    p_msgno     IN NUMBER,
    p_operid       IN NUMBER,
    v_seqno     OUT NUMBER
  )
  RETURN INTEGER;



  --MESSAGE_NO?？？?？？??
  FUNCTION MessageSequenceNo
  (
    p_msgtype     IN NUMBER
  )
  RETURN INTEGER;
  --MESSAGE_NO?？？?？？??--5000?？？??？?？？？？
  FUNCTION MessageSequenceNo(
    p_msgtype     IN NUMBER,
    p_seqno       IN NUMBER,
    p_update      IN NUMBER  --0？？1??？
  )RETURN NUMBER;

  --?？D??？?？
  FUNCTION GetPacketTypeAll
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;
  
  FUNCTION DpiSetClogCommon
  (
    p_code         IN NUMBER,
    p_type         IN NUMBER,
    p_red1         IN NUMBER,
    p_red2         IN NUMBER,
    p_operid       IN NUMBER
  )
  RETURN INTEGER;

     -- д？CLOG??？?? ????????
  FUNCTION DpiSetClogCommonSubmit
  (
    p_code         IN NUMBER,
    p_type         IN NUMBER,
    p_red1         IN NUMBER,
    p_red2         IN NUMBER,
    p_operid       IN NUMBER
  )
  RETURN INTEGER;
  
  FUNCTION GetClogDefineList
  (
    p_pageNo                    IN NUMBER,
    p_pageSize                  IN NUMBER,
    p_word                      IN VARCHAR2,
    p_flag                      IN NUMBER,
    p_clogtype                  IN NUMBER,
    p_outcount                  OUT NUMBER,
    p_cursor                    OUT C_CURSOR
  )
  RETURN INTEGER;

end PKG_DPICONFIG;
/
CREATE package body PKG_DPICONFIG is

--获取Message Type字段分配及定义
  FUNCTION GetMessageTypeAll
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER AS

  BEGIN

    OPEN p_cursor FOR
      SELECT * FROM dpi_v1_dict_MessageType;

   RETURN SUCC_CODE;

EXCEPTION
  WHEN OTHERS THEN
       RAISE;
  END;

--获取所有MSGNO
  FUNCTION GetMessageNoAll
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER AS

  BEGIN

    OPEN p_cursor FOR
      SELECT * FROM dpi_v1_cfg_messageno;

   RETURN SUCC_CODE;

EXCEPTION
  WHEN OTHERS THEN
       RAISE;
  END;

  --通过类型获取MSGNO
  FUNCTION GetMessageByTypeID
  (
    p_typeid   IN NUMBER,
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER AS

  BEGIN

    OPEN p_cursor FOR
      SELECT * FROM dpi_v1_cfg_messageno where MESSAGE_TYPE=p_typeid AND opertype<>3;

   RETURN SUCC_CODE;

EXCEPTION
  WHEN OTHERS THEN
      RAISE;
  END;
  --同上 通过策略类型获取对应的策略组 智能分页
  FUNCTION GetMessageByTypeID
  (
    in_nTypeId        IN NUMBER,
    in_nSize          IN NUMBER,
    in_vWhere         IN VARCHAR2,--传入小写
    in_nIsName        IN NUMBER,
    out_cursor        OUT C_CURSOR
  )RETURN INTEGER
  AS
    vWhere varchar2(200):=' message_type='||in_nTypeId;
  BEGIN
    if in_nIsName=1 then
       vWhere:=vWhere||' and Lower(message_name) like ''%'||
               in_vWhere||'%'' and opertype<>3 and rownum<='||in_nSize;
    else
       vWhere:=vWhere||' and message_no like ''%'||
               in_vWhere||'%'' and opertype<>3 and rownum<='||in_nSize;
    end if;

    OPEN out_cursor FOR
      'SELECT * FROM dpi_v1_cfg_messageno
      where'||vWhere;

    RETURN SUCC_CODE;
  END GetMessageByTypeID;

    --通过名称获取MSGNO
  FUNCTION GetMessageByName
  (
    p_type    IN NUMBER,
    p_name    IN  VARCHAR2,
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER AS

  BEGIN

    OPEN p_cursor FOR
      SELECT * FROM dpi_v1_cfg_messageno
      where MESSAGE_TYPE=p_type and MESSAGE_NAME=p_name and OPERTYPE=1;

   RETURN SUCC_CODE;

EXCEPTION
  WHEN OTHERS THEN
      RAISE;
  END;

  --新增MESSAGE_NO
  FUNCTION AddMessageNo
  (
    p_msgtype   IN NUMBER,
    p_msgname   IN VARCHAR2,
    p_msgno     OUT NUMBER
  )
  RETURN INTEGER AS
  v_result number := 1;
  BEGIN
    --SET TRANSACTION READ WRITE;
    select nvl(max(message_no),0)+1 into p_msgno from dpi_v1_cfg_messageno where message_type=p_msgtype;
    --select SEQ_MESSAGE_NO.Nextval into p_msgno from dual;
    insert into dpi_v1_cfg_messageno(Message_No,Message_Type,Message_Name) values(p_msgno,p_msgtype,p_msgname);
    commit;
   return v_result;
EXCEPTION

  WHEN OTHERS THEN
       ROLLBACK;
       v_result := 0;
       RAISE;

  END;

 --针对通用参数配置的更新（三项共用一项）
  FUNCTION MessageSequenceNoCommon
  (
    p_msgno     IN NUMBER,
    p_operid       IN NUMBER,
    v_seqno     OUT NUMBER
  )
  RETURN INTEGER AS
  v_msgtype NUMBER;
  BEGIN

    v_msgtype:=0;
    select Message_SequenceNo into v_seqno from dpi_v1_dict_messagetype where MESSAGE_TYPE=v_msgtype;

    v_seqno:=v_seqno+1;
    update dpi_v1_dict_messagetype set Message_SequenceNo=v_seqno where MESSAGE_TYPE=v_msgtype;

    dpi_setclog(20000,1,p_msgno,v_seqno,p_operid);

    RETURN SUCC_CODE;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
       RAISE;
  END;


  --MESSAGE_NO的操作自增长（增加后）
  FUNCTION MessageSequenceNo
  (
    p_msgtype     IN NUMBER
  )
  RETURN INTEGER AS
  v_seqno NUMBER;
  v_num   NUMBER;
  BEGIN

    select count(1) into v_num from dpi_v1_dict_messagetype where MESSAGE_TYPE=p_msgtype;
    if v_num=0 then
       RAISE ERROR_EXCEPTION;
    end if;

    select Message_SequenceNo into v_seqno from dpi_v1_dict_messagetype where MESSAGE_TYPE=p_msgtype;
    v_seqno:=v_seqno+1;    
    update dpi_v1_dict_messagetype set Message_SequenceNo=v_seqno where MESSAGE_TYPE=p_msgtype;
    --p_seqno:=v_seqno;
    commit;
    RETURN v_seqno;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
        RAISE;
  END;

  --MESSAGE_NO的操作自增长--5000规则全部完成后，修改
  FUNCTION MessageSequenceNo(
    p_msgtype     IN NUMBER,
    p_seqno       IN NUMBER,
    p_update      IN NUMBER  --0取值1更新
  )RETURN NUMBER
  AS
     v_seqno NUMBER;
     v_num   NUMBER;
  BEGIN
    select count(1) into v_num from dpi_v1_dict_messagetype where MESSAGE_TYPE=p_msgtype;
    if v_num=0 then
       RAISE ERROR_EXCEPTION;
    end if;

    select Message_SequenceNo into v_seqno
    from dpi_v1_dict_messagetype
    where MESSAGE_TYPE=p_msgtype;

    if p_update =1 then
       update dpi_v1_dict_messagetype
       set Message_SequenceNo=p_seqno
       where MESSAGE_TYPE=p_msgtype;
    end if;

    return v_seqno;--返回值无用

  END MessageSequenceNo;

--获取UD报文类型
  FUNCTION GetPacketTypeAll
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER AS

  BEGIN

    OPEN p_cursor FOR
      SELECT * FROM dpi_v1_dict_packettype;

   RETURN SUCC_CODE;

EXCEPTION
  WHEN OTHERS THEN
        RAISE;
  END;





    -- 写入CLOG 不提交 用于程序事务
  FUNCTION DpiSetClogCommon
  (
    p_code         IN NUMBER,
    p_type         IN NUMBER,
    p_red1         IN NUMBER,
    p_red2         IN NUMBER,
    p_operid       IN NUMBER
  )
  RETURN INTEGER AS
  BEGIN

        dpi_setclog(p_code,p_type,p_red1,p_red2,p_operid); --循环结束才写CLOG

    RETURN SUCC_CODE;

EXCEPTION
  WHEN OTHERS THEN
  ROLLBACK;
  RAISE;
  END;

     -- 写入CLOG并提交 公共方法
  FUNCTION DpiSetClogCommonSubmit
  (
    p_code         IN NUMBER,
    p_type         IN NUMBER,
    p_red1         IN NUMBER,
    p_red2         IN NUMBER,
    p_operid       IN NUMBER
  )
  RETURN INTEGER AS
  BEGIN

        dpi_setclog(p_code,p_type,p_red1,p_red2,p_operid); --循环结束才写CLOG
        commit;
    RETURN SUCC_CODE;

EXCEPTION
  WHEN OTHERS THEN
  ROLLBACK;
  RAISE;
  END;


  --获取CLOG定义列表
  FUNCTION GetClogDefineList
  (
    p_pageNo                    IN NUMBER,
    p_pageSize                  IN NUMBER,
    p_word                      IN VARCHAR2,
    p_flag                      IN NUMBER,
    p_clogtype                  IN NUMBER,
    p_outcount                  OUT NUMBER,
    p_cursor                    OUT C_CURSOR
  )
  RETURN INTEGER AS
  nBegin INTEGER;
  nEnd   INTEGER;
  p_where VARCHAR2(1000);
  BEGIN

    nBegin := (p_pageNo - 1) * p_pageSize + 1;
    nEnd   := p_pageNo * p_pageSize;
    p_where:=' WHERE 1=1  ';

     if length(p_word)>0 then
       p_where:= p_where ||'and ( lower(op_modulename) like''%'|| p_word || '%'' or
                                  lower(recid1_name) like''%'|| p_word || '%'' or
                                  lower(recid2_name) like''%'|| p_word || '%'' or
                                  lower(table_name) like''%'|| p_word || '%'' )';
    end if;

     if p_flag<>-1 then
       p_where:= p_where || 'and flag='|| p_flag;
    end if;

     if p_clogtype<>-1 then
       p_where:= p_where || 'and clogtype='|| p_clogtype;
    end if;

    EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM  dic_clog_define  t1  ' || p_where INTO p_outcount;

     OPEN p_cursor FOR
      'SELECT *  FROM (
                   select rownum as rn, a.* from dic_clog_define a '|| p_where||' order by a.op_code desc
                  )  where RN <=  '|| nEnd || 'and RN  >='|| nBegin;

   RETURN SUCC_CODE;

EXCEPTION
  WHEN OTHERS THEN
    RAISE;
  END;


  --添加 CLOG定义
  FUNCTION AddClogDefine(
    p_code                       IN NUMBER,
    p_modulename                 IN VARCHAR2,
    p_recid1                     IN VARCHAR2,
    p_recid2                     IN VARCHAR2,
    p_tablename                  IN VARCHAR2,
    p_flag                       IN NUMBER,
    p_clogtype                   IN NUMBER,
    p_oper                       IN NUMBER
  )
  RETURN INTEGER AS
  v_msgnew VARCHAR2(5000);
  BEGIN

      insert into dic_clog_define (OP_CODE,OP_MODULENAME,RECID1_NAME,RECID2_NAME,TABLE_NAME,FLAG,CREATE_TIME,CLOGTYPE)
      values(p_code,p_modulename,p_recid1,p_recid2,p_tablename,p_flag,sysdate,p_clogtype);

     v_msgnew:=getRow('dic_clog_define','OP_CODE',p_code);--添加日志
     dpi_setuserlog(20037,1,p_code,v_msgnew,'',p_oper);

    RETURN SUCC_CODE;

EXCEPTION
  WHEN OTHERS THEN
  ROLLBACK;
   RAISE;
  END;

   --删除 CLOG定义
  FUNCTION DeleteClogDefine
  (
    p_code                    IN NUMBER,
    p_oper                    IN NUMBER
  )
  RETURN INTEGER AS
  v_msgold VARCHAR2(5000);
  BEGIN

      v_msgold:=getRow('dic_clog_define','OP_CODE',p_code);

      delete dic_clog_define where OP_CODE=p_code;

      dpi_setuserlog(20037,3,p_code,'',v_msgold,p_oper);

    RETURN SUCC_CODE;

EXCEPTION
  WHEN OTHERS THEN
  ROLLBACK;
   RAISE;
  END;

end PKG_DPICONFIG;
/
