CREATE package IDC_ISMS_AUTO_MONITOR_MANAGE is

        --过滤异常ip或域名
       /*procedure autoDealMonitorPolicy(
                 p_error_id in number,
                 p_deal_username in varchar2
       );*/

       --处置异常IP
       procedure dealErrorIP(
                 p_error_id in number,
                 p_deal_username in varchar2
       );

       procedure dealErrorIPForRedis(
                 p_key in varchar2,
                 p_deal_username in varchar2
       );

        --处置违法违规网站
        procedure dealErrorDomain(
                 p_error_id in number,
                 p_deal_username in varchar2
        );

         --处置违法违规网站
        procedure dealErrorDomainForRedis(
                 p_key in varchar2,
                 p_deal_username in varchar2
        );

       --保存策略
       procedure saveMonitorPolicy(
                 p_command_type in number,
                 p_action_block in number,
                 p_action_log in number,
                 p_actionReport in number,
                 p_effecttime in varchar2,
                 p_expiredtime in varchar2,
                 p_house_id in number,
                 p_deal_username in varchar2,
                 p_policy_level in number,
                 --出参
                 p_out_success out number,
                 p_out_cmdid out number

       );

       --保存策略
       procedure saveMonitorPolicyForRedis(
                 p_command_type in number,
                 p_action_block in number,
                 p_action_log in number,
                 p_actionReport in number,
                 p_effecttime in varchar2,
                 p_expiredtime in varchar2,
                 p_houseIdStr in varchar2,
                 p_deal_username in varchar2,
                 p_policy_level in number,
                 --出参
                 p_out_success out number,
                 p_out_cmdid out number

       );

       --处理信息安全管理指令规则表
       procedure AddIdcmngRule(
                 p_subType in number,
                 p_valueStart in varchar2,
                 p_valueEnd in varchar2,
                 p_keyRange in varchar2,
                 p_monitor_cmdId in number,

                 --出参
                 v_out_success out number
       );

       --复制违法违规网站信息并更新当前信息
       procedure updateErrorDomain(
                 p_err_id in number,
                 p_deal_username in varchar2
                 --p_tableName in varchar2
       );

       --复制异常IP信息并更新当前信息
       procedure updateErrorIP(
                 p_err_id in number,
                 p_deal_username in varchar2
                 --p_tableName in varchar2
       );

       --自动处置异常IP和违法违规网站
       procedure autoDealErrorIPAndErrorDomain(
                 p_thresholdValue in number, --阀值
                 --p_errorIPCur out sys_refcursor,
                 --p_errorDomainCur out sys_refcursor,
                 p_errorIPCount out number,
                 p_errorDomainCount out number,
                 p_successFlag out number
       );

end IDC_ISMS_AUTO_MONITOR_MANAGE;
/
CREATE package body IDC_ISMS_AUTO_MONITOR_MANAGE is

        --过滤异常ip或域名
        /*procedure autoDealMonitorPolicy(
                 p_error_id in number,
                 p_deal_username in varchar2
        )as
                 v_ip number;
                 v_domain varchar2(128);
                 v_houser_id number;
                 v_effecttime date;
                 v_expiredtime date;
                 v_sql varchar2(256);
                 v_error_info_cur sys_refcursor;
                 v_illegal_type number;
                 v_reg_error number;
                 v_out_policy_success number;
                 v_out_rule_del_success number;
                 v_out_rule_add_domain_success number;
                 v_out_rule_add_ip_success number;
                 v_out_cmdid number;
        BEGIN
             begin
                 v_sql := 'select HOUSEID,IP,DOMAIN,ILLEGAL_TYPE,REG_ERROR from idc_isms_monitor_error_info where CURRENT_STATE=0';
                 select sysdate,sysdate + interval '7' day into v_effecttime,v_expiredtime from dual;
                 if p_error_id != 0 then
                    v_sql := v_sql || ' and ERRORID=' || p_error_id;
                 end if;
                 open v_error_info_cur for v_sql;
                 loop
                      fetch v_error_info_cur into v_houser_id,v_ip,v_domain,v_illegal_type,v_reg_error;
                      exit when v_error_info_cur%notfound;
                      IDC_ISMS_AUTO_MONITOR_MANAGE.saveMonitorPolicy(2,
                                                                     1,
                                                                     1,
                                                                     1,
                                                                     to_char(v_effecttime,'yyyy-mm-dd hh24:mi:ss'),
                                                                     to_char(v_expiredtime,'yyyy-mm-dd hh24:mi:ss'),
                                                                     v_houser_id,
                                                                     v_out_policy_success,
                                                                     v_out_cmdid);

                       if (v_out_policy_success = 1) then
                            if (v_illegal_type != 0 and v_reg_error != 0) then
                               idc_isms_auto_monitor_manage.AddIdcmngRule(1,v_domain,null,null,v_out_cmdid,v_out_rule_add_domain_success);--域名过滤
                               idc_isms_auto_monitor_manage.AddIdcmngRule(5,v_ip,v_ip,null,v_out_cmdid,v_out_rule_add_ip_success);--ip过滤
                               if (v_out_rule_add_domain_success = 1 and v_out_rule_add_ip_success = 1) then
                                  idc_isms_auto_monitor_manage.updateMonitorErrorInfo(p_error_id,p_deal_username);
                               end if;
                            end if;
                            if (v_illegal_type != 0 and v_reg_error = 0) then
                               idc_isms_auto_monitor_manage.AddIdcmngRule(1,v_domain,null,null,v_out_cmdid,v_out_rule_add_domain_success);--域名过滤
                               if v_out_rule_add_domain_success = 1 then
                                  idc_isms_auto_monitor_manage.updateMonitorErrorInfo(p_error_id,p_deal_username);
                               end if;
                            end if;
                            if (v_illegal_type = 0 and v_reg_error != 0) then
                               idc_isms_auto_monitor_manage.AddIdcmngRule(5,v_ip,v_ip,null,v_out_cmdid,v_out_rule_add_ip_success);--ip过滤
                               if v_out_rule_add_ip_success = 1 then
                                  idc_isms_auto_monitor_manage.updateMonitorErrorInfo(p_error_id,p_deal_username);
                               end if;
                            end if;
                       end if;
                  end loop;
             end;
        END;*/

        --处置异常IP
        procedure dealErrorIP(
                 p_error_id in number,
                 p_deal_username in varchar2
        )as
                 v_ip varchar2(128);
                 v_houser_id number;
                 v_reg_error number;
                 v_effecttime date;
                 v_expiredtime date;
                 v_sql varchar2(256);
                 v_errorIPCur sys_refcursor;
                 v_out_policy_success number;
                 v_out_rule_add_ip_success number;
                 v_out_cmdid number;
        BEGIN
             begin
                 v_sql := 'select HOUSEID,IP,REG_ERROR from IDC_ISMS_MONITOR_ERROR_INFO where CURRENT_STATE = 0 ';
                 select sysdate,sysdate + interval '7' day into v_effecttime,v_expiredtime from dual;
                 if p_error_id > 0 then
                    v_sql := v_sql || ' and ERROR_ID = ' || p_error_id;
                 end if;
                 open v_errorIPCur for v_sql;
                 loop
                      fetch v_errorIPCur into v_houser_id,v_ip,v_reg_error;
                      exit when v_errorIPCur%notfound;
                      IDC_ISMS_AUTO_MONITOR_MANAGE.saveMonitorPolicy(2,
                                                                     1,
                                                                     1,
                                                                     1,
                                                                     to_char(v_effecttime,'yyyy-mm-dd hh24:mi:ss'),
                                                                     to_char(v_expiredtime,'yyyy-mm-dd hh24:mi:ss'),
                                                                     v_houser_id,
                                                                     p_deal_username,
                                                                     2049,
                                                                     v_out_policy_success,
                                                                     v_out_cmdid);

                       if (v_out_policy_success = 1) then
                            if (v_reg_error != 0) then
                               idc_isms_auto_monitor_manage.AddIdcmngRule(5,v_ip,v_ip,null,v_out_cmdid,v_out_rule_add_ip_success);--ip过滤
                               if v_out_rule_add_ip_success = 1 then
                                  idc_isms_auto_monitor_manage.updateErrorIP(p_error_id,p_deal_username);
                               end if;
                            end if;
                       end if;
                  end loop;
                  close v_errorIPCur;
             end;
        END;

        --处置异常IP
        procedure dealErrorIPForRedis(
                 p_key in varchar2,
                 p_deal_username in varchar2
        ) as
                 v_key varchar2(2000);
                 v_index number;
                 v_houseId varchar2(200);
                 v_ip varchar2(128);
                 v_port varchar2(128);
                 v_domain varchar2(256);
                 v_statDate varchar2(10);
                 v_effecttime date;
                 v_expiredtime date;
                 v_out_policy_success number;
                 v_out_rule_add_ip_success number;
                 v_out_cmdid number;
        BEGIN
             begin
                 select p_key into v_key from dual;
                 select instr(v_key, '@') into v_index from dual;
                 select substr(v_key, 0, v_index - 1) into v_houseId from dual;

                 select substr(v_key, v_index + 1, length(v_key)) into v_key from dual;
                 select instr(v_key, '@') into v_index from dual;
                 select substr(v_key, 0, v_index - 1) into v_ip from dual;

                 /*select substr(v_key, v_index + 1, length(v_key)) into v_key from dual;
                 select instr(v_key, '@') into v_index from dual;
                 select substr(v_key, 0, v_index - 1) into v_port from dual;

                 select substr(v_key, v_index + 1, length(v_key)) into v_key from dual;
                 select instr(v_key, '@') into v_index from dual;
                 select substr(v_key, 0, v_index - 1) into v_domain from dual;

                 select substr(v_key, v_index + 1, length(v_key)) into v_key from dual;
                 select v_key into v_statDate from dual;
                 dbms_output.put_line('v_houseId:' || v_houseId || '===v_ip:' || v_ip || '===v_port:' || v_port || '===:v_domain:' || v_domain || '===v_statDate:' || v_statDate);
                 */
                 select sysdate,sysdate + interval '7' day into v_effecttime,v_expiredtime from dual;

                 IDC_ISMS_AUTO_MONITOR_MANAGE.saveMonitorPolicyForRedis( 2,
                                                                 1,
                                                                 1,
                                                                 1,
                                                                 to_char(v_effecttime,'yyyy-mm-dd hh24:mi:ss'),
                                                                 to_char(v_expiredtime,'yyyy-mm-dd hh24:mi:ss'),
                                                                 v_houseId,
                                                                 p_deal_username,
                                                                 2049,
                                                                 v_out_policy_success,
                                                                 v_out_cmdid);
                   if (v_out_policy_success = 1) then
                        idc_isms_auto_monitor_manage.AddIdcmngRule(5,v_ip,v_ip,null,v_out_cmdid,v_out_rule_add_ip_success);--ip过滤
                   end if;
             end;
        END;

         --处置违法违规网站
        procedure dealErrorDomain(
                 p_error_id in number,
                 p_deal_username in varchar2
        )as
                 v_domain varchar2(128);
                 v_houser_id number;
                 v_illegalType number;
                 v_effecttime date;
                 v_expiredtime date;
                 v_sql varchar2(256);
                 v_errorDomainCur sys_refcursor;
                 v_out_policy_success number;
                 v_out_rule_add_domain_success number;
                 v_out_cmdid number;
        BEGIN
             begin
                 v_sql := 'select HOUSEID,DOMAIN,ILLEGAL_TYPE from IDC_ISMS_MONITOR_ERROR_DOMAIN where CURRENT_STATE = 0 ';
                 select sysdate,sysdate + interval '7' day into v_effecttime,v_expiredtime from dual;
                 if p_error_id > 0 then
                    v_sql := v_sql || ' and ERROR_ID = ' || p_error_id;
                 end if;
                 open v_errorDomainCur for v_sql;
                 loop
                      fetch v_errorDomainCur into v_houser_id,v_domain,v_illegalType;
                      exit when v_errorDomainCur%notfound;
                      IDC_ISMS_AUTO_MONITOR_MANAGE.saveMonitorPolicy(2,
                                                                     1,
                                                                     1,
                                                                     1,
                                                                     to_char(v_effecttime,'yyyy-mm-dd hh24:mi:ss'),
                                                                     to_char(v_expiredtime,'yyyy-mm-dd hh24:mi:ss'),
                                                                     v_houser_id,
                                                                     p_deal_username,
                                                                     2112,
                                                                     v_out_policy_success,
                                                                     v_out_cmdid);
                       if (v_out_policy_success = 1) then
                            if (v_illegalType != 0) then
                               idc_isms_auto_monitor_manage.AddIdcmngRule(1,v_domain,null,null,v_out_cmdid,v_out_rule_add_domain_success);--域名过滤
                               if v_out_rule_add_domain_success = 1 then
                                  idc_isms_auto_monitor_manage.updateErrorDomain(p_error_id,p_deal_username);
                               end if;
                            end if;
                       end if;
                  end loop;
                  close v_errorDomainCur;
             end;
        END;

         --处置违法违规网站
        procedure dealErrorDomainForRedis(
                 p_key in varchar2,
                 p_deal_username in varchar2
        ) as
                 v_key varchar2(2000);
                 v_index number;
                 v_houseId varchar2(200);
                 v_ip varchar2(128);
                 v_port varchar2(128);
                 v_domain varchar2(256);
                 v_statDate varchar2(10);
                 v_effecttime date;
                 v_expiredtime date;
                 v_out_policy_success number;
                 v_out_rule_add_domain_success number;
                 v_out_cmdid number;
        BEGIN
             begin
                 select p_key into v_key from dual;
                 select instr(v_key, '@') into v_index from dual;
                 select substr(v_key, 0, v_index - 1) into v_houseId from dual;

                 select substr(v_key, v_index + 1, length(v_key)) into v_key from dual;
                 select instr(v_key, '@') into v_index from dual;
                 select substr(v_key, 0, v_index - 1) into v_ip from dual;

                 select substr(v_key, v_index + 1, length(v_key)) into v_key from dual;
                 select instr(v_key, '@') into v_index from dual;
                 select substr(v_key, 0, v_index - 1) into v_port from dual;

                 select substr(v_key, v_index + 1, length(v_key)) into v_key from dual;
                 select instr(v_key, '@') into v_index from dual;
                 select substr(v_key, 0, v_index - 1) into v_domain from dual;

                 select substr(v_key, v_index + 1, length(v_key)) into v_key from dual;
                 select v_key into v_statDate from dual;
                 dbms_output.put_line('v_houseId:' || v_houseId || '===v_ip:' || v_ip || '===v_port:' || v_port || '===:v_domain:' || v_domain || '===v_statDate:' || v_statDate);
                 select sysdate,sysdate + interval '7' day into v_effecttime,v_expiredtime from dual;
                 IDC_ISMS_AUTO_MONITOR_MANAGE.saveMonitorPolicyForRedis( 2,
                                                                 1,
                                                                 1,
                                                                 1,
                                                                 to_char(v_effecttime,'yyyy-mm-dd hh24:mi:ss'),
                                                                 to_char(v_expiredtime,'yyyy-mm-dd hh24:mi:ss'),
                                                                 v_houseId,
                                                                 p_deal_username,
                                                                 2112,
                                                                 v_out_policy_success,
                                                                 v_out_cmdid);
                   if (v_out_policy_success = 1) then
                        idc_isms_auto_monitor_manage.AddIdcmngRule(1,v_domain,null,null,v_out_cmdid,v_out_rule_add_domain_success);--域名过滤
                   end if;
             end;
        END;

        --保存策略
        procedure saveMonitorPolicy(
                 p_command_type in number,
                 p_action_block in number,
                 p_action_log in number,
                 p_actionReport in number,
                 p_effecttime in varchar2,
                 p_expiredtime in varchar2,
                 p_house_id in number,
                 p_deal_username in varchar2,
                 p_policy_level in number,
                 --出参
                 p_out_success out number,
                 p_out_cmdid out number

       )as
                 v_commandid number;
                 v_message_no number;
                 v_func_ret  number;
                 v_tmp varchar2(2048);
                 v_int  number(10) :=0;
                 v_houseid varchar2(256);
                 v_bind_mes_no number;
                 v_house_id_str varchar2(256);
                 v_messageName varchar2(256) := '';
                 v_messageNameSuffix varchar2(5);
                 v_curTime varchar2(256);
                 v_result number;
                 v_cur PKG_DPICONFIG.C_CURSOR;
                 v_messageNo number;
                 v_message_type number;
                 v_message_Name varchar2(256);
                 v_oper_type number;

       BEGIN
            begin
                 if (p_command_type = 5) then
                    v_messageName := '免过滤网站列表指令_';
                 elsif (p_command_type = 6) then
                    v_messageName := '违法网站列表指令_';
                 else
                    v_messageName := '基础数据异常处置_';
                 end if;
                 SELECT DBMS_RANDOM.STRING('A',5) into v_messageNameSuffix FROM DUAL;
                 select to_char(current_timestamp(3),'yyyymmddHH24missff') into v_curTime from dual;
                 v_messageName := v_messageName || '_' || v_messageNameSuffix || '_' || v_curTime;
                 v_func_ret:=PKG_DPICONFIG.AddMessageNo(16, v_messageName,v_message_no);
                 v_func_ret:=PKG_IDCCONFIG.AddOrUpdateIDCISMS_Policy(0,
                                                                 v_message_no,
                                                                 p_command_type,
                                                                 p_action_block,
                                                                 p_action_log,
                                                                 date2time_t(to_date(p_effecttime,'yyyy-mm-dd hh24:mi:ss')),
                                                                 date2time_t(to_date(p_expiredtime,'yyyy-mm-dd hh24:mi:ss')),
                                                                 -1,
                                                                 p_deal_username,
                                                                 0,
                                                                 p_policy_level,
                                                                 v_commandid);
                 --dbms_output.put_line('v_commandid:' || v_commandid);
                 p_out_cmdid:=v_commandid;
                 v_curTime := '机房策略绑定' || v_curTime;
                 /*v_result := pkg_dpiconfig.GetMessageByName(133, v_curTime, v_cur);
                 loop
                   fetch v_cur into v_messageNo,v_message_type,v_message_Name,v_oper_type;
                   exit when v_cur%notfound;
                   if (v_message_Name is not null) then
                     RAISE PKG_DPICONFIG.ERROR_EXCEPTION;
                   end if;
                   --raise_application_error(-20100,'策略类型为133，名称为' || v_curTime || '的策略组已存在！');
                 end loop;
                 close v_cur;*/
                 if p_house_id = 0 then
                    v_func_ret:=PKG_DPICONFIG.AddMessageNo(133, v_curTime,v_bind_mes_no);
                    v_func_ret:=PKG_IDCCONFIG.AddOrUpdateHousePolicy(0,v_bind_mes_no,0,null,
                              16,v_message_no,-1);
                 else
                    select houseidstr into v_house_id_str from idc_isms_base_house where houseid=p_house_id;
                    v_func_ret:=PKG_DPICONFIG.AddMessageNo(133, v_curTime,v_bind_mes_no);
                    v_func_ret:=PKG_IDCCONFIG.AddOrUpdateHousePolicy(0,v_bind_mes_no,2,v_house_id_str,16,v_message_no,-1);
                 end if;

                 exception
                   WHEN OTHERS THEN
                        ROLLBACK;
                        p_out_success := 0;
                        RETURN;
            end;
            commit;
            p_out_success := 1;
       END;

       --保存策略
        procedure saveMonitorPolicyForRedis(
                 p_command_type in number,
                 p_action_block in number,
                 p_action_log in number,
                 p_actionReport in number,
                 p_effecttime in varchar2,
                 p_expiredtime in varchar2,
                 p_houseIdStr in varchar2,
                 p_deal_username in varchar2,
                 p_policy_level in number,
                 --出参
                 p_out_success out number,
                 p_out_cmdid out number

       )as
                 v_commandid number;
                 v_message_no number;
                 v_func_ret  number;
                 v_tmp varchar2(2048);
                 v_int  number(10) :=0;
                 v_houseid varchar2(256);
                 v_bind_mes_no number;
                 v_house_id_str varchar2(256);
                 v_messageName varchar2(256) := '基础数据异常处置_';
                 v_messageNameSuffix varchar2(5);
                 v_curTime varchar2(256);
                 v_result number;
                 v_cur PKG_DPICONFIG.C_CURSOR;
                 v_messageNo number;
                 v_message_type number;
                 v_message_Name varchar2(256);
                 v_oper_type number;

       BEGIN
            begin
                 SELECT DBMS_RANDOM.STRING('A',5) into v_messageNameSuffix FROM DUAL;
                 select to_char(current_timestamp(3),'yyyymmddHH24missff') into v_curTime from dual;
                 v_messageName := v_messageName || v_messageNameSuffix || '_' || v_curTime;
                 v_func_ret:=PKG_DPICONFIG.AddMessageNo(16, v_messageName,v_message_no);
                 v_func_ret:=PKG_IDCCONFIG.AddOrUpdateIDCISMS_Policy(0,
                                                                 v_message_no,
                                                                 p_command_type,
                                                                 p_action_block,
                                                                 p_action_log,
                                                                 date2time_t(to_date(p_effecttime,'yyyy-mm-dd hh24:mi:ss')),
                                                                 date2time_t(to_date(p_expiredtime,'yyyy-mm-dd hh24:mi:ss')),
                                                                 -1,
                                                                 p_deal_username,
                                                                 0,
                                                                 p_policy_level,
                                                                 v_commandid);
                 --dbms_output.put_line('v_commandid:' || v_commandid);
                 p_out_cmdid:=v_commandid;
                 v_curTime := '机房策略绑定' || v_curTime;
                 /*v_result := pkg_dpiconfig.GetMessageByName(133, v_curTime, v_cur);
                 loop
                   fetch v_cur into v_messageNo,v_message_type,v_message_Name,v_oper_type;
                   exit when v_cur%notfound;
                   if (v_message_Name is not null) then
                     RAISE PKG_DPICONFIG.ERROR_EXCEPTION;
                   end if;
                   --raise_application_error(-20100,'策略类型为133，名称为' || v_curTime || '的策略组已存在！');
                 end loop;
                 close v_cur;*/
                 /*if p_house_id = 0 then
                    v_func_ret:=PKG_DPICONFIG.AddMessageNo(133, v_curTime,v_bind_mes_no);
                    v_func_ret:=PKG_IDCCONFIG.AddOrUpdateHousePolicy(0,v_bind_mes_no,0,null, 16,v_message_no,-1);
                 else
                    select houseidstr into v_house_id_str from idc_isms_base_house where houseid=p_house_id;
                    v_func_ret:=PKG_DPICONFIG.AddMessageNo(133, v_curTime,v_bind_mes_no);
                    v_func_ret:=PKG_IDCCONFIG.AddOrUpdateHousePolicy(0,v_bind_mes_no,2,v_house_id_str,16,v_message_no,-1);
                 end if;*/
                 v_func_ret:=PKG_DPICONFIG.AddMessageNo(133, v_curTime,v_bind_mes_no);
                 v_func_ret:=PKG_IDCCONFIG.AddOrUpdateHousePolicy(0,v_bind_mes_no,2,p_houseIdStr,16,v_message_no,-1);
                 exception
                   WHEN OTHERS THEN
                        ROLLBACK;
                        p_out_success := 0;
                        RETURN;
            end;
            commit;
            p_out_success := 1;
       END;

        --处理信息安全管理指令规则表
       procedure AddIdcmngRule(
                 p_subType in number,
                 p_valueStart in varchar2,
                 p_valueEnd in varchar2,
                 p_keyRange in varchar2,
                 p_monitor_cmdId in number,

                 --出参
                 v_out_success out number
       )as
       BEGIN
            begin
                 insert into IDC_ISMS_MONITOR_POLICY_RULE(RULEID,COMMANDID,SUBTYPE,VALUESTART,VALUEEND,KEYWORDRANGE)
                    values(seq_idc_isms_policyrule_id.NEXTVAL,p_monitor_cmdId,p_subType,p_valueStart,p_valueEnd,p_keyRange);
               exception
                WHEN OTHERS THEN
                      ROLLBACK;
                      v_out_success := 0;
                      RETURN;
            end;
            commit;
            v_out_success := 1;
       END;

        --复制违法违规网站信息并更新当前信息
        procedure updateErrorDomain(
                 p_err_id in number,
                 p_deal_username in varchar2
                 --p_tableName in varchar2
       )as
                 v_sql varchar2(256);
                 v_errorDomainCur sys_refcursor;
                 v_errorId IDC_ISMS_MONITOR_ERROR_DOMAIN.Error_Id%type;
                 v_houseId IDC_ISMS_MONITOR_ERROR_DOMAIN.HOUSEID%type;
                 v_domain IDC_ISMS_MONITOR_ERROR_DOMAIN.Domain%type;
                 v_serviceType IDC_ISMS_MONITOR_ERROR_DOMAIN.Servicetype%type;
                 v_lastFound IDC_ISMS_MONITOR_ERROR_DOMAIN.Last_Found%type;
                 v_illegalType IDC_ISMS_MONITOR_ERROR_DOMAIN.Illegal_Type%type;
                 v_dealFlag IDC_ISMS_MONITOR_ERROR_DOMAIN.Deal_Flag%type;
                 v_ip IDC_ISMS_MONITOR_ERROR_DOMAIN.Ip%type;
                 v_port IDC_ISMS_MONITOR_ERROR_DOMAIN.Port%type;
                 v_protocol IDC_ISMS_MONITOR_ERROR_DOMAIN.Protocol%type;
                 v_isBlock IDC_ISMS_MONITOR_ERROR_DOMAIN.Isblock%type;

       BEGIN
            begin
                 v_sql := 'select ERROR_ID,HOUSEID,DOMAIN,SERVICETYPE,LAST_FOUND,ILLEGAL_TYPE,DEAL_FLAG,IP,PORT,PROTOCOL,ISBLOCK from IDC_ISMS_MONITOR_ERROR_DOMAIN where 1=1 ';--where STATISTIC_FLAG = 0 ';
                 if p_err_id > 0 then
                    v_sql := v_sql || ' and ERROR_ID = ' || p_err_id;
                 end if;
                 open v_errorDomainCur for v_sql;
                 loop
                   fetch v_errorDomainCur into v_errorId,v_houseId,v_domain,v_serviceType,v_lastFound,v_illegalType,v_dealFlag,v_ip,v_port,v_protocol,v_isBlock;
                   exit when v_errorDomainCur%notfound;
                   --复制记录
                   /*insert into IDC_ISMS_MONITOR_ERROR_DOMAIN(ERROR_ID,HOUSEID,DOMAIN,SERVICETYPE,FIRST_FOUND,LAST_FOUND,VISIT_COUNT,
                          ILLEGAL_TYPE,CURRENT_STATE,DEAL_USER,DEAL_TIME,DEAL_FLAG,IP,PORT,PROTOCOL,ISBLOCK,STATISTIC_FLAG
                         )
                   values(SEQ_MONITOR_DOMAIN_ERROR_ID.nextval,v_houseId,v_domain,v_serviceType,v_lastFound,v_lastFound,0,v_illegalType,
                          1,p_deal_username,sysdate,v_dealFlag,v_ip,v_port,v_protocol,1,1
                          ); */
                   --更新原有记录（统计状态设置为1)
                   --update IDC_ISMS_MONITOR_ERROR_DOMAIN set STATISTIC_FLAG = 1 where ERROR_ID = v_errorId;
                   update IDC_ISMS_MONITOR_ERROR_DOMAIN t set STATISTIC_FLAG = 1, CURRENT_STATE = 1, DEAL_USER = p_deal_username, DEAL_TIME = sysdate
                   where t.domain = v_domain;
                 end loop;
                 close v_errorDomainCur;
                 exception
                   WHEN OTHERS THEN
                     ROLLBACK;
                     RETURN;
            end;
            commit;
       END;

        --复制异常IP信息并更新当前信息
        procedure updateErrorIP(
                 p_err_id in number,
                 p_deal_username in varchar2
                 --p_tableName in varchar2
       )as
                 v_sql varchar2(256);
                 v_errorIPCur sys_refcursor;
                 v_errorId IDC_ISMS_MONITOR_ERROR_INFO.ERROR_ID%type;
                 v_houseId IDC_ISMS_MONITOR_ERROR_INFO.HOUSEID%type;
                 v_ip IDC_ISMS_MONITOR_ERROR_INFO.IP%type;
                 v_port IDC_ISMS_MONITOR_ERROR_INFO.PORT%type;
                 v_domain IDC_ISMS_MONITOR_ERROR_INFO.DOMAIN%type;
                 v_serviceType IDC_ISMS_MONITOR_ERROR_INFO.SERVICETYPE%type;
                 v_lastfound IDC_ISMS_MONITOR_ERROR_INFO.LAST_FOUND%type;
                 v_illegalType IDC_ISMS_MONITOR_ERROR_INFO.ILLEGAL_TYPE%type;
                 v_regError IDC_ISMS_MONITOR_ERROR_INFO.REG_ERROR%type;
                 v_regDomain IDC_ISMS_MONITOR_ERROR_INFO.REG_DOMAIN%type;
                 v_dealFlag IDC_ISMS_MONITOR_ERROR_INFO.DEAL_FLAG%type;
                 v_regIpUseWay IDC_ISMS_MONITOR_ERROR_INFO.REG_IP_USE_WAY%type;
                 v_ipUseWay IDC_ISMS_MONITOR_ERROR_INFO.IP_USE_WAY%type;
                 v_protocol IDC_ISMS_MONITOR_ERROR_INFO.PROTOCOL%type;

       BEGIN
            begin
                 v_sql := 'select ERROR_ID,HOUSEID,IP,PORT,DOMAIN,SERVICETYPE,LAST_FOUND,ILLEGAL_TYPE,REG_ERROR,REG_DOMAIN,DEAL_FLAG,REG_IP_USE_WAY,IP_USE_WAY,PROTOCOL from IDC_ISMS_MONITOR_ERROR_INFO where 1=1 ';--where STATISTIC_FLAG = 0 ';
                 if p_err_id > 0 then
                    v_sql := v_sql || ' and ERROR_ID = ' || p_err_id;
                 end if;
                 open v_errorIPCur for v_sql;
                 loop
                   fetch v_errorIPCur into v_errorId,v_houseId,v_ip,v_port,v_domain,v_serviceType,v_lastfound,v_illegalType,v_regError,v_regDomain,v_dealFlag,v_regIpUseWay,v_ipUseWay,v_protocol;
                   exit when v_errorIPCur%notfound;
                   --复制记录
                   /*insert into IDC_ISMS_MONITOR_ERROR_INFO(ERROR_ID,HOUSEID,IP,PORT,DOMAIN,SERVICETYPE,FIRST_FOUND,LAST_FOUND,
                               ILLEGAL_TYPE,CURRENT_STATE,DEAL_USER,DEAL_TIME,REG_ERROR,REG_DOMAIN,DEAL_FLAG,REG_IP_USE_WAY,
                               IP_USE_WAY,VISIT_COUNT,PROTOCOL,STATISTIC_FLAG)
                   values(SEQ_MONITOR_IP_ERROR_ID.nextval,v_houseId,v_ip,v_port,v_domain,v_serviceType,v_lastfound,v_lastfound,v_illegalType,
                               1,p_deal_username,sysdate,v_regError,v_regDomain,v_dealFlag,v_regIpUseWay,v_ipUseWay,0,v_protocol,1
                          ); */
                   --更新原有记录（统计状态设置为1)
                   --update IDC_ISMS_MONITOR_ERROR_INFO set STATISTIC_FLAG = 1 where ERROR_ID = v_errorId;
                   update IDC_ISMS_MONITOR_ERROR_INFO t set CURRENT_STATE = 1,DEAL_USER = p_deal_username,DEAL_TIME = sysdate
                   where t.ip = v_ip;
                 end loop;
                 close v_errorIPCur;
                 exception
                   WHEN OTHERS THEN
                     ROLLBACK;
                     RETURN;
            end;
            commit;
       END;

        procedure autoDealErrorIPAndErrorDomain(
                 p_thresholdValue in number, --阀值
                 --p_errorIPCur out sys_refcursor,
                 --p_errorDomainCur out sys_refcursor,
                 p_errorIPCount out number,
                 p_errorDomainCount out number,
                 p_successFlag out number
       )as
                 v_errorIPSql varchar2(2000);
                 v_errorDomainSql varchar2(2000);
       BEGIN
         begin
           /*v_errorIPSql := 'select a.error_id,a.houseId,a.reg_error,a.current_state,a.deal_flag,a.ip,a.port,a.visit_count,a.first_found,a.last_found,a.deal_user,a.deal_time,a.reg_domain,a.domain,reg_ip_use_way,ip_use_way,a.create_time,b.housename,a.statistic_flag
                            from idc_isms_monitor_error_info a
                            left join IDC_ISMS_BASE_HOUSE b on a.houseid = b.houseid
                            where rownum < 11 and a.CURRENT_STATE = 0 and a.STATISTIC_FLAG = 0 and a.VISIT_COUNT > ' || p_thresholdValue;
           v_errorDomainSql := 'select a.error_id,a.houseId,a.ILLEGAL_TYPE,a.current_state,a.deal_flag,a.SERVICETYPE,a.VISIT_COUNT,a.DOMAIN,a.ip,a.port,a.first_found,a.last_found,a.deal_user,a.deal_time,a.create_time,b.housename,a.statistic_flag
                                from IDC_ISMS_MONITOR_ERROR_DOMAIN a
                                left join IDC_ISMS_BASE_HOUSE b on a.houseid = b.houseid
                                where rownum < 11 and a.CURRENT_STATE = 0 and a.STATISTIC_FLAG = 0 and a.VISIT_COUNT > ' || p_thresholdValue;
           open p_errorIPCur for v_errorIPSql;
           open p_errorDomainCur for v_errorDomainSql;*/
           --select count(1) into p_errorIPCount from idc_isms_monitor_error_info where CURRENT_STATE = 0 and STATISTIC_FLAG = 0 and VISIT_COUNT > p_thresholdValue;
           --select count(1) into p_errorDomainCount from IDC_ISMS_MONITOR_ERROR_DOMAIN where CURRENT_STATE = 0 and STATISTIC_FLAG = 0 and VISIT_COUNT > p_thresholdValue;
           select count(1) into p_errorIPCount from idc_isms_monitor_error_info where CURRENT_STATE = 0 and VISIT_COUNT > p_thresholdValue;
           select count(1) into p_errorDomainCount from IDC_ISMS_MONITOR_ERROR_DOMAIN where CURRENT_STATE = 0 and VISIT_COUNT > p_thresholdValue;
           for errorIPCur in (select ERROR_ID from IDC_ISMS_MONITOR_ERROR_INFO where CURRENT_STATE = 0 and VISIT_COUNT > p_thresholdValue)
           loop
             idc_isms_auto_monitor_manage.dealErrorIP(errorIPCur.ERROR_ID, 'ISMS');
           end loop;
           for errorDomainCur in (select ERROR_ID from IDC_ISMS_MONITOR_ERROR_DOMAIN where CURRENT_STATE = 0 and VISIT_COUNT > p_thresholdValue)
           loop
             idc_isms_auto_monitor_manage.dealErrorDomain(errorDomainCur.ERROR_ID, 'ISMS');
           end loop;
           exception
           WHEN OTHERS THEN
                ROLLBACK;
                p_successFlag := 0;
                RETURN;
          end;
          p_successFlag := 1;
       END;

end IDC_ISMS_AUTO_MONITOR_MANAGE;
/
