CREATE VIEW IDC_ISMS_LOG_STATIS_ORG_TREE_N AS SELECT B.HOUSE_ID AS PID, '' || B.HOUSE_ID || S.R_DESTIP AS ID, S.R_DESTIP AS NAME, 'server' as type
FROM (
  SELECT * FROM IDC_ISMS_CFG_HOUSEPOLICYBIND WHERE MESSAGE_TYPE = '11' AND OPERATETYPE <> '3' AND HOUSE_ID IS NOT NULL
) B
JOIN IDC_ISMS_CFG_FLOWUPLOAD F ON B.BINDMESSAGENO = F.MESSAGE_NO
JOIN IDC_ISMS_CFG_FLOWUPLOAD_SERVER S ON F.SEQ_ID = S.SEQ_ID
JOIN IDC_ISMS_BASE_HOUSE H ON H.HOUSEIDSTR = B.HOUSE_ID

UNION

SELECT software_provider AS PID, '' || B.HOUSE_ID AS ID, H.HOUSENAME AS NAME, 'house' as type
FROM (
  SELECT * FROM IDC_ISMS_CFG_HOUSEPOLICYBIND WHERE MESSAGE_TYPE = '11' AND OPERATETYPE <> '3' AND HOUSE_ID IS NOT NULL
) B
JOIN IDC_ISMS_CFG_FLOWUPLOAD F ON B.BINDMESSAGENO = F.MESSAGE_NO
JOIN IDC_ISMS_BASE_HOUSE H ON H.HOUSEIDSTR = B.HOUSE_ID
join (select st1.area_id,st1.software_provider,st2.software_provider_name from (
select area_id,software_provider from dpi_v1_cfg_dpiserver
where probe_type=1 group by area_id,software_provider ) st1
left join dic_software_provider st2 on st1.software_provider=st2.software_provider) J on J.area_id=B.HOUSE_ID

UNION

SELECT  'province' AS PID,'' || B.software_provider AS ID, software_provider_name AS NAME, 'product' as type FROM (
select st1.area_id,st1.software_provider,st2.software_provider_name from (
select area_id,software_provider from dpi_v1_cfg_dpiserver
where probe_type=1 group by area_id,software_provider ) st1
left join dic_software_provider st2 on st1.software_provider=st2.software_provider
) B

UNION
SELECT 'root' AS PID, 'province' AS ID, '全省' AS NAME, 'province' as type
FROM DUAL
/
