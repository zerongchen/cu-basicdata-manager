CREATE VIEW IDC_ISMS_MONITOR_POLICY_VIEW AS select
  --(select t2.house_id from idc_isms_cfg_housepolicybind t2 where t2.operatetype != 3 and t2.bindmessageno = t_2.message_no) houseidstr,
  t_3.house_id houseidstr,
  t_1.subtype subtype,
  t_1.valuestart valuestart,
  t_1.valueend valueend,
  t_1.valuestartstr valuestartstr,
  t_1.valueendstr valueendstr,
  t_2.smms_cmdid smms_cmdid,
  --(select t2.create_time from idc_isms_cfg_housepolicybind t2 where t2.operatetype != 3 and t2.bindmessageno = t_2.message_no) create_time,
  t_3.create_time create_time,
  t_2.action_block action_block,
  t_2.create_username username
from idc_isms_monitor_policy_rule t_1
join (select * from idc_isms_monitor_policy t1 where t1.command_type = 2 and t1.operatetype != 3 and t1.expiredtime >= date2time_t(sysdate)) t_2 on t_1.commandid = t_2.commandid
join (select * from idc_isms_cfg_housepolicybind t where operatetype != 3) t_3 on t_3.bindmessageno = t_2.message_no
/
