CREATE FUNCTION idc_getidcname
(
  p_jyzid IN number
)
RETURN varchar2 IS
   v_ret Varchar2(256);
BEGIN
 begin
   select idcname into v_ret from idc_isms_base_idc where jyzid=p_jyzid;
  exception when others then
    return null;
  end;
  return v_ret;
END;
/
