CREATE function con_areaCode(var_str1 in varchar2, var_str2 in varchar2) return varchar2 is
  var_result varchar2(4000);
   var_tmp1     varchar2(4000);
   var_tmp2     varchar2(4000);
   var_element varchar2(1000);
begin
  var_tmp1 := var_str1;
  var_tmp2 := var_str2;
  var_result :='';

  while instr(var_tmp1, ',') > 0 loop
        var_element := substr(var_tmp1, 1, instr(var_tmp1, ',') - 1);
        var_tmp1    := substr(var_tmp1, instr(var_tmp1, ',') + length(','), length(var_tmp1));
        if instr(var_tmp2,var_element) > 0 then
           var_result := var_result||','||var_element;
        end if;
  end loop;
  --如果不存在匹配的分割符
  if(instr(var_tmp1, ',') = 0) then
    if(instr(var_tmp2, var_tmp1) >0 ) then
      var_result := '';
    end if;
  end if;
  return(var_result);
end con_areaCode;
/
