CREATE procedure CMD_ALARM_CMDACK_PROCESS(in_commandid IN NUMBER) is
       v_ack_status     varchar2(20) := 'ACK未上报'; -- 初始化为0:未处理
       v_deal_flag NUMBER;
       v_alarmId NUMBER;
       v_status NUMBER := 1;
BEGIN
       -- 取最新的一条记录，正式环境不会出现重复数据
       SELECT deal_flag INTO v_deal_flag FROM  (SELECT deal_flag FROM IDC_ISMS_REPLY_CMD_ACK WHERE commandid=in_commandid ORDER BY CREATE_time DESC) WHERE ROWNUM=1;
       IF v_deal_flag = 2 THEN
             v_ack_status := 'ACK上报失败';
       ELSIF v_deal_flag = 3 THEN
             v_ack_status := 'ACK上报成功';
             v_status := 0;
       ELSIF v_deal_flag = 1 THEN
             v_ack_status := 'ACK上报失败'; -- 始终在执行上报，也标记为失败
       END IF;

       -- 查询告警ID
       SELECT ALARMID INTO v_alarmId from(SELECT ALARMID  FROM IDC_ISMS_ALARM_INFORMATION WHERE SMMS_COMMANDID=in_commandid OR ALARMID=in_commandid ORDER BY CREATE_TIME DESC) WHERE Rownum=1;

       -- 写入告警列表
       INSERT INTO IDC_ISMS_ALARM_INFOR_LIST
              (ID, ALARMID, ALARM_MSG, ALARM_TIME, STATUS,ALARM_TARGET)
       VALUES
              (SEQ_IDC_ISMS_ALARM_INFO_LIST.NEXTVAL,
               v_alarmId,
               v_ack_status,
               TO_CHAR(SYSDATE(), 'yyyy-MM-dd hh24:mi:ss'),
               v_status,1);
end CMD_ALARM_CMDACK_PROCESS;
/
