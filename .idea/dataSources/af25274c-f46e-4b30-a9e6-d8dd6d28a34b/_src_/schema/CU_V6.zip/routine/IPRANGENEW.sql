CREATE function iprangeNew
       (
          ip in varchar2,
          suffix in number,
          houseidstr in varchar2
       )
return number is i number;
       v_ipstart VARCHAR2(60);
begin
  i := 0;
  v_ipstart := substr(ip, 0, INSTR(ip, '.', -1));

  insert into idc_isms_base_ip_info
    (id, startip, endip, iptype, houseidstr)
  values
    (seq_monitor_ip_error_id.nextval,ip2int(v_ipstart || 0), ip2int(v_ipstart || 255), 0, houseidstr);
  commit;
  return(i);
end iprangeNew;
/
