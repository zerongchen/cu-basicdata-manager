CREATE function unix_to_oracle(in_number number) return date is
begin
  return (to_date('19700101','yyyymmdd') + in_number/86400
  + to_number(substr(tz_offset(sessiontimezone),1,3))/24);

end unix_to_oracle;
/
