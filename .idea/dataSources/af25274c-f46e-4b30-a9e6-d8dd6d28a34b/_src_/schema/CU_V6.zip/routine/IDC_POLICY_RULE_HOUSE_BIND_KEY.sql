CREATE procedure IDC_POLICY_RULE_HOUSE_BIND_key
(
       P_COMMAND_TYPE in number, --策略类型(1-监测策略，2-过滤策略)
       p_house_id varchar2  --机房ID
)
is
   c_cur sys_refcursor;
   v_message_type number(5);
   v_message_no number(10);

   o_msgno number(10);
   v_seqno number(10);
   n_ret number(10);
begin
   open c_cur for
       select t2.message_type, t1.message_no
       from IDC_ISMS_MONITOR_POLICY t1 join dpi_v1_cfg_messageno t2  on t1.message_no = t2.message_no and t2.message_type=16
       where CREATE_USERID = -3 and t1.command_type = P_COMMAND_TYPE;

   loop
     fetch c_cur into v_message_type,v_message_no;
     exit when c_cur%notfound;

     n_ret := PKG_DPICONFIG.AddMessageNo(133,'绑定'||v_message_no|| date2time_t(sysdate),o_msgno);
     v_seqno := PKG_DPICONFIG.MessageSequenceNo(133);

     insert into IDC_ISMS_CFG_HOUSEPOLICYBIND(BIND_ID,HOUSE_TYPE,HOUSE_ID,MESSAGE_TYPE,BINDMESSAGENO,MESSAGE_NO,operatetype,message_sequenceno)
     values( seq_dpi_v1_cfg_bindid.nextval, 2, p_house_id, v_message_type, v_message_no,o_msgno,1,v_seqno);

     dpi_setclog(20030,1,o_msgno,v_seqno,-1);

   end loop;
   close c_cur;

   commit;
end IDC_POLICY_RULE_HOUSE_BIND_key;
/
