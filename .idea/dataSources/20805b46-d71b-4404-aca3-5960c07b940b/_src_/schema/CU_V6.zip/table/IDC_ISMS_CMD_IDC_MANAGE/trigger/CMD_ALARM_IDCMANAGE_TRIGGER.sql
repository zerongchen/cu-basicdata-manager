CREATE TRIGGER CMD_ALARM_IDCMANAGE_TRIGGER
AFTER INSERT
  ON IDC_ISMS_CMD_IDC_MANAGE
FOR EACH ROW
  DECLARE
    v_cmd_name     varchar2(64) := '违法信息安全管理';
    v_houseid_list VARCHAR2(200):='0';

    v_house_id   VARCHAR2(100);
    v_str_tab T_RET_TABLE;
    i NUMBER;
    v_house_idstr VARCHAR2(100);
    v_house_cnt NUMBER;
    v_houseidstr_list VARCHAR2(4000):='';
BEGIN
IF :NEW.COMMANDID > 0 THEN
    IF :NEW.HOUSEIDLIST IS NOT NULL THEN
       v_houseid_list := :NEW.HOUSEIDLIST;
    END IF;
    V_STR_TAB := SPLIT_STR(v_houseid_list,',');

    i := 0;
    while i<V_STR_TAB.count loop
        i := i+1;
        v_house_id := V_STR_TAB(i);

        IF to_number(v_house_id) > 0 THEN
            SELECT count(1) INTO v_house_cnt FROM idc_isms_base_house WHERE HOUSEID=to_number(v_house_id);
            IF v_house_cnt > 0 THEN
               SELECT HOUSEIDSTR INTO v_house_idstr FROM idc_isms_base_house WHERE HOUSEID=to_number(v_house_id);
               v_house_id := v_house_idstr;
            END IF;
        END IF;
        v_houseidstr_list := v_houseidstr_list||v_house_id||',';
    end loop;
    -- 插入告警信息
        INSERT INTO IDC_ISMS_ALARM_INFORMATION
          (ALARMID,
           SMMS_COMMANDID,
           ALARM_TYPE,
           ALARM_HOUSE,
           ALARM_LEVEL,
           ALARM_TIME,
           ALARM_MSG,
           ALARM_TARGET,
           SMMS_COMMAND_TYPE)
        VALUES
          (SEQ_IDC_ISMS_ALARM_INFORMATION.NEXTVAL,
           :NEW.COMMANDID,
           1,
           v_houseidstr_list,
           2,
           TO_CHAR(SYSDATE(), 'yyyy-MM-dd hh24:mi:ss'),
           '  ',
           1,
           5+:NEW.CMD_TYPE*10); -- 15监测，25过滤
        -- 插入告警列表信息
        IF :NEW.CMD_TYPE = 1 THEN
           v_cmd_name := v_cmd_name||'-监测';
        ELSE
           v_cmd_name := v_cmd_name||'-过滤';
        END IF;
        INSERT INTO IDC_ISMS_ALARM_INFOR_LIST
          (ID, ALARMID, ALARM_MSG, ALARM_TIME, STATUS,ALARM_TARGET)
        VALUES
          (SEQ_IDC_ISMS_ALARM_INFO_LIST.NEXTVAL,
           SEQ_IDC_ISMS_ALARM_INFORMATION.Currval,
           '管局下发' || v_cmd_name || '指令成功',
           TO_CHAR(SYSDATE(), 'yyyy-MM-dd hh24:mi:ss'),
           0,
           1);
   END IF;
END CMD_ALARM_IDCMANAGE_TRIGGER;
/
