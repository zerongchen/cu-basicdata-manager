CREATE TRIGGER CMD_ALARM_CMDACK_TRIGGER
AFTER INSERT
  ON IDC_ISMS_REPLY_CMD_ACK
FOR EACH ROW
  DECLARE
  v_job_name VARCHAR2(64);
  -- 触发器中执行ddl需要使用自治事务
  pragma autonomous_transaction;
BEGIN
  -- JOB 名称加上commandid保证其唯一性
  v_job_name := 'jack_'||:new.commandid||'_'||trunc(dbms_random.value(0,999));

  -- 创建一个只执行一次的job
  DBMS_SCHEDULER.CREATE_JOB (
    job_name           =>  v_job_name,
    job_type           =>  'STORED_PROCEDURE',
    job_action         =>  'CMD_ALARM_CMDACK_PROCESS',
    enabled             =>  FALSE,
    start_date         =>  SYSDATE+(2/1440), -- 两分钟后执行
    number_of_arguments => 1
  );

  -- 设置JOB的参数
  DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE(
        JOB_NAME      => v_job_name,
        ARGUMENT_POSITION => 1,
        ARGUMENT_VALUE     => :new.commandid
  );

  -- Enable JOB
  DBMS_SCHEDULER.enable(v_job_name);
  COMMIT;
END CMD_ALARM_CMDACK_TRIGGER;
/
