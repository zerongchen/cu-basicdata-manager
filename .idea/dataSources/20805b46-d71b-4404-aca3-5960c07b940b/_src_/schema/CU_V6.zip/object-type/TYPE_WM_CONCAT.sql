CREATE TYPE "TYPE_WM_CONCAT"
   AS OBJECT
(
   l_join_str CLOB,                                -- 连接后的字符串
   l_flag VARCHAR2 (100 BYTE),                             -- 分隔符，默认值可在body中定义
   STATIC FUNCTION ODCIAggregateInitialize                              -- 初始化
                                           (sctx IN OUT type_wm_concat)
      RETURN NUMBER,
   MEMBER FUNCTION ODCIAggregateIterate                          -- 迭代器，处理每行数据
                                        (self    IN OUT type_wm_concat,
                                         VALUE   IN     ConcatObj)
      RETURN NUMBER,
   MEMBER FUNCTION ODCIAggregateTerminate                         -- 迭代结束后处理代码
                                          (self       IN OUT type_wm_concat,
                                           return_v      OUT CLOB,
                                           flags      IN     NUMBER)
      RETURN NUMBER,
   MEMBER FUNCTION ODCIAggregateMerge                                  -- 结果合并
                                      (self   IN OUT type_wm_concat,
                                       ctx2   IN     type_wm_concat)
      RETURN NUMBER
)

/
