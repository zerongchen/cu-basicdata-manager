CREATE VIEW IDC_BASE_FILTER_POLICY_VIEW AS select
  t.houseid houseid,
  t.rule_value rule_value,
  min(t.create_time) create_time,
  'ISMS' username
from (
    select
      t_3.house_id houseid,
      t_1.valuestart rule_value,
      to_char((t_3.create_time - to_date('1970-01-01', 'yyyy-mm-dd'))*24*3600-8*3600) create_time,
      nvl(t_2.create_username,'ISMS') username
    from (select * from idc_isms_monitor_policy_rule t where t.subtype in (1,5)) t_1
    join (select * from idc_isms_monitor_policy t1 where t1.command_type = 2 and t1.operatetype != 3 and t1.expiredtime >= date2time_t(sysdate)) t_2 on t_1.commandid = t_2.commandid
    join (select * from idc_isms_cfg_housepolicybind t where operatetype != 3) t_3 on t_3.bindmessageno = t_2.message_no
    where t_3.house_id is not null
    union all
    select
      a.houseidstr houseid,
      b.rule_value rule_value,
      b.create_time create_time,
      b.username username
    from (select * from idc_isms_base_house h where h.del_flag = 0) a
    full join (
      select
        t_3.house_id houseidstr,
        t_1.valuestart rule_value,
        to_char((t_3.create_time - to_date('1970-01-01', 'yyyy-mm-dd'))*24*3600-8*3600) create_time,
        nvl(t_2.create_username,'ISMS') username
      from (select * from idc_isms_monitor_policy_rule t where t.subtype in (1,5)) t_1
      join (select * from idc_isms_monitor_policy t1 where t1.command_type = 2 and t1.operatetype != 3 and t1.expiredtime >= date2time_t(sysdate)) t_2 on t_1.commandid = t_2.commandid
      join (select * from idc_isms_cfg_housepolicybind t where operatetype != 3) t_3 on t_3.bindmessageno = t_2.message_no
      where t_3.house_id is null
    ) b on 1 = 1
    where b.rule_value is not null
) t group by t.houseid,t.rule_value
/
