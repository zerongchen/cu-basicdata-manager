CREATE VIEW IDC_BASE_DOMAIN_VIEW AS select
  t4.houseidstr houseid,
  t1.domainname domainname,
  wm_concat(t3.username) unitname
from idc_isms_base_service_domain t1
join idc_isms_base_user_service t2 on t2.serviceid = t1.serviceid
join idc_isms_base_house_ipseg_view t3 on t3.userid = t2.userid
join idc_isms_base_house t4 on t4.houseid = t3.houseid
where t1.del_flag = 0
group by t4.houseidstr, t1.domainname
/
