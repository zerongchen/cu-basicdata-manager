CREATE VIEW IDC_ISMS_BASE_USER_FRAME_VIEW AS select
  uf.id,
  u.userid,
  uf.houseid,
  uf.frameid,
  uf.unitname,
  hf.czlx,
  hf.deal_flag
from idc_isms_base_user_frame uf
join (select * from idc_isms_base_house_frame temp where temp.del_flag = 0) hf on uf.frameid = hf.frameid
join (select * from idc_isms_base_user t where t.del_flag = 0) u on uf.unitname = u.unitname
/
