CREATE VIEW IDC_BASE_IP_DOMAIN_VIEW AS select
  t3.houseidstr houseid,
  t1.domainname domainname,
  t2.startip startip,
  t2.endip endip
from idc_isms_base_service_domain t1
join idc_isms_base_house_ipseg_view t2 on t2.userid = t1.userid
join idc_isms_base_house t3 on t3.houseid = t2.houseid
where t1.del_flag = 0
/
