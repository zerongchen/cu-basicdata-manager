CREATE VIEW IDC_BASE_IPSEG_VIEW AS select
   --t2.houseid,
   t2.houseidstr houseid,
   t1.iptype||'' iptype,
   t1.startip startip,
   t1.endip endip,
   wm_concat(t1.username) unitname
from (select * from idc_isms_base_house_ipseg t where t.del_flag = 0) t1
join (select * from idc_isms_base_house t1 where t1.del_flag = 0) t2 on t1.houseid = t2.houseid
group by t2.houseidstr,t1.iptype,t1.startip,t1.endip
/
