CREATE function date2time_t(dtm IN date) return number is
begin
  RETURN (dtm-to_date('1970-01-01', 'yyyy-mm-dd'))*24*3600-8*3600;
end date2time_t;
/
