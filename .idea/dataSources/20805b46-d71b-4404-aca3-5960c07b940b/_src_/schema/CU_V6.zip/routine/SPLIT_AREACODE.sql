CREATE function split_areaCode(
                            var_str1   in varchar2,
                            var_str2   in varchar2
  )
  return int is
  var_num     number;
  var_tmp1     varchar2(4000);
  var_tmp2     varchar2(4000);
  var_element varchar2(4000);

begin
  var_tmp1 := var_str1;
  var_tmp2 := var_str2;
  var_num := 0;
  
  while instr(var_tmp1, ',') > 0 loop
        var_element := substr(var_tmp1, 1, instr(var_tmp1, ',') - 1);
        var_tmp1    := substr(var_tmp1, instr(var_tmp1, ',') + length(','), length(var_tmp1));
        if instr(var_tmp2,var_element) > 0 then
           var_num := 1;
        end if;
  end loop;
  --如果不存在匹配的分割符
  if(instr(var_tmp1, ',') = 0) then
    if(instr(var_tmp2, var_tmp1) >0 ) then
      var_num := 1;
    end if;
  end if;  
  return var_num;
end split_areaCode;
/
