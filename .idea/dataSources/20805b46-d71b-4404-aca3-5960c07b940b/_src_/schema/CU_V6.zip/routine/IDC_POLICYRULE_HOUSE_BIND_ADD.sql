CREATE procedure IDC_POLICYRULE_HOUSE_BIND_ADD
(
    p_house_id varchar2,  --机房ID
    p_houseType in number,
    p_msgNoStart in number,
    p_msgNoEnd   in number
)
is
   o_msgno number(10);
   v_seqno number(10);
   n_ret number(10);
begin
   n_ret := PKG_DPICONFIG.AddMessageNo(133,'绑定'|| date2time_t(sysdate),o_msgno);
   v_seqno := PKG_DPICONFIG.MessageSequenceNo(133);

   insert into IDC_ISMS_CFG_HOUSEPOLICYBIND(BIND_ID,HOUSE_TYPE,HOUSE_ID,MESSAGE_TYPE,BINDMESSAGENO,MESSAGE_NO,operatetype,message_sequenceno)
   SELECT seq_dpi_v1_cfg_bindid.nextval, p_houseType, p_house_id, t2.message_type, t1.message_no, o_msgno, 1, v_seqno
   FROM IDC_ISMS_MONITOR_POLICY t1 join dpi_v1_cfg_messageno t2  on t1.message_no = t2.message_no where t2.message_type=16 and
   t1.operatetype !=3 and t1.message_no between p_msgNoStart and p_msgNoEnd;

   dpi_setclog(20030,1,o_msgno,v_seqno,-2);

   commit;
end IDC_POLICYRULE_HOUSE_BIND_ADD;
/
