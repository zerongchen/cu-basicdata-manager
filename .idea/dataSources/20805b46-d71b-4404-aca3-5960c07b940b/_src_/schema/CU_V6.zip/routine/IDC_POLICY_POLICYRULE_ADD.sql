CREATE procedure IDC_POLICY_POLICYRULE_ADD
(
    p_commandType           IN NUMBER,
    p_actionBlock           IN NUMBER,
    p_starttime             IN NUMBER,
    p_endtime               IN NUMBER,
    p_valueStart            IN VARCHAR2,
    p_valueEnd              IN VARCHAR2,
    p_subType               IN NUMBER,
    p_msgSeqNo              IN NUMBER
)
is
    v_msgname VARCHAR2(100);
    v_msgno NUMBER(10);
    v_commandId number(10);
    v_msgnew VARCHAR2(5000);
    v_ret NUMBER(10);
    v_keyRange VARCHAR2(100);
    v_valueEnd VARCHAR2(100);
begin
      SELECT to_char(systimestamp,'yyyymmddhh24missff3') || trunc(dbms_random.value(1000,9999)) INTO v_msgname FROM dual;
      v_ret := PKG_DPICONFIG.AddMessageNo(16, v_msgname, v_msgno);
      select seq_idc_isms_monitorpolicy_id.nextval into v_commandId from dual;
      insert into IDC_ISMS_MONITOR_POLICY(COMMANDID,MESSAGE_NO,COMMAND_TYPE,ACTION_BLOCK,ACTION_LOG,
               EFFECTTIME,EXPIREDTIME,OPERATETYPE,
               MESSAGE_SEQUENCENO,
               CREATE_TIME,
               CREATE_USERID)
        values(v_commandId,v_msgno,p_commandType,p_actionBlock,1,
               p_starttime,p_endtime,1,p_msgSeqNo,sysdate,-2);

      v_msgnew:=getRow('IDC_ISMS_MONITOR_POLICY','COMMANDID',v_commandId);--添加日志
      --dpi_setclog(20026,1,v_msgno,v_seqno,p_operid);
      --dpi_setuserlog(20026,1,v_commandId,v_msgnew,'',p_operid);

      if(p_subType=3) then
           v_keyRange := '0,1,2';
           v_valueEnd := '';
      elsif(p_subType = 4 or p_subType = 5) then
           v_keyRange := '0,1,2';
           if(p_valueEnd is not null) then
              v_valueEnd :=  p_valueEnd;
           else
              v_valueEnd := '';
           end if;  
      else
           v_keyRange := '';
           v_valueEnd := '';
      end if;
      v_ret :=PKG_IDCCONFIG.AddIspPolicyRuleNotCommit(v_commandId,0,p_subType,p_valueStart,v_valueEnd,v_keyRange,-2);
end IDC_POLICY_POLICYRULE_ADD;
/
