CREATE package IDC_ISMS_SYSTEM_CMD_MANAGE is

procedure list_IDCInfo(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,

                          p_commandId in number,
                          p_idcId in varchar2,
                          p_cmdType in number,
                          p_dealFlag in number,
                          p_beginTimeStamp in varchar2,
                          p_endTimeStamp in varchar2
                          );

procedure list_IDCMNGQuery(   p_ispaging in number,
                              pageindex in number,
                              pagesize in number,
                              p_iscount in number,
                              sortName in varchar2,
                              orderItem in varchar2,
                              p_cursor out sys_refcursor,
                              p_recordcount out number,

                              p_IDCID          in varchar2,
                              p_HOUSEIDLIST    in varchar2,
                              p_S_TIMESTAMP      in varchar2,
                              p_E_TIMESTAMP      in varchar2,
                              p_S_CREATE_TIME    in varchar2,
                              p_E_CREATE_TIME    in varchar2,
                              p_DEAL_FLAG      in number,
                              p_IS_RESULT      in number
                              );

procedure list_IDC(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_houseId in number,
                      p_commandId in number,
                      p_idcId in varchar2,
                      p_cmdTyp in number,
                      p_actionLog  in number,
                      p_actionReport  in number,
                      p_opeType in number,
                      p_dealFlag in number,
                      p_beginTimeStamp in varchar2,
                      p_endTimeStamp in varchar2
                      );

procedure list_log(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_houseId in number,
                      p_commandId in number,
                      p_idcId in varchar2,
                      p_protocolType in number,
                      p_dealFlag in number,
                      p_beginTimeStamp in varchar2,
                      p_endTimeStamp in varchar2
                      );
procedure list_Rule(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_commandId in number,
      p_subType in number,
      p_beginCreatetime in varchar2,
      p_endCreatetime in varchar2
      );
procedure list_cmdack(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_HOUSEID in number,
      p_IDCID in varchar2,
      p_COMMANDFILEID in number,
      p_CMD_TYPE in number,
      p_RESULT_CODE in number,
      p_DEAL_FLAG in number,
      p_S_TIMESTAMP      in varchar2,
      p_E_TIMESTAMP      in varchar2,
      p_S_CREATE_TIME    in varchar2,
      p_E_CREATE_TIME    in varchar2
      );
procedure list_active_state(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_IDCID in varchar2,
      p_DEAL_FLAG in number,
      p_S_TIMESTAMP      in varchar2,
      p_E_TIMESTAMP      in varchar2,
      p_S_CREATE_TIME    in varchar2,
      p_E_CREATE_TIME    in varchar2
      );

--查询基础数据核验处理信息
procedure list_IDCInfo_validate(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_IDCId in varchar2,
      p_beginTimestamp in varchar2,
      p_endTimestamp in varchar2,
      p_beginCreatetime in varchar2,
      p_endCreateTime in varchar2,
      p_dealFlag in number,
      p_isResult in number
);

--查询基础数据核验处理信息对应的机房信息
procedure list_validate_houseInfo(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_returnInfoId in number,
      p_gatewayId in number,
      p_ipSegId in number,
      p_frameInfoId in number
);

--查询基础数据核验处理信息对应的用户信息
procedure list_validate_userInfo(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_returnInfoId in number,
      p_hhId in number
);

--查询核验信息对应用户信息下的服务信息
procedure list_validate_usInfo(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_userId in number,
      p_domainId in number,
      p_hhId in number
);

--查询免过滤网站列表指令
procedure list_IDCInfo_no_filter(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_commandId in number,
      p_idcId in varchar2,
      p_opeType in number,
      p_type in number,
      p_content in varchar2,
      p_dealFlag in number,
      p_beginTimeStamp in varchar2,
      p_endTimeStamp in varchar2
);

--查询违法网站列表指令
procedure list_IDCInfo_Black(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_commandId in number,
      p_idcId in varchar2,
      p_opeType in number,
      p_type in number,
      p_content in varchar2,
      p_dealFlag in number,
      p_beginTimeStamp in varchar2,
      p_endTimeStamp in varchar2
);

--查询活跃资源访问量查询指令
procedure list_IDCInfo_query_view(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_commandId in number,
      p_idcId in varchar2,
      p_type in number,
      p_content in varchar2,
      p_dealFlag in number,
      p_beginQueryTime in varchar2,
      p_endQueryTime in varchar2,
      p_beginTimeStamp in varchar2,
      p_endTimeStamp in varchar2
);

--查询违法管理指令执行记录指令
procedure list_IDCInfo_black_record(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_commandId in number,
      p_idcId in varchar2,
      p_controlsId in number,
      p_dealFlag in number,
      p_beginTimeStamp in varchar2,
      p_endTimeStamp in varchar2,
      p_beginCreateTime in varchar2,
      p_endCreateTime in varchar2
);

--查询指令处理后生成文件信息
procedure list_IDCInfo_fileInfo(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,
      p_commandType in number,
      p_commandId in varchar2,
      p_filename in varchar2,
      p_fileState in number,
      p_beginCreatetime in varchar2,
      p_endCreatetime in varchar2,
      p_beginUpdatetime in varchar2,
      p_endUpdatetime in varchar2
);

--查询指令处理后ACK处理状态信息
procedure list_IDCInfo_ACKInfo(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,
      p_commandType in number,
      p_commandId in number,
      p_houseId in varchar2,
      p_resultCode in number,
      p_idcId in varchar2,
      p_timeStampStart in varchar2,
      p_timeStampEnd in varchar2,
      p_dealFlag in number,
      p_createTimeStart in varchar2,
      p_createTimeEnd in varchar2
);

--查询代码发布表指令
procedure list_IDCInfo_code_release(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_commandId in varchar2,
      p_filename in varchar2,
      p_dealFlag in number,
      p_beginTimeStamp in varchar2,
      p_endTimeStamp in varchar2
);

end IDC_ISMS_SYSTEM_CMD_MANAGE;
/
