CREATE package IDC_ISMS_AUTO_MONITOR_MANAGE is

        --过滤异常ip或域名
       /*procedure autoDealMonitorPolicy(
                 p_error_id in number,
                 p_deal_username in varchar2
       );*/

       --处置异常IP
       procedure dealErrorIP(
                 p_error_id in number,
                 p_deal_username in varchar2
       );

       procedure dealErrorIPForRedis(
                 p_key in varchar2,
                 p_deal_username in varchar2
       );

        --处置违法违规网站
        procedure dealErrorDomain(
                 p_error_id in number,
                 p_deal_username in varchar2
        );

         --处置违法违规网站
        procedure dealErrorDomainForRedis(
                 p_key in varchar2,
                 p_deal_username in varchar2
        );

       --保存策略
       procedure saveMonitorPolicy(
                 p_command_type in number,
                 p_action_block in number,
                 p_action_log in number,
                 p_actionReport in number,
                 p_effecttime in varchar2,
                 p_expiredtime in varchar2,
                 p_house_id in number,
                 p_deal_username in varchar2,
                 p_policy_level in number,
                 --出参
                 p_out_success out number,
                 p_out_cmdid out number

       );

       --保存策略
       procedure saveMonitorPolicyForRedis(
                 p_command_type in number,
                 p_action_block in number,
                 p_action_log in number,
                 p_actionReport in number,
                 p_effecttime in varchar2,
                 p_expiredtime in varchar2,
                 p_houseIdStr in varchar2,
                 p_deal_username in varchar2,
                 p_policy_level in number,
                 --出参
                 p_out_success out number,
                 p_out_cmdid out number

       );

       --处理信息安全管理指令规则表
       procedure AddIdcmngRule(
                 p_subType in number,
                 p_valueStart in varchar2,
                 p_valueEnd in varchar2,
                 p_keyRange in varchar2,
                 p_monitor_cmdId in number,

                 --出参
                 v_out_success out number
       );

       --复制违法违规网站信息并更新当前信息
       procedure updateErrorDomain(
                 p_err_id in number,
                 p_deal_username in varchar2
                 --p_tableName in varchar2
       );

       --复制异常IP信息并更新当前信息
       procedure updateErrorIP(
                 p_err_id in number,
                 p_deal_username in varchar2
                 --p_tableName in varchar2
       );

       --自动处置异常IP和违法违规网站
       procedure autoDealErrorIPAndErrorDomain(
                 p_thresholdValue in number, --阀值
                 --p_errorIPCur out sys_refcursor,
                 --p_errorDomainCur out sys_refcursor,
                 p_errorIPCount out number,
                 p_errorDomainCount out number,
                 p_successFlag out number
       );

end IDC_ISMS_AUTO_MONITOR_MANAGE;
/
