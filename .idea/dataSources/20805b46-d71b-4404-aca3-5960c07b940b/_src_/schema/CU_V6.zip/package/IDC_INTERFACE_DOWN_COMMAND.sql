CREATE package idc_interface_down_command is

  --处理基础数据管理指令
  procedure DealIdcinfoManage(
                         p_cmdId         in number,
                         p_cmdType       in varchar2,
                         p_queryDayfrom  in varchar2,
                         p_queryDayto    in varchar2,
                         p_idcId         in varchar2,
                         p_userIds       in varchar2,
                         p_houseIds      in varchar2,
                         p_timeStamp     in varchar2,
                         --出参
                         v_out_success   out number
                         );

  --处理信息安全管理指令
  procedure DealIdcManage(
                         p_cmdId in   number,
                         p_timeStamp in   varchar2,
                         p_cmdType in   number,
                         p_actionBlock in   number,
                         p_actionReason in   varchar2,
                         p_actionLog in   number,
                         p_actionReport in   number,
                         p_effectTime in varchar2,
                         p_expiredTime in varchar2,
                         p_privilegeOwner in varchar2,
                         p_privilegeVisible in number,
                         p_idcId in   varchar2,
                         p_houseIds in   varchar2,
                         p_operationType in number,
                         p_levelBinary   in varchar2,
                         p_levelDecimal  in number,
                         p_unbund_flag   in number,
                         --出参
                         v_out_success    out number,
                         v_out_cmdid      out number
                         );

  --处理信息安全管理指令规则表
  procedure AddIdcmngRule(
                         p_cmdId          in   number,
                         p_subType        in   number,
                         p_valueStart     in   varchar2,
                         p_valueEnd       in   varchar2,
                         p_valueStartStr  in   varchar2,
                         p_valueEndStr    in   varchar2,
                         p_keyRange       in   varchar2,
                         p_monitor_cmdId  in   number,
                         --出参
                         v_out_success    out number
                         );

  --处理信息安全管理指令规则表
  procedure DelIdcmngRule(
                         p_cmdId in   number,
                         p_monitor_cmdId in   number,
                         --出参
                         v_out_success    out number
                         );

  --处理访问日志查询指令
  procedure DealLogQuery(
                         p_cmdId in   number,
                         p_idcId in   varchar2,
                         p_houseId in   number,
                         p_startTime in varchar2,
                         p_endTime in varchar2,
                         p_srcStartIp   in varchar2,
                         p_srcEndIp   in varchar2,
                         p_destStartIp  in varchar2,
                         p_destEndIp  in varchar2,
                         p_srcPort    in number,
                         p_dstPort    in number,
                         p_protocolType  in number,
                         p_url        in varchar2,
                         p_timeStamp in   varchar2,
                         --出参
                         v_out_success    out number
                         );

  --处理信息安全管理指令查询指令
  procedure DealIdcmngQuery(
                         p_cmdId in   number,
                         p_idcId in   varchar2,
                         p_houseIds in   varchar2,
                         p_timeStamp in   varchar2,
                         --出参
                         v_out_success    out number
                         );
 --处理基础数据核验处理指令
 procedure dealReturnInfo(
                         p_idcId          in varchar2,
                         p_returnCode     in number,
                         p_returnMsg      in varchar2,
                         p_timeStamp      in varchar2,
                         --出参
                         v_out_success    out number,
                         v_returnInfoId   out number
                         );
 --处理退回机房数据
 procedure dealReturnHouseInfo(
                         p_returnInfoId     in number,
                         p_houseId          in number,
                         p_gatewayId        in number,
                         p_ipsegId          in number,
                         p_frameInfoId      in number,
                         --出参
                         v_out_success      out number
                         );
 --处理退回用户数据
 procedure dealReturnUserInfo(
                         p_returnInfoId         in number,
                         p_userId               in number,
                         p_hhId                 in number,
                         --出参
                         v_out_success          out number,
                         v_returnInfoId         out number
                         );
 --处理退回用户服务数据
 procedure dealReturnUserServiceInfo(
                         p_returnInfoId        in number,
                         p_serviceId           in number,
                         p_domainId            in number,
                         p_hhId                in number,
                         --出参
                         v_out_success         out number
                         );
  --处理免过滤域名列表指令
 procedure dealNoFilter(
                       p_commandId       in number,
                       p_idcId           in varchar2,
                       p_operationType   in number,
                       p_type            in number,
                       p_contents        in varchar2,
                       p_levelBinary     in varchar2,
                       p_levelDecimal    in number,
                       p_timeStamp       in varchar2,
                       p_unbund_flag     in number,
                       --出参
                       v_out_success     out number
                       );
  --处理违法网站列表指令
  procedure dealBlackList(
                       p_commandId       in number,
                       p_idcId           in varchar2,
                       p_operationType   in number,
                       p_type            in number,
                       p_contents        in varchar2,
                       p_levelBinary     in varchar2,
                       p_levelDecimal    in number,
                       p_timeStamp       in varchar2,
                       --出参
                       v_out_success         out number
                       );
  --处理活跃资源访问量查询指令
  procedure dealQueryView(
                       p_commandId       in number,
                       p_idcId           in varchar2,
                       p_type            in number,
                       p_content         in varchar2,
                       p_quryTime        in varchar2,
                       p_timeStamp       in varchar2,
                       --出参
                       v_out_success         out number
                       );
  --处理违法管理指令执行记录指令
  procedure dealCommandRecord(
                       p_commandId       in number,
                       p_idcId           in varchar2,
                       p_controlsId      in number,
                       p_timeStamp       in varchar2,
                       --出参
                       v_out_success         out number
                       );
  --添加数据到指令执行情况表
  procedure AddReplyCmdAck(
                         p_cmdId in   number,
                         p_houseId in   varchar2,
                         p_cmdType in   number,
                         p_retCode in   number,
                         p_msgInfo in   varchar2,
                         p_idcId in   varchar2,
                         p_cmdFileId in   number,
                         --出参
                         v_out_success    out number
                         );
  --监测或过滤策略下发的处理
  procedure dealMonitorFilterPolicy(
                         v_smms_cmdid     in   number,
                         v_command_type   in   number,
                         v_action_block   in   number,
                         v_action_reason  in   varchar2,
                         v_action_log     in   number,
                         p_actionReport   in   number,
                         v_effecttime     in   varchar2,
                         v_expiredtime    in   varchar2,
                         v_idcid          in   varchar2,
                         v_houseIds       in   varchar2,
                         v_opType         in   number,
                         v_unbundFlag     in   number,
                         --出参
                         v_out_success    out number,
                         v_out_cmdid      out number
                         );

  procedure addNoFilterOrBlackList(
                        p_commandId       in number,
                        p_idcId           in varchar2,
                        p_operationType   in number,
                        p_type            in number,
                        p_contents        in varchar2,
                        p_levelDecimal    in number,
                        p_commandType      in number,
                        --出参
                        v_out_success     out number
                        );

end idc_interface_down_command;
/
