CREATE package idc_alarm_information is

  --处理监控项告警信息
 procedure dealAlarmInfo (
           p_alarmType           in number,
           p_alarmLevel          in number,
           p_alarmTime           in varchar2,
           p_alarmMessage        in varchar2,
           p_alarmTarget         in number,
           --出参
           v_out_success         out number
       );
procedure list_monitor_file(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      status in number,
      selectFlag in number,
       monitor_task_id in number,
      begin_create_time    in varchar2,
    end_create_time in varchar2
    );
     procedure list_monitor_alarm(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      alarmContent in varchar2,
      alarmParam in varchar2,
      dealStatus    in number,
    alarmBeginTime in varchar2,
    alarmEndTime in varchar2
    );
end idc_alarm_information;
/
