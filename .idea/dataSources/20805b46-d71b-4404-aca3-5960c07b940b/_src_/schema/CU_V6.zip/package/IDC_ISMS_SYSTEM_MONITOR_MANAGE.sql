CREATE package IDC_ISMS_SYSTEM_MONITOR_MANAGE is

procedure list_houseMonitorSetting(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number
      );
procedure list_houseMonitorState(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_STATEID in number,
      p_JYZID   in number,
      p_idcname  in varchar2,
      p_HOUSEID in number,
      p_houseName in varchar2,
      p_MONITOR_STATE in number,
      p_DEAL_TYPE in number,
      s_date in varchar2,
      e_date in varchar2
      );
procedure list_monitorPolicy(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_ACTION_LOG in number,
      p_COMMANDID in number,
      p_COMMAND_TYPE in number,
      p_MONITOR_TYPE in number,
      p_SMMS_CMDID in number,
      p_IDCID in varchar2
      );
procedure list_policyRule(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_COMMANDID in number
      );
/*procedure list_houseMonitorErrorInfo(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_HOUSEID in number,
      p_IP in varchar2,
      p_PORT in number,
      p_DOMAIN in varchar2,
      p_SERVICETYPE in varchar2,
      p_ILLEGAL_TYPE in number,
      p_CURRENT_STATE in number,
      p_ICP_ERROR in number,
      p_REG_ERROR in number,
      p_REG_DOMAIN in varchar2,
      p_DEAL_FLAG in number
      );*/

procedure list_ipdomain(
      p_isPaging in number,
      p_pageIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_sortOrder in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_ip in varchar2,
      p_violation in number,
      p_domain in varchar2
      );

 --查询免过滤网站
 procedure list_website_no_filter(
        p_isPaging in number,
        p_pageIndex in number,
        p_pageSize in number,
        p_isCount in number,
        p_sortName in varchar2,
        p_sortOrder in varchar2,

        p_cursor out sys_refcursor,
        p_recordcount out number,

        p_idcId in varchar2,
        p_ip in varchar2,
        p_createTimeBegin in varchar2,
        p_createTimeEnd in varchar2
 );

--查询违法网站
procedure list_website_black(
              p_isPaging in number,
              p_pageIndex in number,
              p_pageSize in number,
              p_isCount in number,
              p_sortName in varchar2,
              p_sortOrder in varchar2,

              p_cursor out sys_refcursor,
              p_recordcount out number,

              p_idcId in varchar2,
              p_ip in varchar2,
              p_createTimeBegin in varchar2,
              p_createTimeEnd in varchar2
);

procedure list_houseMonitorErrorIpInfo(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_houseId in number,
            p_ip in varchar2,
            p_regDomain in varchar2,
            p_domain in varchar2,
            p_curState in number,
            p_regError in number,
            p_dealFlag in number
);

 --查询违法违规网站信息
procedure list_houseMonitorErrorDomain(
      --入参，分页参数
      p_isPaging in number, --是否分页，如果不分页则返回全部数据
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_IsCount    in number,
      p_sortName   in VARCHAR2,
      p_sortOrder  in VARCHAR2,
      --输出
      p_cursor      out sys_refcursor,
      p_recordCount out number, --非空为错误信息
      --入参，查询参数
      p_houseId in number,
      p_domain in varchar2,
      p_curState in number,
      p_illegalType in number,
      p_dealFlag in number
);

procedure list_IdcUpActiveDomainInfo(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_houseId    in number,
      p_actionBlock in number,
      p_topDomainFlag in number,
      p_domain     in VARCHAR2,
      p_topDomain  in VARCHAR2,
      p_ip         in VARCHAR2,
      p_port     in number,
      p_idcId     in VARCHAR2,
      p_visitsCount in number,
      p_recordcount out number,
      p_cursor      out sys_refcursor
);

procedure list_IdcUpActiveIpInfo(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_houseId    in number,
      p_actionBlock in number,
      p_isInIpSeg in number,
      p_port     in number,
      p_protocol  in number,
      p_ip         in VARCHAR2,
      p_idcId     in VARCHAR2,
      p_visitsCount in number,
      p_recordcount out number,
      p_cursor      out sys_refcursor
);

procedure list_websiteStatistics(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_houseId    in number,
      p_startTime  in VARCHAR2, --开始统计时间
      p_endTime  in VARCHAR2, --结束统计时间
      p_sortName   in VARCHAR2,
      p_sortOrder in varchar2,
      p_recordcount out number,
      p_cursor      out sys_refcursor,
      p_userHouseIDStrs in varchar2
);

procedure list_topNWebsiteStatistics(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_id         in number,
      p_houseId    in number,
      p_domain    in VARCHAR2,
      p_findStartTimeStr in VARCHAR2,
      p_findEndTimeStr in VARCHAR2,
      p_sortName   in VARCHAR2,
      p_sortOrder in VARCHAR2,
      p_recordcount out number,
      p_cursor      out sys_refcursor,
       p_userHouseIDStrs in varchar2
);

procedure list_topNWebsiteBlack(
      p_pageIndex  in number, --页索引
      p_pageSize   in number, --页大小
      p_id         in number,
      p_houseId    in number,
      p_domain    in VARCHAR2,
      p_findStartTimeStr in VARCHAR2,
      p_findEndTimeStr in VARCHAR2,
      p_sortName   in VARCHAR2,
      p_sortOrder in VARCHAR2,
      p_recordcount out number,
      p_cursor      out sys_refcursor,
       p_userHouseIDStrs in varchar2
);
end IDC_ISMS_SYSTEM_MONITOR_MANAGE;
/
