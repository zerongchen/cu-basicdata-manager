CREATE package idc_isms_monitor_manage is

  --处理信息安全管理指令
  procedure DealMonitorPolicy(
                         v_smms_cmdid in   number,
                         v_command_type in   number,
                         v_action_block in   number,
                         v_action_reason in   varchar2,
                         v_action_log in   number,
                         p_actionReport in   number,
                         v_effecttime in varchar2,
                         v_expiredtime in varchar2,
                         v_idcid in   varchar2,
                         v_houseIds in   varchar2,
                         v_opType in number,
                         v_policyLevel in number,
                         --出参
                         v_out_success    out number,
                         v_out_cmdid    out number
                         );

end idc_isms_monitor_manage;
/
