CREATE package PKG_DPICONFIG is

 -- ?？????？
SUCC_CODE CONSTANT NUMBER(5) := 0;

-- ？?？？
TYPE C_CURSOR IS REF CURSOR;

-- ？?？？？??？
ERROR_DATABASE CONSTANT NUMBER(5) := 10000;

-- ?？??？??？(11000 -- 11100)
ERROR_SERVER_EXIST NUMBER(5) := 11000;  -- server?？
  -- Author  : ADMINISTRATOR
  -- Created : 2011-5-19 16:01:13
  -- Purpose :

ERROR_SERVER_NOTEXIST NUMBER(5) := 11001;  -- ???？?？??？

ERROR_EXCEPTION EXCEPTION;


  --?？essage Type？?η？估??？
  FUNCTION GetMessageTypeAll
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;

  --?？？SGNO
  FUNCTION GetMessageNoAll
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;

  --？???？?？SGNO
  FUNCTION GetMessageByTypeID
  (
    p_typeid   IN NUMBER,
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;
  --？？ ？???？？？?？？??？？？？？？？?
  FUNCTION GetMessageByTypeID
  (
    in_nTypeId        IN NUMBER,
    in_nSize          IN NUMBER,
    in_vWhere         IN VARCHAR2,--??？Сд
    in_nIsName        IN NUMBER,
    out_cursor        OUT C_CURSOR
  )RETURN INTEGER;

     --？??？?？？SGNO
  FUNCTION GetMessageByName
  (
    p_type    IN NUMBER,
    p_name    IN  VARCHAR2,
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;
  
  FUNCTION AddClogDefine(
    p_code                       IN NUMBER,
    p_modulename                 IN VARCHAR2,
    p_recid1                     IN VARCHAR2,
    p_recid2                     IN VARCHAR2,
    p_tablename                  IN VARCHAR2,
    p_flag                       IN NUMBER,
    p_clogtype                   IN NUMBER,
    p_oper                       IN NUMBER
  )
  RETURN INTEGER;
  
  FUNCTION DeleteClogDefine
  (
    p_code                    IN NUMBER,
    p_oper                    IN NUMBER
  )
  RETURN INTEGER;

    --？？MESSAGE_NO
  FUNCTION AddMessageNo
  (
    p_msgtype   IN NUMBER,
    p_msgname   IN VARCHAR2,
    p_msgno     OUT NUMBER
  )
  RETURN INTEGER;

   --？?？?？?？?？？?？?？??？？??？？？??
  FUNCTION MessageSequenceNoCommon
  (
    p_msgno     IN NUMBER,
    p_operid       IN NUMBER,
    v_seqno     OUT NUMBER
  )
  RETURN INTEGER;



  --MESSAGE_NO?？？?？？??
  FUNCTION MessageSequenceNo
  (
    p_msgtype     IN NUMBER
  )
  RETURN INTEGER;
  --MESSAGE_NO?？？?？？??--5000?？？??？?？？？？
  FUNCTION MessageSequenceNo(
    p_msgtype     IN NUMBER,
    p_seqno       IN NUMBER,
    p_update      IN NUMBER  --0？？1??？
  )RETURN NUMBER;

  --?？D??？?？
  FUNCTION GetPacketTypeAll
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;
  
  FUNCTION DpiSetClogCommon
  (
    p_code         IN NUMBER,
    p_type         IN NUMBER,
    p_red1         IN NUMBER,
    p_red2         IN NUMBER,
    p_operid       IN NUMBER
  )
  RETURN INTEGER;

     -- д？CLOG??？?? ????????
  FUNCTION DpiSetClogCommonSubmit
  (
    p_code         IN NUMBER,
    p_type         IN NUMBER,
    p_red1         IN NUMBER,
    p_red2         IN NUMBER,
    p_operid       IN NUMBER
  )
  RETURN INTEGER;
  
  FUNCTION GetClogDefineList
  (
    p_pageNo                    IN NUMBER,
    p_pageSize                  IN NUMBER,
    p_word                      IN VARCHAR2,
    p_flag                      IN NUMBER,
    p_clogtype                  IN NUMBER,
    p_outcount                  OUT NUMBER,
    p_cursor                    OUT C_CURSOR
  )
  RETURN INTEGER;

end PKG_DPICONFIG;
/
