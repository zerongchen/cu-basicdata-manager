CREATE package PKG_LOGMANAGE_IDC is

-- 成功返回
SUCC_CODE CONSTANT NUMBER(5) := 0;

-- 游标类型
TYPE C_CURSOR IS REF CURSOR;

-- 数据库错误定义
ERROR_DATABASE CONSTANT NUMBER(5) := 10000;

-- 错误代码定义(11000 -- 11100)
ERROR_SERVER_EXIST NUMBER(5) := 11000;  -- server存在


    ---分页获取操作日志
FUNCTION GetOperLogList(
                            pagesize      NUMBER,
                            pageindex     NUMBER,
                            p_username    VARCHAR2,
                            p_type        NUMBER,
                            p_code        NUMBER,
                            p_clogtype    NUMBER,
                            p_starttime   VARCHAR2,
                            p_endtime     VARCHAR2,
                            p_userid      NUMBER,
                            --出参
                            p_cursor          OUT C_CURSOR,
                            v_out_recordcount OUT NUMBER) RETURN INTEGER;


 ---分页获取登陆日志
FUNCTION GetLoginLogList(
                            pagesize      NUMBER,
                            pageindex     NUMBER,
                            p_username    VARCHAR2,
                            p_loginip     VARCHAR2,
                            p_flag        NUMBER,
                            p_status      NUMBER,
                            p_starttime   VARCHAR2,
                            p_endtime     VARCHAR2,
                            p_systemid    NUMBER,
                            p_userid      NUMBER,
                            --出参
                            p_cursor          OUT C_CURSOR,
                            v_out_recordcount OUT NUMBER) RETURN INTEGER;

--操作恢复
FUNCTION OperUndo(
    p_logid NUMBER,
    p_operid NUMBER
) RETURN INTEGER;

--操作恢复按信息ID
FUNCTION OperUndoById(
    p_dataid NUMBER,
    p_op_code NUMBER,
    p_operid NUMBER
) RETURN INTEGER;

--策略重发操作
FUNCTION PolicyResend(
    p_dataid NUMBER,
    p_op_code NUMBER,
    p_operid NUMBER
) RETURN INTEGER;

--流量镜像策略重发
FUNCTION PolicyMirrorResend(
    p_dataid NUMBER,
    p_op_code NUMBER
) RETURN INTEGER;

--部分设备策略重发操作
FUNCTION PolicyResendPart(
    p_dataid in NUMBER,
    p_op_code in NUMBER,
    p_operid in NUMBER,
    v_msgtype out NUMBER,
    n_message_no out NUMBER,
    p_logid  out number
) RETURN INTEGER;


--部分设备策略重发操作-添加重发设备
FUNCTION AddClogIp(
    p_msgtype NUMBER,
    p_msgno   NUMBER,
    p_logid NUMBER,
    p_ip VARCHAR2
) RETURN INTEGER;

---分页获取策略下发状态
FUNCTION GetPolicyStatus(
                            pagesize      in NUMBER,
                            pageindex     in NUMBER,
                            p_dataid      in NUMBER,
                            p_op_code     in NUMBER,
                            p_status      in NUMBER,--0下发成功 1-下发失败
                            p_houseNo     VARCHAR2,
                            --出参
                            p_cursor          OUT C_CURSOR,
                            v_out_recordcount OUT NUMBER
)RETURN INTEGER;

---分页获取策略下发状态
FUNCTION GetMyPolicyStatus (
                            pagesize      in NUMBER,
                            pageindex     in NUMBER,
                            p_messageNo      in NUMBER,
                            p_messageType     in NUMBER,
                            p_status      in NUMBER,--0下发成功 1-下发失败
                            p_houseNo     VARCHAR2,
                            --出参
                            p_cursor          OUT C_CURSOR,
                            v_out_recordcount OUT NUMBER
)RETURN INTEGER;

--部分设备策略重发操作
FUNCTION PolicyMyResendPart(
    p_seqenceNo in NUMBER,
    p_messageNo  in NUMBER,
    p_messageType in NUMBER,
    p_op_code in NUMBER,
    p_operid in NUMBER,
    p_logid  out number
) RETURN INTEGER;
end PKG_LOGMANAGE_IDC;
/
