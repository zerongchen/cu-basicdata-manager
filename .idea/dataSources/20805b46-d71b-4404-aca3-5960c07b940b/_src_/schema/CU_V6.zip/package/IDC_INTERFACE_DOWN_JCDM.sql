CREATE package idc_interface_down_jcdm is

 --处理基础代码备案属性
 procedure DealJCDMbasx(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        );

 --处理基础代码代理类型
 procedure DealJCDMdllx(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        );

 --处理基础代码单位属性
 procedure DealJCDMdwsx(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        );

 --处理基础代码服务内容
 procedure DealJCDMfwnr(
       v_id in number,
       v_mc    in varchar2,
       v_fl in number,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        );

 --处理基础代码规则类型
 procedure DealJCDMgzlx(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        );

 --处理基础代码机房性质
 procedure DealJCDMjfxz(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        );

 --处理基础代码接入方式
 procedure DealJCDMjrfs(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        );

 --处理基础代码违法违规情况
 procedure DealJCDMwfwgqk(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        );

 --处理基础代码证件类型
 procedure DealJCDMzjlx(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        );

--处理基础代码域名子分类信息
 procedure DealJCDMurlcontent(
       v_id    in number,
       v_mc    in varchar2,
       v_fl    in number,
       v_bz    in varchar2,
       v_sfyx  in number,
       --出参
       v_out_success    out number
       );

--处理基础代码网络应用/协议信息
 procedure DealJCDMproapp(
       v_id    in number,
       v_mc    in varchar2,
       v_bz    in varchar2,
       v_type  in number,
       v_sfyx  in number,
       --出参
       v_out_success    out number
       );

--处理基础代码应用服务类型信息
 procedure DealJCDMyyfwlx(
       v_id    in number,
       v_mc    in varchar2,
       v_bz    in varchar2,
       v_sfyx  in number,
       --出参
       v_out_success    out number
       );

--处理基础代码前置审批
 procedure DealJCDMqzsp(
       v_id    in number,
       v_mc    in varchar2,
       v_bz    in varchar2,
       v_sfyx  in number,
       --出参
       v_out_success    out number
       );

end idc_interface_down_jcdm;
/
