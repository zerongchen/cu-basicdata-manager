CREATE package IDC_ISMS_BASE_USER_MANAGE is
   procedure prelist_user_information(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_nature in NUMBER,
            p_unitName in VARCHAR2,
            p_userCode in VARCHAR2,
            p_unitNature in number,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            p_officerName in VARCHAR2,
            p_officerIdType in NUMBER,
            p_officerId in VARCHAR2,
            p_officerTelephone in VARCHAR2,
            p_officerMobile in VARCHAR2,
            p_officerEmail in VARCHAR2,
            p_unitAddress in VARCHAR2,
            p_unitZipCode in varchar2,
            p_registeTimeS in VARCHAR2,
            p_registeTimeE in VARCHAR2,
            p_serviceRegTimeS in VARCHAR2,
            p_serviceRegTimeE in VARCHAR2,
            p_otherCondition in varchar2,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_czlx in number,
            p_userLevel in number,
            p_identify in number,
            p_houseId  in varchar2
   );
   procedure list_user_information(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_nature in NUMBER,
            p_unitName in VARCHAR2,
            p_userCode in VARCHAR2,
            p_unitNature in number,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            p_officerName in VARCHAR2,
            p_officerIdType in NUMBER,
            p_officerId in VARCHAR2,
            p_officerTelephone in VARCHAR2,
            p_officerMobile in VARCHAR2,
            p_officerEmail in VARCHAR2,
            p_unitAddress in VARCHAR2,
            p_unitZipCode in varchar2,
            p_registeTimeS in VARCHAR2,
            p_registeTimeE in VARCHAR2,
            p_serviceRegTimeS in VARCHAR2,
            p_serviceRegTimeE in VARCHAR2,
            p_otherCondition in varchar2,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_czlx in number,
            p_userLevel in number,
            p_identify in number,
            p_houseId  in varchar2,
            p_infoComplete in varchar2
   );

   --用户查询列表的数据查询
         procedure user_query_list_information(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_nature in NUMBER,
            p_unitName in VARCHAR2,
            p_unitNature in VARCHAR2,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            p_officerName in VARCHAR2,
            p_officerIdType in NUMBER,
            p_officerId in VARCHAR2,
            p_officerTelephone in VARCHAR2,
            p_officerMobile in VARCHAR2,
            p_officerEmail in VARCHAR2,
            p_unitAddress in VARCHAR2,
            p_unitZipCode in NUMBER,
            p_registeTime in VARCHAR2,
            p_otherCondition in varchar2 --其它而外的查询条件
            
         );

   procedure prelist_user_service_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_userId in NUMBER,
            p_serviceContent in VARCHAR2,
            p_unitName in VARCHAR2,
            p_business in NUMBER,
            p_domainName in varchar2,
            p_registerId in VARCHAR2,
            p_setmode in NUMBER,
            p_otherCondition in varchar2,
            p_delFlag in number,
            p_dealFlag in number,
            p_userHouseIDStrs in varchar2,
            p_userLevel in number,
            p_houseId in varchar2
   );
   
   procedure list_user_service_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_userId in NUMBER,
            p_serviceContent in VARCHAR2,
            p_unitName in VARCHAR2,
            p_business in NUMBER,
            p_domainName in varchar2,
            p_registerId in VARCHAR2,
            p_setmode in NUMBER,
            p_otherCondition in varchar2,
            p_delFlag in number,
            p_dealFlag in number,
            p_userHouseIDStrs in varchar2,
            p_userLevel in number,
            p_houseId in varchar2
   );
   
   procedure list_user_service_infor_new(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_userId in NUMBER,
            p_serviceContent in VARCHAR2,
            p_registerId in VARCHAR2,
            p_setmode in NUMBER,
            p_otherCondition in varchar2,
            p_delFlag in number
   );


   --用户服务的查询列表的数据查询
   procedure user_service_query_list(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_userId in NUMBER,
            p_serviceContent in VARCHAR2,
            p_registerType in NUMBER,
            p_registerId in VARCHAR2,
            p_setmode in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
   );
   
   --服务ip的查询列表的数据查询
   procedure service_ip_query_list(
            -- 入参，分页参数
            p_isPaging        in number, --是否分页，如果不分页返回全部数据
            p_pageIndex       in number, --页索引
            p_pageSize        in number, --页大小
            p_isCount         in number, 
            p_sortName        in varchar2, 
            p_sortOrder       in varchar2, 
            --输出
            p_cursor          out sys_refcursor, 
            p_recordCount     out number, 
            --入参，查询参数
            p_unitName        in varchar2, 
            p_regId           in varchar2, 
            p_business        in number,
            p_houseName       in varchar2, 
            p_internetStartIP in varchar2, 
            p_internetEndIP   in varchar2, 
            p_netStartIP      in varchar2, 
            p_netEndIP        in varchar2, 
            p_userHouseIDStrs in varchar2, 
            p_delFlag         in number,
            p_areaCode in varchar2,
            p_userLevel in number
   );
   
   --用户ip的查询列表的数据查询
   procedure user_ip_query_list (
            -- 入参，分页参数
            p_isPaging        in number, --是否分页，如果不分页返回全部数据
            p_pageIndex       in number, --页索引
            p_pageSize        in number, --页大小
            p_isCount         in number, 
            p_sortName        in varchar2, 
            p_sortOrder       in varchar2, 
            --输出
            p_cursor          out sys_refcursor, 
            p_recordCount     out number, 
            --入参，查询参数
            p_unitName        in varchar2, 
            p_houseName       in varchar2, 
            p_startIP         in varchar2, 
            p_endIP           in varchar2, 
            p_userHouseIDStrs in varchar2, 
            p_delFlag         in number,
            p_areaCode in varchar2,
            p_userLevel in number
   ); 
     procedure preuser_ip_query_list (
            -- 入参，分页参数
            p_isPaging        in number, --是否分页，如果不分页返回全部数据
            p_pageIndex       in number, --页索引
            p_pageSize        in number, --页大小
            p_isCount         in number, 
            p_sortName        in varchar2, 
            p_sortOrder       in varchar2, 
            --输出
            p_cursor          out sys_refcursor, 
            p_recordCount     out number, 
            --入参，查询参数
            p_unitName        in varchar2, 
            p_houseName       in varchar2, 
            p_startIP         in varchar2, 
            p_endIP           in varchar2, 
            p_userHouseIDStrs in varchar2, 
            p_delFlag         in number,
            p_areaCode in varchar2,
            p_userLevel in number
   );  
   --虚拟主机信息的查询列表的数据查询
   procedure virtual_host_query_list(
            --入参，分页参数
            p_isPaging        in number, --是否分页，如果不分页返回全部数据
            p_pageIndex       in number, --页索引
            p_pageSize        in number, --页大小
            p_isCount         in number, 
            p_sortName        in varchar2, 
            p_sortOrder       in varchar2, 
            --输出
            p_cursor          out sys_refcursor, 
            p_recordCount     out number,
            --入参，查询参数
            p_unitName        in varchar2, 
            p_regId           in varchar2, 
            p_business        in number,
            p_houseName       in varchar2, 
            p_hostName        in varchar2, 
            p_networkAddress  in varchar2, 
            p_status          in number, 
            p_type            in number, 
            p_mgnAddress      in varchar2,
            p_userHouseIDStrs in varchar2, 
            p_delFlag         in number,
            p_areaCode        in varchar2,
            p_userLevel       in number
   );

   procedure previrtual_host_query_list(
            --入参，分页参数
            p_isPaging        in number, --是否分页，如果不分页返回全部数据
            p_pageIndex       in number, --页索引
            p_pageSize        in number, --页大小
            p_isCount         in number, 
            p_sortName        in varchar2, 
            p_sortOrder       in varchar2, 
            --输出
            p_cursor          out sys_refcursor, 
            p_recordCount     out number,
            --入参，查询参数
            p_unitName        in varchar2, 
            p_regId           in varchar2, 
            p_business        in number,
            p_houseName       in varchar2, 
            p_hostName        in varchar2, 
            p_networkAddress  in varchar2, 
            p_status          in number, 
            p_type            in number, 
            p_mgnAddress      in varchar2,
            p_userHouseIDStrs in varchar2, 
            p_delFlag         in number,
            p_areaCode        in varchar2,
            p_userLevel       in number
   );
   
   procedure preservice_hh_frame_query_list(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_unitName        in varchar2, 
            p_houseName       in varchar2, 
            p_frameName         in varchar2, 
            p_userHouseIDStrs in varchar2,
            p_areaCode in varchar2,
            p_userLevel in number
   );   
   procedure service_hh_frame_query_list(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_unitName        in varchar2, 
            p_houseName       in varchar2, 
            p_frameName         in varchar2, 
            p_userHouseIDStrs in varchar2,
            p_areaCode in varchar2,
            p_userLevel in number
   );
   procedure prelist_house_occupancy_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_unitName in VARCHAR2,
            p_houseId in VARCHAR2,
            p_beginDistributeTime in VARCHAR2,
            p_endDistributeTime in VARCHAR2,
            p_bandWidth in NUMBER,
            p_otherCondition in varchar2,
            p_areaCode in varchar2,
            p_userLevel in number,
            p_delFlag in number,
            p_houseIds in varchar2
   );
   procedure list_house_occupancy_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_unitName in VARCHAR2,
            p_houseId in number,
            p_beginDistributeTime in VARCHAR2,
            p_endDistributeTime in VARCHAR2,
            p_bandWidth in NUMBER,
            p_otherCondition in varchar2,
            p_areaCode in varchar2,
            p_userLevel in number,
            p_delFlag in number,
            p_houseIds in varchar2
   );

   --用户占用的机房查询列表的数据查询
   procedure hh_query_list (
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_userId in NUMBER,
            p_distributeTime in VARCHAR2,
            p_bandWidth in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
   );

   procedure list_hh_ipSegment_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_hhId in NUMBER,
            p_startIP in varchar2,
            p_endIP in varchar2,
            p_otherCondition in varchar2,
            p_delFlag in number
   );

   --用户占用机房的ip地址段查询列表的数据查询
   procedure hh_ipSegment_query_list(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_hhId in NUMBER,
            p_userId in NUMBER,
            p_startIP in NUMBER,
            p_endIP in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
   );

   procedure list_service_domain_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_serviceId in NUMBER,
            p_userId in NUMBER,
            p_domainName in VARCHAR2,
            p_otherCondition in varchar2,
            p_delFlag in number
   );

   --服务域名的查询列表的数据查询
   procedure service_domain_query_list (
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_serviceId in NUMBER,
            p_userId in NUMBER,
            p_domainName in VARCHAR2,
            p_otherCondition in varchar2 --其它而外的查询条件
   );

   procedure list_service_hh_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_serviceId in NUMBER,
            p_houseId in number,
            --p_nodeNo in varchar2,
            p_beginDistributeTime in VARCHAR2,
            p_endDistributeTime in VARCHAR2,
            p_bandWidth in NUMBER,
            --p_business in number,
            p_otherCondition in varchar2,
            p_delFlag in number
   );

   --服务占用机房的查询列表的数据查询
   procedure service_hh_query_list (
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_serviceId in NUMBER,
            p_userId in NUMBER,
            p_distributeTime in VARCHAR2,
            p_bandWidth in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
   );

   procedure list_service_hh_trans_infor(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_hhId in NUMBER,
            p_internetStartIP in varchar2,
            p_internetEndIP in varchar2,
            p_netStartIP in varchar2,
            p_netEndIP in varchar2,
            p_otherCondition in varchar2,
            p_delFlag in number
   );

   --ip地址转换的查询列表的数据查询
   procedure service_hh_trans_query_list (
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_hhId in NUMBER,
            p_serviceId in NUMBER,
            p_userId in NUMBER,
            p_internetStartIP in NUMBER,
            p_internetEndIP in NUMBER,
            p_netStartIP in NUMBER,
            p_netEndIP in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
   );

    procedure del_user_hh_information(
            p_hhId in varchar2,
            --出参
            v_out_success out number
   );

   procedure delete_user_hh_information(
            p_hhId in varchar2,
            --出参
            v_out_success out number
   );
   procedure del_service_hh_information(
            p_hhId   in varchar2,
            --出参
            v_out_success    out number
   );

   procedure delete_service_hh_information(
            p_hhId   in varchar2,
            --出参
            v_out_success    out number
   );
   
   procedure del_serv_domain_information(
                p_domainId in varchar2,
                --出参
                v_out_success out number
           );

   procedure delete_serv_domain_information(
                p_domainId in varchar2,
                --出参
                v_out_success out number
           );

   procedure delete_service_virtual_infor(
            p_virtualId in varchar2,
            --出参
            v_out_success out number
         );

    procedure del_service_hh_iptrans(
         p_iptransId in varchar2,
         v_out_success out number
    );
    procedure del_service_information(
            p_serviceId in varchar2,
            --出参
            v_out_success out number
   );
   
   
   procedure delete_service_ip_infomation(
             p_iptransId     in number, 
             p_hhId          in number, 
             p_statusCode    out varchar2, 
             p_message       out varchar2 
   );
   
   procedure check_batch_del_service_ip(
             p_hhId          in number, 
             p_count_iptransId     in number, 
             p_isCan         out varchar2
   ); 
   
   procedure check_batch_del_user_ip(
             p_hhId          in number, 
             p_count_ipsegId     in number, 
             p_isCan         out varchar2
   ); 
   
   procedure batchDel_service_ip_infor(
             p_iptransIds    in varchar2,
             p_statusCode    out varchar2, 
             p_message       out varchar2
   );
   
   procedure batchDel_user_ip_infor(
             p_ipsegIds      in varchar2,
             p_statusCode    out varchar2, 
             p_message       out varchar2
   );
   
   procedure batchDelete_virtual_host_info(
             p_virtualIds    in varchar2, 
             p_statusCode    out varchar2, 
             p_message       out varchar2
   );
   
   procedure batchDel_service_hh_frame_info(
             p_frameIds    in varchar2, 
             p_statusCode    out varchar2, 
             p_message       out varchar2
   );
   
   procedure delete_user_ip_information(
             p_ipsegId       in number, 
             p_hhId          in number, 
             p_statusCode    out varchar2, 
             p_message       out varchar2
   );
   
   procedure del_service_ip(
             p_iptransId     in varchar2, 
             p_statusCode    out varchar2, 
             p_message       out varchar2 
   );
   
   procedure del_user_ip(
             p_ipsegId       in varchar2, 
             p_statusCode    out varchar2, 
             p_message       out varchar2 
   ); 
   
   procedure del_virtual_host(
             p_virtualId    in varchar2, 
             p_statusCode    out varchar2, 
             p_message       out varchar2 
   );
   
   procedure delete_virtual_host_info(
             p_virtualId     in varchar2, 
             p_statusCode    out varchar2, 
             p_message       out varchar2
   );

   procedure delete_service_information(
            p_serviceId in varchar2,
            --出参
            v_out_success out number
   );
    procedure del_user_information(
            p_userId in varchar2,
            --出参
            v_out_success out number
   );

   procedure delete_user_information(
            p_userId in varchar2,
         --   p_nature in number,
            --出参
            v_out_success out number
   );

   procedure delete_user_information(
            p_userId in varchar2,
            p_temp in number, --用于重载，没有实际意义
            --出参
            v_out_success out number
   );
   
     procedure delete_user_information_nature(
            p_nature in number,
            --出参
            v_out_success out number
   );
   
   procedure del_user_information_nature(
            p_nature in number,
            --出参
            v_out_success out number
   );

   procedure del_user_hh_ipseg(
             p_ipsegId in varchar2,
             v_out_success out number
   );

   --增加其它用户占用机房信息
   procedure insert_user_hh_information(
             p_userId in number,
             p_houseId in number,
             p_distributeTime in varchar2,
             p_bandWidth in number,
             p_opeType in number,
             p_dealFlag in number,
             p_createUserId in number,
             p_frameIds in varchar2,
             p_areaCode in varchar2,
             p_hhId out number
   );

    --修改其它用户占用机房信息
    procedure update_user_hh_information(
             p_hhId in number,
             p_houseId in number,
             p_distributeTime in varchar2,
             p_bandWidth in number,
             p_frameIds in varchar2,
             p_areaCode in varchar2
   );
   
   procedure insert_service_hh_frame_info(
            p_houseId in number,
            p_frameIds in varchar2,
            p_unitName in varchar2
   );

   --增加服务用户占用机房信息
   procedure insert_service_hh_information(
             p_userId in number,
             p_serviceId in number,
             p_houseId in number,
             --p_nodeNo in varchar2,
             p_distributeTime in varchar2,
             p_bandWidth in number,
             p_opeType in number,
             p_dealFlag in number,
             p_createUserId in number,
             p_frameIds in varchar2,
             p_hhId out number,
             p_areaCode in varchar2
             --p_business in number
   );

    --修改服务用户占用机房信息
    procedure update_service_hh_information(
             p_hhId in number,
             p_houseId in number,
             p_distributeTime in varchar2,
             p_bandWidth in number,
             p_frameIds in varchar2
   );

    procedure list_service_hh_virtual_info(

            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_hhID in number,
            p_virtualNo in varchar2,
            p_name in varchar2,
            p_status in number,
            p_type in number,
            p_delFlag in number
         );

     procedure recover_HHIPSeg_information(
            p_ipsegId in varchar2,
            --出参
            v_out_success out number
     );

      procedure recover_user_hh_information(
            p_hhId in varchar2,
            --出参
            v_out_success out number
     );

      procedure recover_service_hh_iptrans(
            p_ipTransId in varchar2,
            --出参
            v_out_success out number
     );

      procedure recover_virtual_host(
            p_virtualId in varchar2,
            --出参
            v_out_success out number
     );

      procedure recover_service_hh(
            p_hhId in varchar2,
            --出参
            v_out_success out number
     );

      procedure recover_service_domain(
            p_domainId in varchar2,
            --出参
            v_out_success out number
     );

     procedure recover_user_service(
            p_serviceId in varchar2,
            --出参
            v_out_success out number
     );

      procedure recover_user_information(
            p_userId in varchar2,
            --出参
            v_out_success out number
     );
     
     procedure recover_user_information_new(
            p_userId in varchar2,
         --   p_nature in number,
            --出参
            v_out_success out number
   );
   procedure updateStatus_user_information(
            p_userId in varchar2,
         --   p_nature in number,
            --出参
            v_out_success out number
   );
     --更新导入,修改其它用户占用机房信息
    procedure update_imp_user_hh_information(
             p_userId in number,
             p_houseId in number,
             p_distributeTime in varchar2,
             p_bandWidth in number,
             p_opeType in number,
             p_dealFlag in number,
             p_createUserId in number   
   );
   
   
   procedure update_imp_user_service(
             p_userId in number,
             p_serviceContent in varchar2,
             p_regId in varchar2,
             p_serviceType in number,
             p_setmode in number,
             p_business in number,
             p_opeType in number,
             p_dealFlag in number,
             p_createUserId in number   
   );
   
    procedure update_imp_service_hh(
             p_houseId in number,
             p_serviceId in varchar2,
             p_userId in varchar2,
             p_distributeTime in varchar2,
             p_bandWidth in number,
             p_opeType in number,
             p_dealFlag in number,
             p_createUserId in number, 
             p_areaCode in varchar2
   );
  
  procedure update_user_deal_flag(  
            p_userCode in varchar2,
            --出参
            v_out_success out number
  );
  
  -- 修改服务ip信息
  procedure update_service_ip_information(
             p_hhId               in number, 
             p_houseId            in number,
             p_distributeTime     in varchar2, 
             p_bandWidth          in number, 
             p_iptransId          in number, 
             p_selIpTrans         in number, 
             p_internetStartIP    in varchar2, 
             p_internetStartIPStr in varchar2, 
             p_internetEndIP      in varchar2,
             p_internetEndIPStr   in varchar2,
             p_netStartIP         in varchar2,
             p_netStartIPStr      in varchar2,
             p_netEndIP           in varchar2,
             p_netEndIPStr        in varchar2
   );
   
   -- 修改用户ip信息
   procedure update_user_ip_information(
             p_hhId               in number, 
             p_houseId            in number,
             p_distributeTime     in varchar2, 
             p_bandWidth          in number, 
             p_ipsegId            in number, 
             p_selIpTrans         in number,
             p_startIP            in varchar2, 
             p_startIPStr         in varchar2, 
             p_endIP              in varchar2,
             p_endIPStr           in varchar2
   );
   
   -- 修改虚拟主机信息
   procedure update_virtual_host_infor(
             p_hhId                 in number, 
             p_houseId              in number, 
             p_distributeTime       in varchar2, 
             p_bandWidth            in number, 
             p_virtualId            in number, 
             p_virtualNo            in varchar2, 
             p_virtualhostName      in varchar2, 
             p_networkAddress       in varchar2, 
             p_virtualhostState     in number, 
             p_virtualhostType      in number, 
             p_mgnAddress           in varchar2,
             p_userId               in number
   );
   
   procedure update_service_hh_frame_infor(
             p_houseId              in number, 
             p_frameId              in number, 
             p_hhId                 in number, 
             p_id                   in number
   );
  
   procedure delete_user_infor_nocommit(
            p_userId in varchar2,
            --出参
            v_out_success out number
   );
   
   procedure delete_user_hh_infor_nocommit(
            p_hhId in varchar2,
            --出参
            v_out_success out number
   );
   
   procedure delete_service_infor_nocommit(
                p_serviceId in varchar2,
                --出参
                v_out_success out number
   );
   
   procedure delete_service_hh_nocommit(
                p_hhId   in varchar2,
                --出参
                v_out_success    out number
   );

   procedure delete_service_vir_nocommit(
            p_virtualId in varchar2,
            --出参
            v_out_success out number
   );
   
   procedure delete_user_hh_ipseg_nocommit(
               p_ipsegId in varchar2,
               v_out_success out number
   );
   
   -- 处理用户表的地址，讲unitAdd字段转化为省份code，省份name，市code，市name，县code，县name，详细地址
   procedure processUnitAdd;
   
   -- 通过地址的name获取地址的code
   procedure getAddCodeByAddName(
     p_unitAddAreaName in varchar2, 
     p_result out varchar2
   ); 
   
   -- SERVICE_HH_FRAME中间表转化为USER_FRAME中间表
   procedure convServiceHHFrameToUserFrame;

end IDC_ISMS_BASE_USER_MANAGE;
/
