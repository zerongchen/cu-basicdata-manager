CREATE package idc_isms_command_level is

  -- Created : 2014/10/14 20:45:24
  -- Purpose : 指令优先级的处理包
  -- Created by : Jason.cw.Cheung

  --处理有优先级高的指令
  procedure dealCommandWithLevel (
       p_commandId           in  number,          --指令id
       p_subType             in   number,         --规则类型
       p_valueStart          in   varchar2,       --规则起始值
       p_valueStartStr       in   varchar2,       --ip规则时，表示起始ip地址的十进制数据
       p_valueEndStr         in   varchar2,       --ip规则时，表示结束ip地址的十进制数据
       p_commandLevel        in   number,         --指令优先级
       p_commandType         in   number,         --信息安全管理指令类型；1—监测指令、2—过滤指令
       p_type                in   number,         --指令类容类型(违法违规网站列表、免过滤网站列表必填)
       p_contents            in   varchar2,       --指令内容 (违法违规网站列表、免过滤网站列表必填)
       p_ip_str              in   varchar2,       --ip地址时，传入此ip地址转换后的十进制数据，支持IPv6
       --出参
       v_unbund_flag         out  number,         --解绑策略的输出标志
       v_out_success         out number
     );

  --免过滤网站列表指令优先级的处理
  procedure dealNoFilterWithLevel (
       p_type            in number,   --指令类容类型(违法违规网站列表、免过滤网站列表必填)
       p_contents        in varchar2, --指令内容 (违法违规网站列表、免过滤网站列表必填)
       p_ip_str          in varchar2, --ip地址时，传入此ip地址转换后的十进制数据，支持IPv6
       --出参
       v_unbund_flag     out  number, --解绑策略的输出标志
       v_out_success     out number
     );

  --违法信息过滤指令优先级的处理
  procedure dealFilterWithLevel (
       p_cmdId               in   number,  --管局下发的指令id
       p_subType             in   number,  --指令规则类型
       p_valueStart          in   varchar2,--规则起始值
       p_valueStartStr       in   varchar2,--ip规则时，表示起始ip地址的十进制数据
       p_valueEndStr         in   varchar2,--ip规则时，表示结束ip地址的十进制数据
       p_commandLevel        in   number,  --指令的优先级
       v_unbund_flag         out  number,  --解绑策略的输出标志
       v_out_success         out  number   --成功标志
    );

  --违法信息监测指令优先级的处理
  procedure dealMonitorWithLevel (
       p_cmdId               in   number,
       p_subType             in   number,
       p_valueStart          in   varchar2,
       p_valueStartStr       in   varchar2,
       p_valueEndStr         in   varchar2,
       p_commandLevel        in   number,
       v_unbund_flag         out  number,
       v_out_success         out  number
    );

  --判断策略规则是否存在
  procedure judgeExists(
	     p_cmdType	           in   number,
	     p_type				         in   number,--免过滤指令idc_isms_cmd_no_filter(1)或策略表idc_isms_monitor_policy(2)的标志
	     p_subType             in   number,
       p_valueStart          in   varchar2,
       p_valueStartStr       in   varchar2,
       p_valueEndStr         in   varchar2,
	     v_out_count	         out  number
  );

  --更新策略的状态
  procedure updatePolicyState(
	     p_cmdId               in   number,
	     p_cmdType			       in   number,
       p_subType             in   number,
       p_valueStart          in   varchar2,
       p_valueStartStr       in   varchar2,
       p_valueEndStr         in   varchar2,
       v_out_success         out  number
  );

  --解绑策略
  procedure unbundPolicy(
	     p_cmdId			         in   number,
	     p_cmdType			       in   number,
       p_subType             in   number,
       p_valueStart          in   varchar2,
       p_valueStartStr       in   varchar2,
       p_valueEndStr         in   varchar2,
       p_commandLevel        in   number,
       v_out_success         out  number
    );

end idc_isms_command_level;
/
