CREATE package body IDC_ISMS_BASE_BASIC_MANAGE is
       /*procedure change_cancel_operation(
          p_jyzid   in NUMBER,
          p_userId  in NUMBER,
          p_houseId  in NUMBER,
          p_gatewayId  in NUMBER,
          p_ipSegId  in NUMBER,
          p_userHHId  in NUMBER,
          p_serviceId  in NUMBER,
          p_domainId  in NUMBER,
          p_serviceHHId  in NUMBER,
          p_isChangeOrCancel  in NUMBER,
          --出参
          v_out_success    out number
       ) as
       v_operationType number(10);
       v_count number(10);
       begin
         v_count := 0;
         if(p_isChangeOrCancel = 1) then
            v_operationType := 1;
         else
            v_operationType := 1;
         end if;
         if(p_jyzid is not null) then
            select count(1) into v_count from idc_isms_base_idc idc where idc.jyzid = (select jyzid from idc_hist_base_idc where histId = p_jyzid);
            if(v_count = 1) then
                delete idc_isms_base_idc idc where idc.jyzid = (select jyzid from idc_hist_base_idc where histId = p_jyzid);
            end if;
            insert into idc_isms_base_idc
              (jyzid, idcid, idcname, idcadd, idczip, corp, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, ec_name, ec_idtype, ec_id, ec_tel, ec_mobile, ec_email, czlx, deal_flag, create_time, update_time, create_userid)
            select
              jyzid, idcid, idcname, idcadd, idczip, corp, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, ec_name, ec_idtype, ec_id, ec_tel, ec_mobile, ec_email, v_operationType, 0, create_time, update_time, create_userid
            from idc_hist_base_idc
            where histid = p_jyzid;
            delete idc_hist_base_idc where histid = p_jyzid;
         end if;
         if (p_userId is not null) then
            select count(1) into v_count from idc_isms_base_user idc_user where idc_user.userid = (select userid from idc_hist_base_user where histId = p_jyzid);
            if(v_count = 1) then
                delete idc_isms_base_user idc_user where idc_user.userid = (select userid from idc_hist_base_user where histId = p_jyzid);
            end if;
            insert into idc_isms_base_user
              (userid, jyzid, nature, unitname, unitnature, idtype, idnumber, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, unitadd, zipcode, registertime, czlx, deal_flag, create_time, update_time, create_userid)
            select
              userid, jyzid, nature, unitname, unitnature, idtype, idnumber, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, unitadd, zipcode, registertime, v_operationType, 0, create_time, update_time, create_userid
            from idc_hist_base_user idc_user
            where idc_user.histid = p_userId;
            delete idc_hist_base_user where histId = p_userId;
         end if;
         if (p_houseId is not null) then
            select count(1) into v_count from idc_isms_base_house house where house.houseid = (select houseid from idc_hist_base_house where histid=p_houseId);
            if(v_count = 1) then
                delete idc_isms_base_house house where house.houseid = (select houseid from idc_hist_base_house where histid=p_houseId);
            end if;
            insert into idc_isms_base_house
               (houseid, jyzid, houseidstr, housename, housetype, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype, ho_id, ho_tel, ho_mobile, ho_email, czlx, deal_flag, create_time, update_time, create_userid)
            select
               houseid, jyzid, houseidstr, housename, housetype, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype, ho_id, ho_tel, ho_mobile, ho_email, v_operationType, 0, create_time, update_time, create_userid
            from idc_hist_base_house house
            where house.histid = p_houseId;
            delete idc_hist_base_house where histid = p_houseId;
         end if;
         if(p_gatewayId is not null) then
            select count(1) into v_count from idc_isms_base_house_gateway house_gateway where house_gateway.gatewayid = (select gatewayid from idc_hist_base_house_gateway where histId=p_gatewayId);
            if(v_count = 1) then
                delete idc_isms_base_house_gateway house_gateway where house_gateway.gatewayid = (select gatewayid from idc_hist_base_house_gateway where histId=p_gatewayId);
            end if;
            insert into idc_isms_base_house_gateway
              (gatewayid, bandwidth, gatewayip, houseid, czlx, deal_flag, create_time, update_time)
            select
              gatewayid, bandwidth, gatewayip, houseid, v_operationType, 0, create_time, update_time
            from idc_hist_base_house_gateway house_gateway
            where house_gateway.histid = p_gatewayId;
            delete idc_hist_base_house_gateway where histid = p_gatewayId;
         end if;
         if(p_ipSegId is not null) then
            select count(1) into v_count from idc_isms_base_house_ipseg house_ipseg where house_ipseg.ipsegid = (select ipsegid from idc_hist_base_house_ipseg where histid= p_ipSegId);
            if(v_count = 1) then
                delete idc_isms_base_house_ipseg house_ipseg where house_ipseg.ipsegid = (select ipsegid from idc_hist_base_house_ipseg where histid= p_ipSegId);
            end if;
            insert into idc_isms_base_house_ipseg
              (ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, czlx, deal_flag, create_time, update_time)
            select
              ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, v_operationType, 0, create_time, update_time
            from idc_hist_base_house_ipseg house_ipseg
            where house_ipseg.histid = p_ipSegId;
            delete idc_hist_base_house_ipseg where histid = p_ipSegId;
         end if;
         if(p_userHHId is not null) then
            select count(1) into v_count from idc_isms_base_user_hh user_hh where user_hh.hhid =(select hhid from idc_hist_base_user_hh where histid=p_userHHId);
            if(v_count = 1) then
                delete idc_isms_base_user_hh where hhid = (select hhid from idc_hist_base_user_hh where histid=p_userHHId);
            end if;
            insert into idc_isms_base_user_hh
              (hhid, houseid, distributetime, bandwidth, userid, czlx, deal_flag, create_time, update_time)
            select
              hhid, houseid, distributetime, bandwidth, userid, v_operationType, 0, create_time, update_time
            from idc_hist_base_user_hh user_hh
            where user_hh.histid = p_userHHId;
            delete idc_hist_base_user_hh where histid = p_userHHId;
         end if;
         if(p_serviceId is not null) then
            select count(1) into v_count from idc_isms_base_user_service user_service where user_service.serviceid = (select serviceid from idc_hist_base_user_service where histid= p_serviceId);
            if(v_count = 1) then
                delete idc_isms_base_user_service where serviceid = (select serviceid from idc_hist_base_user_service where histid= p_serviceId);
            end if;
            insert into idc_isms_base_user_service
              (serviceid, servicecontent, regid, setmode, userid, czlx, deal_flag, create_time, update_time)
            select
              serviceid, servicecontent, regid, setmode, userid, v_operationType, 0, create_time, update_time
            from idc_hist_base_user_service user_service
            where user_service.histid = p_serviceId;
            delete idc_hist_base_user_service where histid = p_serviceId;
         end if;
         if(p_domainId is not null) then
            select count(1) into v_count from idc_isms_base_service_domain service_domain where service_domain.domainid = (select domainid from idc_hist_base_service_domain where histid = p_domainId);
            if(v_count = 1) then
                delete idc_isms_base_service_domain where domainid = (select domainid from idc_hist_base_service_domain where histid = p_domainId);
            end if;
            insert into idc_isms_base_service_domain
              (domainid, domainname, serviceid, czlx, deal_flag, userid, create_time, update_time)
            select
              domainid, domainname, serviceid, v_operationType, 0, userid, create_time, update_time
            from idc_hist_base_service_domain service_domain
            where service_domain.histid = p_domainId;
            delete idc_hist_base_service_domain where histid = p_domainId;
         end if;
         if (p_serviceHHId is not null) then
            select count(1) into v_count from idc_isms_base_service_hh service_hh where service_hh.hhid = (select hhid from idc_hist_base_service_hh where histid = p_serviceHHId);
            if(v_count = 1) then
                delete idc_isms_base_service_hh where hhid = (select hhid from idc_hist_base_service_hh where histid = p_serviceHHId);
            end if;
            insert into idc_isms_base_service_hh
              (hhid, houseid, distributetime, bandwidth, serviceid, czlx, deal_flag, userid, create_time, update_time)
            select
              hhid, houseid, distributetime, bandwidth, serviceid, v_operationType, 0, userid, create_time, update_time
            from idc_hist_base_service_hh service_hh
            where service_hh.histid = p_serviceHHId;
            delete idc_hist_base_service_hh where histid = p_serviceHHId;
         end if;
         exception when others then
            rollback;
            v_out_success := 0;
            return;
         commit;
         v_out_success:=1;
       end;*/

       procedure report_operation(
          p_jyzid   in NUMBER,
          p_userId  in NUMBER,
          p_houseId  in NUMBER,
          --p_gatewayId  in NUMBER,
          --p_ipSegId  in NUMBER,
          p_userHHId  in NUMBER,
          p_serviceId  in NUMBER,
          --p_domainId  in NUMBER,
          --p_serviceHHId  in NUMBER,
          --p_frameId in number,
          --出参
          v_out_success    out number
       ) as
       v_operationType number(10);
       begin
         v_operationType := 1;
         if(p_jyzid is not null) then
             --处理IDC上报
             update idc_isms_base_idc idc set idc.deal_flag = v_operationType, idc.update_time = sysdate where idc.jyzid = p_jyzid;
             --处理IDC下面机房信息上报
             update idc_isms_base_house idc_house set idc_house.deal_flag = v_operationType,idc_house.update_time = sysdate where idc_house.jyzid = p_jyzid;
             update idc_isms_base_house_gateway house_gateway set house_gateway.deal_flag = v_operationType,house_gateway.update_time = sysdate where house_gateway.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid);
             update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = v_operationType,house_ipseg.update_time = sysdate where house_ipseg.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid);
             update idc_isms_base_house_frame set deal_flag = v_operationType,update_time = sysdate where houseid in (select houseid from idc_isms_base_house where jyzid = p_jyzid);
             --处理IDC下面用户信息上报
             update idc_isms_base_user set deal_flag = v_operationType,update_time = sysdate where jyzid = p_jyzid;
             update idc_isms_base_user_hh set deal_flag = v_operationType,update_time = sysdate where userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
             update idc_isms_base_user_hh_ipseg set deal_flag = v_operationType,UPDATE_TIME = sysdate where userid in (select userid from idc_isms_base_user where jyzid = p_jyzid);
             update idc_isms_base_user_service set deal_flag = v_operationType,update_time = sysdate where userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
             update idc_isms_base_service_domain set deal_flag = v_operationType,update_time = sysdate where userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
             update idc_isms_base_service_hh set deal_flag = v_operationType,update_time = sysdate where userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
             update idc_isms_base_service_iptrans set deal_flag = v_operationType,update_time = sysdate where userid in (select userid from idc_isms_base_user where jyzid = p_jyzid);
             update idc_isms_base_service_virtual set deal_flag = v_operationType,update_time = sysdate where userid in (select userid from idc_isms_base_user where jyzid = p_jyzid);
         end if;
         if (p_userId is not null) then
             --处理用户上报
             update idc_isms_base_user idc_user set deal_flag = v_operationType,update_time = sysdate where idc_user.userid = p_userId;
             update idc_isms_base_user_hh set deal_flag = v_operationType,update_time = sysdate where userid = p_userId;
             update idc_isms_base_user_hh_ipseg set deal_flag = v_operationType,update_time = sysdate where userid = p_userId;
             update idc_isms_base_user_service set deal_flag = v_operationType,update_time = sysdate where userid = p_userId;
             update idc_isms_base_service_domain set deal_flag = v_operationType,update_time = sysdate where userid = p_userId;
             update idc_isms_base_service_hh set deal_flag = v_operationType,update_time = sysdate where userid = p_userId;
             update idc_isms_base_service_iptrans set deal_flag = v_operationType,update_time = sysdate where userid = p_userId;
             update idc_isms_base_service_virtual set deal_flag = v_operationType,update_time = sysdate where userid = p_userId;
         end if;
         if (p_houseId is not null) then
             --处理IDC下面机房信息上报
             update idc_isms_base_house idc_house set idc_house.deal_flag = v_operationType,idc_house.update_time = sysdate where idc_house.houseid = p_houseId;
             update idc_isms_base_house_gateway house_gateway set house_gateway.deal_flag = v_operationType,house_gateway.update_time = sysdate where house_gateway.houseid = p_houseId;
             update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = v_operationType,house_ipseg.update_time = sysdate where house_ipseg.houseid = p_houseId;
             update idc_isms_base_house_frame set deal_flag = v_operationType,update_time = sysdate where houseid = p_houseId;
         end if;
         /*if(p_gatewayId is not null) then
             update idc_isms_base_house_gateway house_gateway set house_gateway.deal_flag = v_operationType,house_gateway.update_time = sysdate where house_gateway.gatewayid = p_gatewayId;
         end if;
         if(p_ipSegId is not null) then
             update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = v_operationType,house_ipseg.update_time = sysdate where house_ipseg.ipsegid = p_ipSegId;
         end if;
         if(p_frameId is not null) then
             update IDC_ISMS_BASE_HOUSE_FRAME set deal_flag = v_operationType,update_time = sysdate where FRAMEID = p_frameId;
         end if;*/
         --其它用户占用机房上报
         if (p_userHHId is not null) then
             update idc_isms_base_user_hh set deal_flag = v_operationType,update_time = sysdate where hhid = p_userHHId;
             update idc_isms_base_user_hh_ipseg set deal_flag = v_operationType,update_time = sysdate where hhid = p_userHHId;
         end if;
         --服务上报
         if (p_serviceId is not null) then
             update idc_isms_base_user_service set deal_flag = v_operationType,update_time = sysdate where serviceid = p_serviceId;
             update idc_isms_base_service_domain set deal_flag = v_operationType,update_time = sysdate where serviceid = p_serviceId;
             update idc_isms_base_service_hh set deal_flag = v_operationType,update_time = sysdate where serviceid = p_serviceId;
             update idc_isms_base_service_iptrans set deal_flag = v_operationType,update_time = sysdate where serviceid = p_serviceId;
             update idc_isms_base_service_virtual set deal_flag = v_operationType,update_time = sysdate where serviceid = p_serviceId;
         end if;
         /*if(p_domainId is not null) then
             update idc_isms_base_service_domain set deal_flag = v_operationType,update_time = sysdate where domainid = p_domainId;
         end if;
         if (p_serviceHHId is not null) then
             update idc_isms_base_service_hh set deal_flag = v_operationType,update_time = sysdate where hhid = p_serviceHHId;
         end if;*/
         exception when others then
            rollback;
            v_out_success := 0;
            return;
         commit;
         v_out_success:=1;
       end;

       procedure report_operation(
          p_jyzid   in varchar2,
          p_userId  in varchar2,
          p_houseId  in varchar2,
          p_userHHId  in varchar2,
          p_serviceId  in varchar2,
          p_reportType in number,
          --出参
          v_out_success    out number
       ) as
       v_operationType number(10) := 1;
       v_userIdCur sys_refcursor;
       v_houseIdCur sys_refcursor;
       v_userHHIdCur sys_refcursor;
       v_serviceIdCur sys_refcursor;
       v_userId idc_isms_base_user.userid%type;
       v_houseId idc_isms_base_house.houseid%type;
       v_userHHId idc_isms_base_user_hh.hhid%type;
       v_serviceId idc_isms_base_user_service.serviceid%type;
       begin
         if(p_jyzid is not null) then
             --修改上报类型
             update idc_isms_base_idc idc set idc.report_type = p_reportType, idc.update_time = sysdate where idc.jyzid = p_jyzid and idc.del_flag != 1;
             --修改上报状态
             update idc_isms_base_idc idc set idc.deal_flag = v_operationType, idc.update_time = sysdate where idc.jyzid = p_jyzid and idc.del_flag != 1 ;
             if p_reportType = 0 then
               --处理IDC上报
               --处理IDC下面机房信息上报
               update idc_isms_base_house idc_house set idc_house.deal_flag = v_operationType,idc_house.update_time = sysdate where idc_house.jyzid = p_jyzid and idc_house.del_flag != 1 ;
               update idc_isms_base_house_gateway house_gateway set house_gateway.deal_flag = v_operationType,house_gateway.update_time = sysdate where house_gateway.del_flag != 1  and house_gateway.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid);
               --update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = v_operationType,house_ipseg.update_time = sysdate where house_ipseg.del_flag != 1  and house_ipseg.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid);
               update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = v_operationType,house_ipseg.update_time = sysdate where house_ipseg.del_flag != 1 and house_ipseg.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid) and house_ipseg.ipsegid in (select v.ipsegid from idc_isms_base_house_ipseg_view v); 
               update idc_isms_base_house_frame set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and houseid in (select houseid from idc_isms_base_house where jyzid = p_jyzid);
               --处理IDC下面用户信息上报
               update idc_isms_base_user set deal_flag = v_operationType,update_time = sysdate where del_flag != 1 and jyzid = p_jyzid ;
               update idc_isms_base_user_hh set deal_flag = v_operationType,update_time = sysdate where del_flag != 1 and userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
               update idc_isms_base_user_hh_ipseg set deal_flag = v_operationType,UPDATE_TIME = sysdate where del_flag != 1 and userid in (select userid from idc_isms_base_user where jyzid = p_jyzid);
               update idc_isms_base_user_service set deal_flag = v_operationType,update_time = sysdate where del_flag != 1 and userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
               update idc_isms_base_service_domain set deal_flag = v_operationType,update_time = sysdate where del_flag != 1 and userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
               update idc_isms_base_service_hh set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
               update idc_isms_base_service_iptrans set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid in (select userid from idc_isms_base_user where jyzid = p_jyzid);
               update idc_isms_base_service_virtual set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid in (select userid from idc_isms_base_user where jyzid = p_jyzid);
             end if;
         end if;
         if (p_userId is not null) then
             open v_userIdCur for 'select USERID from IDC_ISMS_BASE_USER where USERID in (' || p_userId || ')';
             loop
               fetch v_userIdCur into v_userId;
               exit when v_userIdCur%notfound;
               --处理用户上报
               update idc_isms_base_user idc_user set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and idc_user.userid = v_userId;
               update idc_isms_base_user_hh set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_user_hh_ipseg set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_user_service set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_service_domain set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_service_hh set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_service_iptrans set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_service_virtual set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_idc set report_type = p_reportType where JYZID = (select JYZID from idc_isms_base_user where USERID = v_userId);
             end loop;
             close v_userIdCur;
         end if;
         if (p_houseId is not null) then
             open v_houseIdCur for 'select HOUSEID from IDC_ISMS_BASE_HOUSE where HOUSEID in (' || p_houseId || ')';
             loop
               fetch v_houseIdCur into v_houseId;
               exit when v_houseIdCur%notfound;
               --处理IDC下面机房信息上报
               update idc_isms_base_house idc_house set idc_house.deal_flag = v_operationType,idc_house.update_time = sysdate where idc_house.del_flag != 1  and idc_house.houseid = v_houseId;
               update idc_isms_base_house_gateway house_gateway set house_gateway.deal_flag = v_operationType,house_gateway.update_time = sysdate where house_gateway.del_flag != 1  and house_gateway.houseid = v_houseId;
               --update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = v_operationType,house_ipseg.update_time = sysdate where house_ipseg.del_flag != 1  and house_ipseg.houseid = v_houseId;
               update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = v_operationType,house_ipseg.update_time = sysdate where house_ipseg.del_flag != 1  and house_ipseg.houseid = v_houseId and house_ipseg.ipsegid in (select v.ipsegid from idc_isms_base_house_ipseg_view v);
               update idc_isms_base_house_frame set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and houseid = v_houseId;
               update idc_isms_base_idc set report_type = p_reportType where JYZID = (select JYZID from IDC_ISMS_BASE_HOUSE where HOUSEID = v_houseId);
             end loop;
             close v_houseIdCur;
         end if;
         --其它用户占用机房上报
         if (p_userHHId is not null) then
             open v_userHHIdCur for 'select HHID from IDC_ISMS_BASE_USER_HH where HHID in (' || p_userHHId || ')';
             loop
               fetch v_userHHIdCur into v_userHHId;
               exit when v_userHHIdCur%notfound;
               update idc_isms_base_user_hh set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and hhid = v_userHHId;
               update idc_isms_base_user_hh_ipseg set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and hhid = v_userHHId;
               update idc_isms_base_idc set report_type = p_reportType where JYZID = (select JYZID from idc_isms_base_user where USERID = (select USERID from IDC_ISMS_BASE_USER_HH where HHID = v_userHHId));
             end loop;
             close v_userHHIdCur;
         end if;
         --服务上报
         if (p_serviceId is not null) then
             open v_serviceIdCur for 'select SERVICEID from IDC_ISMS_BASE_USER_SERVICE where SERVICEID in (' || p_serviceId || ')';
             fetch v_serviceIdCur into v_serviceId;
             loop
               update idc_isms_base_user_service set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and serviceid = v_serviceId;
               update idc_isms_base_service_domain set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and serviceid = v_serviceId;
               update idc_isms_base_service_hh set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and serviceid = v_serviceId;
               update idc_isms_base_service_iptrans set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and serviceid = v_serviceId;
               update idc_isms_base_service_virtual set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and serviceid = v_serviceId;
               update idc_isms_base_idc set report_type = p_reportType where JYZID = (select JYZID from idc_isms_base_user where USERID = (select USERID from IDC_ISMS_BASE_USER_SERVICE where SERVICEID = v_serviceId));
             end loop;
             close v_serviceIdCur;
         end if;
         exception when others then
            rollback;
            v_out_success := 0;
            return;
         commit;
         v_out_success:=1;
       end;
       
       --撤销上报
      procedure cancelReport_operation(
          p_jyzid   in varchar2,
          p_userId  in varchar2,
          p_houseId  in varchar2,
          p_userHHId  in varchar2,
          p_serviceId  in varchar2,
          p_reportType in number,
          --出参
          v_out_success    out number
       ) as
       v_operationType number(10) := 0;
       v_userIdCur sys_refcursor;
       v_houseIdCur sys_refcursor;
       v_userHHIdCur sys_refcursor;
       v_serviceIdCur sys_refcursor;
       v_userId idc_isms_base_user.userid%type;
       v_houseId idc_isms_base_house.houseid%type;
       v_userHHId idc_isms_base_user_hh.hhid%type;
       v_serviceId idc_isms_base_user_service.serviceid%type;
       begin
         if(p_jyzid is not null) then
             --修改上报类型
             update idc_isms_base_idc idc set idc.report_type = p_reportType, idc.update_time = sysdate where idc.jyzid = p_jyzid and idc.del_flag != 1;
             --修改上报状态
             update idc_isms_base_idc idc set idc.deal_flag = v_operationType, idc.update_time = sysdate where idc.jyzid = p_jyzid and idc.del_flag != 1 ;
             if p_reportType = 0 then
               --处理IDC上报
               --处理IDC下面机房信息上报
               update idc_isms_base_house idc_house set idc_house.deal_flag = v_operationType,idc_house.update_time = sysdate where idc_house.jyzid = p_jyzid and idc_house.del_flag != 1 ;
               update idc_isms_base_house_gateway house_gateway set house_gateway.deal_flag = v_operationType,house_gateway.update_time = sysdate where house_gateway.del_flag != 1  and house_gateway.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid);
               --update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = v_operationType,house_ipseg.update_time = sysdate where house_ipseg.del_flag != 1  and house_ipseg.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid);
               update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = v_operationType,house_ipseg.update_time = sysdate where house_ipseg.del_flag != 1 and house_ipseg.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid) and house_ipseg.ipsegid in (select v.ipsegid from idc_isms_base_house_ipseg_view v); 
               update idc_isms_base_house_frame set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and houseid in (select houseid from idc_isms_base_house where jyzid = p_jyzid);
               --处理IDC下面用户信息上报
               update idc_isms_base_user set deal_flag = v_operationType,update_time = sysdate where del_flag != 1 and jyzid = p_jyzid and deal_flag = 0;
               update idc_isms_base_user_hh set deal_flag = v_operationType,update_time = sysdate where del_flag != 1 and userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
               update idc_isms_base_user_hh_ipseg set deal_flag = v_operationType,UPDATE_TIME = sysdate where del_flag != 1 and userid in (select userid from idc_isms_base_user where jyzid = p_jyzid);
               update idc_isms_base_user_service set deal_flag = v_operationType,update_time = sysdate where del_flag != 1 and userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
               update idc_isms_base_service_domain set deal_flag = v_operationType,update_time = sysdate where del_flag != 1 and userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
               update idc_isms_base_service_hh set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
               update idc_isms_base_service_iptrans set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid in (select userid from idc_isms_base_user where jyzid = p_jyzid);
               update idc_isms_base_service_virtual set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid in (select userid from idc_isms_base_user where jyzid = p_jyzid);
             end if;
         end if;
         if (p_userId is not null) then
             open v_userIdCur for 'select USERID from IDC_ISMS_BASE_USER where USERID in (' || p_userId || ')';
             loop
               fetch v_userIdCur into v_userId;
               exit when v_userIdCur%notfound;
               --处理用户上报
               update idc_isms_base_user idc_user set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and idc_user.userid = v_userId;
               update idc_isms_base_user_hh set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_user_hh_ipseg set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_user_service set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_service_domain set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_service_hh set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_service_iptrans set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_service_virtual set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and userid = v_userId;
               update idc_isms_base_idc set report_type = p_reportType where JYZID = (select JYZID from idc_isms_base_user where USERID = v_userId);
             end loop;
             close v_userIdCur;
         end if;
         if (p_houseId is not null) then
             open v_houseIdCur for 'select HOUSEID from IDC_ISMS_BASE_HOUSE where HOUSEID in (' || p_houseId || ')';
             loop
               fetch v_houseIdCur into v_houseId;
               exit when v_houseIdCur%notfound;
               --处理IDC下面机房信息上报
               update idc_isms_base_house idc_house set idc_house.deal_flag = v_operationType,idc_house.update_time = sysdate where idc_house.del_flag != 1  and idc_house.houseid = v_houseId;
               update idc_isms_base_house_gateway house_gateway set house_gateway.deal_flag = v_operationType,house_gateway.update_time = sysdate where house_gateway.del_flag != 1  and house_gateway.houseid = v_houseId;
               --update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = v_operationType,house_ipseg.update_time = sysdate where house_ipseg.del_flag != 1  and house_ipseg.houseid = v_houseId;
               update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = v_operationType,house_ipseg.update_time = sysdate where house_ipseg.del_flag != 1  and house_ipseg.houseid = v_houseId;-- and house_ipseg.ipsegid in (select v.ipsegid from idc_isms_base_house_ipseg_view v);
               update idc_isms_base_house_frame set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and houseid = v_houseId;
               update idc_isms_base_idc set report_type = p_reportType where JYZID = (select JYZID from IDC_ISMS_BASE_HOUSE where HOUSEID = v_houseId);
             end loop;
             close v_houseIdCur;
         end if;
         --其它用户占用机房上报
         if (p_userHHId is not null) then
             open v_userHHIdCur for 'select HHID from IDC_ISMS_BASE_USER_HH where HHID in (' || p_userHHId || ')';
             loop
               fetch v_userHHIdCur into v_userHHId;
               exit when v_userHHIdCur%notfound;
               update idc_isms_base_user_hh set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and hhid = v_userHHId;
               update idc_isms_base_user_hh_ipseg set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and hhid = v_userHHId;
               update idc_isms_base_idc set report_type = p_reportType where JYZID = (select JYZID from idc_isms_base_user where USERID = (select USERID from IDC_ISMS_BASE_USER_HH where HHID = v_userHHId));
             end loop;
             close v_userHHIdCur;
         end if;
         --服务上报
         if (p_serviceId is not null) then
             open v_serviceIdCur for 'select SERVICEID from IDC_ISMS_BASE_USER_SERVICE where SERVICEID in (' || p_serviceId || ')';
             fetch v_serviceIdCur into v_serviceId;
             loop
               update idc_isms_base_user_service set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and serviceid = v_serviceId;
               update idc_isms_base_service_domain set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and serviceid = v_serviceId;
               update idc_isms_base_service_hh set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and serviceid = v_serviceId;
               update idc_isms_base_service_iptrans set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and serviceid = v_serviceId;
               update idc_isms_base_service_virtual set deal_flag = v_operationType,update_time = sysdate where del_flag != 1  and serviceid = v_serviceId;
               update idc_isms_base_idc set report_type = p_reportType where JYZID = (select JYZID from idc_isms_base_user where USERID = (select USERID from IDC_ISMS_BASE_USER_SERVICE where SERVICEID = v_serviceId));
             end loop;
             close v_serviceIdCur;
         end if;
         exception when others then
            rollback;
            v_out_success := 0;
            return;
         commit;
         v_out_success:=1;
       end;
       
       procedure restoreDataSet(
          p_restoreDate   in varchar2,
          --出参
          v_out_success    out varchar2
       ) as
       v_baseDelCur sys_refcursor;
       v_deltype idc_isms_base_delete.del_type%type;
       v_idcid idc_isms_base_delete.idcid%type;
       v_houseid idc_isms_base_delete.houseid%type;
       v_userid idc_isms_base_delete.userid%type;
       v_serviceid idc_isms_base_delete.serviceid%type;
       begin
         
         if (p_restoreDate is not null) then
             open v_baseDelCur for 'select del_type,idcid,houseid,userid,serviceid from IDC_ISMS_BASE_DELETE where createtime >=to_date(''' || p_restoreDate || ''',''yyyy-mm-dd hh24:mi:ss'')';
             loop
               fetch v_baseDelCur into v_deltype,v_idcid,v_houseid,v_userid,v_serviceid;
               exit when v_baseDelCur%notfound;
               --修改上报状态
               if(v_deltype=1) then
                 update idc_isms_base_idc set deal_flag =0,czlx=1 where idcid=v_idcid;
               elsif(v_deltype=2) then
                 update idc_isms_base_house set deal_flag =0,czlx=1 where houseid=v_houseid;
               elsif(v_deltype=3) then
                 update idc_isms_base_user set deal_flag =0,czlx=1 where userid=v_userid;
                 update idc_isms_base_user_service set deal_flag =0,czlx=1 where userid=v_userid and serviceid=v_serviceid;
               elsif(v_deltype=4) then
                 update idc_isms_base_house set deal_flag =0,czlx=1 where houseid=v_houseid;
                 update idc_isms_base_user set deal_flag =0,czlx=1 where userid=v_userid;
                 
               end if;
             end loop;
             close v_baseDelCur;
         end if;
         exception when others then
            rollback;
            v_out_success := '0';
            return;
         commit;
         v_out_success:='1';
       end;
end IDC_ISMS_BASE_BASIC_MANAGE;
/
