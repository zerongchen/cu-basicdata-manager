CREATE package IDC_ISMS_SYSTEM_JCDM_MANAGE is

procedure list_basx(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,
                          p_name in varchar2
                          );

procedure list_dllx(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,
                          p_name in varchar2
                          );

procedure list_dwsx(   p_ispaging in number,
                              pageindex in number,
                              pagesize in number,
                              p_iscount in number,
                              sortName in varchar2,
                              orderItem in varchar2,
                              p_cursor out sys_refcursor,
                              p_recordcount out number,
                              p_name in varchar2
                              );

procedure list_fwnr(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_fl in number,
                      p_name in varchar2
                      );

procedure list_gzlx(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_name in varchar2
                      );

procedure list_jfxz(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_name in varchar2
                      );

procedure list_jrfs(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_name in varchar2
                      );

procedure list_wfwgqk(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_name in varchar2
                      );

procedure list_zjlx(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_name in varchar2
                      );

end IDC_ISMS_SYSTEM_JCDM_MANAGE;
/
