CREATE package IDC_ISMS_SYSTEM_DOIP_MANAGE is

procedure list_domain(
                p_isPaging in number,
                p_pageIndex in number,
                p_pageSize in number,
                p_iscount in number,
                sortName in varchar2,
                orderItem in varchar2,
                p_cursor out sys_refcursor,
                p_recordcount out number,
                p_houseidstr in varchar2,
                p_domaintype in number,
                p_domain in varchar2
      );
procedure list_ip(
      p_isPaging in number,
      p_pageIndex in number,
      p_pageSize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_houseidstr in varchar2,
      p_iptype in number,
      p_ip1 in varchar2,
      p_ip2 in varchar2
      );
procedure list_domainip(
      p_isPaging in number,
      p_pageIndex in number,
      p_pageSize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_houseidstr in varchar2,
      p_ip1 in varchar2,
      p_ip2 in varchar2,
      p_domain in varchar2
      );
   procedure   add_domain(
                p_domain in varchar2,
                p_houseidstr in varchar2,
                p_domaintype in  number,
                o_returnvalue out number
                );
   procedure   add_ip(
                p_startip in varchar2,
                p_endip in varchar2,
                p_houseidstr in varchar2,
                p_iptype in  number,
                o_returnvalue out number
                );
   procedure   add_domainip(
                p_startip in varchar2,
                p_endip in varchar2,
                p_domain in varchar2,
                p_houseidstr in varchar2,
               /* p_iptype in  number,*/
                o_returnvalue out number
                );
end IDC_ISMS_SYSTEM_DOIP_MANAGE;
/
