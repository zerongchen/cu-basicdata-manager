CREATE package IDC_ISMS_MONITOR_INFO is

  --监控入口
  procedure monitor_base_main;

  --经营者
  procedure monitor_base_idc;

  --机房
  procedure monitor_base_house_new;
  --机房
  procedure monitor_base_house;

  --用户
  procedure monitor_base_user;

  --服务查看
  procedure monitor_base_service;

 --经营者
  procedure monitor_base_idc_new;

  --用户
  procedure monitor_base_user_new;

  --服务查看
  procedure monitor_base_service_new;
  --占用机房查看（互联网用户）
  procedure monitor_base_service_hh;

  procedure monitor_base_user_hh_new;
  --占用机房查看（其他用户）
  procedure monitor_base_user_hh;

  --更新
  procedure update_info(
             table_name in varchar2,
             id_name in varchar2,
             id_val in number,
             field_val in varchar2

  );

end IDC_ISMS_MONITOR_INFO;
/
