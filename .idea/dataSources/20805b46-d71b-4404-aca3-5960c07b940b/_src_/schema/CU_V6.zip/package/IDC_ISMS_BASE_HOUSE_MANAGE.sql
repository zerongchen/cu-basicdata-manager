CREATE package IDC_ISMS_BASE_HOUSE_MANAGE is
      procedure prelist_house_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_houseName   in VARCHAR2,
            p_houseIdStr   in VARCHAR2,
            p_houseType   in NUMBER,
            p_houseProvince in NUMBER,
            p_houseCity in NUMBER,
            p_houseCounty in NUMBER,
            --p_houseAddress in VARCHAR2,
            --p_houseZipCode in VARCHAR2,
            p_houseOfficerName in  VARCHAR2,
            /*p_houseOfficerIdType in NUMBER,
            p_houseOfficerId in VARCHAR2,
            p_houseOfficerTelephone in VARCHAR2,
            p_houseOfficerMobile in VARCHAR2,
            p_houseOfficerEmail in VARCHAR2,*/
            p_gatewayIP in VARCHAR2,
            p_startIP in VARCHAR2,
            p_endIP in VARCHAR2,
            p_dealFlag in number,
            p_delFlag in number,
            p_czlx in number,
            p_userHouseIDStrs in varchar2,
            p_identify in number
   );
   
   procedure list_house_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_houseName   in VARCHAR2,
            p_houseIdStr   in VARCHAR2,
            p_houseType   in NUMBER,
            p_houseProvince in NUMBER,
            p_houseCity in NUMBER,
            p_houseCounty in NUMBER,
            --p_houseAddress in VARCHAR2,
            --p_houseZipCode in VARCHAR2,
            p_houseOfficerName in  VARCHAR2,
            /*p_houseOfficerIdType in NUMBER,
            p_houseOfficerId in VARCHAR2,
            p_houseOfficerTelephone in VARCHAR2,
            p_houseOfficerMobile in VARCHAR2,
            p_houseOfficerEmail in VARCHAR2,*/
            p_gatewayIP in VARCHAR2,
            p_startIP in VARCHAR2,
            p_endIP in VARCHAR2,
            p_dealFlag in number,
            p_delFlag in number,
            p_czlx in number,
            p_userHouseIDStrs in varchar2,
            p_identify in number,
            p_infoComplete in varchar2
   );

   --机房查询列表的数据查询
   procedure house_query_list_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_houseName   in VARCHAR2,
            p_houseType   in NUMBER,
            p_houseProvince in NUMBER,
            p_houseCity in NUMBER,
            p_houseCounty in NUMBER,
            p_houseOfficerName in  VARCHAR2,
            p_gatewayIP in VARCHAR2,
            p_startIP in VARCHAR2,
            p_endIP in VARCHAR2,
            p_otherCondition in varchar2 --其它而外的查询条件
   );

   procedure list_houseGateway_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in VARCHAR2,
            p_bandWidth in NUMBER,
            p_linkNo in varchar2,
            p_gatewauIP in varchar2,
            p_operationType in number,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_userLevel in number

   );

   procedure prelist_gateway_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in VARCHAR2,
            p_bandWidth in NUMBER,
            p_linkNo in varchar2,
            p_gatewauIP in varchar2,
            p_operationType in number,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_userLevel in number

   );
   
   --机架信息查询
   procedure list_houseFrame_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in varchar2,
            p_frameName in varchar2,
            p_frameNo in varchar2,
            p_useType in number,
            p_distribution in number,
            p_occupancy in number,
            p_opeType in number,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_userLevel in number
   );
   
    --机架信息查询 预录入
   procedure prelist_houseFrame_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in varchar2,
            p_frameName in varchar2,
            p_frameNo in varchar2,
            p_useType in number,
            p_distribution in number,
            p_occupancy in number,
            p_opeType in number,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_userLevel in number
   );
    --机架信息导出
   procedure list_houseFrame_informationNew(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseId   in NUMBER,
            p_frameName in varchar2,
            p_frameNo in varchar2,
            p_useType in number,
            p_distribution in number,
            p_occupancy in number,
            p_delFlag in number,
            p_userHouseIDStrs in varchar2,
            p_dealFlag in number
   );
       --机架信息查询(导出)
         procedure list_houseFrame_information_ex(
                  --入参，分页参数
                  p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
                  p_pageIndex  in NUMBER, --页索引
                  p_pageSize   in NUMBER, --页大小
                  p_IsCount    in NUMBER,
                  p_sortName   in VARCHAR2,
                  p_sortOrder  in VARCHAR2,
                  --输出
                  p_cursor      out sys_refcursor,
                  p_recordCount out NUMBER, --非空为错误信息
                  --入参，查询参数
                  p_houseId   in varchar2,
                  p_frameName in varchar2,
                  p_useType in number,
                  p_distribution in number,
                  p_occupancy in number,
                  p_delFlag in number,
                  p_userHouseIDStrs in varchar2

         );
   --机房网关查询列表的数据查询
   procedure gateway_query_list_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseId   in NUMBER,
            p_bandWidth in NUMBER,
            p_gatewauIP in NUMBER,
            --p_userId in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
   );



   procedure list_houseIPSeg_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in VARCHAR2,
            p_startIP   in varchar2,
            p_endIP   in varchar2,
            p_ipType in NUMBER,
            p_userName in VARCHAR2,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            p_operationType in number,
            p_delFlag in number,
            p_dealFlag in number,
            p_areaCode in varchar2,
            p_userLevel in number

   );
   procedure prelist_houseIPSeg_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in VARCHAR2,
            p_startIP   in varchar2,
            p_endIP   in varchar2,
            p_ipType in NUMBER,
            p_userName in VARCHAR2,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            p_operationType in number,
            p_delFlag in number,
            p_dealFlag in number,
            p_areaCode in varchar2,
            p_userLevel in number

   );
   --机房IP地址段的查询列表数据查询
   procedure ipSeg_query_list_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseId   in NUMBER,
            p_startIP   in NUMBER,
            p_endIP   in NUMBER,
            p_ipType in NUMBER,
            p_userName in VARCHAR2,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            --p_userId in NUMBER,
            p_otherCondition in VARCHAR2 --其它而外的查询条件
   );

   procedure del_house_information(
            p_houseId in varchar2,
            --出参
            v_out_success out number
   );

   procedure delete_house_information(
            p_houseId in varchar2,
            --出参
            v_out_success out number
   );
     procedure delete_house_informationbystr(
            p_houseIdStr in varchar2,
            --出参
            v_out_success out number
         ) ;

   procedure delete_house_information(
            p_houseId in varchar2,
            p_temp in number, --用于重载，没有实际意义
            --出参
            v_out_success out number
   );

   procedure del_gateway_information(
            p_gatewayId   in varchar2,
            --出参
            v_out_success    out number
         );
   procedure del_gateway_information_v(
            p_gatewayId in varchar2,
            --出参
            v_out_success out number,
            v_out_errormsg out varchar2
         );
   procedure delete_gateway_information(
            p_gatewayId   in varchar2,
            --出参
            v_out_success    out number
         );
    procedure delete_gateway_information_v(
            p_gatewayId in varchar2,
            --出参
            v_out_success out number,
             v_out_errormsg out varchar2
         );
              procedure delete_gatewaybylinkno_v(
            p_linkno in varchar2,
            --出参
            v_out_success out number,
             v_out_errormsg out varchar2
         ) ;
   procedure del_ipseg_information(
            p_ipsegId   in varchar2,
            --出参
            v_out_success    out number
         );
   procedure del_ipseg_information_v(
            p_ipsegId   in varchar2,
            --出参
            v_out_success    out number,
            v_out_errormsg out varchar2
         ) ;

   procedure delete_ipseg_information(
            p_ipsegId   in varchar2,
            --出参
            v_out_success    out number
         );
       procedure delete_ipseg_information_v(
            p_ipsegId   in varchar2,
            --出参
            v_out_success    out number,
            v_out_errormsg out varchar2
         ) ;
             procedure delete_ipsegbyipsegno_v(
            p_ipsegno   in varchar2,
            --出参
            v_out_success    out number,
            v_out_errormsg out varchar2
         );
   procedure del_frame_information(
            p_frameId in varchar2,
            --出参
            v_out_success out number
         );
  procedure del_frame_information_v(
            p_frameId in varchar2,
            --出参
            v_out_success out number,
            v_out_errormsg out varchar2
         ) ;
  procedure delete_frame_information(
            p_frameId in varchar2,
            --出参
            v_out_success out number
         );
procedure delete_frame_information_v(
            p_frameId in varchar2,
            --出参
            v_out_success out number,
            v_out_errormsg out varchar2
         );
         procedure delete_framebyframeno_v(
            p_frameno in varchar2,
            --出参
            v_out_success out number,
            v_out_errormsg out varchar2
         );
   procedure recover_gateway_information(
      p_gatewayId in varchar2,
      --出参
      v_out_success out number
   );

   procedure recover_ipseg_information(
      p_ipsegId in varchar2,
      --出参
      v_out_success out number
   );

    procedure recover_frame_information(
      p_frameId in varchar2,
      --出参
      v_out_success out number
   );



   procedure recover_house_information(
      p_houseId in varchar2,
      --出参
      v_out_success out number
   );
    procedure updateStatus_house_information(
      p_houseId in varchar2,
      --出参
      v_out_success out number
   );

end IDC_ISMS_BASE_HOUSE_MANAGE;
/
