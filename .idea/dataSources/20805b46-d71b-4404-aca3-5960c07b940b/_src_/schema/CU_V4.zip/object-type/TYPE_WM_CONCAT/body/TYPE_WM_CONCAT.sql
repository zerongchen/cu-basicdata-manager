CREATE TYPE BODY "TYPE_WM_CONCAT"
IS
   STATIC FUNCTION ODCIAggregateInitialize                              -- 初始化
                                           (sctx IN OUT type_wm_concat)
      RETURN NUMBER
   IS
   BEGIN
      sctx := type_wm_concat (NULL, NULL);
      RETURN ODCIConst.success;
   END ODCIAggregateInitialize;

   MEMBER FUNCTION ODCIAggregateIterate                          -- 迭代器，处理每行数据
                                        (self    IN OUT type_wm_concat,
                                         VALUE   IN     ConcatObj)
      RETURN NUMBER
   IS
   BEGIN
      IF self.l_join_str IS NOT NULL AND VALUE.fieldValue IS NOT NULL
      THEN
         self.l_join_str := self.l_join_str || self.l_flag || VALUE.fieldValue;
      ELSIF VALUE.fieldValue IS NOT NULL
      THEN
         self.l_join_str := VALUE.fieldValue;
         self.l_flag := VALUE.separator;
      END IF;

      RETURN ODCIConst.Success;
   END;


   MEMBER FUNCTION ODCIAggregateTerminate                         -- 迭代结束后处理代码
                                          (self       IN OUT type_wm_concat,
                                           return_v      OUT CLOB,
                                           flags      IN     NUMBER)
      RETURN NUMBER
   IS
   BEGIN
      return_v := self.l_join_str;
      RETURN ODCIConst.Success;
   END;


   MEMBER FUNCTION ODCIAggregateMerge (self   IN OUT type_wm_concat,
                                       ctx2   IN     type_wm_concat)
      RETURN NUMBER
   IS
   BEGIN
      IF ctx2.l_join_str IS NOT NULL AND self.l_join_str IS NOT NULL
      THEN
         self.l_join_str := self.l_join_str || self.l_flag || ctx2.l_join_str;
      ELSIF ctx2.l_join_str IS NOT NULL
      THEN
         self.l_join_str := ctx2.l_join_str;
      END IF;

      RETURN ODCIConst.Success;
   END;
END;
/
