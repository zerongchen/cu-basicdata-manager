CREATE package IDC_ISMS_SYSTEM_CMD_MANAGE is

procedure list_IDCInfo(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,

                          p_commandId in number,
                          p_idcId in varchar2,
                          p_cmdType in number,
                          p_dealFlag in number,
                          p_beginTimeStamp in varchar2,
                          p_endTimeStamp in varchar2
                          );

procedure list_IDCMNGQuery(   p_ispaging in number,
                              pageindex in number,
                              pagesize in number,
                              p_iscount in number,
                              sortName in varchar2,
                              orderItem in varchar2,
                              p_cursor out sys_refcursor,
                              p_recordcount out number,

                              p_IDCID          in varchar2,
                              p_HOUSEIDLIST    in varchar2,
                              p_S_TIMESTAMP      in varchar2,
                              p_E_TIMESTAMP      in varchar2,
                              p_S_CREATE_TIME    in varchar2,
                              p_E_CREATE_TIME    in varchar2,
                              p_DEAL_FLAG      in number,
                              p_IS_RESULT      in number
                              );

procedure list_IDC(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_houseId in number,
                      p_commandId in number,
                      p_idcId in varchar2,
                      p_cmdTyp in number,
                      p_actionLog  in number,
                      p_actionReport  in number,
                      p_opeType in number,
                      p_dealFlag in number,
                      p_beginTimeStamp in varchar2,
                      p_endTimeStamp in varchar2
                      );

procedure list_log(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_houseId in number,
                      p_commandId in number,
                      p_idcId in varchar2,
                      p_protocolType in number,
                      p_dealFlag in number,
                      p_beginTimeStamp in varchar2,
                      p_endTimeStamp in varchar2
                      );
procedure list_Rule(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_commandId in number,
      p_subType in number,
      p_beginCreatetime in varchar2,
      p_endCreatetime in varchar2
      );
procedure list_cmdack(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_HOUSEID in number,
      p_IDCID in varchar2,
      p_COMMANDFILEID in number,
      p_CMD_TYPE in number,
      p_RESULT_CODE in number,
      p_DEAL_FLAG in number,
      p_S_TIMESTAMP      in varchar2,
      p_E_TIMESTAMP      in varchar2,
      p_S_CREATE_TIME    in varchar2,
      p_E_CREATE_TIME    in varchar2
      );
procedure list_active_state(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_IDCID in varchar2,
      p_DEAL_FLAG in number,
      p_S_TIMESTAMP      in varchar2,
      p_E_TIMESTAMP      in varchar2,
      p_S_CREATE_TIME    in varchar2,
      p_E_CREATE_TIME    in varchar2
      );

--查询基础数据核验处理信息
procedure list_IDCInfo_validate(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_IDCId in varchar2,
      p_beginTimestamp in varchar2,
      p_endTimestamp in varchar2,
      p_beginCreatetime in varchar2,
      p_endCreateTime in varchar2,
      p_dealFlag in number,
      p_isResult in number
);

--查询基础数据核验处理信息对应的机房信息
procedure list_validate_houseInfo(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_returnInfoId in number,
      p_gatewayId in number,
      p_ipSegId in number,
      p_frameInfoId in number
);

--查询基础数据核验处理信息对应的用户信息
procedure list_validate_userInfo(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_returnInfoId in number,
      p_hhId in number
);

--查询核验信息对应用户信息下的服务信息
procedure list_validate_usInfo(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_userId in number,
      p_domainId in number,
      p_hhId in number
);

--查询免过滤网站列表指令
procedure list_IDCInfo_no_filter(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_commandId in number,
      p_idcId in varchar2,
      p_opeType in number,
      p_type in number,
      p_content in varchar2,
      p_dealFlag in number,
      p_beginTimeStamp in varchar2,
      p_endTimeStamp in varchar2
);

--查询违法网站列表指令
procedure list_IDCInfo_Black(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_commandId in number,
      p_idcId in varchar2,
      p_opeType in number,
      p_type in number,
      p_content in varchar2,
      p_dealFlag in number,
      p_beginTimeStamp in varchar2,
      p_endTimeStamp in varchar2
);

--查询活跃资源访问量查询指令
procedure list_IDCInfo_query_view(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_commandId in number,
      p_idcId in varchar2,
      p_type in number,
      p_content in varchar2,
      p_dealFlag in number,
      p_beginQueryTime in varchar2,
      p_endQueryTime in varchar2,
      p_beginTimeStamp in varchar2,
      p_endTimeStamp in varchar2
);

--查询违法管理指令执行记录指令
procedure list_IDCInfo_black_record(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_commandId in number,
      p_idcId in varchar2,
      p_controlsId in number,
      p_dealFlag in number,
      p_beginTimeStamp in varchar2,
      p_endTimeStamp in varchar2,
      p_beginCreateTime in varchar2,
      p_endCreateTime in varchar2
);

--查询指令处理后生成文件信息
procedure list_IDCInfo_fileInfo(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,
      p_commandType in number,
      p_commandId in varchar2,
      p_filename in varchar2,
      p_fileState in number,
      p_beginCreatetime in varchar2,
      p_endCreatetime in varchar2,
      p_beginUpdatetime in varchar2,
      p_endUpdatetime in varchar2
);

--查询指令处理后ACK处理状态信息
procedure list_IDCInfo_ACKInfo(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,
      p_commandType in number,
      p_commandId in number,
      p_houseId in varchar2,
      p_resultCode in number,
      p_idcId in varchar2,
      p_timeStampStart in varchar2,
      p_timeStampEnd in varchar2,
      p_dealFlag in number,
      p_createTimeStart in varchar2,
      p_createTimeEnd in varchar2
);

--查询代码发布表指令
procedure list_IDCInfo_code_release(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,

      p_commandId in varchar2,
      p_filename in varchar2,
      p_dealFlag in number,
      p_beginTimeStamp in varchar2,
      p_endTimeStamp in varchar2
);

end IDC_ISMS_SYSTEM_CMD_MANAGE;
/
CREATE package body IDC_ISMS_SYSTEM_CMD_MANAGE is

--基础数据查询指令
procedure list_IDCInfo(   p_ispaging in number,
                          pageindex in number,
                          pagesize in number,
                          p_iscount in number,
                          sortName in varchar2,
                          orderItem in varchar2,
                          p_cursor out sys_refcursor,
                          p_recordcount out number,

                          p_commandId in number,
                          p_idcId in varchar2,
                          p_cmdType in number,
                          p_dealFlag in number,
                          p_beginTimeStamp in varchar2,
                          p_endTimeStamp in varchar2

                          )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_CMD_IDCINFO_MANAGE ';
      v_field    := ' COMMANDID,CMD_TYPE,IDCID,QUERYDAYFROM,QUERYDAYTO,USERIDLIST,HOUSEIDLIST,TIMESTAMP,DEAL_FLAG ';

      --条件语句
      v_condition := ' where 1=1 ';

      if p_commandId > 0 then
          v_condition := v_condition || '  and COMMANDID = ' || p_commandId;
      end if;
      if (p_idcId is not null) then
           v_condition := v_condition || ' and IDCID like ''%' || p_idcId || '%''';
      end if;
      if p_cmdType >= 0 then
          v_condition := v_condition || '  and CMD_TYPE = ' || p_cmdType;
      end if;
      if p_dealFlag >= 0 then
          v_condition := v_condition || '  and DEAL_FLAG = ' || p_dealFlag;
      end if;
      if (p_beginTimeStamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP >= to_date(''' || p_beginTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_endTimeStamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP <= to_date(''' || p_endTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;

      if p_iscount = 1 then
        v_count := 'select count(1) ' || v_innersql || v_condition;
        execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;

procedure list_IDCMNGQuery(   p_ispaging in number,
                              pageindex in number,
                              pagesize in number,
                              p_iscount in number,
                              sortName in varchar2,
                              orderItem in varchar2,
                              p_cursor out sys_refcursor,
                              p_recordcount out number,

                              p_IDCID          in varchar2,
                              p_HOUSEIDLIST    in varchar2,
                              p_S_TIMESTAMP      in varchar2,
                              p_E_TIMESTAMP      in varchar2,
                              p_S_CREATE_TIME    in varchar2,
                              p_E_CREATE_TIME    in varchar2,
                              p_DEAL_FLAG      in number,
                              p_IS_RESULT      in number
                              )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_CMD_IDCMNG_QUERY ';
      v_field    := ' COMMANDID,IDCID,HOUSEIDLIST,TIMESTAMP,CREATE_TIME,DEAL_FLAG,IS_RESULT ';

      --条件语句
      v_condition := ' where 1=1 ';
      if p_DEAL_FLAG >0  then
          v_condition := v_condition || '  and DEAL_FLAG =' || (p_DEAL_FLAG-1);
      end if;
      if p_IS_RESULT >0  then
          v_condition := v_condition || '  and IS_RESULT =' || (p_IS_RESULT-1);
      end if;
      if(p_IDCID  is not null ) then
          v_condition := v_condition || '  and IDCID =''' || p_IDCID || '''';
      end if;
       if(p_HOUSEIDLIST  is not null ) then
          v_condition := v_condition || '  and HOUSEIDLIST =''' || p_HOUSEIDLIST || '''';
      end if;
      if(p_S_TIMESTAMP is not null) then
          v_condition := v_condition || ' and TIMESTAMP >= to_date(''' || p_S_TIMESTAMP || ''',''yyyy-mm-dd'') ';
      end if;
      if(p_E_TIMESTAMP is not null) then
          v_condition := v_condition || ' and TIMESTAMP <= to_date(''' || p_E_TIMESTAMP || ' 23:59:59'',''yyyy-mm-dd hh24:mi:ss'') ';
      end if;
      if(p_S_CREATE_TIME is not null) then
          v_condition := v_condition || ' and TIMESTAMP >= to_date(''' || p_S_CREATE_TIME || ''',''yyyy-mm-dd'') ';
      end if;
      if(p_E_CREATE_TIME is not null) then
          v_condition := v_condition || ' and TIMESTAMP <= to_date(''' || p_E_CREATE_TIME || ' 23:59:59'',''yyyy-mm-dd hh24:mi:ss'') ';
      end if;

      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;

procedure list_IDC(
                p_ispaging in number,
                pageindex in number,
                pagesize in number,
                p_iscount in number,
                sortName in varchar2,
                orderItem in varchar2,
                p_cursor out sys_refcursor,
                p_recordcount out number,
                p_houseId in number,
                p_commandId in number,
                p_idcId in varchar2,
                p_cmdTyp in number,
                p_actionLog  in number,
                p_actionReport  in number,
                p_opeType in number,
                p_dealFlag in number,
                p_beginTimeStamp in varchar2,
                p_endTimeStamp in varchar2
)is
      --定义
      v_field     varchar2(2000); --字段
      v_outfield  varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_CMD_IDC_MANAGE  a';
      v_field    := ' COMMANDID,CMD_TYPE,IDCID,HOUSEIDLIST,ACTION_LOG,ACTION_REPORT,EFFECTTIME,EXPIREDTIME,OPERATION_TYPE,LEVEL_BINARY,LEVEL_DECIMAL,TIMESTAMP,DEAL_FLAG ';
      
      --条件语句
      v_condition := ' where 1 = 1';--PRIVILEGE_VISIBLE != 0';
      if p_houseId > 0 then
          v_condition := v_condition || ' and '|| p_houseId ||' in (select * from table(splitstr(houseidlist,'',''))) ';
      end if;
      if p_commandId > 0  then
          v_condition := v_condition || ' and a.COMMANDID = ' || p_commandId;
      end if;
      if (p_idcId is not null) then
           v_condition := v_condition || ' and a.IDCID like ''%' || p_idcId || '%''';
      end if;
      if p_cmdTyp > 0 then
          v_condition := v_condition || ' and a.CMD_TYPE = ' || p_cmdTyp;
      end if;
      if p_actionLog >= 0 then
          v_condition := v_condition || ' and a.ACTION_LOG = ' || p_actionLog;
      end if;
      if p_actionReport >= 0 then
          v_condition := v_condition || ' and a.ACTION_REPORT = ' || p_actionReport;
      end if;
      if p_opeType >= 0 then
          v_condition := v_condition || ' and a.OPERATION_TYPE = ' || p_opeType;
      end if;
      if p_dealFlag >= 0 then
          v_condition := v_condition || ' and a.DEAL_FLAG = ' || p_dealFlag;
      end if;
      if (p_beginTimeStamp is not null) then
         v_condition := v_condition || ' and a.TIMESTAMP >= to_date(''' || p_beginTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
      end if;
      if (p_endTimeStamp is not null) then
         v_condition := v_condition || ' and a.TIMESTAMP <= to_date(''' || p_endTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
      end if;

      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      dbms_output.put_line(v_sql);
      open p_cursor for v_sql;
  end;

--访问日志查询指令
procedure list_log(   p_ispaging in number,
                      pageindex in number,
                      pagesize in number,
                      p_iscount in number,
                      sortName in varchar2,
                      orderItem in varchar2,
                      p_cursor out sys_refcursor,
                      p_recordcount out number,
                      p_houseId in number,
                      p_commandId in number,
                      p_idcId in varchar2,
                      p_protocolType in number,
                      p_dealFlag in number,
                      p_beginTimeStamp in varchar2,
                      p_endTimeStamp in varchar2
                      )is
      --定义
      v_field     varchar2(2000); --字段
      v_outfield  varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_CMD_LOG_QUERY a inner join IDC_ISMS_BASE_HOUSE b on a.HOUSEID= b.HOUSEID ';
      v_field    := ' a.COMMANDID,a.IDCID,a.HOUSEID,a.STARTTIME,a.ENDTIME,a.SRCIP_START,a.SRCIP_END,a.DESTIP_START,a.DESTIP_END,
                     a.SRCPORT,a.DSTPORT,a.URL,a.TIMESTAMP,a.DEAL_FLAG,a.PROTOCOLTYPE,b.HOUSENAME  ';
      v_outfield := ' COMMANDID,IDCID,HOUSEID,STARTTIME,ENDTIME,SRCIP_START,SRCIP_END,DESTIP_START,DESTIP_END,
                     SRCPORT,DSTPORT,URL,TIMESTAMP,DEAL_FLAG,PROTOCOLTYPE,HOUSENAME  ';

      --条件语句
      v_condition := ' where 1=1 ';
      if p_houseId > 0 then
          v_condition := v_condition || ' and a.HOUSEID = ' || p_houseId;
      end if;
      if p_commandId > 0 then
          v_condition := v_condition || ' and a.COMMANDID = ' || p_commandId;
      end if;
      if (p_idcId  is not null) then
          v_condition := v_condition || ' and a.IDCID like ''%' || p_idcId || '%''';
      end if;
      if p_protocolType > 0  then
          v_condition := v_condition || ' and a.PROTOCOLTYPE = ' || p_protocolType;
      end if;
      if p_dealFlag >= 0  then
          v_condition := v_condition || ' and a.DEAL_FLAG = ' || p_dealFlag;
      end if;
      if (p_beginTimeStamp is not null) then
         v_condition := v_condition || ' and a.TIMESTAMP >= to_date(''' || p_beginTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
      end if;
      if (p_endTimeStamp is not null) then
         v_condition := v_condition || ' and a.TIMESTAMP <= to_date(''' || p_endTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
      end if;

      if p_iscount = 1 then
        v_count := 'select count(1) ' || v_innersql || v_condition;
        execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_outfield ||' from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum <= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end IF;
      open p_cursor for v_sql;
  end;
procedure list_Rule(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_commandId in number,
      p_subType in number,
      p_beginCreatetime in varchar2,
      p_endCreatetime in varchar2
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
      v_temSql    varchar2(500); --临时语句
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_CMD_IDCMNG_RULE ';
      v_field    := ' RULEID,COMMANDID,SUBTYPE,VALUESTART,VALUEEND,KEYWORDRANGE,CREATE_TIME ';

      --条件语句
      v_condition := ' where 1=1 ';
      if p_commandId > 0 then
        v_condition := v_condition || '  and COMMANDID = ' || p_commandId;
      end if;
      if p_subType > 0 then
        v_condition := v_condition || '  and SUBTYPE = ' || p_subType;
      end if;
      if (p_beginCreatetime is not null) then
         v_condition := v_condition || ' and CREATE_TIME >= to_date(''' || p_beginCreatetime || ''',''yyyy-mm-dd hh24:mi:ss'')';
      end if;
      if (p_endCreatetime is not null) then
         v_condition := v_condition || ' and CREATE_TIME <= to_date(''' || p_endCreatetime || ''',''yyyy-mm-dd hh24:mi:ss'')';
      end if;

      if p_iscount=1 then
        v_count := 'select count(1) ' || v_innersql || v_condition;
        execute immediate v_count into p_recordcount;
      end if;

      v_order := ' order by ' || sortName || '  ' || orderItem;

      v_temSql := v_field || v_innersql || v_condition || v_order;
      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_temSql;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select ' || v_field || ' from(';
          v_sql := v_sql || ' select ' || ' my_table.*,rownum my_rownum from(select ';
          v_sql := v_sql || v_temSql;
          v_sql := v_sql || ') my_table where rownum <= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      dbms_output.put_line(v_sql);
      open p_cursor for v_sql;
  end;
procedure list_cmdack(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_HOUSEID in number,
      p_IDCID in varchar2,
      p_COMMANDFILEID in number,
      p_CMD_TYPE in number,
      p_RESULT_CODE in number,
      p_DEAL_FLAG in number,
      p_S_TIMESTAMP      in varchar2,
      p_E_TIMESTAMP      in varchar2,
      p_S_CREATE_TIME    in varchar2,
      p_E_CREATE_TIME    in varchar2
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_REPLY_CMD_ACK ';
      v_field    := ' COMMANDID,HOUSEID,CMD_TYPE,RESULT_CODE,MSGINFO,IDCID,COMMANDFILEID,TIMESTAMP,CREATE_TIME,DEAL_FLAG ';

      --条件语句
      v_condition := ' where 1=1 ';

      if p_COMMANDFILEID >0  then
          v_condition := v_condition || '  and COMMANDFILEID =' || p_COMMANDFILEID;
      end if;
      if p_HOUSEID >0  then
          v_condition := v_condition || '  and HOUSEID =' || p_HOUSEID;
      end if;
      if p_DEAL_FLAG >0  then
          v_condition := v_condition || '  and DEAL_FLAG =' || (p_DEAL_FLAG-1);
      end if;
      if p_CMD_TYPE >0  then
          v_condition := v_condition || '  and CMD_TYPE =' || p_CMD_TYPE;
      end if;
      if p_RESULT_CODE >0  then
          v_condition := v_condition || '  and RESULT_CODE =' || p_RESULT_CODE;
      end if;
      if(p_S_TIMESTAMP is not null) then
          v_condition := v_condition || ' and TIMESTAMP >= to_date(''' || p_S_TIMESTAMP || ''',''yyyy-mm-dd'') ';
      end if;
      if(p_E_TIMESTAMP is not null) then
          v_condition := v_condition || ' and TIMESTAMP <= to_date(''' || p_E_TIMESTAMP || ' 23:59:59'',''yyyy-mm-dd hh24:mi:ss'') ';
      end if;
      if(p_S_CREATE_TIME is not null) then
          v_condition := v_condition || ' and CREATE_TIME >= to_date(''' || p_S_CREATE_TIME || ''',''yyyy-mm-dd'') ';
      end if;
      if(p_E_CREATE_TIME is not null) then
          v_condition := v_condition || ' and CREATE_TIME <= to_date(''' || p_E_CREATE_TIME || ' 23:59:59'',''yyyy-mm-dd hh24:mi:ss'') ';
      end if;
      if(p_IDCID  is not null ) then
          v_condition := v_condition || '  and IDCID =''' || p_IDCID || '''';
      end if;
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select COMMANDID,HOUSEID,CMD_TYPE,decode(CMD_TYPE,1,''监测指令'',2,''过滤指令'',3,''完成基础数据打开或关闭指令'',4,''代码发布指令'',''未知'') CMD_TYPE_NAME,RESULT_CODE,decode(RESULT_CODE,1,''成功'',2,''部分成功'',3,''失败'',''未知'') RESULT_CODE_NAME,MSGINFO,IDCID,COMMANDFILEID,TIMESTAMP,CREATE_TIME,DEAL_FLAG,decode(DEAL_FLAG,0,''未上报'',1,''上报中'',2,''上报失败'',3,''上报成功'',''未知'') DEAL_FLAG_NAME  from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;
procedure list_active_state(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_IDCID in varchar2,
      p_DEAL_FLAG in number,
      p_S_TIMESTAMP      in varchar2,
      p_E_TIMESTAMP      in varchar2,
      p_S_CREATE_TIME    in varchar2,
      p_E_CREATE_TIME    in varchar2
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from IDC_ISMS_REPLY_ACTIVE_STATE ';
      v_field    := ' REPLYID,IDCID,HOUSE_AMOUT,ERRHOUSE_AMOUT,ERRHOUSE_IDLIST,TIMESTAMP,CREATE_TIME,DEAL_FLAG ';

      --条件语句
      v_condition := ' where 1=1 ';
      if(p_IDCID  is not null ) then
          v_condition := v_condition || '  and IDCID =''' || p_IDCID || '''';
      end if;
      if p_DEAL_FLAG >0  then
          v_condition := v_condition || '  and DEAL_FLAG =' || (p_DEAL_FLAG-1);
      end if;
      if(p_S_TIMESTAMP is not null) then
          v_condition := v_condition || ' and TIMESTAMP >= to_date(''' || p_S_TIMESTAMP || ''',''yyyy-mm-dd'') ';
      end if;
      if(p_E_TIMESTAMP is not null) then
          v_condition := v_condition || ' and TIMESTAMP <= to_date(''' || p_E_TIMESTAMP || ' 23:59:59'',''yyyy-mm-dd hh24:mi:ss'') ';
      end if;
      if(p_S_CREATE_TIME is not null) then
          v_condition := v_condition || ' and CREATE_TIME >= to_date(''' || p_S_CREATE_TIME || ''',''yyyy-mm-dd'') ';
      end if;
      if(p_E_CREATE_TIME is not null) then
          v_condition := v_condition || ' and CREATE_TIME <= to_date(''' || p_E_CREATE_TIME || ' 23:59:59'',''yyyy-mm-dd hh24:mi:ss'') ';
      end if;
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := pageindex * pagesize;
          v_s := (pageindex - 1) * pagesize + 1;
          v_sql := 'select REPLYID,IDCID,HOUSE_AMOUT,ERRHOUSE_AMOUT,ERRHOUSE_IDLIST,idc_gethousename(ERRHOUSE_IDLIST) ERRHOUSE_IDLIST_NAME,TIMESTAMP,CREATE_TIME,DEAL_FLAG,decode(DEAL_FLAG,0,''未上报'',1,''上报中'',2,''上报失败'',3,''上报成功'',''未知'') DEAL_FLAG_NAME from (select rownum my_rownum,my_table.* from(';
          v_sql := v_sql || ' select ' || v_field || v_innersql ||
                   v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum<= ' || v_e ||
                   ' ) where my_rownum >= ' || v_s;
        end;
      end if;
      open p_cursor for v_sql;
  end;

----查询基础数据核验处理信息
procedure list_IDCInfo_validate(
                                p_isPaging in number,
                                p_curIndex in number,
                                p_pageSize in number,
                                p_isCount in number,
                                p_sortName in varchar2,
                                p_direction in varchar2,
                                p_cursor out sys_refcursor,
                                p_recordCount out number,

                                p_IDCId in varchar2,
                                p_beginTimestamp in varchar2,
                                p_endTimestamp in varchar2,
                                p_beginCreatetime in varchar2,
                                p_endCreateTime in varchar2,
                                p_dealFlag in number,
                                p_isResult in number
                                )is

      v_field     varchar2(2000); --字段
      v_innerSql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000) := ''; --条件语句
      v_countSql  varchar2(2000); --统计记录总数语句
      v_sql varchar2(2000); --查询语句
      v_startIndex number(10); --开始记录
      v_endIndex number(10); --结束记录
      v_temSql varchar2(500); --临时语句

    BEGIN
        v_field := ' RETURNINFOID,IDCID,RETRUNMSG,RETURNCODE,TIMESTAMP,CREATE_TIME,DEAL_FLAG,IS_RESULT ';
        v_innerSql := ' from IDC_ISMS_CMD_RETURN_INFO where 1 = 1 ';

        v_order := ' order by ' || p_sortName || ' ' || p_direction;

        if (p_IDCId is not null) then
           v_condition := v_condition || ' and IDCID like ''%' || p_IDCId || '%''';
        end if;
        if (p_beginTimestamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP >= to_date(''' || p_beginTimestamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_endTimestamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP <= to_date(''' || p_endTimestamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_beginCreatetime is not null) then
           v_condition := v_condition || ' and CREATE_TIME >= to_date(''' || p_beginCreatetime || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_endCreateTime is not null) then
           v_condition := v_condition || ' and CREATE_TIME <= to_date(''' || p_endCreateTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if p_dealFlag >= 0 then
           v_condition := v_condition || ' and DEAL_FLAG = ' || p_dealFlag;
        end if;
        if p_isResult >= 0 then
           v_condition := v_condition || ' and IS_RESULT = ' || p_isResult;
        end if;
        --统计总记录数
        if p_isCount = 1 then
           v_countSql := 'select count(1)' || v_innerSql || v_condition;
           execute immediate v_countSql into p_recordCount;
        end if;

        v_temSql := v_field || v_innerSql || v_condition || v_order;
        if p_isPaging = 1 then
          v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
           v_endIndex := p_curIndex * p_pageSize;
           v_sql := 'select ' || v_field || 'from (select a.*,rownum rn from (select ';
           v_sql := v_sql || v_temSql || ') a where rownum <= ' || v_endIndex;
           v_sql := v_sql || ') where rn >= ' || v_startIndex;
        else
           v_sql := 'select ' || v_temSql;
        end if;
        open p_cursor for v_sql;
    END;

--查询基础数据核验处理信息对应的机房信息
procedure list_validate_houseInfo(
                    p_isPaging in number,
                    p_curIndex in number,
                    p_pageSize in number,
                    p_isCount in number,
                    p_sortName in varchar2,
                    p_direction in varchar2,
                    p_cursor out sys_refcursor,
                    p_recordCount out number,

                    p_returnInfoId in number,
                    p_gatewayId in number,
                    p_ipSegId in number,
                    p_frameInfoId in number
)is

        v_field     varchar2(2000); --字段
        v_innerSql  varchar2(2000); --内部语句，完整的查询sql
        v_order     varchar2(500); --内部排序语句
        v_condition varchar2(2000) := ''; --条件语句
        v_countSql  varchar2(2000); --统计记录总数语句
        v_sql varchar2(2000); --查询语句
        v_startIndex number(10); --开始记录
        v_endIndex number(10); --结束记录
        v_temSql varchar2(500); --临时语句

    BEGIN
        v_field := ' HOUSEID,RETURNINFOID,GATEWAYID,IPSEGID,FRAMEINFOID ';
        v_innerSql := ' from IDC_ISMS_CMD_RETURN_HOUSE_INFO where RETURNINFOID = ' || p_returnInfoId || ' and 1 = 1 ';

        v_order := ' order by ' || p_sortName || ' ' || p_direction;

        if p_gatewayId > 0 then
           v_condition := v_condition || ' and GATEWAYID = ' || p_gatewayId;
        end if;
         if p_ipSegId >= 0 then
           v_condition := v_condition || ' and IPSEGID = ' || p_ipSegId;
        end if;
        if p_frameInfoId > 0 then
           v_condition := v_condition || ' and FRAMEINFOID = ' || p_frameInfoId;
        end if;

        --统计总记录数
        if p_isCount = 1 then
           v_countSql := 'select count(1)' || v_innerSql || v_condition;
           execute immediate v_countSql into p_recordCount;
        end if;

        v_temSql := v_field || v_innerSql || v_condition || v_order;
        if p_isPaging = 1 then
          v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
           v_endIndex := p_curIndex * p_pageSize;
           v_sql := 'select ' || v_field || 'from (select a.*,rownum rn from (select ';
           v_sql := v_sql || v_temSql || ') a where rownum <= ' || v_endIndex;
           v_sql := v_sql || ') where rn >= ' || v_startIndex;
        else
           v_sql := 'select ' || v_temSql;
        end if;
        open p_cursor for v_sql;
    END;

--查询基础数据核验处理信息对应的用户信息
procedure list_validate_userInfo(
                    p_isPaging in number,
                    p_curIndex in number,
                    p_pageSize in number,
                    p_isCount in number,
                    p_sortName in varchar2,
                    p_direction in varchar2,
                    p_cursor out sys_refcursor,
                    p_recordCount out number,

                    p_returnInfoId in number,
                    p_hhId in number
)is

        v_field     varchar2(2000); --字段
        v_innerSql  varchar2(2000); --内部语句，完整的查询sql
        v_order     varchar2(500); --内部排序语句
        v_condition varchar2(2000) := ''; --条件语句
        v_countSql  varchar2(2000); --统计记录总数语句
        v_sql varchar2(2000); --查询语句
        v_startIndex number(10); --开始记录
        v_endIndex number(10); --结束记录
        v_temSql varchar2(500); --临时语句

    BEGIN
        v_field := ' USERID,RETURNINFOID,HHID ';
        v_innerSql := ' from IDC_ISMS_CMD_RETURN_USER_INFO where RETURNINFOID = ' || p_returnInfoId || ' and 1 = 1 ';

        v_order := ' order by ' || p_sortName || ' ' || p_direction;

        if p_hhId > 0 then
           v_condition := v_condition || ' and HHID = ' || p_hhId;
        end if;

        --统计总记录数
        if p_isCount = 1 then
           v_countSql := 'select count(1)' || v_innerSql || v_condition;
           execute immediate v_countSql into p_recordCount;
        end if;

        v_temSql := v_field || v_innerSql || v_condition || v_order;
        if p_isPaging = 1 then
          v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
           v_endIndex := p_curIndex * p_pageSize;
           v_sql := 'select ' || v_field || 'from (select a.*,rownum rn from (select ';
           v_sql := v_sql || v_temSql || ') a where rownum <= ' || v_endIndex;
           v_sql := v_sql || ') where rn >= ' || v_startIndex;
        else
           v_sql := 'select ' || v_temSql;
        end if;
        open p_cursor for v_sql;
    END;

--查询核验信息对应用户信息下的服务信息
procedure list_validate_usInfo(
                    p_isPaging in number,
                    p_curIndex in number,
                    p_pageSize in number,
                    p_isCount in number,
                    p_sortName in varchar2,
                    p_direction in varchar2,
                    p_cursor out sys_refcursor,
                    p_recordCount out number,

                    p_userId in number,
                    p_domainId in number,
                    p_hhId in number
)is

        v_field     varchar2(2000); --字段
        v_innerSql  varchar2(2000); --内部语句，完整的查询sql
        v_order     varchar2(500); --内部排序语句
        v_condition varchar2(2000) := ''; --条件语句
        v_countSql  varchar2(2000); --统计记录总数语句
        v_sql varchar2(2000); --查询语句
        v_startIndex number(10); --开始记录
        v_endIndex number(10); --结束记录
        v_temSql varchar2(500); --临时语句

    BEGIN
        v_field := ' SERVICEID,RETURNINFOID,DOMAINID,HHID ';
        v_innerSql := ' from IDC_ISMS_CMD_RETURN_US_INFO where RETURNINFOID = ' || p_userId || ' and 1 = 1 ';

        v_order := ' order by ' || p_sortName || ' ' || p_direction;

        if p_domainId > 0 then
           v_condition := v_condition || ' and DOMAINID = ' || p_domainId;
        end if;
        if p_hhId > 0 then
           v_condition := v_condition || ' and HHID = ' || p_hhId;
        end if;

        --统计总记录数
        if p_isCount = 1 then
           v_countSql := 'select count(1)' || v_innerSql || v_condition;
           execute immediate v_countSql into p_recordCount;
        end if;

        v_temSql := v_field || v_innerSql || v_condition || v_order;
        if p_isPaging = 1 then
          v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
           v_endIndex := p_curIndex * p_pageSize;
           v_sql := 'select ' || v_field || 'from (select a.*,rownum rn from (select ';
           v_sql := v_sql || v_temSql || ') a where rownum <= ' || v_endIndex;
           v_sql := v_sql || ') where rn >= ' || v_startIndex;
        else
           v_sql := 'select ' || v_temSql;
        end if;
        open p_cursor for v_sql;
    END;

--查询免过滤网站列表指令
procedure list_IDCInfo_no_filter(
                  p_isPaging in number,
                  p_curIndex in number,
                  p_pageSize in number,
                  p_isCount in number,
                  p_sortName in varchar2,
                  p_direction in varchar2,
                  p_cursor out sys_refcursor,
                  p_recordCount out number,

                  p_commandId in number,
                  p_idcId in varchar2,
                  p_opeType in number,
                  p_type in number,
                  p_content in varchar2,
                  p_dealFlag in number,
                  p_beginTimeStamp in varchar2,
                  p_endTimeStamp in varchar2
)is

        v_field     varchar2(2000); --字段
        v_innerSql  varchar2(2000); --内部语句，完整的查询sql
        v_order     varchar2(500); --内部排序语句
        v_condition varchar2(2000) := ''; --条件语句
        v_countSql  varchar2(2000); --统计记录总数语句
        v_sql varchar2(2000); --查询语句
        v_startIndex number(10); --开始记录
        v_endIndex number(10); --结束记录
        v_temSql varchar2(500); --临时语句

    BEGIN
        v_field := ' COMMANDID,IDCID,OPERATIONTYPE,COMMANDTYPE,CONTENT,TIMESTAMP,LEVEL_BINARY,LEVEL_DECIMAL,DEAL_FLAG ';
        --加上COMMANDID > 0为了过滤掉免过滤网站信息
        v_innerSql := ' from IDC_ISMS_CMD_NO_FILTER where COMMANDID > 0 ';

        v_order := ' order by ' || p_sortName || ' ' || p_direction;

        if p_commandId > 0 then
           v_condition := v_condition || ' and COMMANDID = ' || p_commandId;
        end if;
        if (p_idcId is not null) then
           v_condition := v_condition || ' and IDCID like ''%' || p_idcId || '%''';
        end if;
        if p_opeType >= 0 then
           v_condition := v_condition || ' and OPERATIONTYPE = ' || p_opeType;
        end if;
        if p_type > 0 then
           v_condition := v_condition || ' and COMMANDTYPE = ' || p_type;
        end if;
        if (p_content is not null) then
           v_condition := v_condition || ' and CONTENT like ''%' || p_content || '%''';
        end if;
        if p_dealFlag >= 0 then
           v_condition := v_condition || ' and DEAL_FLAG = ' || p_dealFlag;
        end if;
        if (p_beginTimeStamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP >= to_date(''' || p_beginTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_endTimeStamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP <= to_date(''' || p_endTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;

        --统计总记录数
        if p_isCount = 1 then
           v_countSql := 'select count(1)' || v_innerSql || v_condition;
           execute immediate v_countSql into p_recordCount;
        end if;

        v_temSql := v_field || v_innerSql || v_condition || v_order;
        if p_isPaging = 1 then
          v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
           v_endIndex := p_curIndex * p_pageSize;
           v_sql := 'select ' || v_field || 'from (select a.*,rownum rn from (select ';
           v_sql := v_sql || v_temSql || ') a where rownum <= ' || v_endIndex;
           v_sql := v_sql || ') where rn >= ' || v_startIndex;
        else
           v_sql := 'select ' || v_temSql;
        end if;
        open p_cursor for v_sql;
    END;

--查询违法网站列表指令
procedure list_IDCInfo_Black(
                  p_isPaging in number,
                  p_curIndex in number,
                  p_pageSize in number,
                  p_isCount in number,
                  p_sortName in varchar2,
                  p_direction in varchar2,
                  p_cursor out sys_refcursor,
                  p_recordCount out number,

                  p_commandId in number,
                  p_idcId in varchar2,
                  p_opeType in number,
                  p_type in number,
                  p_content in varchar2,
                  p_dealFlag in number,
                  p_beginTimeStamp in varchar2,
                  p_endTimeStamp in varchar2
)is

        v_field     varchar2(2000); --字段
        v_innerSql  varchar2(2000); --内部语句，完整的查询sql
        v_order     varchar2(500); --内部排序语句
        v_condition varchar2(2000) := ''; --条件语句
        v_countSql  varchar2(2000); --统计记录总数语句
        v_sql varchar2(2000); --查询语句
        v_startIndex number(10); --开始记录
        v_endIndex number(10); --结束记录
        v_temSql varchar2(500); --临时语句

    BEGIN
        v_field := ' COMMANDID,IDCID,OPERATIONTYPE,COMMANDTYPE,CONTENT,TIMESTAMP,LEVEL_BINARY,LEVEL_DECIMAL,DEAL_FLAG ';
        --加上COMMANDID > 0为了过滤掉违法网站信息
        v_innerSql := ' from IDC_ISMS_CMD_BLACK_LIST where COMMANDID > 0 ';

        v_order := ' order by ' || p_sortName || ' ' || p_direction;

        if p_commandId > 0 then
           v_condition := v_condition || ' and COMMANDID = ' || p_commandId;
        end if;
        if (p_idcId is not null) then
           v_condition := v_condition || ' and IDCID like ''%' || p_idcId || '%''';
        end if;
        if p_opeType >= 0 then
           v_condition := v_condition || ' and OPERATIONTYPE = ' || p_opeType;
        end if;
        if p_type > 0 then
           v_condition := v_condition || ' and COMMANDTYPE = ' || p_type;
        end if;
        if (p_content is not null) then
           v_condition := v_condition || ' and CONTENT like ''%' || p_content || '%''';
        end if;
        if p_dealFlag >= 0 then
           v_condition := v_condition || ' and DEAL_FLAG = ' || p_dealFlag;
        end if;
        if (p_beginTimeStamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP >= to_date(''' || p_beginTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_endTimeStamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP <= to_date(''' || p_endTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;

        --统计总记录数
        if p_isCount = 1 then
           v_countSql := 'select count(1)' || v_innerSql || v_condition;
           execute immediate v_countSql into p_recordCount;
        end if;

        v_temSql := v_field || v_innerSql || v_condition || v_order;
        if p_isPaging = 1 then
          v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
           v_endIndex := p_curIndex * p_pageSize;
           v_sql := 'select ' || v_field || 'from (select a.*,rownum rn from (select ';
           v_sql := v_sql || v_temSql || ') a where rownum <= ' || v_endIndex;
           v_sql := v_sql || ') where rn >= ' || v_startIndex;
        else
           v_sql := 'select ' || v_temSql;
        end if;
        open p_cursor for v_sql;
    END;

--查询活跃资源访问量查询指令
procedure list_IDCInfo_query_view(
                    p_isPaging in number,
                    p_curIndex in number,
                    p_pageSize in number,
                    p_isCount in number,
                    p_sortName in varchar2,
                    p_direction in varchar2,
                    p_cursor out sys_refcursor,
                    p_recordCount out number,

                    p_commandId in number,
                    p_idcId in varchar2,
                    p_type in number,
                    p_content in varchar2,
                    p_dealFlag in number,
                    p_beginQueryTime in varchar2,
                    p_endQueryTime in varchar2,
                    p_beginTimeStamp in varchar2,
                    p_endTimeStamp in varchar2
)is
        v_field     varchar2(2000); --字段
        v_innerSql  varchar2(2000); --内部语句，完整的查询sql
        v_order     varchar2(500); --内部排序语句
        v_condition varchar2(2000) := ''; --条件语句
        v_countSql  varchar2(2000); --统计记录总数语句
        v_sql varchar2(2000); --查询语句
        v_startIndex number(10); --开始记录
        v_endIndex number(10); --结束记录
        v_temSql varchar2(500); --临时语句

    BEGIN
        v_field := ' COMMANDID,IDCID,QUERYTYPE,CONTENT,QUERYTIME,TIMESTAMP,CREATE_TIME,DEAL_FLAG ';
        v_innerSql := ' from IDC_ISMS_CMD_QUERY_VIEW where 1 = 1 ';

        v_order := ' order by ' || p_sortName || ' ' || p_direction;

        if p_commandId > 0 then
           v_condition := v_condition || ' and COMMANDID = ' || p_commandId;
        end if;
        if (p_idcId is not null) then
           v_condition := v_condition || ' and IDCID like ''%' || p_idcId || '%''';
        end if;
        if p_type > 0 then
           v_condition := v_condition || ' and QUERYTYPE = ' || p_type;
        end if;
        if (p_content is not null) then
           v_condition := v_condition || ' and CONTENT like ''%' || p_content || '%''';
        end if;
        if p_dealFlag >= 0 then
           v_condition := v_condition || ' and DEAL_FLAG = ' || p_dealFlag;
        end if;
        if (p_beginQueryTime is not null) then
           v_condition := v_condition || ' and QUERYTIME >= to_date(''' || p_beginQueryTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_endQueryTime is not null) then
           v_condition := v_condition || ' and QUERYTIME <= to_date(''' || p_endQueryTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
         if (p_beginTimeStamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP >= to_date(''' || p_beginTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_endTimeStamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP <= to_date(''' || p_endTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;

        --统计总记录数
        if p_isCount = 1 then
           v_countSql := 'select count(1)' || v_innerSql || v_condition;
           execute immediate v_countSql into p_recordCount;
        end if;

        v_temSql := v_field || v_innerSql || v_condition || v_order;
        if p_isPaging = 1 then
          v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
           v_endIndex := p_curIndex * p_pageSize;
           v_sql := 'select ' || v_field || 'from (select a.*,rownum rn from (select ';
           v_sql := v_sql || v_temSql || ') a where rownum <= ' || v_endIndex;
           v_sql := v_sql || ') where rn >= ' || v_startIndex;
        else
           v_sql := 'select ' || v_temSql;
        end if;
        open p_cursor for v_sql;
    END;

--查询违法管理指令执行记录指令
procedure list_IDCInfo_black_record(
                    p_isPaging in number,
                    p_curIndex in number,
                    p_pageSize in number,
                    p_isCount in number,
                    p_sortName in varchar2,
                    p_direction in varchar2,
                    p_cursor out sys_refcursor,
                    p_recordCount out number,

                    p_commandId in number,
                    p_idcId in varchar2,
                    p_controlsId in number,
                    p_dealFlag in number,
                    p_beginTimeStamp in varchar2,
                    p_endTimeStamp in varchar2,
                    p_beginCreateTime in varchar2,
                    p_endCreateTime in varchar2
)is

        v_field     varchar2(2000); --字段
        v_innerSql  varchar2(2000); --内部语句，完整的查询sql
        v_order     varchar2(500); --内部排序语句
        v_condition varchar2(2000) := ''; --条件语句
        v_countSql  varchar2(2000); --统计记录总数语句
        v_sql varchar2(2000); --查询语句
        v_startIndex number(10); --开始记录
        v_endIndex number(10); --结束记录
        v_temSql varchar2(500); --临时语句

    BEGIN
        v_field := ' COMMANDID,IDCID,CONTROLSID,TIMESTAMP,CREATE_TIME,DEAL_FLAG ';
        v_innerSql := ' from IDC_ISMS_CMD_COMMAND_RECORD where 1 = 1 ';

        v_order := ' order by ' || p_sortName || ' ' || p_direction;

        if p_commandId > 0 then
           v_condition := v_condition || ' and COMMANDID = ' || p_commandId;
        end if;
        if (p_idcId is not null) then
           v_condition := v_condition || ' and IDCID like ''%' || p_idcId || '%''';
        end if;
        if p_controlsId > 0 then
           v_condition := v_condition || ' and CONTROLSID = ' || p_controlsId;
        end if;
        if p_dealFlag >= 0 then
           v_condition := v_condition || ' and DEAL_FLAG = ' || p_dealFlag;
        end if;
        if (p_beginTimeStamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP >= to_date(''' || p_beginTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_endTimeStamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP <= to_date(''' || p_endTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_beginCreateTime is not null) then
           v_condition := v_condition || ' and CREATE_TIME >= to_date(''' || p_beginCreateTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_endCreateTime is not null) then
           v_condition := v_condition || ' and CREATE_TIME <= to_date(''' || p_endCreateTime || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;

        --统计总记录数
        if p_isCount = 1 then
           v_countSql := 'select count(1)' || v_innerSql || v_condition;
           execute immediate v_countSql into p_recordCount;
        end if;

        v_temSql := v_field || v_innerSql || v_condition || v_order;
        if p_isPaging = 1 then
          v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
           v_endIndex := p_curIndex * p_pageSize;
           v_sql := 'select ' || v_field || 'from (select a.*,rownum rn from (select ';
           v_sql := v_sql || v_temSql || ') a where rownum <= ' || v_endIndex;
           v_sql := v_sql || ') where rn >= ' || v_startIndex;
        else
           v_sql := 'select ' || v_temSql;
        end if;
        open p_cursor for v_sql;
    END;

--查询指令处理后生成文件信息
procedure list_IDCInfo_fileInfo(
                  p_isPaging in number,
                  p_curIndex in number,
                  p_pageSize in number,
                  p_isCount in number,
                  p_sortName in varchar2,
                  p_direction in varchar2,
                  p_cursor out sys_refcursor,
                  p_recordCount out number,
                  p_commandType in number,
                  p_commandId in varchar2,
                  p_filename in varchar2,
                  p_fileState in number,
                  p_beginCreatetime in varchar2,
                  p_endCreatetime in varchar2,
                  p_beginUpdatetime in varchar2,
                  p_endUpdatetime in varchar2
)is

        v_field     varchar2(2000); --字段
        v_innerSql  varchar2(2000); --内部语句，完整的查询sql
        v_order     varchar2(500); --内部排序语句
        v_condition varchar2(2000) := ''; --条件语句
        v_countSql  varchar2(2000); --统计记录总数语句
        v_sql varchar2(2000); --查询语句
        v_startIndex number(10); --开始记录
        v_endIndex number(10); --结束记录
        v_temSql varchar2(500); --临时语句

    BEGIN
        v_field := ' COMMANDID,COMMANDTYPE,FILENAME,FILE_STATE,CREATE_TIME,UPDATE_TIME,DMMS ';
        v_innerSql := ' from IDC_ISMS_CMD_FILE_STATE where 1 = 1 ';

        v_order := ' order by ' || p_sortName || ' ' || p_direction;

        if(p_commandType > 0) then
           v_condition := v_condition || ' and COMMANDTYPE = ' || p_commandType;
        end if;
        if (p_commandId is not null) then
           v_condition := v_condition || ' and COMMANDID = ''' || p_commandId || '''';
        end if;
        if (p_filename is not null) then
           v_condition := v_condition || ' and FILENAME like ''%' || p_filename || '%''';
        end if;
        if p_fileState >= -1 then
           v_condition := v_condition || ' and FILE_STATE = ' || p_fileState;
        end if;
        if (p_beginCreatetime is not null) then
           v_condition := v_condition || ' and CREATE_TIME >= to_date(''' || p_beginCreatetime || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_endCreatetime is not null) then
           v_condition := v_condition || ' and CREATE_TIME <= to_date(''' || p_endCreatetime || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
         if (p_beginUpdatetime is not null) then
           v_condition := v_condition || ' and UPDATE_TIME >= to_date(''' || p_beginUpdatetime || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_endUpdatetime is not null) then
           v_condition := v_condition || ' and UPDATE_TIME <= to_date(''' || p_endUpdatetime || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;

        --统计总记录数
        if p_isCount = 1 then
           v_countSql := 'select count(1)' || v_innerSql || v_condition;
           execute immediate v_countSql into p_recordCount;
        end if;

        v_temSql := v_field || v_innerSql || v_condition || v_order;
        if p_isPaging = 1 then
          v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
           v_endIndex := p_curIndex * p_pageSize;
           v_sql := 'select ' || v_field || 'from (select a.*,rownum rn from (select ';
           v_sql := v_sql || v_temSql || ') a where rownum <= ' || v_endIndex;
           v_sql := v_sql || ') where rn >= ' || v_startIndex;
        else
           v_sql := 'select ' || v_temSql;
        end if;
        dbms_output.put_line(v_sql);
        open p_cursor for v_sql;
    END;
    
    --查询指令处理后ack状态信息
procedure list_IDCInfo_ACKInfo(
      p_isPaging in number,
      p_curIndex in number,
      p_pageSize in number,
      p_isCount in number,
      p_sortName in varchar2,
      p_direction in varchar2,
      p_cursor out sys_refcursor,
      p_recordCount out number,
      p_commandType in number,
      p_commandId in number,
      p_houseId in varchar2,
      p_resultCode in number,
      p_idcId in varchar2,
      p_timeStampStart in varchar2,
      p_timeStampEnd in varchar2,
      p_dealFlag in number,
      p_createTimeStart in varchar2,
      p_createTimeEnd in varchar2
)is

        v_field     varchar2(2000); --字段
        v_innerSql  varchar2(2000); --内部语句，完整的查询sql
        v_order     varchar2(500); --内部排序语句
        v_condition varchar2(2000) := ''; --条件语句
        v_countSql  varchar2(2000); --统计记录总数语句
        v_sql varchar2(2000); --查询语句
        v_startIndex number(10); --开始记录
        v_endIndex number(10); --结束记录
        v_temSql varchar2(500); --临时语句

    BEGIN
        v_field := ' ackid,COMMANDID,cmd_type,idcID,deal_flag,CREATE_TIME,houseId,result_Code,TIMESTAMP ';
        v_innerSql := ' from IDC_ISMS_REPLY_CMD_ACK where 1 = 1 ';

        v_order := ' order by ' || p_sortName || ' ' || p_direction;

        if(p_commandType > 0) then
           v_condition := v_condition || ' and CMD_TYPE = ' || p_commandType;
        end if;
        if (p_commandId is not null) then
           v_condition := v_condition || ' and COMMANDID = ''' || p_commandId || '''';
        end if;
        if (p_resultCode >=0) then
           v_condition := v_condition || ' and RESULT_CODE like ''%' || p_resultCode || '%''';
        end if;
        if (p_dealFlag >=0) then
           v_condition := v_condition || ' and deal_flag = ' || p_dealFlag ;
        end if;
        if (p_timeStampStart is not null) then
           v_condition := v_condition || ' and timeStamp >= to_date(''' || p_timeStampStart || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_timeStampEnd is not null) then
           v_condition := v_condition || ' and timeStamp <= to_date(''' || p_timeStampEnd || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_createTimeStart is not null) then
           v_condition := v_condition || ' and CREATE_TIME >= to_date(''' || p_createTimeStart || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_createTimeEnd is not null) then
           v_condition := v_condition || ' and CREATE_TIME <= to_date(''' || p_createTimeEnd || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        
        --统计总记录数
        if p_isCount = 1 then
           v_countSql := 'select count(1)' || v_innerSql || v_condition;
           execute immediate v_countSql into p_recordCount;
        end if;

        v_temSql := v_field || v_innerSql || v_condition || v_order;
        if p_isPaging = 1 then
          v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
           v_endIndex := p_curIndex * p_pageSize;
           v_sql := 'select ' || v_field || 'from (select a.*,rownum rn from (select ';
           v_sql := v_sql || v_temSql || ') a where rownum <= ' || v_endIndex;
           v_sql := v_sql || ') where rn >= ' || v_startIndex;
        else
           v_sql := 'select ' || v_temSql;
        end if;
        dbms_output.put_line(v_sql);
        open p_cursor for v_sql;
    END;


--查询代码发布表指令
procedure list_IDCInfo_code_release(
              p_isPaging in number,
              p_curIndex in number,
              p_pageSize in number,
              p_isCount in number,
              p_sortName in varchar2,
              p_direction in varchar2,
              p_cursor out sys_refcursor,
              p_recordCount out number,

              p_commandId in varchar2,
              p_filename in varchar2,
              p_dealFlag in number,
              p_beginTimeStamp in varchar2,
              p_endTimeStamp in varchar2
)is
        v_field     varchar2(2000); --字段
        v_innerSql  varchar2(2000); --内部语句，完整的查询sql
        v_order     varchar2(500); --内部排序语句
        v_condition varchar2(2000) := ''; --条件语句
        v_countSql  varchar2(2000); --统计记录总数语句
        v_sql varchar2(2000); --查询语句
        v_startIndex number(10); --开始记录
        v_endIndex number(10); --结束记录
        v_temSql varchar2(500); --临时语句

    BEGIN
        v_field := ' COMMANDID,FILENAME,TIMESTAMP,DEAL_FLAG ';
        v_innerSql := ' from IDC_ISMS_CMD_CODE_LIST where 1 = 1 ';

        v_order := ' order by ' || p_sortName || ' ' || p_direction;


        if p_commandId > 0 then
           v_condition := v_condition || ' and COMMANDID = ' || p_commandId;
        end if;
        if (p_filename is not null) then
           v_condition := v_condition || ' and FILENAME = ''%' || p_filename || '%''';
        end if;
        if p_dealFlag >= 0 then
           v_condition := v_condition || ' and DEAL_FLAG = ' || p_dealFlag;
        end if;
        if (p_beginTimeStamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP >= to_date(''' || p_beginTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;
        if (p_endTimeStamp is not null) then
           v_condition := v_condition || ' and TIMESTAMP <= to_date(''' || p_endTimeStamp || ''',''yyyy-mm-dd hh24:mi:ss'')';
        end if;

        --统计总记录数
        if p_isCount = 1 then
           v_countSql := 'select count(1)' || v_innerSql || v_condition;
           execute immediate v_countSql into p_recordCount;
        end if;

        v_temSql := v_field || v_innerSql || v_condition || v_order;
        if p_isPaging = 1 then
          v_startIndex := (p_curIndex - 1) * p_pageSize + 1;
           v_endIndex := p_curIndex * p_pageSize;
           v_sql := 'select ' || v_field || 'from (select a.*,rownum rn from (select ';
           v_sql := v_sql || v_temSql || ') a where rownum <= ' || v_endIndex;
           v_sql := v_sql || ') where rn >= ' || v_startIndex;
        else
           v_sql := 'select ' || v_temSql;
        end if;
        open p_cursor for v_sql;
    END;

end IDC_ISMS_SYSTEM_CMD_MANAGE;
/
