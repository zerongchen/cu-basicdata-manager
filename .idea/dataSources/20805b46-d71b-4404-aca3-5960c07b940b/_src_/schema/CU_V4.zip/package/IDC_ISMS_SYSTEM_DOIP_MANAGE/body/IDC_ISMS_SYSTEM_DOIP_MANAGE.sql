CREATE package body IDC_ISMS_SYSTEM_DOIP_MANAGE is
procedure list_domain(
      p_isPaging in number,
      p_pageIndex in number,
      p_pageSize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_houseidstr in varchar2,
      p_domaintype in number,
      p_domain in varchar2
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_fieldsel varchar2(1000);
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from idc_isms_base_domain_info ';
      v_field    :=  ' id,domain,houseidstr,domaintype as violation,decode(domaintype,0,''正常'',1,''黑名单'',''未知'') as violationstr,create_time ';
      v_fieldsel :=  ' id,domain,houseidstr, violation, violationstr,create_time ';
      --条件语句
      v_condition := ' where 1=1 ';
      if p_houseidstr is not null and To_Number(Length(p_houseidstr)) > 0 then
       v_condition := v_condition || ' and houseidstr like ''%'|| p_houseidstr || '%''';
      end if;
      if p_domaintype >= 0 then
        v_condition := v_condition || ' and domaintype = ' || p_domaintype;
      end if;
      if p_domain is not null and To_Number(Length(p_domain)) > 0 then
        v_condition := v_condition || ' and domain like ''%'|| p_domain || '%''';
      end if;

      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

        if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := p_pageIndex * p_pageSize;
          v_s := (p_pageIndex - 1) * p_pageSize + 1;
          v_sql := ' select ' || v_fieldsel || ' from (select rownum my_rownum, my_table.* from ( ';
          v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
        end;
      end if;

      --v_sql := 'select id,domain,houseidstr,domaintype as violation,decode(domaintype,0,''正常'',1,''黑名单'',''未知'') as violationstr,create_time from idc_isms_base_domain_info '||v_condition||v_order;
      open p_cursor for v_sql;
      end;

procedure list_ip(
      p_isPaging in number,
      p_pageIndex in number,
      p_pageSize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_houseidstr in varchar2,
      p_iptype in number,
      p_ip1 in varchar2,
      p_ip2 in varchar2
      )is
     --定义
      v_field     varchar2(2000); --字段
      v_fieldsel varchar2(1000);
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := ' from idc_isms_base_ip_info ';
      v_field    :=  ' id,startip as IP,endip as IP1,houseidstr,iptype as violation,decode(iptype,0,''正常'',1,''保留'',''未知'') as violationstr,create_time ';
      v_fieldsel :=  ' id,IP,IP1,houseidstr,violation,violationstr,create_time ';

      --条件语句
      v_condition := ' where 1=1 ';
      if p_houseidstr is not null and To_Number(Length(p_houseidstr)) > 0 then
       v_condition := v_condition || ' and houseidstr like ''%'|| p_houseidstr || '%''';
      end if;
      if p_iptype >= 0 then
        v_condition := v_condition || ' and iptype = ' || p_iptype;
      end if;
      if p_ip1 is not null and To_Number(Length(p_ip1)) > 0 then
        v_condition := v_condition || ' and ip2int('''|| p_ip1 ||''') >= ip2int(startip) ';
      end if;

       if p_ip2 is not null and To_Number(Length(p_ip2)) > 0 then
        v_condition := v_condition || ' and ip2int('''|| p_ip2 ||''')   <= ip2int(endip) ';
      end if;

      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

       if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := p_pageIndex * p_pageSize;
          v_s := (p_pageIndex - 1) * p_pageSize + 1;
          v_sql := ' select ' || v_fieldsel || ' from (select rownum my_rownum, my_table.* from ( ';
          v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
        end;
      end if;

      --v_sql := 'select id,startip as IP,endip as IP1,houseidstr,iptype as violation,decode(iptype,0,''正常'',1,''保留'',''未知'') as violationstr,create_time from idc_isms_base_ip_info '||v_condition||v_order;
      open p_cursor for v_sql;
      end;

procedure list_domainip(
      p_isPaging in number,
      p_pageIndex in number,
      p_pageSize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      p_houseidstr in varchar2,
      p_ip1 in varchar2,
      p_ip2 in varchar2,
      p_domain in varchar2
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_fieldsel varchar2(1000);
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
       --内部sql语句
      v_innersql := ' from idc_isms_base_ip_domain_info ';
      v_field    :=  ' id,startip as IP,endip as IP1,houseidstr,domain,create_time ';
      v_fieldsel :=  ' id,IP, IP1,houseidstr,domain,create_time ';

      --条件语句
      v_condition := ' where 1=1 ';
      if p_houseidstr is not null and To_Number(Length(p_houseidstr)) > 0 then
       v_condition := v_condition || ' and houseidstr like ''%'|| p_houseidstr || '%''';
      end if;

       if p_domain is not null and To_Number(Length(p_domain)) > 0 then
        v_condition := v_condition || ' and domain like ''%'|| p_domain || '%''';
      end if;

      if p_ip1 is not null and To_Number(Length(p_ip1)) > 0 then
        v_condition := v_condition || ' and ip2int('''|| p_ip1 ||''') >= ip2int(startip) ';
      end if;

       if p_ip2 is not null and To_Number(Length(p_ip2)) > 0 then
        v_condition := v_condition || ' and ip2int('''|| p_ip2 ||''')   <= ip2int(endip) ';
      end if;

      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

          if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
        begin
          v_e := p_pageIndex * p_pageSize;
          v_s := (p_pageIndex - 1) * p_pageSize + 1;
          v_sql := ' select ' || v_fieldsel || ' from (select rownum my_rownum, my_table.* from ( ';
          v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
          v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
        end;
      end if;

      --v_sql := 'select id,startip as IP,endip as IP1,houseidstr,domain,create_time from idc_isms_base_ip_domain_info '||v_condition||v_order;
      open p_cursor for v_sql;
      end;
    procedure   add_domain(
                p_domain in varchar2,
                p_houseidstr in varchar2,
                p_domaintype in  number,
                o_returnvalue out number
                )is
         v_count number(10);
         v_sqlstr varchar2(1000);
         v_innersql varchar2(1000);
         v_condition varchar2(1000);
     begin
       o_returnvalue := 0;
       v_innersql := ' from idc_isms_base_domain_info ';
       --条件语句
      v_condition := ' where 1=1 ';
      if p_houseidstr is not null and To_Number(Length(p_houseidstr)) > 0 then
       v_condition := v_condition || ' and houseidstr = '''|| p_houseidstr || '''';
      end if;
     /* if p_domaintype >= 0 then
        v_condition := v_condition || ' and domaintype = ' || p_domaintype;
      end if;*/
      if p_domain is not null and To_Number(Length(p_domain)) > 0 then
        v_condition := v_condition || ' and domain = '''|| p_domain || '''';
      end if;
      v_sqlstr := 'select count(1) ' || v_innersql || v_condition;
       execute immediate v_sqlstr into v_count;
       begin
       if v_count = 0 then
         insert into idc_isms_base_domain_info(id,domaintype,domain,houseidstr)
         values(seq_idc_isms_base_domain_info.nextval,p_domaintype,p_domain,p_houseidstr);
         o_returnvalue:=1;
         commit;
         end if;
       Exception when others then
         o_returnvalue:= -1;
       end;
   end add_domain;

   procedure   add_ip(
                p_startip in varchar2,
                p_endip in varchar2,
                p_houseidstr in varchar2,
                p_iptype in  number,
                o_returnvalue out number
                )is
         v_count number(10);
         v_houseidstr number(10);
         v_sqlstr varchar2(1000);
         v_innersql varchar2(1000);
         v_condition varchar2(1000);
     begin
       o_returnvalue := 0;
       v_innersql := ' from idc_isms_base_ip_info ';
       --条件语句
      v_condition := ' where 1=1 ';
      if p_houseidstr is not null and To_Number(Length(p_houseidstr)) > 0 then
         select house.houseidstr into v_houseidstr from idc_isms_base_house house where houseid = To_Number(p_houseidstr);
         v_condition := v_condition || ' and houseidstr = '''|| v_houseidstr || '''';
      end if;
    /* if p_iptype >= 0 then
        v_condition := v_condition || ' and iptype = ' || p_iptype;
      end if;*/
      if p_startip is not null and To_Number(Length(p_startip)) > 0 then
        v_condition := v_condition || ' and startip = '''|| p_startip || '''';
      end if;
        if p_endip is not null and To_Number(Length(p_endip)) > 0 then
        v_condition := v_condition || ' and endip = '''|| p_endip || '''';
      end if;

      v_sqlstr := 'select count(1) ' || v_innersql || v_condition;
       execute immediate v_sqlstr into v_count;
       begin
       if v_count = 0 then
         insert into idc_isms_base_ip_info(id,startip,endip,iptype,houseidstr)
         values(seq_idc_isms_base_ip_info.nextval,p_startip,p_endip,p_iptype,v_houseidstr);
         o_returnvalue:=1;
         commit;
         end if;
       Exception when others then
         o_returnvalue:= -1;
       end;
   end add_ip;

    procedure   add_domainip(
                p_startip in varchar2,
                p_endip in varchar2,
                p_domain in varchar2,
                p_houseidstr in varchar2,
               /* p_iptype in  number,*/
                o_returnvalue out number
                )is
         v_count number(10);
         v_sqlstr varchar2(1000);
         v_innersql varchar2(1000);
         v_condition varchar2(1000);
     begin
       o_returnvalue := 0;
       v_innersql := ' from idc_isms_base_ip_domain_info ';
       --条件语句
      v_condition := ' where 1=1 ';
      if p_houseidstr is not null and To_Number(Length(p_houseidstr)) > 0 then
       v_condition := v_condition || ' and houseidstr = '''|| p_houseidstr || '''';
      end if;
     /* if p_iptype >= 0 then
        v_condition := v_condition || ' and iptype = ' || p_iptype;
      end if;*/
      if p_startip is not null and To_Number(Length(p_startip)) > 0 then
        v_condition := v_condition || ' and startip = '''|| p_startip || '''';
      end if;
        if p_endip is not null and To_Number(Length(p_endip)) > 0 then
        v_condition := v_condition || ' and endip = '''|| p_endip || '''';
      end if;
       if p_domain is not null and To_Number(Length(p_domain)) > 0 then
        v_condition := v_condition || ' and domain = '''|| p_domain || '''';
      end if;
      v_sqlstr := 'select count(1) ' || v_innersql || v_condition;
       execute immediate v_sqlstr into v_count;
       begin
       if v_count = 0 then
         insert into idc_isms_base_ip_domain_info(id,startip,endip,domain,houseidstr)
         values(seq_idc_isms_base_ip_domain.nextval,p_startip,p_endip,p_domain,p_houseidstr);
         o_returnvalue:=1;
         commit;
         end if;
       Exception when others then
         o_returnvalue:= -1;
       end;
   end add_domainip;

end IDC_ISMS_SYSTEM_DOIP_MANAGE;
/
