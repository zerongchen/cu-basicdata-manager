CREATE package IDC_ISMS_BASE_HOUSE_MANAGE is
      procedure prelist_house_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_houseName   in VARCHAR2,
            p_houseIdStr   in VARCHAR2,
            p_houseType   in NUMBER,
            p_houseProvince in NUMBER,
            p_houseCity in NUMBER,
            p_houseCounty in NUMBER,
            --p_houseAddress in VARCHAR2,
            --p_houseZipCode in VARCHAR2,
            p_houseOfficerName in  VARCHAR2,
            /*p_houseOfficerIdType in NUMBER,
            p_houseOfficerId in VARCHAR2,
            p_houseOfficerTelephone in VARCHAR2,
            p_houseOfficerMobile in VARCHAR2,
            p_houseOfficerEmail in VARCHAR2,*/
            p_gatewayIP in VARCHAR2,
            p_startIP in VARCHAR2,
            p_endIP in VARCHAR2,
            p_dealFlag in number,
            p_delFlag in number,
            p_czlx in number,
            p_userHouseIDStrs in varchar2,
            p_identify in number
   );
   
   procedure list_house_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_houseName   in VARCHAR2,
            p_houseIdStr   in VARCHAR2,
            p_houseType   in NUMBER,
            p_houseProvince in NUMBER,
            p_houseCity in NUMBER,
            p_houseCounty in NUMBER,
            --p_houseAddress in VARCHAR2,
            --p_houseZipCode in VARCHAR2,
            p_houseOfficerName in  VARCHAR2,
            /*p_houseOfficerIdType in NUMBER,
            p_houseOfficerId in VARCHAR2,
            p_houseOfficerTelephone in VARCHAR2,
            p_houseOfficerMobile in VARCHAR2,
            p_houseOfficerEmail in VARCHAR2,*/
            p_gatewayIP in VARCHAR2,
            p_startIP in VARCHAR2,
            p_endIP in VARCHAR2,
            p_dealFlag in number,
            p_delFlag in number,
            p_czlx in number,
            p_userHouseIDStrs in varchar2,
            p_identify in number,
            p_infoComplete in varchar2
   );

   --机房查询列表的数据查询
   procedure house_query_list_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_houseName   in VARCHAR2,
            p_houseType   in NUMBER,
            p_houseProvince in NUMBER,
            p_houseCity in NUMBER,
            p_houseCounty in NUMBER,
            p_houseOfficerName in  VARCHAR2,
            p_gatewayIP in VARCHAR2,
            p_startIP in VARCHAR2,
            p_endIP in VARCHAR2,
            p_otherCondition in varchar2 --其它而外的查询条件
   );

   procedure list_houseGateway_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in VARCHAR2,
            p_bandWidth in NUMBER,
            p_linkNo in varchar2,
            p_gatewauIP in varchar2,
            p_operationType in number,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_userLevel in number

   );

   procedure prelist_gateway_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in VARCHAR2,
            p_bandWidth in NUMBER,
            p_linkNo in varchar2,
            p_gatewauIP in varchar2,
            p_operationType in number,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_userLevel in number

   );
   
   --机架信息查询
   procedure list_houseFrame_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in varchar2,
            p_frameName in varchar2,
            p_frameNo in varchar2,
            p_useType in number,
            p_distribution in number,
            p_occupancy in number,
            p_opeType in number,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_userLevel in number
   );
   
    --机架信息查询 预录入
   procedure prelist_houseFrame_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in varchar2,
            p_frameName in varchar2,
            p_frameNo in varchar2,
            p_useType in number,
            p_distribution in number,
            p_occupancy in number,
            p_opeType in number,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_userLevel in number
   );
    --机架信息导出
   procedure list_houseFrame_informationNew(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseId   in NUMBER,
            p_frameName in varchar2,
            p_frameNo in varchar2,
            p_useType in number,
            p_distribution in number,
            p_occupancy in number,
            p_delFlag in number,
            p_userHouseIDStrs in varchar2,
            p_dealFlag in number
   );
       --机架信息查询(导出)
         procedure list_houseFrame_information_ex(
                  --入参，分页参数
                  p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
                  p_pageIndex  in NUMBER, --页索引
                  p_pageSize   in NUMBER, --页大小
                  p_IsCount    in NUMBER,
                  p_sortName   in VARCHAR2,
                  p_sortOrder  in VARCHAR2,
                  --输出
                  p_cursor      out sys_refcursor,
                  p_recordCount out NUMBER, --非空为错误信息
                  --入参，查询参数
                  p_houseId   in varchar2,
                  p_frameName in varchar2,
                  p_useType in number,
                  p_distribution in number,
                  p_occupancy in number,
                  p_delFlag in number,
                  p_userHouseIDStrs in varchar2

         );
   --机房网关查询列表的数据查询
   procedure gateway_query_list_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseId   in NUMBER,
            p_bandWidth in NUMBER,
            p_gatewauIP in NUMBER,
            --p_userId in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
   );



   procedure list_houseIPSeg_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in VARCHAR2,
            p_startIP   in varchar2,
            p_endIP   in varchar2,
            p_ipType in NUMBER,
            p_userName in VARCHAR2,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            p_operationType in number,
            p_delFlag in number,
            p_dealFlag in number,
            p_areaCode in varchar2,
            p_userLevel in number

   );
   procedure prelist_houseIPSeg_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in VARCHAR2,
            p_startIP   in varchar2,
            p_endIP   in varchar2,
            p_ipType in NUMBER,
            p_userName in VARCHAR2,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            p_operationType in number,
            p_delFlag in number,
            p_dealFlag in number,
            p_areaCode in varchar2,
            p_userLevel in number

   );
   --机房IP地址段的查询列表数据查询
   procedure ipSeg_query_list_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseId   in NUMBER,
            p_startIP   in NUMBER,
            p_endIP   in NUMBER,
            p_ipType in NUMBER,
            p_userName in VARCHAR2,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            --p_userId in NUMBER,
            p_otherCondition in VARCHAR2 --其它而外的查询条件
   );

   procedure del_house_information(
            p_houseId in varchar2,
            --出参
            v_out_success out number
   );

   procedure delete_house_information(
            p_houseId in varchar2,
            --出参
            v_out_success out number
   );
     procedure delete_house_informationbystr(
            p_houseIdStr in varchar2,
            --出参
            v_out_success out number
         ) ;

   procedure delete_house_information(
            p_houseId in varchar2,
            p_temp in number, --用于重载，没有实际意义
            --出参
            v_out_success out number
   );

   procedure del_gateway_information(
            p_gatewayId   in varchar2,
            --出参
            v_out_success    out number
         );
   procedure del_gateway_information_v(
            p_gatewayId in varchar2,
            --出参
            v_out_success out number,
            v_out_errormsg out varchar2
         );
   procedure delete_gateway_information(
            p_gatewayId   in varchar2,
            --出参
            v_out_success    out number
         );
    procedure delete_gateway_information_v(
            p_gatewayId in varchar2,
            --出参
            v_out_success out number,
             v_out_errormsg out varchar2
         );
              procedure delete_gatewaybylinkno_v(
            p_linkno in varchar2,
            --出参
            v_out_success out number,
             v_out_errormsg out varchar2
         ) ;
   procedure del_ipseg_information(
            p_ipsegId   in varchar2,
            --出参
            v_out_success    out number
         );
   procedure del_ipseg_information_v(
            p_ipsegId   in varchar2,
            --出参
            v_out_success    out number,
            v_out_errormsg out varchar2
         ) ;

   procedure delete_ipseg_information(
            p_ipsegId   in varchar2,
            --出参
            v_out_success    out number
         );
       procedure delete_ipseg_information_v(
            p_ipsegId   in varchar2,
            --出参
            v_out_success    out number,
            v_out_errormsg out varchar2
         ) ;
             procedure delete_ipsegbyipsegno_v(
            p_ipsegno   in varchar2,
            --出参
            v_out_success    out number,
            v_out_errormsg out varchar2
         );
   procedure del_frame_information(
            p_frameId in varchar2,
            --出参
            v_out_success out number
         );
  procedure del_frame_information_v(
            p_frameId in varchar2,
            --出参
            v_out_success out number,
            v_out_errormsg out varchar2
         ) ;
  procedure delete_frame_information(
            p_frameId in varchar2,
            --出参
            v_out_success out number
         );
procedure delete_frame_information_v(
            p_frameId in varchar2,
            --出参
            v_out_success out number,
            v_out_errormsg out varchar2
         );
         procedure delete_framebyframeno_v(
            p_frameno in varchar2,
            --出参
            v_out_success out number,
            v_out_errormsg out varchar2
         );
   procedure recover_gateway_information(
      p_gatewayId in varchar2,
      --出参
      v_out_success out number
   );

   procedure recover_ipseg_information(
      p_ipsegId in varchar2,
      --出参
      v_out_success out number
   );

    procedure recover_frame_information(
      p_frameId in varchar2,
      --出参
      v_out_success out number
   );



   procedure recover_house_information(
      p_houseId in varchar2,
      --出参
      v_out_success out number
   );
    procedure updateStatus_house_information(
      p_houseId in varchar2,
      --出参
      v_out_success out number
   );

end IDC_ISMS_BASE_HOUSE_MANAGE;
/
CREATE package body IDC_ISMS_BASE_HOUSE_MANAGE is
        procedure prelist_house_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_houseName in VARCHAR2,
            p_houseIdStr   in VARCHAR2,
            p_houseType in NUMBER,
            p_houseProvince in NUMBER,
            p_houseCity in NUMBER,
            p_houseCounty in NUMBER,
            --p_houseAddress in VARCHAR2,
            --p_houseZipCode in VARCHAR2,
            p_houseOfficerName in  VARCHAR2,
            p_gatewayIP in VARCHAR2,
            p_startIP in VARCHAR2,
            p_endIP in VARCHAR2,
            p_dealFlag in number,
            p_delFlag in number,
            p_czlx in number,
            p_userHouseIDStrs in varchar2,
            p_identify in number
         ) is
         --定义
         v_field     varchar2(2000); --字段
         v_innersql  varchar2(4000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(10000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
             v_innersql := ' from (select a.ROOMID,a.DATADATE,a.IS_ABNORMAL,a.ABNORMAL_INFORMATION,a.OPERTYPE, houseid, a.jyzid, houseidstr,a.identify, housename, housetype,(housetype || ''-'' || tt1.mc) as housetypestr, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype,(ho_idtype||''-'' || tt2.mc) as ho_idtypestr, ho_id, ho_tel, ho_mobile, ho_email, a.czlx, a.deal_flag, a.create_time, a.update_time, a.create_userid, a.info_complete,a.DEL_FLAG, a.SUBORDINATEUNIT_AREACODE
                                 from PRE_IDC_ISMS_BASE_HOUSE a left join idc_jcdm_jfxz tt1 on a.housetype = tt1.id left join idc_jcdm_zjlx tt2 on a.ho_idtype = tt2.id ) ';
            
            v_field    := 'ROOMID,DATADATE,IS_ABNORMAL,ABNORMAL_INFORMATION,OPERTYPE, houseid, jyzid, houseidstr, housename, housetype, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype, ho_id, ho_tel, ho_mobile, ho_email, czlx, deal_flag, create_time, update_time, create_userid, info_complete,DEL_FLAG,housetypestr,ho_idtypestr,SUBORDINATEUNIT_AREACODE,identify ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' ROOMID DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if p_jyzId  > 0 then
                v_condition := v_condition || ' and jyzId = ' || p_jyzId ;
            end if;
            if(p_houseName is not null) then
                v_condition := v_condition || ' and housename like ''%' || p_houseName || '%''' ;
            end if;
            if(p_houseIdStr is not null) then
                v_condition := v_condition || ' and houseIdStr like ''%' || p_houseIdStr || '%''' ;
            end if;
            if p_houseType > 0 then
                v_condition := v_condition || ' and housetype = ' || p_houseType ;
            end if;
            if p_identify > 0 then
                v_condition := v_condition || ' and identify = ' || p_identify ;
            end if;
            if (p_houseProvince  is not null) then
                v_condition := v_condition || ' and houseprovince = ' || p_houseProvince ;
            end if;
            if (p_houseCity is not null) then
                v_condition := v_condition || ' and housecity = ' || p_houseCity ;
            end if;
            if p_czlx >0 then
            v_condition := v_condition || ' and czlx = ' || p_czlx ;
            end if;
            if (p_houseCounty is not null) then
                v_condition := v_condition || ' and housecounty = ' || p_houseCounty ;
            end if;
            if (p_houseOfficerName is not null) then
                v_condition := v_condition || ' and ho_name like ''%' || p_houseOfficerName || '%''' ;
            end if;
            /*if (p_gatewayIP is not null) then
                v_condition := v_condition || ' and houseid in (select houseid from idc_isms_base_house_gateway houseGateway where houseGateway.gatewayip = ' || p_gatewayIP || ')';
            end if;
            if (p_startIP is not null) then
                v_condition := v_condition || ' and houseid in (select houseid from idc_isms_base_house_ipseg houseIPSeg where houseIPSeg.startip = ' || p_startIP || ')';
            end if;
            if (p_endIP is not null) then
                v_condition := v_condition || ' and houseid in (select houseid from idc_isms_base_house_ipseg houseIPSeg where houseIPSeg.endip = ' || p_endIP || ')';
            end if;*/
            if p_dealFlag >= 0 then
                v_condition := v_condition || ' and DEAL_FLAG = ' || p_dealFlag;
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            dbms_output.put_line(v_sql);
            open p_cursor for v_sql;
         end;
         
        procedure list_house_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_houseName in VARCHAR2,
            p_houseIdStr   in VARCHAR2,
            p_houseType in NUMBER,
            p_houseProvince in NUMBER,
            p_houseCity in NUMBER,
            p_houseCounty in NUMBER,
            --p_houseAddress in VARCHAR2,
            --p_houseZipCode in VARCHAR2,
            p_houseOfficerName in  VARCHAR2,
            /*p_houseOfficerIdType in NUMBER,
            p_houseOfficerId in VARCHAR2,
            p_houseOfficerTelephone in VARCHAR2,
            p_houseOfficerMobile in VARCHAR2,
            p_houseOfficerEmail in VARCHAR2,*/
            p_gatewayIP in VARCHAR2,
            p_startIP in VARCHAR2,
            p_endIP in VARCHAR2,
            p_dealFlag in number,
            p_delFlag in number,
            p_czlx in number,
            p_userHouseIDStrs in varchar2,
            p_identify in number,
            p_infoComplete in varchar2
         ) is
         --定义
         v_field     varchar2(2000); --字段
         v_innersql  varchar2(4000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(10000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            --内部sql语句
            if p_userHouseIDStrs is not null then
               v_innersql := ' from (select houseid, a.jyzid, idcname, houseidstr,a.identify, housename, housetype,(housetype || ''-'' || tt1.mc) as housetypestr, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype,(ho_idtype||''-'' || tt2.mc) as ho_idtypestr, ho_id, ho_tel, ho_mobile, ho_email, a.czlx, a.deal_flag, a.create_time, a.update_time, a.create_userid, a.info_complete,a.DEL_FLAG, a.SUBORDINATEUNIT_AREACODE
                                 from (select * from idc_isms_base_house where houseid in ('||p_userHouseIDStrs||') ) a join idc_isms_base_idc b on a.jyzid = b.jyzid   left join idc_jcdm_jfxz tt1 on a.housetype = tt1.id left join idc_jcdm_zjlx tt2 on a.ho_idtype = tt2.id ) ';
            else
               v_innersql := ' from (select houseid, a.jyzid, idcname, houseidstr,a.identify, housename, housetype,(housetype || ''-'' || tt1.mc) as housetypestr, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype,(ho_idtype||''-'' || tt2.mc) as ho_idtypestr, ho_id, ho_tel, ho_mobile, ho_email, a.czlx, a.deal_flag, a.create_time, a.update_time, a.create_userid, a.info_complete,a.DEL_FLAG, a.SUBORDINATEUNIT_AREACODE
                                 from (select * from idc_isms_base_house where 1!=1) a join idc_isms_base_idc b on a.jyzid = b.jyzid   left join idc_jcdm_jfxz tt1 on a.housetype = tt1.id left join idc_jcdm_zjlx tt2 on a.ho_idtype = tt2.id ) ';
            end if;
            v_field    := ' houseid, jyzid, idcname, houseidstr, housename, housetype, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype, ho_id, ho_tel, ho_mobile, ho_email, czlx, deal_flag, create_time, update_time, create_userid, info_complete,DEL_FLAG,housetypestr,ho_idtypestr,SUBORDINATEUNIT_AREACODE,identify ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' houseid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if p_jyzId  > 0 then
                v_condition := v_condition || ' and jyzId = ' || p_jyzId ;
            end if;
            if(p_houseName is not null) then
                v_condition := v_condition || ' and housename like ''%' || p_houseName || '%''' ;
            end if;
            if(p_houseIdStr is not null) then
                v_condition := v_condition || ' and houseIdStr like ''%' || p_houseIdStr || '%''' ;
            end if;
            if p_houseType > 0 then
                v_condition := v_condition || ' and housetype = ' || p_houseType ;
            end if;
            if p_identify > 0 then
                v_condition := v_condition || ' and identify = ' || p_identify ;
            end if;
            if (p_houseProvince  is not null) then
                v_condition := v_condition || ' and houseprovince = ' || p_houseProvince ;
            end if;
            if (p_houseCity is not null) then
                v_condition := v_condition || ' and housecity = ' || p_houseCity ;
            end if;
            if p_czlx >0 then
            v_condition := v_condition || ' and czlx = ' || p_czlx ;
            end if;
            if (p_houseCounty is not null) then
                v_condition := v_condition || ' and housecounty = ' || p_houseCounty ;
            end if;
            if (p_infoComplete is not null) then
                v_condition := v_condition || ' and INFO_COMPLETE  = ''' || p_infoComplete || '''' ;
            end if;
            
            /*if(p_houseAddress  is not null ) then
                v_condition := v_condition || ' and houseadd like ''%' || p_houseAddress || '%''' ;
            end if;
            if(p_houseZipCode  is not null ) then
                v_condition := v_condition || ' and housezip like ''%' || p_houseZipCode || '%''' ;
            end if;*/
            if (p_houseOfficerName is not null) then
                v_condition := v_condition || ' and ho_name like ''%' || p_houseOfficerName || '%''' ;
            end if;
            /*if(p_houseOfficerIdType  is not null ) then
                v_condition := v_condition || ' and ho_idtype = ' || p_houseOfficerIdType ;
            end if;
            if(p_houseOfficerId  is not null ) then
                v_condition := v_condition || ' and ho_id like ''%' || p_houseOfficerId || '%''' ;
            end if;
            if(p_houseOfficerTelephone  is not null ) then
                v_condition := v_condition || ' and ho_tel like ''%' || p_houseOfficerTelephone || '%''' ;
            end if;
            if(p_houseOfficerMobile is not null ) then
                v_condition := v_condition || ' and ho_mobile  = ' || p_houseOfficerMobile ;
            end if;
            if(p_houseOfficerEmail  is not null ) then
                v_condition := v_condition || ' and ho_email like ''%' || p_houseOfficerEmail || '%''' ;
            end if; */
            if (p_gatewayIP is not null) then
                v_condition := v_condition || ' and houseid in (select houseid from idc_isms_base_house_gateway houseGateway where houseGateway.gatewayip = ' || p_gatewayIP || ')';
            end if;
            if (p_startIP is not null) then
                v_condition := v_condition || ' and houseid in (select houseid from idc_isms_base_house_ipseg houseIPSeg where houseIPSeg.startip = ' || p_startIP || ')';
            end if;
            if (p_endIP is not null) then
                v_condition := v_condition || ' and houseid in (select houseid from idc_isms_base_house_ipseg houseIPSeg where houseIPSeg.endip = ' || p_endIP || ')';
            end if;
            if p_dealFlag >= 0 then
                v_condition := v_condition || ' and DEAL_FLAG = ' || p_dealFlag;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and DEL_FLAG = ' || p_delFlag;
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            dbms_output.put_line(v_sql);
            open p_cursor for v_sql;
         end;

         --机房查询列表的数据查询
         procedure house_query_list_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_jyzId   in NUMBER,
            p_houseName in VARCHAR2,
            p_houseType in NUMBER,
            p_houseProvince in NUMBER,
            p_houseCity in NUMBER,
            p_houseCounty in NUMBER,
            p_houseOfficerName in  VARCHAR2,
            p_gatewayIP in VARCHAR2,
            p_startIP in VARCHAR2,
            p_endIP in VARCHAR2,
            p_otherCondition in VARCHAR2 --其它而外的查询条件
         ) is
         --定义
         v_field     varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_hist_base_house house';
            v_field    := ' histid,houseid, jyzid, houseidstr, housename, housetype, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype, ho_id, ho_tel, ho_mobile, ho_email, create_time, update_time, create_userid ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' houseid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_jyzId  is not null ) then
                v_condition := v_condition || ' and house.jyzId = ' || p_jyzId ;
            end if;
            if(p_houseName  is not null ) then
                v_condition := v_condition || ' and house.housename like ''%' || p_houseName || '%''' ;
            end if;
            if(p_houseType  is not null ) then
                v_condition := v_condition || ' and house.housetype = ' || p_houseType ;
            end if;
            if(p_houseProvince  is not null ) then
                v_condition := v_condition || ' and house.houseprovince = ' || p_houseProvince ;
            end if;
            if(p_houseCity  is not null ) then
                v_condition := v_condition || ' and house.housecity = ' || p_houseCity ;
            end if;
            if(p_houseCounty  is not null ) then
                v_condition := v_condition || ' and house.housecounty = ' || p_houseCounty ;
            end if;
            if(p_houseOfficerName  is not null ) then
                v_condition := v_condition || ' and house.ho_name like ''%' || p_houseOfficerName || '%''' ;
            end if;
            if(p_gatewayIP is not null ) then
                v_condition := v_condition || ' and house.houseid in (select houseid from idc_isms_base_house_gateway houseGateway where houseGateway.gatewayip = ' || p_gatewayIP || ')';
            end if;
            if(p_startIP is not null ) then
                v_condition := v_condition || ' and house.houseid in (select houseid from idc_isms_base_house_ipseg houseIPSeg where houseIPSeg.startip = ' || p_startIP || ')';
            end if;
            if(p_endIP is not null ) then
                v_condition := v_condition || ' and house.houseid in (select houseid from idc_isms_base_house_ipseg houseIPSeg where houseIPSeg.endip = ' || p_endIP || ')';
            end if;
            if(p_otherCondition  is not null ) then
                v_condition := v_condition || p_otherCondition;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure list_houseGateway_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_houseIds   in VARCHAR2,
            p_bandWidth in NUMBER,
            p_linkNo in varchar2,
            p_gatewauIP in varchar2,
            p_operationType in number,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_userLevel in number

         ) is
         --定义
         v_field     varchar2(2000); --字段
         v_secondField     varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句 subordinateunit_areacode in ('||p_areaCode||')
            -- select * from table(splitstr('''||p_areaCode||''','','')) )
            if p_areaCode is not null then
               if p_userLevel =2 then--管理员登陆
                  v_innersql := ' from (select * from idc_isms_base_house_gateway where houseid in ('||p_areaCode||')) a join IDC_ISMS_BASE_HOUSE b on a.HOUSEID = b.HOUSEID ';
               else
                  v_innersql := ' from (select * from idc_isms_base_house_gateway where houseid in ('||p_houseIds||') and  subordinateunit_areacode in ( select * from table(splitstr('''||p_areaCode||''','','')) )) a join IDC_ISMS_BASE_HOUSE b on a.HOUSEID = b.HOUSEID ';
               end if;
            else
               v_innersql := ' from (select * from idc_isms_base_house_gateway where 1!=1) a inner join IDC_ISMS_BASE_HOUSE b on a.HOUSEID = b.HOUSEID ';
            end if;
            v_field := ' gatewayid, bandwidth, gatewayip, LINKTYPE,LINKTYPESTR,ACCESSUNIT,houseid, czlx, deal_flag, create_time, update_time,HOUSENO,LINKNO,DEL_FLAG,HOUSENAME,SUBORDINATEUNIT_AREACODE ';
            v_secondField := ' gatewayid, bandwidth, gatewayip, LINKTYPE,decode(LINKTYPE,1,LINKTYPE||''-电信'',2,LINKTYPE||''-联通'',3,LINKTYPE||''-移动'',4,LINKTYPE||''-铁通'',9,LINKTYPE||''-其他'',LINKTYPE||''-未知'') as LINKTYPESTR,ACCESSUNIT,a.houseid, a.czlx, a.deal_flag, a.create_time, a.update_time,HOUSENO,LINKNO,a.DEL_FLAG,HOUSENAME,a.SUBORDINATEUNIT_AREACODE ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' gatewayid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if (p_houseIds is not null) then
                v_condition := v_condition || ' and a.houseid in (' || p_houseIds || ') ' ;
            end if;
            if p_bandWidth >= 0 then
                v_condition := v_condition || ' and bandwidth = ' || p_bandWidth;
            end if;
            if (p_linkNo is not null) then
                v_condition := v_condition || ' and linkNo like ''%' || p_linkNo || '%''';
            end if;
            if (p_gatewauIP is not null) then
                v_condition := v_condition || ' and gatewayip like ''%' || p_gatewauIP || '%''';
            end if;
             if p_operationType >= 0 then
                v_condition := v_condition || ' and a.czlx = ' || p_operationType;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and a.DEL_FLAG = ' || p_delFlag;
            end if;
            if (p_dealFlag is not null) then
                v_condition := v_condition || ' and a.deal_flag like ''%' || p_dealFlag || '%''';
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure prelist_gateway_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_houseIds   in VARCHAR2,
            p_bandWidth in NUMBER,
            p_linkNo in varchar2,
            p_gatewauIP in varchar2,
            p_operationType in number,
            p_delFlag in number,
            p_areaCode in varchar2,
            p_dealFlag in number,
            p_userLevel in number

         ) is
         --定义
         v_field     varchar2(2000); --字段
         v_secondField     varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            v_innersql := ' from PRE_IDC_ISMS_BASE_HOUSE_LINK a inner join PRE_IDC_ISMS_BASE_HOUSE b on a.ROOMID = b.ROOMID ';
            v_field := 'LINKID,ROOMID,IS_ABNORMAL,ABNORMAL_INFORMATION, gatewayid, bandwidth, gatewayip, LINKTYPE,LINKTYPESTR,ACCESSUNIT,houseid, czlx, deal_flag, create_time, update_time,HOUSENO,LINKNO,DEL_FLAG,HOUSENAME,SUBORDINATEUNIT_AREACODE ';
            v_secondField := 'a.LINKID,a.ROOMID,a.IS_ABNORMAL,a.ABNORMAL_INFORMATION, gatewayid, bandwidth, gatewayip, LINKTYPE,decode(LINKTYPE,1,LINKTYPE||''-电信'',2,LINKTYPE||''-联通'',3,LINKTYPE||''-移动'',4,LINKTYPE||''-铁通'',9,LINKTYPE||''-其他'',LINKTYPE||''-未知'') as LINKTYPESTR,ACCESSUNIT,a.houseid, a.czlx, a.deal_flag, a.create_time, a.update_time,HOUSENO,LINKNO,a.DEL_FLAG,HOUSENAME,a.SUBORDINATEUNIT_AREACODE ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' LINKID DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if p_bandWidth >= 0 then
                v_condition := v_condition || ' and bandwidth = ' || p_bandWidth;
            end if;
            if (p_houseIds is not null) then
                v_condition := v_condition || ' and a.ROOMID =''' || p_houseIds || '''';
            end if;
            if (p_linkNo is not null) then
                v_condition := v_condition || ' and linkNo like ''%' || p_linkNo || '%''';
            end if;
            if (p_gatewauIP is not null) then
                v_condition := v_condition || ' and gatewayip like ''%' || p_gatewauIP || '%''';
            end if;
             if p_operationType >= 0 then
                v_condition := v_condition || ' and a.czlx = ' || p_operationType;
            end if;
            if (p_dealFlag is not null) then
                v_condition := v_condition || ' and a.deal_flag like ''%' || p_dealFlag || '%''';
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;
         
         --机架信息查询
         procedure list_houseFrame_information(
                  --入参，分页参数
                  p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
                  p_pageIndex  in NUMBER, --页索引
                  p_pageSize   in NUMBER, --页大小
                  p_IsCount    in NUMBER,
                  p_sortName   in VARCHAR2,
                  p_sortOrder  in VARCHAR2,
                  --输出
                  p_cursor      out sys_refcursor,
                  p_recordCount out NUMBER, --非空为错误信息
                  --入参，查询参数
                  p_houseIds   in varchar2,
                  p_frameName in varchar2,
                  p_frameNo in varchar2,
                  p_useType in number,
                  p_distribution in number,
                  p_occupancy in number,
                  p_opeType in number,
                  p_delFlag in number,
                  p_areaCode in varchar2,
                  p_dealFlag in number,
                  p_userLevel in number

         )is

          --定义
         v_field     varchar2(2000); --字段
         v_secondField varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(4000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            if p_areaCode is not null then
               if p_userLevel  =2 then--管理员登陆
                v_innersql := ' from (select * from IDC_ISMS_BASE_HOUSE_FRAME where houseid in ('||p_areaCode||') ) a join IDC_ISMS_BASE_HOUSE b on a.HOUSEID = b.HOUSEID';
                else
                 v_innersql := ' from (select * from IDC_ISMS_BASE_HOUSE_FRAME where houseid in ('||p_houseIds||') and subordinateunit_areacode in ('||p_areaCode||') ) a join IDC_ISMS_BASE_HOUSE b on a.HOUSEID = b.HOUSEID';
                end if;
          else
                 v_innersql := ' from (select * from IDC_ISMS_BASE_HOUSE_FRAME where 1!=1 ) a join IDC_ISMS_BASE_HOUSE b on a.HOUSEID = b.HOUSEID';
            end if;
            v_field := ' FRAMEID, FRAMENAME, USETYPE,USETYPESTR, DISTRIBUTION,DISTRIBUTIONSTR,OCCUPANCY,OCCUPANCYSTR,houseid,houseName,czlx,deal_flag,create_time,update_time,FRAMENO,DEL_FLAG,SUBORDINATEUNIT_AREACODE';
            --v_secondField := ' FRAMEID, FRAMENAME, USETYPE, decode(USETYPE,1,USETYPE||''-自用'',2,USETYPE||''-租用'',USETYPE||''-其他'') as USETYPESTR,DISTRIBUTION,decode(DISTRIBUTION,1,DISTRIBUTION||''-未分配'',2,DISTRIBUTION||''-已分配'',DISTRIBUTION||''-其他'') as DISTRIBUTIONSTR ,OCCUPANCY,decode(OCCUPANCY,1,OCCUPANCY||''-未占用'',2,OCCUPANCY||''-已占用'',OCCUPANCY||''-其他'') as OCCUPANCYSTR,a.houseid, a.czlx, a.deal_flag, a.create_time, a.update_time,FRAMENO,a.DEL_FLAG,HOUSENAME,a.SUBORDINATEUNIT_AREACODE,(select my_wm_concat(ConcatObj(unitName, '';'')) from IDC_ISMS_BASE_USER_FRAME where frameId = a.frameId) unitName ';
            v_secondField := ' FRAMEID, FRAMENAME, USETYPE, decode(USETYPE,1,USETYPE||''-自用'',2,USETYPE||''-租用'',USETYPE||''-其他'') as USETYPESTR,DISTRIBUTION,decode(DISTRIBUTION,1,DISTRIBUTION||''-未分配'',2,DISTRIBUTION||''-已分配'',DISTRIBUTION||''-其他'') as DISTRIBUTIONSTR ,OCCUPANCY,decode(OCCUPANCY,1,OCCUPANCY||''-未占用'',2,OCCUPANCY||''-已占用'',OCCUPANCY||''-其他'') as OCCUPANCYSTR,a.houseid, a.czlx, a.deal_flag, a.create_time, a.update_time,FRAMENO,a.DEL_FLAG,HOUSENAME,a.SUBORDINATEUNIT_AREACODE';
            v_order := ' ORDER BY ';
            if (p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder||',frameId desc' ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' FRAMEID DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if p_houseIds is not null then
                v_condition := v_condition || ' and a.houseid in (' || p_houseIds || ') ' ;
            end if;
            if p_frameName is not null then
               v_condition := v_condition || ' and FRAMENAME like ''%' || p_frameName || '%''';
            end if;
            if p_frameNo is not null then
               v_condition := v_condition || ' and FRAMENO like ''%' || p_frameNo || '%''';
            end if;
            if (p_useType > 0) then
                v_condition := v_condition || ' and USETYPE = ' || p_useType;
            end if;
            if (p_distribution > 0) then
                v_condition := v_condition || ' and DISTRIBUTION = ' || p_distribution;
            end if;
            if (p_occupancy > 0) then
                v_condition := v_condition || ' and OCCUPANCY = ' || p_occupancy;
            end if;
            if p_opeType >= 0 then
                v_condition := v_condition || ' and a.czlx = ' || p_opeType;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and a.DEL_FLAG = ' || p_delFlag;
            end if;
            if (p_dealFlag is not null )then
                v_condition := v_condition || ' and a.DEAL_FLAG = ' || p_dealFlag;
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --机架信息查询 预录入
         procedure prelist_houseFrame_information(
                  --入参，分页参数
                  p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
                  p_pageIndex  in NUMBER, --页索引
                  p_pageSize   in NUMBER, --页大小
                  p_IsCount    in NUMBER,
                  p_sortName   in VARCHAR2,
                  p_sortOrder  in VARCHAR2,
                  --输出
                  p_cursor      out sys_refcursor,
                  p_recordCount out NUMBER, --非空为错误信息
                  --入参，查询参数
                  p_houseIds   in varchar2,
                  p_frameName in varchar2,
                  p_frameNo in varchar2,
                  p_useType in number,
                  p_distribution in number,
                  p_occupancy in number,
                  p_opeType in number,
                  p_delFlag in number,
                  p_areaCode in varchar2,
                  p_dealFlag in number,
                  p_userLevel in number

         )is

          --定义
         v_field     varchar2(2000); --字段
         v_secondField varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(4000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from PRE_IDC_ISMS_BASE_HOUSE_FRAME a join PRE_IDC_ISMS_BASE_HOUSE b on a.ROOMID = b.ROOMID';
            
            v_field := 'RACKID,ROOMID,IS_ABNORMAL,ABNORMAL_INFORMATION, FRAMEID, FRAMENAME, USETYPE,USETYPESTR, DISTRIBUTION,DISTRIBUTIONSTR,OCCUPANCY,OCCUPANCYSTR,houseid,houseName,czlx,deal_flag,create_time,update_time,FRAMENO,DEL_FLAG,SUBORDINATEUNIT_AREACODE';
            v_secondField := 'a.RACKID,a.ROOMID,a.IS_ABNORMAL,a.ABNORMAL_INFORMATION, FRAMEID, FRAMENAME, USETYPE, decode(USETYPE,1,USETYPE||''-自用'',2,USETYPE||''-租用'',USETYPE||''-其他'') as USETYPESTR,DISTRIBUTION,decode(DISTRIBUTION,1,DISTRIBUTION||''-未分配'',2,DISTRIBUTION||''-已分配'',DISTRIBUTION||''-其他'') as DISTRIBUTIONSTR ,OCCUPANCY,decode(OCCUPANCY,1,OCCUPANCY||''-未占用'',2,OCCUPANCY||''-已占用'',OCCUPANCY||''-其他'') as OCCUPANCYSTR,a.houseid, a.czlx, a.deal_flag, a.create_time, a.update_time,FRAMENO,a.DEL_FLAG,HOUSENAME,a.SUBORDINATEUNIT_AREACODE';
            v_order := ' ORDER BY ';
            if (p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder||',frameId desc' ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' RACKID DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            /*if p_houseIds is not null then
                v_condition := v_condition || ' and a.houseid in (' || p_houseIds || ') ' ;
            end if;*/
            if (p_houseIds is not null) then
                v_condition := v_condition || ' and a.ROOMID =''' || p_houseIds || '''';
            end if;
            if p_frameName is not null then
               v_condition := v_condition || ' and FRAMENAME like ''%' || p_frameName || '%''';
            end if;
            if p_frameNo is not null then
               v_condition := v_condition || ' and FRAMENO like ''%' || p_frameNo || '%''';
            end if;
            if (p_useType > 0) then
                v_condition := v_condition || ' and USETYPE = ' || p_useType;
            end if;
            if (p_distribution > 0) then
                v_condition := v_condition || ' and DISTRIBUTION = ' || p_distribution;
            end if;
            if (p_occupancy > 0) then
                v_condition := v_condition || ' and OCCUPANCY = ' || p_occupancy;
            end if;
            if p_opeType >= 0 then
                v_condition := v_condition || ' and a.czlx = ' || p_opeType;
            end if;
            
            if (p_dealFlag is not null )then
                v_condition := v_condition || ' and a.DEAL_FLAG = ' || p_dealFlag;
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;
         
         
         --机架信息导出
         procedure list_houseFrame_informationNew(
                  --入参，分页参数
                  p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
                  p_pageIndex  in NUMBER, --页索引
                  p_pageSize   in NUMBER, --页大小
                  p_IsCount    in NUMBER,
                  p_sortName   in VARCHAR2,
                  p_sortOrder  in VARCHAR2,
                  --输出
                  p_cursor      out sys_refcursor,
                  p_recordCount out NUMBER, --非空为错误信息
                  --入参，查询参数
                  p_houseId   in NUMBER,
                  p_frameName in varchar2,
                  p_frameNo in varchar2,
                  p_useType in number,
                  p_distribution in number,
                  p_occupancy in number,
                  p_delFlag in number,
                  p_userHouseIDStrs in varchar2,
                  p_dealFlag in number

         )is

          --定义
         v_field     varchar2(2000); --字段
         v_secondField varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from (select * from IDC_ISMS_BASE_HOUSE_FRAME where houseid in ('||p_userHouseIDStrs||') ) a join (select * from IDC_ISMS_BASE_HOUSE where houseid in ('||p_userHouseIDStrs||')) b on a.HOUSEID = b.HOUSEID left join idc_isms_base_user_frame c on a.frameid = c.frameid';
            v_field := ' FRAMEID, FRAMENAME, USETYPE,USETYPESTR, DISTRIBUTION,DISTRIBUTIONSTR,OCCUPANCY,OCCUPANCYSTR,houseid,houseName,czlx,deal_flag,create_time,update_time,FRAMENO,DEL_FLAG,SUBORDINATEUNIT_AREACODE';
            v_secondField := ' a.FRAMEID, FRAMENAME,UNITNAME, USETYPE, decode(USETYPE,1,USETYPE||''-自用'',2,USETYPE||''-租用'',USETYPE||''-其他'') as USETYPESTR,DISTRIBUTION,decode(DISTRIBUTION,1,DISTRIBUTION||''-未分配'',2,DISTRIBUTION||''-已分配'',DISTRIBUTION||''-其他'') as DISTRIBUTIONSTR ,OCCUPANCY,decode(OCCUPANCY,1,OCCUPANCY||''-未占用'',2,OCCUPANCY||''-已占用'',OCCUPANCY||''-其他'') as OCCUPANCYSTR,a.houseid, a.czlx, a.deal_flag, a.create_time, a.update_time,FRAMENO,a.DEL_FLAG,HOUSENAME, a.SUBORDINATEUNIT_AREACODE ';
            v_order := ' ORDER BY ';
            if (p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' FRAMEID DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if (p_houseId > 0) then
                v_condition := v_condition || ' and a.houseid = ' || p_houseId ;
            end if;
            if p_frameName is not null then
               v_condition := v_condition || ' and FRAMENAME like ''%' || p_frameName || '%''';
            end if;
            if p_frameNo is not null then
               v_condition := v_condition || ' and FRAMENO like ''%' || p_frameNo || '%''';
            end if;
            if (p_useType > 0) then
                v_condition := v_condition || ' and USETYPE = ' || p_useType;
            end if;
            if (p_distribution > 0) then
                v_condition := v_condition || ' and DISTRIBUTION = ' || p_distribution;
            end if;
            if (p_occupancy > 0) then
                v_condition := v_condition || ' and OCCUPANCY = ' || p_occupancy;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and a.DEL_FLAG = ' || p_delFlag;
            end if;
            if (p_dealFlag is not null )then
                v_condition := v_condition || ' and a.DEAL_FLAG = ' || p_dealFlag;
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;
           --机架信息查询
         procedure list_houseFrame_information_ex(
                  --入参，分页参数
                  p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
                  p_pageIndex  in NUMBER, --页索引
                  p_pageSize   in NUMBER, --页大小
                  p_IsCount    in NUMBER,
                  p_sortName   in VARCHAR2,
                  p_sortOrder  in VARCHAR2,
                  --输出
                  p_cursor      out sys_refcursor,
                  p_recordCount out NUMBER, --非空为错误信息
                  --入参，查询参数
                  p_houseId   in varchar2,
                  p_frameName in varchar2,
                  p_useType in number,
                  p_distribution in number,
                  p_occupancy in number,
                  p_delFlag in number,
                  p_userHouseIDStrs in varchar2

         )is

          --定义
         v_field     varchar2(2000); --字段
         v_secondField varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from (select * from IDC_ISMS_BASE_HOUSE_FRAME where houseid in ('||p_userHouseIDStrs||') ) a join (select * from IDC_ISMS_BASE_HOUSE where houseid in ('||p_userHouseIDStrs||')) b on a.HOUSEID = b.HOUSEID ';
            v_field := ' FRAMEID, FRAMENAME, USETYPE, DISTRIBUTION,OCCUPANCY,houseid,houseName,czlx,deal_flag,create_time,update_time,FRAMENO,DEL_FLAG';
            v_secondField := ' FRAMEID, FRAMENAME, USETYPE, DISTRIBUTION,OCCUPANCY,a.houseid, a.czlx, a.deal_flag, a.create_time, a.update_time,FRAMENO,a.DEL_FLAG,HOUSENAME ';
            v_order := ' ORDER BY ';
            if (p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' FRAMEID DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if  p_houseId is not null then
                v_condition := v_condition || ' and a.houseid in ('||p_houseId||')' ;
            end if;
            if p_frameName is not null then
               v_condition := v_condition || ' and FRAMENAME like ''%' || p_frameName || '%''';
            end if;
            if (p_useType > 0) then
                v_condition := v_condition || ' and USETYPE = ' || p_useType;
            end if;
            if (p_distribution > 0) then
                v_condition := v_condition || ' and DISTRIBUTION = ' || p_distribution;
            end if;
            if (p_occupancy > 0) then
                v_condition := v_condition || ' and OCCUPANCY = ' || p_occupancy;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and a.DEL_FLAG = ' || p_delFlag;
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --机房网关查询列表的数据查询
         procedure gateway_query_list_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_houseId   in NUMBER,
            p_bandWidth in NUMBER,
            p_gatewauIP in NUMBER,
            --p_userId in NUMBER,
            p_otherCondition in varchar2 --其它而外的查询条件
         ) is
         --定义
         v_field     varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_hist_base_house_gateway ';
            v_field    := ' histid,gatewayid, bandwidth, gatewayip, houseid, create_time, update_time ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' gatewayid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_houseId  is not null ) then
                v_condition := v_condition || ' and houseid = ' || p_houseId ;
            end if;
            if(p_bandWidth  is not null ) then
                v_condition := v_condition || ' and bandwidth = ' || p_bandWidth;
            end if;
            if(p_gatewauIP  is not null ) then
                v_condition := v_condition || ' and gatewayip = ' || p_gatewauIP ;
            end if;
            if(p_otherCondition  is not null ) then
                v_condition := v_condition || p_otherCondition;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure prelist_houseIPSeg_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in varchar2,
            p_startIP   in varchar2,
            p_endIP   in varchar2,
            p_ipType in NUMBER,
            p_userName in VARCHAR2,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            p_operationType in number,
            p_delFlag in number,
            p_dealFlag in number,
            p_areaCode in varchar2,
            p_userLevel in number

         ) is
         --定义
         v_field     varchar2(2000); --字段
         v_secondField varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from  PRE_IDC_ISMS_BASE_HOUSE_IPSEG  a left join IDC_JCDM_ZJLX b on a.IDTYPE = b.ID left join PRE_IDC_ISMS_BASE_HOUSE c on a.ROOMID = c.ROOMID';
            v_field := ' IPSEGIDSTR,ROOMID,IS_ABNORMAL,ABNORMAL_INFORMATION,ipsegid, startip, endip, iptype,iptypestr, MC, username, idtype, idnumber, usetime, houseid, czlx, deal_flag, create_time, update_time,SOURCEUNIT,ALLOCATIONUNIT,DEL_FLAG,IPSEG_NO,HOUSENAME,SUBORDINATEUNIT_AREACODE ';
            v_secondField := 'a.IPSEGIDSTR,a.ROOMID,a.IS_ABNORMAL,a.ABNORMAL_INFORMATION, ipsegid, startip, endip, iptype,decode(iptype,0,iptype||''-静态'',1,iptype||''-动态'',2,iptype||''-保留'',iptype||''-其他'') as iptypestr, MC, username, idtype,idnumber, usetime, a.houseid, a.czlx, a.deal_flag, a.create_time, a.update_time,SOURCEUNIT,ALLOCATIONUNIT,a.DEL_FLAG,IPSEG_NO,HOUSENAME, a.SUBORDINATEUNIT_AREACODE ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' IPSEGIDSTR DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if (p_houseIds is not null) then
                v_condition := v_condition || ' and a.ROOMID =''' || p_houseIds || '''';
            end if;
            if (p_startIP is not null) then
                v_condition := v_condition || ' and ip2int(STARTIP) >= ' || to_number(p_startIP);
            end if;
            if (p_endIP is not null) then
                v_condition := v_condition || ' and ip2int(ENDIP) <= ' || to_number(p_endIP);
            end if;
            if (p_ipType >= 0) then
                v_condition := v_condition || ' and iptype = ' || p_ipType;
            end if;
            if (p_userName is not null) then
                v_condition := v_condition || ' and username like ''%' || p_userName || '%''';
            end if;
            if (p_idType > 0 ) then
                v_condition := v_condition || ' and idtype = ' || p_idType;
            end if;
            if (p_idNumber is not null) then
                v_condition := v_condition || ' and idnumber like ''%' || p_idNumber || '%''';
            end if;
            if p_operationType >= 0 then
                v_condition := v_condition || ' and a.czlx = ' || p_operationType;
            end if;
            if (p_dealFlag is not null) then
                v_condition := v_condition || ' and a.deal_flag = ' || p_dealFlag ;
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;
         
         procedure list_houseIPSeg_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseIds   in varchar2,
            p_startIP   in varchar2,
            p_endIP   in varchar2,
            p_ipType in NUMBER,
            p_userName in VARCHAR2,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            p_operationType in number,
            p_delFlag in number,
            p_dealFlag in number,
            p_areaCode in varchar2,
            p_userLevel in number

         ) is
         --定义
         v_field     varchar2(2000); --字段
         v_secondField varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            if p_areaCode is not null then
                if p_userLevel  =2 then--管理员登陆
                   v_innersql := ' from (select tt1.*,decode(iptype,2,'''',(tt1.idtype || ''-'' || tt2.mc)) as idtypestr from (select * from idc_isms_base_house_ipseg where houseid in ('||p_areaCode||')) tt1  left join idc_jcdm_zjlx tt2 on tt1.idtype = tt2.id ) a
                          left join IDC_JCDM_ZJLX b on a.IDTYPE = b.ID
                          join IDC_ISMS_BASE_HOUSE c on a.HOUSEID = c.HOUSEID ';
                else
                   v_innersql := ' from (select tt1.*,decode(iptype,2,'''',(tt1.idtype || ''-'' || tt2.mc)) as idtypestr from (select * from idc_isms_base_house_ipseg where houseid in ('||p_houseIds||') and  subordinateunit_areacode in('||p_areaCode||')) tt1  left join idc_jcdm_zjlx tt2 on tt1.idtype = tt2.id ) a
                          left join IDC_JCDM_ZJLX b on a.IDTYPE = b.ID
                          join IDC_ISMS_BASE_HOUSE c on a.HOUSEID = c.HOUSEID ';
                end if;
            else
               v_innersql := ' from (select tt1.*,decode(iptype,2,'''',(tt1.idtype || ''-'' || tt2.mc)) as idtypestr from (select * from idc_isms_base_house_ipseg where 1!=1) tt1  left join idc_jcdm_zjlx tt2 on tt1.idtype = tt2.id ) a
                          left join IDC_JCDM_ZJLX b on a.IDTYPE = b.ID
                          join IDC_ISMS_BASE_HOUSE c on a.HOUSEID = c.HOUSEID ';
            end if;
            v_field := ' ipsegid, startip, endip, iptype,iptypestr, MC, username, idtype,idtypestr, idnumber, usetime, houseid, czlx, deal_flag, create_time, update_time,SOURCEUNIT,ALLOCATIONUNIT,DEL_FLAG,IPSEG_NO,HOUSENAME,SUBORDINATEUNIT_AREACODE ';
            v_secondField := ' ipsegid, startip, endip, iptype,decode(iptype,0,iptype||''-静态'',1,iptype||''-动态'',2,iptype||''-保留'',iptype||''-其他'') as iptypestr, MC, username, idtype, idtypestr,idnumber, usetime, a.houseid, a.czlx, a.deal_flag, a.create_time, a.update_time,SOURCEUNIT,ALLOCATIONUNIT,a.DEL_FLAG,IPSEG_NO,HOUSENAME, a.SUBORDINATEUNIT_AREACODE ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' ipsegid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if (p_houseIds is not null) then
                v_condition := v_condition || ' and a.houseid in (' || p_houseIds || ') ';
            end if;
            if (p_startIP is not null) then
                v_condition := v_condition || ' and startipstr >= ' || to_number(p_startIP);
            end if;
            if (p_endIP is not null) then
                v_condition := v_condition || ' and endipstr <= ' || to_number(p_endIP);
            end if;
            if (p_ipType >= 0) then
                v_condition := v_condition || ' and iptype = ' || p_ipType;
            end if;
            if (p_userName is not null) then
                v_condition := v_condition || ' and username like ''%' || p_userName || '%''';
            end if;
            if (p_idType > 0 ) then
                v_condition := v_condition || ' and idtype = ' || p_idType;
            end if;
            if (p_idNumber is not null) then
                v_condition := v_condition || ' and idnumber like ''%' || p_idNumber || '%''';
            end if;
            if p_operationType >= 0 then
                v_condition := v_condition || ' and a.czlx = ' || p_operationType;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and a.DEL_FLAG = ' || p_delFlag;
            end if;
            if (p_dealFlag is not null) then
                v_condition := v_condition || ' and a.deal_flag = ' || p_dealFlag ;
            end if;

            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_secondField || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_secondField || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --机房IP地址段的查询列表数据查询
         procedure ipSeg_query_list_information(
            --入参，分页参数
            p_isPaging in NUMBER, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in NUMBER, --页索引
            p_pageSize   in NUMBER, --页大小
            p_IsCount    in NUMBER,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out NUMBER, --非空为错误信息
            --入参，查询参数
            p_houseId   in NUMBER,
            p_startIP   in NUMBER,
            p_endIP   in NUMBER,
            p_ipType in NUMBER,
            p_userName in VARCHAR2,
            p_idType in NUMBER,
            p_idNumber in VARCHAR2,
            --p_userId in NUMBER,
            p_otherCondition in VARCHAR2 --其它而外的查询条件
         ) is
         --定义
         v_field     varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_hist_base_house_ipseg ';
            v_field    := ' histid,ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' ipsegid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_houseId  is not null ) then
                v_condition := v_condition || ' and houseid = ' || p_houseId ;
            end if;
            if(p_startIP is not null ) then
                v_condition := v_condition || ' and startip = ' || p_startIP ;
            end if;
            if(p_endIP is not null ) then
                v_condition := v_condition || ' and endip = ' || p_endIP;
            end if;
            if(p_ipType is not null ) then
                v_condition := v_condition || ' and iptype = ' || p_ipType;
            end if;
            if(p_userName is not null ) then
                v_condition := v_condition || ' and username like ''%' || p_userName || '%''';
            end if;
            if(p_idType is not null ) then
                v_condition := v_condition || ' and idtype = ' || p_idType;
            end if;
            if(p_idNumber is not null ) then
                v_condition := v_condition || ' and idnumber like ''%' || p_idNumber || '%''';
            end if;
            if(p_otherCondition  is not null ) then
                v_condition := v_condition || p_otherCondition;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         procedure del_house_information(
            p_houseId in varchar2,
            --出参
            v_out_success out number
         ) as
          --v_count1 number(5);
          --v_count2 number(5);
          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house.czlx%type;
          v_houseId idc_isms_base_house.houseid%type;
          v_houseIdCur sys_refcursor;
          v_sql varchar2(2000);
          v_delType idc_isms_base_delete.del_type%type := 2;
          v_userHHCount number;
          v_serviceCount number;
          Begin
               begin
                  --如果p_houseId为null则做全部删除
                  if (p_houseId is null) then
                    v_sql := 'select HOUSEID from IDC_ISMS_BASE_HOUSE where DEAL_FLAG != 1';
                  else
                    v_sql := 'select HOUSEID from IDC_ISMS_BASE_HOUSE where HOUSEID in (' || p_houseId || ')';
                  end if;
                  open v_houseIdCur for v_sql;
                  loop
                    fetch v_houseIdCur into v_houseId;
                    exit when v_houseIdCur%notfound;

                    select czlx into v_czlx from idc_isms_base_house where houseid = v_houseId;
                    if (v_czlx = 2) then
                       select count(1) into v_userHHCount from idc_isms_base_user_hh where HOUSEID = v_houseId and DEL_FLAG = 0;
                       select count(1) into v_serviceCount from idc_isms_base_service_hh where HOUSEID = v_houseId and DEL_FLAG = 0;
                       if (v_userHHCount > 0 or v_serviceCount > 0) then
                         v_delType := 4;
                       end if;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseId);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,v_delType,v_idcid,v_houseId);
                    end if;

                    /* --添加历史记录start
                     --链路
                     insert into idc_hist_base_house_gateway
                       (histid, gatewayid, bandwidth, gatewayip, houseid, create_time, update_time,LINKTYPE,ACCESSUNIT,CREATE_USERID,HOUSENO,LINKNO)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL, gatewayid, bandwidth, gatewayip, houseid, create_time, update_time,LINKTYPE,ACCESSUNIT,CREATE_USERID,HOUSENO,LINKNO from idc_isms_base_house_gateway where houseid = p_houseId;
                     --ip地址段
                     insert into idc_hist_base_house_ipseg
                       (histid, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,CREATE_USERID,ALLOCATIONUNIT,SOURCEUNIT)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL,ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,CREATE_USERID,ALLOCATIONUNIT,SOURCEUNIT from idc_isms_base_house_ipseg where houseid = p_houseId;
                     --机架
                     insert into idc_hist_base_house_frame
                       (HISTID,FRAMEID,HOUSEID,USETYPE,DISTRIBUTION,OCCUPANCY,CREATE_TIME,UPDATE_TIME,FRAMENO,FRAMENAME,CREATE_USERID)
                     select SEQ_ISMS_HIST_HISTID.Nextval,FRAMEID,HOUSEID,USETYPE,DISTRIBUTION,OCCUPANCY,CREATE_TIME,UPDATE_TIME,FRAMENO,FRAMENAME,CREATE_USERID from idc_isms_base_house_frame where houseid = p_houseId;
                     --机房
                     insert into idc_hist_base_house
                       (histid, houseid, jyzid, houseidstr, housename, housetype, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype, ho_id, ho_tel, ho_mobile, ho_email, create_time, update_time, create_userid)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL,houseid, jyzid, houseidstr, housename, housetype, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype, ho_id, ho_tel, ho_mobile, ho_email, create_time, update_time, create_userid from idc_isms_base_house where houseid = p_houseId;
                     --end*/

                    delete from idc_isms_base_house_gateway a  where a.houseid = v_houseId;
                    delete from idc_isms_base_house_ipseg a where a.houseid = v_houseId;
                    delete from idc_isms_base_house_frame a where a.houseid = v_houseId;
                    delete from idc_isms_base_house a where a.houseid = v_houseId;
                  end loop;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

         procedure delete_house_information(
            p_houseId in varchar2,
            --出参
            v_out_success out number
         ) as
          --v_count1 number(5);
          --v_count2 number(5);
          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house.czlx%type;
          v_houseId idc_isms_base_house.houseid%type;
          v_houseIdCur sys_refcursor;
          v_sql varchar2(2000);
          v_delType idc_isms_base_delete.del_type%type := 2;
          v_userHHCount number;
          v_serviceCount number;
          Begin
               begin
                  --如果p_houseId为null则做全部删除
                  if (p_houseId is null) then
                    v_sql := 'select HOUSEID from IDC_ISMS_BASE_HOUSE where DEAL_FLAG != 1';
                  else
                    v_sql := 'select HOUSEID from IDC_ISMS_BASE_HOUSE where HOUSEID in (' || p_houseId || ')';
                  end if;
                  open v_houseIdCur for v_sql;
                  loop
                    fetch v_houseIdCur into v_houseId;
                    exit when v_houseIdCur%notfound;

                    select czlx into v_czlx from idc_isms_base_house where houseid = v_houseId;
                    if (v_czlx = 2) then
                       select count(1) into v_userHHCount from idc_isms_base_user_hh where HOUSEID = v_houseId and DEL_FLAG = 0;
                       select count(1) into v_serviceCount from idc_isms_base_service_hh where HOUSEID = v_houseId and DEL_FLAG = 0;
                       if (v_userHHCount > 0 or v_serviceCount > 0) then
                         v_delType := 4;
                       end if;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseId);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,v_delType,v_idcid,v_houseId);
                    end if;

                    /* --添加历史记录start
                     --链路
                     insert into idc_hist_base_house_gateway
                       (histid, gatewayid, bandwidth, gatewayip, houseid, create_time, update_time,LINKTYPE,ACCESSUNIT,CREATE_USERID,HOUSENO,LINKNO)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL, gatewayid, bandwidth, gatewayip, houseid, create_time, update_time,LINKTYPE,ACCESSUNIT,CREATE_USERID,HOUSENO,LINKNO from idc_isms_base_house_gateway where houseid = p_houseId;
                     --ip地址段
                     insert into idc_hist_base_house_ipseg
                       (histid, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,CREATE_USERID,ALLOCATIONUNIT,SOURCEUNIT)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL,ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,CREATE_USERID,ALLOCATIONUNIT,SOURCEUNIT from idc_isms_base_house_ipseg where houseid = p_houseId;
                     --机架
                     insert into idc_hist_base_house_frame
                       (HISTID,FRAMEID,HOUSEID,USETYPE,DISTRIBUTION,OCCUPANCY,CREATE_TIME,UPDATE_TIME,FRAMENO,FRAMENAME,CREATE_USERID)
                     select SEQ_ISMS_HIST_HISTID.Nextval,FRAMEID,HOUSEID,USETYPE,DISTRIBUTION,OCCUPANCY,CREATE_TIME,UPDATE_TIME,FRAMENO,FRAMENAME,CREATE_USERID from idc_isms_base_house_frame where houseid = p_houseId;
                     --机房
                     insert into idc_hist_base_house
                       (histid, houseid, jyzid, houseidstr, housename, housetype, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype, ho_id, ho_tel, ho_mobile, ho_email, create_time, update_time, create_userid)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL,houseid, jyzid, houseidstr, housename, housetype, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype, ho_id, ho_tel, ho_mobile, ho_email, create_time, update_time, create_userid from idc_isms_base_house where houseid = p_houseId;
                     --end*/

                    update idc_isms_base_house_gateway a set a.del_flag = 1 where a.houseid = v_houseId;
                    update idc_isms_base_house_ipseg a set a.del_flag = 1 where a.houseid = v_houseId;
                    update idc_isms_base_house_frame a set a.del_flag = 1 where a.houseid = v_houseId;
                    update idc_isms_base_house a set a.del_flag = 1 where a.houseid = v_houseId;
                  end loop;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

            procedure delete_house_informationbystr(
            p_houseIdStr in varchar2,
            --出参
            v_out_success out number
         ) as
          --v_count1 number(5);
          --v_count2 number(5);
          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house.czlx%type;
          v_houseId idc_isms_base_house.houseid%type;
          v_houseIdCur sys_refcursor;
          v_sql varchar2(2000);
          v_delType idc_isms_base_delete.del_type%type := 2;
          v_userHHCount number;
          v_serviceCount number;
          Begin
               begin
                  --如果p_houseId为null则做全部删除
                  if (p_houseIdStr is null) then
                    v_sql := 'select HOUSEID from IDC_ISMS_BASE_HOUSE where DEAL_FLAG != 1';
                  else
                    v_sql := 'select HOUSEID from IDC_ISMS_BASE_HOUSE where HOUSEID = '''||p_houseIdStr||'''';
                  end if;
                  open v_houseIdCur for v_sql;
                  loop
                    fetch v_houseIdCur into v_houseId;
                    exit when v_houseIdCur%notfound;

                    select czlx into v_czlx from idc_isms_base_house where houseid = v_houseId;
                    if (v_czlx = 2) then
                       select count(1) into v_userHHCount from idc_isms_base_user_hh where HOUSEID = v_houseId and DEL_FLAG = 0;
                       select count(1) into v_serviceCount from idc_isms_base_service_hh where HOUSEID = v_houseId and DEL_FLAG = 0;
                       if (v_userHHCount > 0 or v_serviceCount > 0) then
                         v_delType := 4;
                       end if;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseId);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,v_delType,v_idcid,v_houseId);
                    end if;

                    /* --添加历史记录start
                     --链路
                     insert into idc_hist_base_house_gateway
                       (histid, gatewayid, bandwidth, gatewayip, houseid, create_time, update_time,LINKTYPE,ACCESSUNIT,CREATE_USERID,HOUSENO,LINKNO)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL, gatewayid, bandwidth, gatewayip, houseid, create_time, update_time,LINKTYPE,ACCESSUNIT,CREATE_USERID,HOUSENO,LINKNO from idc_isms_base_house_gateway where houseid = p_houseId;
                     --ip地址段
                     insert into idc_hist_base_house_ipseg
                       (histid, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,CREATE_USERID,ALLOCATIONUNIT,SOURCEUNIT)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL,ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,CREATE_USERID,ALLOCATIONUNIT,SOURCEUNIT from idc_isms_base_house_ipseg where houseid = p_houseId;
                     --机架
                     insert into idc_hist_base_house_frame
                       (HISTID,FRAMEID,HOUSEID,USETYPE,DISTRIBUTION,OCCUPANCY,CREATE_TIME,UPDATE_TIME,FRAMENO,FRAMENAME,CREATE_USERID)
                     select SEQ_ISMS_HIST_HISTID.Nextval,FRAMEID,HOUSEID,USETYPE,DISTRIBUTION,OCCUPANCY,CREATE_TIME,UPDATE_TIME,FRAMENO,FRAMENAME,CREATE_USERID from idc_isms_base_house_frame where houseid = p_houseId;
                     --机房
                     insert into idc_hist_base_house
                       (histid, houseid, jyzid, houseidstr, housename, housetype, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype, ho_id, ho_tel, ho_mobile, ho_email, create_time, update_time, create_userid)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL,houseid, jyzid, houseidstr, housename, housetype, houseprovince, housecity, housecounty, houseadd, housezip, ho_name, ho_idtype, ho_id, ho_tel, ho_mobile, ho_email, create_time, update_time, create_userid from idc_isms_base_house where houseid = p_houseId;
                     --end*/

                    update idc_isms_base_house_gateway a set a.del_flag = 1 where a.houseid = v_houseId;
                    update idc_isms_base_house_ipseg a set a.del_flag = 1 where a.houseid = v_houseId;
                    update idc_isms_base_house_frame a set a.del_flag = 1 where a.houseid = v_houseId;
                    update idc_isms_base_house a set a.del_flag = 1 where a.houseid = v_houseId;
                  end loop;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

      procedure delete_house_information(
            p_houseId in varchar2,
            p_temp in number,
            --出参
            v_out_success out number
      )as
          v_houseId idc_isms_base_house.houseid%type;
          v_houseIdCur sys_refcursor;
          v_sql varchar2(2000);
          Begin
               begin
                  --如果p_houseId为null则做全部删除
                  if (p_houseId is null) then
                    v_sql := 'select HOUSEID from IDC_ISMS_BASE_HOUSE where DEAL_FLAG != 1';
                  else
                    v_sql := 'select HOUSEID from IDC_ISMS_BASE_HOUSE where HOUSEID in (' || p_houseId || ')';
                  end if;
                  open v_houseIdCur for v_sql;
                  loop
                    fetch v_houseIdCur into v_houseId;
                    exit when v_houseIdCur%notfound;
                    update idc_isms_base_house_gateway a set a.del_flag = 1 where a.houseid = v_houseId;
                    update idc_isms_base_house_ipseg a set a.del_flag = 1 where a.houseid = v_houseId;
                    update idc_isms_base_house_frame a set a.del_flag = 1 where a.houseid = v_houseId;
                    update idc_isms_base_house a set a.del_flag = 1 where a.houseid = v_houseId;
                  end loop;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

            procedure del_gateway_information(
            p_gatewayId in varchar2,
            --出参
            v_out_success out number
         ) as

          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house_gateway.czlx%type;
          v_houseid idc_isms_base_house_gateway.houseid%type;
          v_gatewayId idc_isms_base_house_gateway.gatewayid%type;
          v_gatewayIdCur sys_refcursor;
          v_sql varchar2(2000);
          Begin
               begin
                  if (p_gatewayId is null) then
                    v_sql := 'select GATEWAYID from IDC_ISMS_BASE_HOUSE_GATEWAY where DEAL_FLAG != 1';
                  else
                    v_sql := 'select GATEWAYID from IDC_ISMS_BASE_HOUSE_GATEWAY where GATEWAYID in (' || p_gatewayId || ')';
                  end if;
                  open v_gatewayIdCur for v_sql;
                  loop
                    fetch v_gatewayIdCur into v_gatewayId;
                    exit when v_gatewayIdCur%notfound;
                    select czlx into v_czlx from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                    if (v_czlx = 2) then
                       select houseid into v_houseid from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid,gatewayid)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_gatewayId);
                    end if;
                     --添加历史记录start
                     /*insert into idc_hist_base_house_gateway
                       (histid, gatewayid, bandwidth, gatewayip, houseid,LINKTYPE,ACCESSUNIT,HOUSENO,LINKNO,CREATE_USERID, create_time, update_time)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL,gatewayid, bandwidth, gatewayip, houseid,LINKTYPE,ACCESSUNIT,HOUSENO,LINKNO,CREATE_USERID, create_time, update_time from idc_isms_base_house_gateway where gatewayid = p_gatewayId;
                     --end*/
                    delete from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                  end loop;
                  close v_gatewayIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

procedure del_gateway_information_v(
            p_gatewayId in varchar2,
            --出参
            v_out_success out number,
            v_out_errormsg out varchar2
         ) as

          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house_gateway.czlx%type;
          v_houseid idc_isms_base_house_gateway.houseid%type;
          v_housename idc_isms_base_house.housename%type;
          v_gatewayId idc_isms_base_house_gateway.gatewayid%type;
          v_gatewayIdCur sys_refcursor;
          v_sql varchar2(2000);
          v_count number(10);
          Begin
               begin
               v_out_errormsg := '';
                  if (p_gatewayId is null) then
                    v_sql := 'select GATEWAYID from IDC_ISMS_BASE_HOUSE_GATEWAY where DEAL_FLAG != 1';
                  else
                    v_sql := 'select GATEWAYID from IDC_ISMS_BASE_HOUSE_GATEWAY where GATEWAYID in (' || p_gatewayId || ')';
                  end if;
                  open v_gatewayIdCur for v_sql;
                  loop
                    fetch v_gatewayIdCur into v_gatewayId;
                    exit when v_gatewayIdCur%notfound;
                    select houseid into v_houseid from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                    /*select count(1) into v_count from idc_isms_base_house_gateway where houseid = v_houseid and DEL_FLAG != 1;
                    if v_count > 1 then
                      select czlx into v_czlx from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                    if (v_czlx = 2) then
                           --select houseid into v_houseid from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                           select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                           insert into idc_isms_base_delete(delid,del_type,idcid,houseid,gatewayid)
                           values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_gatewayId);
                        end if;
                         --添加历史记录start
                         /insert into idc_hist_base_house_gateway
                           (histid, gatewayid, bandwidth, gatewayip, houseid,LINKTYPE,ACCESSUNIT,HOUSENO,LINKNO,CREATE_USERID, create_time, update_time)
                         select SEQ_ISMS_HIST_HISTID.NEXTVAL,gatewayid, bandwidth, gatewayip, houseid,LINKTYPE,ACCESSUNIT,HOUSENO,LINKNO,CREATE_USERID, create_time, update_time from idc_isms_base_house_gateway where gatewayid = p_gatewayId;
                         --end/
                        delete from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                    else
                      select housename into v_housename from idc_isms_base_house where houseid = v_houseid;
                     if instr(v_out_errormsg,v_housename) is null or instr(v_out_errormsg,v_housename) = 0  then
                        v_out_errormsg := v_out_errormsg || v_housename || ',';
                      end if;
                    end if;*/
                    delete from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                  end loop;
                  close v_gatewayIdCur;

               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

            procedure delete_gateway_information(
            p_gatewayId in varchar2,
            --出参
            v_out_success out number
         ) as

          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house_gateway.czlx%type;
          v_houseid idc_isms_base_house_gateway.houseid%type;
          v_gatewayId idc_isms_base_house_gateway.gatewayid%type;
          v_gatewayIdCur sys_refcursor;
          v_sql varchar2(2000);
          Begin
               begin
                  if (p_gatewayId is null) then
                    v_sql := 'select GATEWAYID from IDC_ISMS_BASE_HOUSE_GATEWAY where DEAL_FLAG != 1';
                  else
                    v_sql := 'select GATEWAYID from IDC_ISMS_BASE_HOUSE_GATEWAY where GATEWAYID in (' || p_gatewayId || ')';
                  end if;
                  open v_gatewayIdCur for v_sql;
                  loop
                    fetch v_gatewayIdCur into v_gatewayId;
                    exit when v_gatewayIdCur%notfound;
                    select czlx into v_czlx from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                    if (v_czlx = 2) then
                       select houseid into v_houseid from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid,gatewayid)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_gatewayId);
                    end if;
                     --添加历史记录start
                     /*insert into idc_hist_base_house_gateway
                       (histid, gatewayid, bandwidth, gatewayip, houseid,LINKTYPE,ACCESSUNIT,HOUSENO,LINKNO,CREATE_USERID, create_time, update_time)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL,gatewayid, bandwidth, gatewayip, houseid,LINKTYPE,ACCESSUNIT,HOUSENO,LINKNO,CREATE_USERID, create_time, update_time from idc_isms_base_house_gateway where gatewayid = p_gatewayId;
                     --end*/
                    update idc_isms_base_house_gateway set DEL_FLAG = 1 where gatewayid = v_gatewayId;
                  end loop;
                  close v_gatewayIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

            procedure delete_gateway_information_v(
            p_gatewayId in varchar2,
            --出参
            v_out_success out number,
             v_out_errormsg out varchar2
         ) as

          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house_gateway.czlx%type;
          v_houseid idc_isms_base_house_gateway.houseid%type;
           v_housename idc_isms_base_house.housename%type;
          v_gatewayId idc_isms_base_house_gateway.gatewayid%type;
          v_gatewayIdCur sys_refcursor;
          v_sql varchar2(2000);
           v_count number(10);
          Begin
               begin
                 v_out_errormsg := '';
                  if (p_gatewayId is null) then
                    v_sql := 'select GATEWAYID from IDC_ISMS_BASE_HOUSE_GATEWAY where DEAL_FLAG != 1';
                  else
                    v_sql := 'select GATEWAYID from IDC_ISMS_BASE_HOUSE_GATEWAY where GATEWAYID in (' || p_gatewayId || ')';
                  end if;
                  open v_gatewayIdCur for v_sql;
                  loop
                    fetch v_gatewayIdCur into v_gatewayId;
                    exit when v_gatewayIdCur%notfound;
                     select houseid into v_houseid from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                    select count(1) into v_count from idc_isms_base_house_gateway where houseid = v_houseid and DEL_FLAG != 1;
                     if v_count > 0 then
                       select czlx into v_czlx from idc_isms_base_house_gateway where gatewayid = v_gatewayId and DEL_FLAG != 1;
                    if (v_czlx = 2) then
                       --select houseid into v_houseid from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid,gatewayid)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_gatewayId);
                    end if;
                     --添加历史记录start
                     /*insert into idc_hist_base_house_gateway
                       (histid, gatewayid, bandwidth, gatewayip, houseid,LINKTYPE,ACCESSUNIT,HOUSENO,LINKNO,CREATE_USERID, create_time, update_time)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL,gatewayid, bandwidth, gatewayip, houseid,LINKTYPE,ACCESSUNIT,HOUSENO,LINKNO,CREATE_USERID, create_time, update_time from idc_isms_base_house_gateway where gatewayid = p_gatewayId;
                     --end*/
                    update idc_isms_base_house_gateway set DEL_FLAG = 1 where gatewayid = v_gatewayId;
                     else
                        select housename into v_housename from idc_isms_base_house where houseid = v_houseid;
                      if instr(v_out_errormsg,v_housename) is null or instr(v_out_errormsg,v_housename) = 0  then
                        v_out_errormsg := v_out_errormsg || v_housename || ',';
                      end if;
                     end if;

                  end loop;
                  close v_gatewayIdCur;

               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

       procedure delete_gatewaybylinkno_v(
            p_linkno in varchar2,
            --出参
            v_out_success out number,
             v_out_errormsg out varchar2
         ) as

          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house_gateway.czlx%type;
          v_houseid idc_isms_base_house_gateway.houseid%type;
           v_housename idc_isms_base_house.housename%type;
          v_gatewayId idc_isms_base_house_gateway.gatewayid%type;
          v_gatewayIdCur sys_refcursor;
          v_sql varchar2(2000);
           v_count number(10);
          Begin
               begin
                 v_out_errormsg := '';
                  if (p_linkno is null) then
                    v_sql := 'select GATEWAYID from IDC_ISMS_BASE_HOUSE_GATEWAY where DEAL_FLAG != 1';
                  else
                    v_sql := 'select GATEWAYID from IDC_ISMS_BASE_HOUSE_GATEWAY where linkno = '''||p_linkno||'''';
                  end if;
                  open v_gatewayIdCur for v_sql;
                  loop
                    fetch v_gatewayIdCur into v_gatewayId;
                    exit when v_gatewayIdCur%notfound;
                     select houseid into v_houseid from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                    select count(1) into v_count from idc_isms_base_house_gateway where houseid = v_houseid and DEL_FLAG != 1;
                     if v_count > 1 then
                       select czlx into v_czlx from idc_isms_base_house_gateway where gatewayid = v_gatewayId and DEL_FLAG != 1;
                    if (v_czlx = 2) then
                       --select houseid into v_houseid from idc_isms_base_house_gateway where gatewayid = v_gatewayId;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid,gatewayid)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_gatewayId);
                    end if;
                     --添加历史记录start
                     /*insert into idc_hist_base_house_gateway
                       (histid, gatewayid, bandwidth, gatewayip, houseid,LINKTYPE,ACCESSUNIT,HOUSENO,LINKNO,CREATE_USERID, create_time, update_time)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL,gatewayid, bandwidth, gatewayip, houseid,LINKTYPE,ACCESSUNIT,HOUSENO,LINKNO,CREATE_USERID, create_time, update_time from idc_isms_base_house_gateway where gatewayid = p_gatewayId;
                     --end*/
                    update idc_isms_base_house_gateway set DEL_FLAG = 1 where gatewayid = v_gatewayId;
                     else
                        select housename into v_housename from idc_isms_base_house where houseid = v_houseid;
                      if instr(v_out_errormsg,v_housename) is null or instr(v_out_errormsg,v_housename) = 0  then
                        v_out_errormsg := v_out_errormsg || v_housename || ',';
                      end if;
                     end if;

                  end loop;
                  close v_gatewayIdCur;

               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

       procedure del_ipseg_information(
            p_ipsegId   in varchar2,
            --出参
            v_out_success    out number
         ) as

          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house_ipseg.czlx%type;
          v_houseid idc_isms_base_house_ipseg.houseid%type;
          v_ipsegId idc_isms_base_house_ipseg.ipsegid%type;
          v_ipsegIdCur sys_refcursor;
          v_sql varchar2(2000);
          Begin
               begin
                  if (p_ipsegId is null) then
                    v_sql := 'select IPSEGID from IDC_ISMS_BASE_HOUSE_IPSEG where DEAL_FLAG != 1';
                  else
                    v_sql := 'select IPSEGID from IDC_ISMS_BASE_HOUSE_IPSEG where IPSEGID in (' || p_ipsegId || ')';
                  end if;
                  open v_ipsegIdCur for v_sql;
                  loop
                    fetch v_ipsegIdCur into v_ipsegId;
                    exit when v_ipsegIdCur%notfound;
                    select czlx into v_czlx from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                    if v_czlx = 2 then
                       select houseid into v_houseid from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid,ipsegid)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_ipsegId);
                    end if;
                     --添加历史记录start
                     /*insert into idc_hist_base_house_ipseg
                       (histid, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,SOURCEUNIT,ALLOCATIONUNIT,CREATE_USERID)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,SOURCEUNIT,ALLOCATIONUNIT,CREATE_USERID from idc_isms_base_house_ipseg where ipsegid = p_ipsegId;
                     --end*/
                    delete from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                  end loop;
                  close v_ipsegIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;
procedure del_ipseg_information_v(
            p_ipsegId   in varchar2,
            --出参
            v_out_success    out number,
            v_out_errormsg out varchar2
         ) as

          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house_ipseg.czlx%type;
          v_houseid idc_isms_base_house_ipseg.houseid%type;
          v_housename idc_isms_base_house.housename%type;
          v_ipsegId idc_isms_base_house_ipseg.ipsegid%type;
          v_ipsegIdCur sys_refcursor;
          v_sql varchar2(2000);
          v_count number(10);
          Begin

               begin
                  v_out_errormsg := '';
                  if (p_ipsegId is null) then
                    v_sql := 'select IPSEGID from IDC_ISMS_BASE_HOUSE_IPSEG where DEAL_FLAG != 1';
                  else
                    v_sql := 'select IPSEGID from IDC_ISMS_BASE_HOUSE_IPSEG where IPSEGID in (' || p_ipsegId || ')';
                  end if;
                  open v_ipsegIdCur for v_sql;
                  loop
                    fetch v_ipsegIdCur into v_ipsegId;
                    exit when v_ipsegIdCur%notfound;
                    select houseid into v_houseid from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                   /* select count(1) into v_count from idc_isms_base_house_ipseg where houseid = v_houseid and DEL_FLAG != 1;
                    if v_count > 1 then
                      select czlx into v_czlx from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                      if v_czlx = 2 then
                         --select houseid into v_houseid from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                         select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                         insert into idc_isms_base_delete(delid,del_type,idcid,houseid,ipsegid)
                         values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_ipsegId);
                      end if;
                       --添加历史记录start
                       /insert into idc_hist_base_house_ipseg
                         (histid, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,SOURCEUNIT,ALLOCATIONUNIT,CREATE_USERID)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,SOURCEUNIT,ALLOCATIONUNIT,CREATE_USERID from idc_isms_base_house_ipseg where ipsegid = p_ipsegId;
                       --end/
                      delete from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                      v_out_success:=1;
                    else
                      select housename into v_housename from idc_isms_base_house where houseid = v_houseid;
                      if instr(v_out_errormsg,v_housename) is null or instr(v_out_errormsg,v_housename) = 0  then
                        v_out_errormsg := v_out_errormsg || v_housename || ',';
                      end if;
                    end if;*/
                    delete from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                    v_out_success:=1;
                  end loop;
                  close v_ipsegIdCur;

               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

      procedure delete_ipseg_information(
            p_ipsegId   in varchar2,
            --出参
            v_out_success    out number
         ) as

          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house_ipseg.czlx%type;
          v_houseid idc_isms_base_house_ipseg.houseid%type;
          v_ipsegId idc_isms_base_house_ipseg.ipsegid%type;
          v_ipsegIdCur sys_refcursor;
          v_sql varchar2(2000);
          Begin
               begin
                -- v_out_success := 0; return;
                  if (p_ipsegId is null) then
                    v_sql := 'select IPSEGID from IDC_ISMS_BASE_HOUSE_IPSEG where DEAL_FLAG != 1';
                  else
                    v_sql := 'select IPSEGID from IDC_ISMS_BASE_HOUSE_IPSEG where IPSEGID in (' || p_ipsegId || ')';
                  end if;
                  open v_ipsegIdCur for v_sql;
                  loop
                    fetch v_ipsegIdCur into v_ipsegId;
                    exit when v_ipsegIdCur%notfound;
                    select czlx into v_czlx from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                    if v_czlx = 2 then
                       select houseid into v_houseid from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid,ipsegid)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_ipsegId);
                    end if;
                     --添加历史记录start
                     /*insert into idc_hist_base_house_ipseg
                       (histid, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,SOURCEUNIT,ALLOCATIONUNIT,CREATE_USERID)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,SOURCEUNIT,ALLOCATIONUNIT,CREATE_USERID from idc_isms_base_house_ipseg where ipsegid = p_ipsegId;
                     --end*/
                    update idc_isms_base_house_ipseg set DEL_FLAG = 1 where ipsegid = v_ipsegId;
                  end loop;
                  close v_ipsegIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

            procedure delete_ipseg_information_v(
            p_ipsegId   in varchar2,
            --出参
            v_out_success    out number,
            v_out_errormsg out varchar2
         ) as

          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house_ipseg.czlx%type;
          v_houseid idc_isms_base_house_ipseg.houseid%type;
           v_housename idc_isms_base_house.housename%type;
          v_ipsegId idc_isms_base_house_ipseg.ipsegid%type;
          v_ipsegIdCur sys_refcursor;
          v_sql varchar2(2000);
          v_count number(10);
          Begin

               begin
                  v_out_errormsg := '';
                -- v_out_success := 0; return;
                  if (p_ipsegId is null) then
                    v_sql := 'select IPSEGID from IDC_ISMS_BASE_HOUSE_IPSEG where DEAL_FLAG != 1';
                  else
                    v_sql := 'select IPSEGID from IDC_ISMS_BASE_HOUSE_IPSEG where IPSEGID in (' || p_ipsegId || ')';
                  end if;
                  open v_ipsegIdCur for v_sql;
                  loop
                    fetch v_ipsegIdCur into v_ipsegId;
                    exit when v_ipsegIdCur%notfound;
                    select houseid into v_houseid from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                    select count(1) into v_count from idc_isms_base_house_ipseg where houseid = v_houseid and DEL_FLAG != 1;
                    if v_count > 0 then
                      select czlx into v_czlx from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                    if v_czlx = 2 then
                       --select houseid into v_houseid from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid,ipsegid)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_ipsegId);
                    end if;
                     --添加历史记录start
                     /*insert into idc_hist_base_house_ipseg
                       (histid, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,SOURCEUNIT,ALLOCATIONUNIT,CREATE_USERID)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,SOURCEUNIT,ALLOCATIONUNIT,CREATE_USERID from idc_isms_base_house_ipseg where ipsegid = p_ipsegId;
                     --end*/
                     update idc_isms_base_house_ipseg set DEL_FLAG = 1 where ipsegid = v_ipsegId;
                    else
                    select housename into v_housename from idc_isms_base_house where houseid = v_houseid;
                      if instr(v_out_errormsg,v_housename) is null or instr(v_out_errormsg,v_housename) = 0  then
                        v_out_errormsg := v_out_errormsg || v_housename || ',';
                      end if;
                    end if;

                  end loop;
                  close v_ipsegIdCur;

               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;


             procedure delete_ipsegbyipsegno_v(
            p_ipsegno   in varchar2,
            --出参
            v_out_success    out number,
            v_out_errormsg out varchar2
         ) as

          v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house_ipseg.czlx%type;
          v_houseid idc_isms_base_house_ipseg.houseid%type;
           v_housename idc_isms_base_house.housename%type;
          v_ipsegId idc_isms_base_house_ipseg.ipsegid%type;
          v_ipsegIdCur sys_refcursor;
          v_sql varchar2(2000);
          v_count number(10);
          Begin

               begin
                  v_out_errormsg := '';
                -- v_out_success := 0; return;
                  if (p_ipsegno is null) then
                    v_sql := 'select IPSEGID from IDC_ISMS_BASE_HOUSE_IPSEG where DEAL_FLAG != 1';
                  else
                    v_sql := 'select IPSEGID from IDC_ISMS_BASE_HOUSE_IPSEG where ipseg_no = '''||p_ipsegno||'';
                  end if;
                  open v_ipsegIdCur for v_sql;
                  loop
                    fetch v_ipsegIdCur into v_ipsegId;
                    exit when v_ipsegIdCur%notfound;
                    select houseid into v_houseid from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                    select count(1) into v_count from idc_isms_base_house_ipseg where houseid = v_houseid and DEL_FLAG != 1;
                    if v_count > 1 then
                      select czlx into v_czlx from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                    if v_czlx = 2 then
                       --select houseid into v_houseid from idc_isms_base_house_ipseg where ipsegid = v_ipsegId;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid,ipsegid)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_ipsegId);
                    end if;
                     --添加历史记录start
                     /*insert into idc_hist_base_house_ipseg
                       (histid, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,SOURCEUNIT,ALLOCATIONUNIT,CREATE_USERID)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL, ipsegid, startip, endip, iptype, username, idtype, idnumber, usetime, houseid, create_time, update_time,SOURCEUNIT,ALLOCATIONUNIT,CREATE_USERID from idc_isms_base_house_ipseg where ipsegid = p_ipsegId;
                     --end*/
                     update idc_isms_base_house_ipseg set DEL_FLAG = 1 where ipsegid = v_ipsegId;
                    else
                    select housename into v_housename from idc_isms_base_house where houseid = v_houseid;
                      if instr(v_out_errormsg,v_housename) is null or instr(v_out_errormsg,v_housename) = 0  then
                        v_out_errormsg := v_out_errormsg || v_housename || ',';
                      end if;
                    end if;

                  end loop;
                  close v_ipsegIdCur;

               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

             procedure delete_frame_information(
            p_frameId in varchar2,
            --出参
            v_out_success out number
         ) as
          --v_count1 number(5);
          --v_count2 number(5);
          v_idcid idc_isms_base_idc.idcid%type;
          --v_czlx idc_isms_base_house_frame.czlx%type;
          --v_houseid idc_isms_base_house_ipseg.houseid%type;
          v_frameId idc_isms_base_house_frame.frameid%type;
          v_frameIdCur sys_refcursor;
          v_sql varchar2(2000);
          Begin
               begin
                  --如果p_frameId为null则做全部删除
                  if (p_frameId is null) then
                    v_sql := 'select frameid from IDC_ISMS_BASE_HOUSE_FRAME where DEAL_FLAG != 1';
                  else
                     v_sql := 'select frameid from IDC_ISMS_BASE_HOUSE_FRAME where frameid in (' || p_frameId || ')';
                  end if;
                  open v_frameIdCur for v_sql;
                  loop
                    fetch v_frameIdCur into v_frameId;
                    exit when v_frameIdCur%notfound;
                    /*select czlx into v_czlx from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                    if(v_czlx = 2) then
                       select houseid into v_houseid from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid,FRAMEINFOID)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_frameId);
                    end if;*/
                     /*--添加历史记录start
                     insert into IDC_HIST_BASE_HOUSE_FRAME
                       (histid, FRAMEID, USETYPE, DISTRIBUTION, OCCUPANCY, FRAMENO, FRAMENAME,HOUSEID, create_time, update_time,CREATE_USERID)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL, FRAMEID, USETYPE, DISTRIBUTION, OCCUPANCY, FRAMENO, FRAMENAME, HOUSEID, create_time, update_time, CREATE_USERID from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = p_frameId;
                     --end*/
                    update IDC_ISMS_BASE_HOUSE_FRAME set del_flag = 1 where FRAMEID = v_frameId;
                  end loop;
                  close v_frameIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;
procedure delete_frame_information_v(
            p_frameId in varchar2,
            --出参
            v_out_success out number,
            v_out_errormsg out varchar2
         ) as
          --v_count1 number(5);
          --v_count2 number(5);
          v_idcid idc_isms_base_idc.idcid%type;
          --v_czlx idc_isms_base_house_frame.czlx%type;
          v_houseid idc_isms_base_house_ipseg.houseid%type;
           v_housename idc_isms_base_house.housename%type;
          v_frameId idc_isms_base_house_frame.frameid%type;
          v_framename idc_isms_base_house_frame.framename%type;
          v_frameIdCur sys_refcursor;
          v_sql varchar2(2000);
          v_count number(10);

          Begin

               begin
                 v_out_errormsg := '';
                  --如果p_frameId为null则做全部删除
                  if (p_frameId is null) then
                    v_sql := 'select frameid from IDC_ISMS_BASE_HOUSE_FRAME where DEAL_FLAG != 1';
                  else
                     v_sql := 'select frameid from IDC_ISMS_BASE_HOUSE_FRAME where frameid in (' || p_frameId || ')';
                  end if;
                  open v_frameIdCur for v_sql;
                  loop
                    fetch v_frameIdCur into v_frameId;
                    exit when v_frameIdCur%notfound;
                    select houseid into v_houseid from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                    select count(1) into v_count from IDC_ISMS_BASE_HOUSE_FRAME where houseid = v_houseid and DEL_FLAG != 1;
                    if v_count > 0 then
                      /*select czlx into v_czlx from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                    if(v_czlx = 2) then
                       select houseid into v_houseid from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid,FRAMEINFOID)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_frameId);
                    end if;*/
                     /*--添加历史记录start
                     insert into IDC_HIST_BASE_HOUSE_FRAME
                       (histid, FRAMEID, USETYPE, DISTRIBUTION, OCCUPANCY, FRAMENO, FRAMENAME,HOUSEID, create_time, update_time,CREATE_USERID)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL, FRAMEID, USETYPE, DISTRIBUTION, OCCUPANCY, FRAMENO, FRAMENAME, HOUSEID, create_time, update_time, CREATE_USERID from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = p_frameId;
                     --end*/
                    update IDC_ISMS_BASE_HOUSE_FRAME set del_flag = 1 where FRAMEID = v_frameId;
                    else
                      select housename into v_housename from idc_isms_base_house where houseid = v_houseid;
                     if instr(v_out_errormsg,v_housename) is null or instr(v_out_errormsg,v_housename) = 0  then
                        v_out_errormsg := v_out_errormsg || v_housename || ',';
                      end if;
                    end if;
                  end loop;
                  close v_frameIdCur;

               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

procedure delete_framebyframeno_v(
            p_frameno in varchar2,
            --出参
            v_out_success out number,
            v_out_errormsg out varchar2
         ) as
          --v_count1 number(5);
          --v_count2 number(5);
          v_idcid idc_isms_base_idc.idcid%type;
          --v_czlx idc_isms_base_house_frame.czlx%type;
          v_houseid idc_isms_base_house_ipseg.houseid%type;
           v_housename idc_isms_base_house.housename%type;
          v_frameId idc_isms_base_house_frame.frameid%type;
          v_framename idc_isms_base_house_frame.framename%type;
          v_frameIdCur sys_refcursor;
          v_sql varchar2(2000);
          v_count number(10);

          Begin

               begin
                 v_out_errormsg := '';
                  --如果p_frameId为null则做全部删除
                  if (p_frameno is null) then
                    v_sql := 'select frameid from IDC_ISMS_BASE_HOUSE_FRAME where DEAL_FLAG != 1';
                  else
                     v_sql := 'select frameid from IDC_ISMS_BASE_HOUSE_FRAME where frameno = '''||p_frameno||'''';
                  end if;
                  open v_frameIdCur for v_sql;
                  loop
                    fetch v_frameIdCur into v_frameId;
                    exit when v_frameIdCur%notfound;
                    select houseid into v_houseid from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                    select count(1) into v_count from IDC_ISMS_BASE_HOUSE_FRAME where houseid = v_houseid and DEL_FLAG != 1;
                    if v_count > 1 then
                      /*select czlx into v_czlx from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                    if(v_czlx = 2) then
                       select houseid into v_houseid from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid,FRAMEINFOID)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_frameId);
                    end if;*/
                     /*--添加历史记录start
                     insert into IDC_HIST_BASE_HOUSE_FRAME
                       (histid, FRAMEID, USETYPE, DISTRIBUTION, OCCUPANCY, FRAMENO, FRAMENAME,HOUSEID, create_time, update_time,CREATE_USERID)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL, FRAMEID, USETYPE, DISTRIBUTION, OCCUPANCY, FRAMENO, FRAMENAME, HOUSEID, create_time, update_time, CREATE_USERID from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = p_frameId;
                     --end*/
                    update IDC_ISMS_BASE_HOUSE_FRAME set del_flag = 1 where FRAMEID = v_frameId;
                    else
                      select housename into v_housename from idc_isms_base_house where houseid = v_houseid;
                     if instr(v_out_errormsg,v_housename) is null or instr(v_out_errormsg,v_housename) = 0  then
                        v_out_errormsg := v_out_errormsg || v_housename || ',';
                      end if;
                    end if;
                  end loop;
                  close v_frameIdCur;

               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;
            procedure del_frame_information(
            p_frameId in varchar2,
            --出参
            v_out_success out number
         ) as
          --v_count1 number(5);
          --v_count2 number(5);
          v_idcid idc_isms_base_idc.idcid%type;
          --v_czlx idc_isms_base_house_frame.czlx%type;
          --v_houseid idc_isms_base_house_ipseg.houseid%type;
          v_frameId idc_isms_base_house_frame.frameid%type;
          v_frameIdCur sys_refcursor;
          v_sql varchar2(2000);
          Begin
               begin
                  --如果p_frameId为null则做全部删除
                  if (p_frameId is null) then
                    v_sql := 'select frameid from IDC_ISMS_BASE_HOUSE_FRAME where DEAL_FLAG != 1';
                  else
                     v_sql := 'select frameid from IDC_ISMS_BASE_HOUSE_FRAME where frameid in (' || p_frameId || ')';
                  end if;
                  open v_frameIdCur for v_sql;
                  loop
                    fetch v_frameIdCur into v_frameId;
                    exit when v_frameIdCur%notfound;
                    /*select czlx into v_czlx from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                    if(v_czlx = 2) then
                       select houseid into v_houseid from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                       select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                       insert into idc_isms_base_delete(delid,del_type,idcid,houseid,FRAMEINFOID)
                       values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_frameId);
                    end if;*/
                     /*--添加历史记录start
                     insert into IDC_HIST_BASE_HOUSE_FRAME
                       (histid, FRAMEID, USETYPE, DISTRIBUTION, OCCUPANCY, FRAMENO, FRAMENAME,HOUSEID, create_time, update_time,CREATE_USERID)
                     select SEQ_ISMS_HIST_HISTID.NEXTVAL, FRAMEID, USETYPE, DISTRIBUTION, OCCUPANCY, FRAMENO, FRAMENAME, HOUSEID, create_time, update_time, CREATE_USERID from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = p_frameId;
                     --end*/
                    delete from IDC_ISMS_BASE_HOUSE_FRAME  where FRAMEID = v_frameId;
                  end loop;
                  close v_frameIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

            procedure del_frame_information_v(
            p_frameId in varchar2,
            --出参
            v_out_success out number,
            v_out_errormsg out varchar2
         ) as
          --v_count1 number(5);
          --v_count2 number(5);
          v_idcid idc_isms_base_idc.idcid%type;
          --v_czlx idc_isms_base_house_frame.czlx%type;
          v_houseid idc_isms_base_house_ipseg.houseid%type;
           v_housename idc_isms_base_house.housename%type;
          v_frameId idc_isms_base_house_frame.frameid%type;
          v_framename idc_isms_base_house_frame.framename%type;
          v_frameIdCur sys_refcursor;
          v_sql varchar2(2000);
           v_count number(10);
          Begin

               begin
                 v_out_errormsg := '';
                  --如果p_frameId为null则做全部删除
                  if (p_frameId is null) then
                    v_sql := 'select frameid from IDC_ISMS_BASE_HOUSE_FRAME where DEAL_FLAG != 1';
                  else
                     v_sql := 'select frameid from IDC_ISMS_BASE_HOUSE_FRAME where frameid in (' || p_frameId || ')';
                  end if;
                  open v_frameIdCur for v_sql;
                  loop
                    fetch v_frameIdCur into v_frameId;
                    exit when v_frameIdCur%notfound;
                   /* select houseid into v_houseid from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                    select count(1) into v_count from IDC_ISMS_BASE_HOUSE_FRAME where houseid = v_houseid and DEL_FLAG != 1;
                    if v_count > 1 then
                         /*select czlx into v_czlx from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                      if(v_czlx = 2) then
                         select houseid into v_houseid from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = v_frameId;
                         select idcid into v_idcid from idc_isms_base_idc where jyzid = (select jyzid from idc_isms_base_house where houseid = v_houseid);
                         insert into idc_isms_base_delete(delid,del_type,idcid,houseid,FRAMEINFOID)
                         values(SEQ_IDC_ISMS_BASE_DELID.Nextval,2,v_idcid,v_houseid,v_frameId);
                      end if;/
                       /--添加历史记录start
                       insert into IDC_HIST_BASE_HOUSE_FRAME
                         (histid, FRAMEID, USETYPE, DISTRIBUTION, OCCUPANCY, FRAMENO, FRAMENAME,HOUSEID, create_time, update_time,CREATE_USERID)
                       select SEQ_ISMS_HIST_HISTID.NEXTVAL, FRAMEID, USETYPE, DISTRIBUTION, OCCUPANCY, FRAMENO, FRAMENAME, HOUSEID, create_time, update_time, CREATE_USERID from IDC_ISMS_BASE_HOUSE_FRAME where FRAMEID = p_frameId;
                       --end/
                      delete from IDC_ISMS_BASE_HOUSE_FRAME  where FRAMEID = v_frameId;
                    else
                      select housename into v_housename from idc_isms_base_house where houseid = v_houseid;
                     if instr(v_out_errormsg,v_housename) is null or instr(v_out_errormsg,v_housename) = 0  then
                        v_out_errormsg := v_out_errormsg || v_housename || ',';
                      end if;
                    end if;*/
                   delete from IDC_ISMS_BASE_HOUSE_FRAME  where FRAMEID = v_frameId;
                  end loop;
                  close v_frameIdCur;

               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;

            --还原链路
            procedure recover_gateway_information(
              p_gatewayId in varchar2,
              --出参
              v_out_success out number
            ) as

            v_gatewayCount number := 0;
            v_gatewayId idc_isms_base_house_gateway.gatewayid%type;
            var_out t_ret_table;

            BEGIN
              begin
                var_out := split_str(p_gatewayId, ',');
                for i in 1..var_out.count loop
                  v_gatewayId := var_out(i);
                  select count(1) into v_gatewayCount from idc_isms_base_house_gateway a where a.linkno = (select b.linkno from idc_isms_base_house_gateway b where b.gatewayid = v_gatewayId) and a.del_flag = 0;
                  if v_gatewayCount > 0 then
                    v_out_success := 0;
                    return;
                  else
                    update idc_isms_base_house_gateway a set a.del_flag = 0,a.czlx =1,a.deal_flag = 0 where a.gatewayid = v_gatewayId;
                  end if;
                end loop;
                exception
                 WHEN OTHERS THEN
                      ROLLBACK;
                      v_out_success := 2;
                      RETURN;
               end;
               commit;
               v_out_success := 1;
            END;

            --还原IP地址段
            procedure recover_ipseg_information(
              p_ipsegId in varchar2,
              --出参
              v_out_success out number
            ) as

            v_ipsegCount number := 0;
            v_ipsegId idc_isms_base_house_ipseg.ipsegid%type;
            var_out t_ret_table;

            BEGIN
              begin
                var_out := split_str(p_ipsegId, ',');
                for i in 1..var_out.count loop
                  v_ipsegId := var_out(i);
                  select count(1) into v_ipsegCount from idc_isms_base_house_ipseg a where a.ipseg_no = (select b.ipseg_no from idc_isms_base_house_ipseg b where b.ipsegid = v_ipsegId) and a.del_flag = 0;
                  if v_ipsegCount > 0 then
                    v_out_success := 0;
                    return;
                  else
                    update idc_isms_base_house_ipseg a set a.del_flag = 0,a.czlx =1,a.deal_flag = 0 where a.ipsegid = v_ipsegId;
                  end if;
                end loop;
                exception
                 WHEN OTHERS THEN
                      ROLLBACK;
                      v_out_success := 2;
                      RETURN;
               end;
               commit;
               v_out_success := 1;
            END;

            --还原机架
            procedure recover_frame_information(
              p_frameId in varchar2,
              --出参
              v_out_success out number
            ) as

            v_frameCount number := 0;
            v_frameId idc_isms_base_house_frame.frameid%type;
            var_out t_ret_table;

            BEGIN
              begin
                var_out := split_str(p_frameId, ',');
                for i in 1..var_out.count loop
                  v_frameId := var_out(i);
                  select count(1) into v_frameCount from idc_isms_base_house_frame a where a.frameno = (select b.frameno from idc_isms_base_house_frame b where b.frameid = v_frameId) and a.del_flag = 0;
                  if v_frameCount > 0 then
                    v_out_success := 0;
                    return;
                  else
                    update idc_isms_base_house_frame a set a.del_flag = 0,a.czlx =1,a.deal_flag = 0 where a.frameid = v_frameId;
                  end if;
                end loop;
                exception
                 WHEN OTHERS THEN
                      ROLLBACK;
                      v_out_success := 2;
                      RETURN;
               end;
               commit;
               v_out_success := 1;
            END;



            --还原机房信息
            procedure recover_house_information(
              p_houseId in varchar2,
              --出参
              v_out_success out number
            ) as

            v_houseCount number := 0;
            v_idcCount number := 0;
            v_jyzId idc_isms_base_idc.jyzid%type;
            v_idcid idc_isms_base_idc.idcid%type;
            v_idcName idc_isms_base_idc.idcname%type;
            v_idcDelFlag idc_isms_base_idc.del_flag%type;
            v_houseid idc_isms_base_house.houseid%type;
            v_houseNo idc_isms_base_house.houseidstr%type;
            var_out t_ret_table;

            BEGIN
              begin
                var_out := split_str(p_houseId, ',');
                for i in 1..var_out.count loop
                  v_houseid := var_out(i);
                  select a.jyzid into v_jyzId from idc_isms_base_house a where a.houseid = v_houseid;
                  select a.houseidstr into v_houseNo from idc_isms_base_house a where a.houseid = v_houseid;
                  select count(1) into v_houseCount from idc_isms_base_house a where a.houseidstr = v_houseNo and a.del_flag = 0;
                  select a.idcid,a.idcname,a.del_flag into v_idcid,v_idcName,v_idcDelFlag from idc_isms_base_idc a where a.jyzid = v_jyzId;
                  if v_idcDelFlag = 1 then
                     select count(1) into v_idcCount from idc_isms_base_idc a where (a.idcid = v_idcid or a.idcname = v_idcName) and a.del_flag = 0;
                  end if;

                  if (v_houseCount > 0 or v_idcCount > 0) then
                    v_out_success := 0;
                    return;
                  else
                    --还原经营者信息
                    if v_idcDelFlag = 1 then
                      update idc_isms_base_idc a set a.del_flag = 0 where a.jyzid = v_jyzId;
                    end if;
                    --还原机房信息
                    update idc_isms_base_house_gateway a set a.del_flag = 0,a.czlx =1,a.deal_flag = 0 where a.houseid = v_houseId;
                    update idc_isms_base_house_ipseg a set a.del_flag = 0,a.czlx =1,a.deal_flag = 0 where a.houseid = v_houseId;
                    update idc_isms_base_house_frame a set a.del_flag = 0,a.czlx =1,a.deal_flag = 0 where a.houseid = v_houseId;
                    update idc_isms_base_house a set a.del_flag = 0,a.czlx =1,a.deal_flag = 0 where a.houseid = v_houseId;
                  end if;
                end loop;
                exception
                 WHEN OTHERS THEN
                      ROLLBACK;
                      v_out_success := 2;
                      RETURN;
               end;
               commit;
               v_out_success := 1;
            END;
            procedure updateStatus_house_information(
              p_houseId in varchar2,
              --出参
              v_out_success out number
            ) as
             v_idcid idc_isms_base_idc.idcid%type;
          v_czlx idc_isms_base_house.czlx%type;
          v_houseId idc_isms_base_house.houseid%type;
          v_houseIdCur sys_refcursor;
          v_sql varchar2(2000);
          v_delType idc_isms_base_delete.del_type%type := 2;
          v_userHHCount number;
          v_serviceCount number;
          Begin
               begin
                    v_sql := 'select HOUSEID from IDC_ISMS_BASE_HOUSE where HOUSEID in (' || p_houseId || ')';
                  open v_houseIdCur for v_sql;
                  loop
                    fetch v_houseIdCur into v_houseId;
                    exit when v_houseIdCur%notfound;
                    update idc_isms_base_house_gateway a set a.czlx =1,a.deal_flag = 0 where a.houseid = v_houseId;
                    update idc_isms_base_house_ipseg a set a.czlx =1,a.deal_flag = 0 where a.houseid = v_houseId;
                    update idc_isms_base_house_frame a set a.czlx =1,a.deal_flag = 0 where a.houseid = v_houseId;
                    update idc_isms_base_house a set a.czlx =1,a.deal_flag = 0 where a.houseid = v_houseId;
                  end loop;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
            end;
end IDC_ISMS_BASE_HOUSE_MANAGE;
/
