CREATE package body idc_interface_down_jcdm is

 --处理基础代码备案属性
 procedure DealJCDMbasx(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        )as
   v_count number(5);
 Begin

 begin
   select count(*) into v_count from idc_jcdm_basx where id=v_id;

   if(v_count=0) then
      insert into idc_jcdm_basx
        (id, mc, bz, sfyx)
      values
        (v_id, v_mc, v_bz, v_sfyx);
   else
      update idc_jcdm_basx
         set mc = v_mc,
             bz = v_bz,
             sfyx = v_sfyx
       where id=v_id;
   end if;

 exception
  WHEN OTHERS THEN
        ROLLBACK;
        v_out_success := 0;
        RETURN;
 end;
 commit;
  v_out_success:=1;
 end;

 --处理基础代码代理类型
 procedure DealJCDMdllx(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        )as
   v_count number(5);
 Begin
   begin
     select count(*) into v_count from idc_jcdm_dllx where id=v_id;
     if(v_count=0) then
        insert into idc_jcdm_dllx
          (id, mc, bz, sfyx)
        values
          (v_id, v_mc, v_bz, v_sfyx);
     else
        update idc_jcdm_dllx
           set mc = v_mc,
               bz = v_bz,
               sfyx = v_sfyx
         where id=v_id;
     end if;
     exception WHEN OTHERS THEN
     ROLLBACK;
     v_out_success := 0;
     RETURN;
   end;
   commit;
   v_out_success:=1;
end;

 --处理基础代码单位属性
 procedure DealJCDMdwsx(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        )as
   v_count number(5);
 Begin

 begin
   select count(*) into v_count from idc_jcdm_dwsx where id=v_id;

   if(v_count=0) then
      insert into idc_jcdm_dwsx
        (id, mc, bz, sfyx)
      values
        (v_id, v_mc, v_bz, v_sfyx);
   else
      update idc_jcdm_dwsx
         set mc = v_mc,
             bz = v_bz,
             sfyx = v_sfyx
       where id=v_id;
   end if;

 exception
  WHEN OTHERS THEN
        ROLLBACK;
        v_out_success := 0;
        RETURN;
 end;
 commit;
  v_out_success:=1;
 end;

 --处理基础代码服务内容
 procedure DealJCDMfwnr(
       v_id in number,
       v_mc    in varchar2,
       v_fl in number,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        )as
   v_count number(5);
 Begin

 begin
   select count(*) into v_count from idc_jcdm_fwnr where id=v_id;

   if(v_count=0) then
      insert into idc_jcdm_fwnr
        (id, mc,fl, bz, sfyx)
      values
        (v_id, v_mc,v_fl, v_bz, v_sfyx);
   else
      update idc_jcdm_fwnr
         set mc = v_mc,
             bz = v_bz,
             fl = v_fl,
             sfyx = v_sfyx
       where id=v_id;
   end if;

 exception
  WHEN OTHERS THEN
        ROLLBACK;
        v_out_success := 0;
        RETURN;
 end;
 commit;
  v_out_success:=1;
 end;

 --处理基础代码规则类型
 procedure DealJCDMgzlx(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        )as
   v_count number(5);
 Begin

 begin
   select count(*) into v_count from idc_jcdm_gzlx where id=v_id;

   if(v_count=0) then
      insert into idc_jcdm_gzlx
        (id, mc, bz, sfyx)
      values
        (v_id, v_mc, v_bz, v_sfyx);
   else
      update idc_jcdm_gzlx
         set mc = v_mc,
             bz = v_bz,
             sfyx = v_sfyx
       where id=v_id;
   end if;

 exception
  WHEN OTHERS THEN
        ROLLBACK;
        v_out_success := 0;
        RETURN;
 end;
 commit;
  v_out_success:=1;
 end;

 --处理基础代码机房性质
 procedure DealJCDMjfxz(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        )as
   v_count number(5);
 Begin

 begin
   select count(*) into v_count from idc_jcdm_jfxz where id=v_id;

   if(v_count=0) then
      insert into idc_jcdm_jfxz
        (id, mc, bz, sfyx)
      values
        (v_id, v_mc, v_bz, v_sfyx);
   else
      update idc_jcdm_jfxz
         set mc = v_mc,
             bz = v_bz,
             sfyx = v_sfyx
       where id=v_id;
   end if;

 exception
  WHEN OTHERS THEN
        ROLLBACK;
        v_out_success := 0;
        RETURN;
 end;
 commit;
  v_out_success:=1;
 end;

 --处理基础代码接入方式
 procedure DealJCDMjrfs(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        )as
   v_count number(5);
 Begin

 begin
   select count(*) into v_count from idc_jcdm_jrfs where id=v_id;

   if(v_count=0) then
      insert into idc_jcdm_jrfs
        (id, mc, bz, sfyx)
      values
        (v_id, v_mc, v_bz, v_sfyx);
   else
      update idc_jcdm_jrfs
         set mc = v_mc,
             bz = v_bz,
             sfyx = v_sfyx
       where id=v_id;
   end if;

 exception
  WHEN OTHERS THEN
        ROLLBACK;
        v_out_success := 0;
        RETURN;
 end;
 commit;
  v_out_success:=1;
 end;

 --处理基础代码违法违规情况
 procedure DealJCDMwfwgqk(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        )as
   v_count number(5);
 Begin

 begin
   select count(*) into v_count from idc_jcdm_wfwgqk where id=v_id;

   if(v_count=0) then
      insert into idc_jcdm_wfwgqk
        (id, mc, bz, sfyx)
      values
        (v_id, v_mc, v_bz, v_sfyx);
   else
      update idc_jcdm_wfwgqk
         set mc = v_mc,
             bz = v_bz,
             sfyx = v_sfyx
       where id=v_id;
   end if;

 exception
  WHEN OTHERS THEN
        ROLLBACK;
        v_out_success := 0;
        RETURN;
 end;
 commit;
  v_out_success:=1;
 end;

 --处理基础代码证件类型
 procedure DealJCDMzjlx(
       v_id in number,
       v_mc    in varchar2,
       v_bz in   varchar2,
       v_sfyx in   number,
          --出参
          v_out_success    out number
        )as
   v_count number(5);
 Begin

 begin
   select count(*) into v_count from idc_jcdm_zjlx where id=v_id;

   if(v_count=0) then
      insert into idc_jcdm_zjlx
        (id, mc, bz, sfyx)
      values
        (v_id, v_mc, v_bz, v_sfyx);
   else
      update idc_jcdm_zjlx
         set mc = v_mc,
             bz = v_bz,
             sfyx = v_sfyx
       where id=v_id;
   end if;

 exception
  WHEN OTHERS THEN
        ROLLBACK;
        v_out_success := 0;
        RETURN;
 end;
 commit;
  v_out_success:=1;
 end;

        --处理基础代码域名子分类信息
         procedure DealJCDMurlcontent(
               v_id    in number,
               v_mc    in varchar2,
               v_fl    in number,
               v_bz    in varchar2,
               v_sfyx  in number,
               --出参
               v_out_success    out number
               ) as
           v_count number(5);
         Begin
           begin
             select count(*) into v_count from idc_jcdm_urlcontent where id=v_id;
             if(v_count = 0) then
                insert into idc_jcdm_urlcontent
                  (id, mc, bz, fl, sfyx)
                values
                  (v_id, v_mc, v_bz, v_fl, v_sfyx);
             else
                update idc_jcdm_urlcontent
                   set id = v_id,
                       mc = v_mc,
                       bz = v_bz,
                       fl = v_fl,
                       sfyx = v_sfyx
                 where id = v_id;
             end if;
             exception WHEN OTHERS THEN
             ROLLBACK;
             v_out_success := 0;
             RETURN;
           end;
           commit;
           v_out_success:=1;
        end;

         --处理基础代码网络应用/协议信息
         procedure DealJCDMproapp(
               v_id    in number,
               v_mc    in varchar2,
               v_bz    in varchar2,
               v_type  in number,
               v_sfyx  in number,
               --出参
               v_out_success    out number
               ) as
           v_count number(5);
         Begin
           begin
             select count(*) into v_count from idc_jcdm_proapp where id=v_id;
             if(v_count = 0) then
                insert into idc_jcdm_proapp
                  (id, mc, sfyx, bz, type)
                values
                  (v_id, v_mc, v_sfyx, v_bz, v_type);
             else
                update idc_jcdm_proapp
                   set id = v_id,
                       mc = v_mc,
                       sfyx = v_sfyx,
                       bz = v_bz,
                       type = v_type
                 where id = v_id;
             end if;
             exception WHEN OTHERS THEN
             ROLLBACK;
             v_out_success := 0;
             RETURN;
           end;
           commit;
           v_out_success:=1;
        end;

        --处理基础代码应用服务类型信息
        procedure DealJCDMyyfwlx(
             v_id    in number,
             v_mc    in varchar2,
             v_bz    in varchar2,
             v_sfyx  in number,
             --出参
             v_out_success    out number
         ) as
           v_count number(5);
         Begin
           begin
             select count(*) into v_count from idc_jcdm_yyfwlx where id=v_id;
             if(v_count = 0) then
                insert into idc_jcdm_yyfwlx
                  (id, mc, sfyx, bz)
                values
                  (v_id, v_mc, v_sfyx, v_bz);
             else
                update idc_jcdm_yyfwlx
                   set id = v_id,
                       mc = v_mc,
                       sfyx = v_sfyx,
                       bz = v_bz
                 where id = v_id;
             end if;
             exception WHEN OTHERS THEN
             ROLLBACK;
             v_out_success := 0;
             RETURN;
           end;
           commit;
           v_out_success:=1;
        end;

        --处理基础代码前置审批
        procedure DealJCDMqzsp(
               v_id    in number,
               v_mc    in varchar2,
               v_bz    in varchar2,
               v_sfyx  in number,
               --出参
               v_out_success    out number
               ) as
           v_count number(5);
         Begin
           begin
             select count(*) into v_count from idc_jcdm_qzsp where id=v_id;
             if(v_count = 0) then
                insert into idc_jcdm_qzsp
                  (id, mc, sfyx, bz)
                values
                  (v_id, v_mc, v_sfyx, v_bz);
             else
                update idc_jcdm_qzsp
                   set id = v_id,
                       mc = v_mc,
                       sfyx = v_sfyx,
                       bz = v_bz
                 where id = v_id;
             end if;
             exception WHEN OTHERS THEN
             ROLLBACK;
             v_out_success := 0;
             RETURN;
           end;
           commit;
           v_out_success:=1;
        end;

end idc_interface_down_jcdm;
/
