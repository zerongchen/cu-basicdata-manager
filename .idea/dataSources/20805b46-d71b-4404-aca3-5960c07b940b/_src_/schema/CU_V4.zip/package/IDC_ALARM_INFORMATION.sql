CREATE package idc_alarm_information is

  --处理监控项告警信息
 procedure dealAlarmInfo (
           p_alarmType           in number,
           p_alarmLevel          in number,
           p_alarmTime           in varchar2,
           p_alarmMessage        in varchar2,
           p_alarmTarget         in number,
           --出参
           v_out_success         out number
       );
procedure list_monitor_file(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      status in number,
      selectFlag in number,
       monitor_task_id in number,
      begin_create_time    in varchar2,
    end_create_time in varchar2
    );
     procedure list_monitor_alarm(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      alarmContent in varchar2,
      alarmParam in varchar2,
      dealStatus    in number,
    alarmBeginTime in varchar2,
    alarmEndTime in varchar2
    );
end idc_alarm_information;
/
CREATE package body idc_alarm_information is

  --处理基础代码备案属性
 procedure dealAlarmInfo(
           p_alarmType           in number,
           p_alarmLevel          in number,
		       p_alarmTime			     in varchar2,
           p_alarmMessage        in varchar2,
           p_alarmTarget         in number,
           --出参
           v_out_success  out number
        ) as
       v_alarmType           number;
       v_alarmLevel          number;
       v_alarmTime			     varchar2(100);
       v_alarmMessage        varchar2(4000);
       v_alarmTarget         number;
       v_count               number;
       v_alarmId             number;
       v_status              number;
 Begin
   begin
     if (p_alarmLevel = 2) then
        v_status := 0;
     else 
        v_status := 1;
     end if;
     select count(*) into v_count from idc_isms_alarm_information info where info.alarm_target = p_alarmTarget;
     if(v_count = 0) then
       select seq_idc_isms_alarm_information.nextval into v_alarmId from dual;
       --插入告警信息表
       insert into idc_isms_alarm_information
         (alarmid, alarm_type, alarm_house, alarm_level, alarm_time, alarm_msg, create_time, update_time, alarm_target)
       values
         (v_alarmId, p_alarmType, '-1', p_alarmLevel, p_alarmTime, p_alarmMessage, sysdate, sysdate, p_alarmTarget);
       --插入告警信息历史表
       insert into idc_isms_alarm_infor_list
         (id, alarmid, alarm_msg, alarm_time, status, create_time, update_time, alarm_target)
       values
         (seq_idc_isms_alarm_info_list.nextval, v_alarmId, p_alarmMessage, p_alarmTime, v_status, sysdate, sysdate, p_alarmTarget);       
     else
       select 
         info.alarmid, info.alarm_level into v_alarmId, v_alarmLevel
       from idc_isms_alarm_information info where info.alarm_target = p_alarmTarget;
       if (p_alarmLevel = v_alarmLevel) then
          update idc_isms_alarm_information
          set alarm_type = p_alarmType,
              alarm_level = p_alarmLevel,
              alarm_time = p_alarmTime,
              alarm_msg = p_alarmMessage,
              update_time = sysdate,
              alarm_target = p_alarmTarget
          where alarmid = v_alarmid;          
       else 
         --更新告警信息表
         update idc_isms_alarm_information
         set  alarm_type = p_alarmType,
              alarm_level = p_alarmLevel,
              alarm_time = p_alarmTime,
              alarm_msg = p_alarmMessage,
              update_time = sysdate,
              alarm_target = p_alarmTarget
          where alarmid = v_alarmid;
         --插入告警信息历史表
         insert into idc_isms_alarm_infor_list
           (id, alarmid, alarm_msg, alarm_time, status, create_time, update_time, alarm_target)
         values
           (seq_idc_isms_alarm_info_list.nextval, v_alarmId, p_alarmMessage, p_alarmTime, v_status, sysdate, sysdate, p_alarmTarget); 
       end if;
     end if;
   exception WHEN OTHERS THEN
    ROLLBACK;
    v_out_success := 0;
    raise;
  end;
  commit;
  v_out_success:=1;
 end;
 --查询监控文件列表
 procedure list_monitor_file(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      status in number,
      selectFlag in number,
      monitor_task_id in number,
      begin_create_time    in varchar2,
	  end_create_time in varchar2
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := 'from IDC_MONITOR_TASK_FILE';
      v_field    := 'FILE_ID,TASK_ID,MONITOR_TASK_ID,SERVER_IP,FILE_NAME,RECORD_NUM1,RECORD_NUM2,RECORD_NUM3,RECORD_NUM4,RECORD_NUM5,
	  STATUS,CREATE_TIME,Deal_Result,TIMEOUT_FLAG ';

      --条件语句
      v_condition := ' where 1=1 ';
      if(monitor_task_id  is not null ) then
          v_condition := v_condition || '  and MONITOR_TASK_ID = '||monitor_task_id;
      end if;
      if(status is not null) then
           v_condition := v_condition || '  and STATUS = '||status;
      end if;
      if(selectFlag  = 0 ) then
          v_condition := v_condition || '  and STATUS >0 ';
      end if;
      /*if(selectFlag  = 1 ) then
          v_condition := v_condition || '  and STATUS=-1 ';
      end if;*/
      if(selectFlag  = 2 ) then
          v_condition := v_condition || '  and TIMEOUT_FLAG =1 ';
      end if;
      if begin_create_time is not null  then
          v_condition := v_condition || '  and CREATE_TIME >=to_date('''||begin_create_time||''',''yyyy-mm-dd hh24:mi:ss'') ';
      end if;
	  if end_create_time is not null  then
          v_condition := v_condition || '  and CREATE_TIME <=to_date('''||end_create_time||''',''yyyy-mm-dd hh24:mi:ss'') ';
      end if;
      
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
		--只返回分页记录
        --填充记录列表
        v_e := pageindex * pagesize;
        v_s := (pageindex - 1) * pagesize + 1;
        v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
        v_sql := v_sql || ' select * ' || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
      end if;
      open p_cursor for v_sql;
  end;
  --告警信息表分页
  procedure list_monitor_alarm(
      p_ispaging in number,
      pageindex in number,
      pagesize in number,
      p_iscount in number,
      sortName in varchar2,
      orderItem in varchar2,
      p_cursor out sys_refcursor,
      p_recordcount out number,

      alarmContent in varchar2,
      alarmParam in varchar2,
      dealStatus    in number,
	  alarmBeginTime in varchar2,
	  alarmEndTime in varchar2
      )is
      --定义
      v_field     varchar2(2000); --字段
      v_innersql  varchar2(2000); --内部语句，完整的查询sql
      v_order     varchar2(500); --内部排序语句
      v_condition varchar2(2000); --条件语句
      v_count     varchar2(2000); --统计记录总数语句
      v_sql       varchar2(2000); --查询语句
      v_s         number(10); --开始记录
      v_e         number(10); --结束记录
    begin

      p_recordcount := 0;
      --内部sql语句
      v_innersql := 'from idc_monitor_task_alarm';
      v_field    := 'ALARM_ID,MONITOR_TASK_ID,TASK_ID,TASK_TYPE,TASK_SUBTYPE,ALARM_CONTENT,ALARM_PARAMS,ALARM_TIME,DEAL_STATUS,DEAL_SOLUTION,DEAL_USER,DEAL_TIME';

      --条件语句
      v_condition := ' where 1=1 ';
      if(alarmContent  is not null ) then
          v_condition := v_condition || ' and ALARM_CONTENT like ''%' || alarmContent || '%''';
      end if;
      if(alarmParam  is not null ) then
          v_condition := v_condition || ' and ALARM_PARAMS like ''%' || alarmParam || '%''';
      end if;
      if (dealStatus is not null)  then
          v_condition := v_condition || '  and DEAL_STATUS = '|| dealStatus;
      end if;
	    if (alarmBeginTime is not null)  then
          v_condition := v_condition || '  and ALARM_TIME >=to_date('''||alarmBeginTime||''',''yyyy-mm-dd hh24:mi:ss'')';
      end if;
      if (alarmEndTime is not null)  then
          v_condition := v_condition || '  and ALARM_TIME <=to_date('''||alarmEndTime||''',''yyyy-mm-dd hh24:mi:ss'')';
      end if;
      if p_iscount=1 then
      v_count := 'select count(1) ' || v_innersql || v_condition;
      execute immediate v_count into p_recordcount;
      end if;
      v_order := ' order by ' || sortName || '  ' || orderItem;

      if p_ispaging = 0 then
        begin
          v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
        end;
      else
		--只返回分页记录
        --填充记录列表
        v_e := pageindex * pagesize;
        v_s := (pageindex - 1) * pagesize + 1;
        v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
        v_sql := v_sql || ' select * ' || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                    dbms_output.put_line(v_sql);
      end if;
      open p_cursor for v_sql;
  end;
end idc_alarm_information;
/
