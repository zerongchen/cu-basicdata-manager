CREATE package IDC_ISMS_BASE_IDC_MANAGE as
procedure save_idc_information(
            p_idcId in VARCHAR2,
            p_idcName in VARCHAR2,
            p_idcAddress in VARCHAR2,
            p_idcZipCode in VARCHAR2,
            p_corporater in VARCHAR2,
            p_officerName in VARCHAR2,
            p_officerIdType in NUMBER,
            p_officerId in VARCHAR2,
            p_officerTelephone in VARCHAR2,
            p_officerMobile in VARCHAR2,
            p_officerEmail in VARCHAR2,
            p_ecName in VARCHAR2,
            p_ecIdtype in NUMBER,
            p_ecId in VARCHAR2,
            p_ecTelephone in VARCHAR2,
            p_ecMobile in VARCHAR2,
            p_ecEmail in VARCHAR2,
            p_optertionType in NUMBER,
            p_dealFlag in NUMBER,
            p_createUserId in NUMBER,
            p_msg out varchar2 --非空为错误信息
           );
           
           procedure list_idc_information(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数

            p_idcId in VARCHAR2,
            p_idcName in VARCHAR2,
            p_corporater in VARCHAR2,
            p_officerName in VARCHAR2,
            p_ecName in VARCHAR2,
            p_dealFlag in number,
            p_delFlag in number
         );
         
          --查询列表的数据查询
         procedure idc_query_list_information(
                  --入参，分页参数
                  p_isPaging in number, --是否分页，如果不分页则返回全部数据
                  p_pageIndex  in number, --页索引
                  p_pageSize   in number, --页大小
                  p_IsCount    in number,
                  p_sortName   in VARCHAR2,
                  p_sortOrder  in VARCHAR2,
                  --输出
                  p_cursor      out sys_refcursor,
                  p_recordCount out number, --非空为错误信息
                  --入参，查询参数
                  p_idcId in VARCHAR2,
                  p_idcName in VARCHAR2,
                  p_corporater in VARCHAR2,
                  p_officerName in VARCHAR2,
                  p_ecName in VARCHAR2,
                  p_houseName in VARCHAR2,
                  p_houseProvince in NUMBER,
                  p_houseCity in NUMBER,
                  p_houseCounty in NUMBER,
                  p_houseOfficerName in VARCHAR2,
                  p_unitName in VARCHAR2,
                  p_unitOfficerName in VARCHAR2
         );
         
          procedure del_idc_information(
              p_jyzid in varchar2,
              --出参
              v_out_success out number
         );
         
          procedure delete_idc_information(
              p_jyzid in varchar2,
              --出参
              v_out_success out number
         );
         
         --统计机房数量
        procedure statisticHouseNum;
        
         --还原经营者
          procedure recover_idc(
            p_jyzId in varchar2,
            --出参
            v_out_success out number
          );
           procedure completeReport(
             p_jyzId in varchar2,
              --出参
              v_out_success out number
            );

end IDC_ISMS_BASE_IDC_MANAGE;
/
CREATE package body IDC_ISMS_BASE_IDC_MANAGE is
       procedure save_idc_information(
            p_idcId in VARCHAR2,
            p_idcName in VARCHAR2,
            p_idcAddress in VARCHAR2,
            p_idcZipCode in VARCHAR2,
            p_corporater in VARCHAR2,
            p_officerName in VARCHAR2,
            p_officerIdType in NUMBER,
            p_officerId in VARCHAR2,
            p_officerTelephone in VARCHAR2,
            p_officerMobile in VARCHAR2,
            p_officerEmail in VARCHAR2,
            p_ecName in VARCHAR2,
            p_ecIdtype in NUMBER,
            p_ecId in VARCHAR2,
            p_ecTelephone in VARCHAR2,
            p_ecMobile in VARCHAR2,
            p_ecEmail in VARCHAR2,
            p_optertionType in NUMBER,
            p_dealFlag in NUMBER,
            p_createUserId in NUMBER,
            p_msg out varchar2 --非空为错误信息
           ) is
        begin
            insert into idc_isms_base_idc (JYZID,IDCID,IDCNAME,IDCADD,IDCZIP,
                   CORP,OFFICER_NAME,OFFICER_IDTYPE,OFFICER_ID,OFFICER_TEL,
                   OFFICER_MOBILE,OFFICER_EMAIL,EC_NAME,EC_IDTYPE,EC_ID,
                   EC_TEL,EC_MOBILE,EC_EMAIL,CZLX,DEAL_FLAG,UPDATE_TIME,CREATE_USERID)
            values (
                   SEQ_ISMS_BASE_JYZID.Nextval,p_idcId,p_idcName,p_idcAddress,p_idcZipCode,
                   p_corporater, p_officerName,p_officerIdType,p_officerId,p_officerTelephone,
                   p_officerMobile,p_officerEmail,p_ecName,p_ecIdtype,p_ecId,
                   p_ecTelephone,p_ecMobile,p_ecEmail,p_optertionType,p_dealFlag,sysdate,p_createUserId
                   );
            commit;
        exception
          when others then
            rollback;
            p_msg:= sqlcode || sqlerrm;
            return;
        end;

        procedure list_idc_information(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数

            p_idcId in VARCHAR2,
            p_idcName in VARCHAR2,
            p_corporater in VARCHAR2,
            p_officerName in VARCHAR2,
            p_ecName in VARCHAR2,
            p_dealFlag in number,
            p_delFlag in number
         ) is

         --定义
         v_field     varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录

         begin
            --内部sql语句
            v_innersql := ' from idc_isms_base_idc idc';
            v_field    := ' jyzid, idcid, idcname, idcadd, idczip, corp, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, ec_name, ec_idtype, ec_id, ec_tel, ec_mobile, ec_email, czlx, deal_flag, create_time, update_time, create_userid,info_complete,HOUSENUMBER,DEL_FLAG ';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' jyzid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';

            if (p_idcId is not null) then
                v_condition := v_condition || ' and idc.idcid like ''%' || p_idcId|| '%''';
            end if;
            if (p_idcName is not null) then
                v_condition := v_condition || ' and idc.idcname like ''%' || p_idcName || '%''' ;
            end if;
            if (p_corporater is not null) then
                v_condition := v_condition || ' and idc.corp like ''%' || p_corporater || '%''' ;
            end if;
            if (p_officerName is not null ) then
                v_condition := v_condition || ' and idc.officer_name like ''%' || p_officerName || '%''' ;
            end if;
            if (p_ecName  is not null ) then
                v_condition := v_condition || ' and idc.ec_name like ''%' || p_ecName || '%''' ;
            end if;
            if p_dealFlag >= 0 then
               v_condition := v_condition || ' and idc.DEAL_FLAG = ' || p_dealFlag;
            end if;
            if p_delFlag >= 0 then
                v_condition := v_condition || ' and DEL_FLAG = ' || p_delFlag;
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;

            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;

         --查询列表的数据查询
         procedure idc_query_list_information(
                  --入参，分页参数
                  p_isPaging in number, --是否分页，如果不分页则返回全部数据
                  p_pageIndex  in number, --页索引
                  p_pageSize   in number, --页大小
                  p_IsCount    in number,
                  p_sortName   in VARCHAR2,
                  p_sortOrder  in VARCHAR2,
                  --输出
                  p_cursor      out sys_refcursor,
                  p_recordCount out number, --非空为错误信息
                  --入参，查询参数
                  p_idcId in VARCHAR2,
                  p_idcName in VARCHAR2,
                  p_corporater in VARCHAR2,
                  p_officerName in VARCHAR2,
                  p_ecName in VARCHAR2,
                  p_houseName in VARCHAR2,
                  p_houseProvince in NUMBER,
                  p_houseCity in NUMBER,
                  p_houseCounty in NUMBER,
                  p_houseOfficerName in VARCHAR2,
                  p_unitName in VARCHAR2,
                  p_unitOfficerName in VARCHAR2
         ) is
         --定义
         v_field     varchar2(2000); --字段
         v_innersql  varchar2(2000); --内部语句，完整的查询sql
         v_order     varchar2(500); --内部排序语句
         v_condition varchar2(2000); --条件语句
         v_count     varchar2(2000); --统计记录总数语句
         v_sql       varchar2(2000); --查询语句
         v_s         number(10); --开始记录
         v_e         number(10); --结束记录
         begin
            p_recordcount := 0;
            --内部sql语句
            v_innersql := ' from idc_hist_base_idc idc';
            v_field    := ' histid,jyzid, idcid, idcname, idcadd, idczip, corp, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, ec_name, ec_idtype, ec_id, ec_tel, ec_mobile, ec_email, create_time, update_time, create_userid';
            v_order := ' ORDER BY ';
            if(p_sortName is not null ) then
                if(p_sortOrder is not null ) then
                    v_order := v_order || p_sortName || ' ' || p_sortOrder ;
                else
                    v_order := v_order || p_sortName || ' DESC';
                end if;
            else
                v_order := v_order || ' jyzid DESC';
            end if;
            --条件语句
            v_condition := ' where 1=1 ';
            if(p_idcId  is not null ) then
                v_condition := v_condition || ' and idc.idcid like ''%' || p_idcId || '%''' ;
            end if;
            if(p_idcName  is not null ) then
                v_condition := v_condition || ' and idc.idcname like ''%' || p_idcName || '%''' ;
            end if;
            if(p_corporater  is not null ) then
                v_condition := v_condition || ' and idc.corp like ''%' || p_corporater || '%''' ;
            end if;
            if(p_officerName  is not null ) then
                v_condition := v_condition || ' and idc.officer_name like ''%' || p_officerName || '%''' ;
            end if;
            if(p_ecName  is not null ) then
                v_condition := v_condition || ' and idc.ec_name like ''%' || p_ecName || '%''' ;
            end if;
            if(p_houseName is not null ) then
                v_condition := v_condition || ' and idc.jyzid in (select house.jyzid from idc_isms_base_house house where house.housename like ''%' || p_houseName || '%'')';
            end if;
            if(p_houseProvince is not null ) then
                v_condition := v_condition || ' and idc.jyzid in (select house.jyzid from idc_isms_base_house house where house.houseprovince = ' || p_houseProvince || ')';
            end if;
            if(p_houseCity is not null ) then
                v_condition := v_condition || ' and idc.jyzid in (select house.jyzid from idc_isms_base_house house where house.housecity = ' || p_houseCity || ')';
            end if;
            if(p_houseCounty is not null ) then
                v_condition := v_condition || ' and idc.jyzid in (select house.jyzid from idc_isms_base_house house where house.housecounty = ' || p_houseCounty || ')';
            end if;
            if(p_houseOfficerName is not null ) then
                v_condition := v_condition || ' and idc.jyzid in (select house.jyzid from idc_isms_base_house house where house.ho_name like ''%' || p_houseOfficerName || '%'')';
            end if;
            if(p_unitName is not null ) then
                v_condition := v_condition || ' and idc.jyzid in (select idcUser.jyzid from idc_isms_base_user idcUser where idcUser.unitname like ''%' || p_unitName || '%'')';
            end if;
            if(p_unitOfficerName is not null ) then
                v_condition := v_condition || ' and idc.jyzid in (select idcUser.jyzid from idc_isms_base_user idcUser where idcUser.officer_name like ''%' || p_unitOfficerName || '%'')';
            end if;
            --如果需要统计则统计记录总数
            if p_IsCount = 1 then
                v_count := 'select count(1) ' || v_innersql || v_condition;
                execute immediate v_count into p_recordCount;
            end if;
            if p_ispaging = 0 then
               --如果不分页返回全部记录
                begin
                    v_sql := ' select ' || v_field || v_innersql || v_condition || v_order;
                end;
            else
                begin
                    --只返回分页记录
                    --填充记录列表
                    v_e := p_pageIndex * p_pageSize;
                    v_s := (p_pageIndex - 1) * p_pageSize + 1;
                    v_sql := ' select ' || v_field || ' from (select rownum my_rownum, my_table.* from( ';
                    v_sql := v_sql || ' select ' || v_field || v_innersql || v_condition || v_order;
                    v_sql := v_sql || ') my_table where rownum <= ' || v_e || ' ) where my_rownum >= ' || v_s;
                end;
            end if;
            open p_cursor for v_sql;
         end;
         
        procedure del_idc_information(
              p_jyzid in varchar2,
              --出参
              v_out_success out number
         ) as
           --v_count1 number(5);
           --v_count2 number(5);
           --v_houseids varchar2(4000):='';
           --v_userids varchar2(4000):='';
           v_out_userSuccess number;
           v_out_houseSuccess number;
           v_idcid idc_isms_base_idc.idcid%type;
           v_czlx idc_isms_base_idc.czlx%type;
           v_jyzId idc_isms_base_idc.jyzid%type;
           v_userId idc_isms_base_user.userid%type;
           v_houseId idc_isms_base_house.houseid%type;
           userIdCur sys_refcursor;
           houseIdCur sys_refcursor;
           jyzIdCur sys_refcursor;
           v_sql varchar2(100);
          Begin
                begin
                  --如果p_jyzid为null则做全部删除
                   if (p_jyzid is null) then
                     v_sql := 'select JYZID from IDC_ISMS_BASE_IDC where DEAL_FLAG != 1';
                   else
                     v_sql := 'select JYZID from IDC_ISMS_BASE_IDC where JYZID in (' || p_jyzid || ')';
                   end if;
                   open jyzIdCur for v_sql;
                   loop
                     fetch jyzIdCur into v_jyzId;
                        exit when jyzIdCur%notfound;
                     open userIdCur for select userid from idc_isms_base_user where jyzid = v_jyzId and del_flag = 1;
                     loop
                         fetch userIdCur into v_userId;
                              exit when userIdCur%notfound;
                             IDC_ISMS_BASE_USER_MANAGE.del_user_information(v_userId,v_out_userSuccess);
                     end loop;
                     close userIdCur;
                     open houseIdCur for select houseid from idc_isms_base_house where jyzid = v_jyzId and del_flag = 1;
                     loop
                         fetch houseIdCur into v_houseId;
                              exit when houseIdCur%notfound;
                             IDC_ISMS_BASE_HOUSE_MANAGE.del_house_information(v_houseId,v_out_houseSuccess);
                     end loop;
                     close houseIdCur;
                     select idcid,czlx into v_idcid,v_czlx from idc_isms_base_idc where jyzid = v_jyzId;
                     if (v_czlx = 2) then
                        insert into idc_isms_base_delete(delid,del_type,idcid)
                        values(SEQ_IDC_ISMS_BASE_DELID.Nextval,1,v_idcid);
                     end if;
                   delete from idc_isms_base_idc a where a.jyzid = v_jyzId;
                end loop;
                close jyzIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
               dbms_output.put_line('');
         end;

         procedure delete_idc_information(
              p_jyzid in varchar2,
              --出参
              v_out_success out number
         ) as
           --v_count1 number(5);
           --v_count2 number(5);
           --v_houseids varchar2(4000):='';
           --v_userids varchar2(4000):='';
           v_out_userSuccess number;
           v_out_houseSuccess number;
           v_idcid idc_isms_base_idc.idcid%type;
           v_czlx idc_isms_base_idc.czlx%type;
           v_jyzId idc_isms_base_idc.jyzid%type;
           v_userId idc_isms_base_user.userid%type;
           v_houseId idc_isms_base_house.houseid%type;
           userIdCur sys_refcursor;
           houseIdCur sys_refcursor;
           jyzIdCur sys_refcursor;
           v_sql varchar2(100);
          Begin
               begin
                   --如果p_jyzid为null则做全部删除
                   if (p_jyzid is null) then
                     v_sql := 'select JYZID from IDC_ISMS_BASE_IDC where DEAL_FLAG != 1';
                   else
                     v_sql := 'select JYZID from IDC_ISMS_BASE_IDC where JYZID in (' || p_jyzid || ')';
                   end if;
                   open jyzIdCur for v_sql;
                   loop
                     fetch jyzIdCur into v_jyzId;
                        exit when jyzIdCur%notfound;
                     open userIdCur for select userid from idc_isms_base_user where jyzid = v_jyzId and del_flag = 0;
                     loop
                         fetch userIdCur into v_userId;
                              exit when userIdCur%notfound;
                             IDC_ISMS_BASE_USER_MANAGE.delete_user_information(v_userId,0,v_out_userSuccess);
                     end loop;
                     close userIdCur;
                     open houseIdCur for select houseid from idc_isms_base_house where jyzid = v_jyzId and del_flag = 0;
                     loop
                         fetch houseIdCur into v_houseId;
                              exit when houseIdCur%notfound;
                             IDC_ISMS_BASE_HOUSE_MANAGE.delete_house_information(v_houseId,0,v_out_houseSuccess);
                     end loop;
                     close houseIdCur;
                     select idcid,czlx into v_idcid,v_czlx from idc_isms_base_idc where jyzid = v_jyzId;
                     if (v_czlx = 2) then
                        insert into idc_isms_base_delete(delid,del_type,idcid)
                        values(SEQ_IDC_ISMS_BASE_DELID.Nextval,1,v_idcid);
                     end if;
                   /*--添加历史记录start
                   insert into idc_hist_base_idc
                     (histid, jyzid, idcid, idcname, idcadd, idczip, corp, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, ec_name, ec_idtype, ec_id, ec_tel, ec_mobile, ec_email, create_time, update_time, create_userid,housenumber)
                   select SEQ_ISMS_HIST_HISTID.NEXTVAL,jyzid, idcid, idcname, idcadd, idczip, corp, officer_name, officer_idtype, officer_id, officer_tel, officer_mobile, officer_email, ec_name, ec_idtype, ec_id, ec_tel, ec_mobile, ec_email, create_time, update_time, create_userid,housenumber from idc_isms_base_idc where jyzid = p_jyzid;
                   --end*/
                   update idc_isms_base_idc a set a.del_flag = 1 where a.jyzid = v_jyzId;
                end loop;
                close jyzIdCur;
               exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 0;
                    RETURN;
               end;
               commit;
               v_out_success:=1;
         end;

        --统计机房数量
        procedure statisticHouseNum
        as
           cursor v_cur is select jyzid,del_flag,num from (select a.jyzid,a.del_flag,c.num from idc_isms_base_idc a
                             left join
                        (select jyzid,count(1) num from idc_isms_base_house b where b.del_flag != 1 group by jyzid) c on a.jyzid = c.jyzid)
                        where del_flag != 1;
           v_row v_cur%rowtype;
        BEGIN
           begin
             for v_row in v_cur loop
               if v_row.num is null then
                  v_row.num := 0;
               end if;
               update idc_isms_base_idc set HOUSENUMBER = v_row.num where JYZID = v_row.jyzid;
             end loop;
             exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    RETURN;
           end;
           commit;
        END;
       /*procedure report_idc_information(
          p_jyzid   in NUMBER,
          --出参
          v_out_success    out number
       ) as
       begin
         if(p_jyzid is not null) then
            --处理IDC信息
            update idc_isms_base_idc idc set idc.deal_flag = 1, idc.update_time = sysdate where idc.jyzid = p_jyzid;
            --处理IDC下面机房信息
            update idc_isms_base_house idc_house set idc_house.deal_flag = 1,idc_house.update_time = sysdate where idc_house.jyzid = p_jyzid;
            update idc_isms_base_house_gateway house_gateway set house_gateway.deal_flag = 1,house_gateway.update_time = sysdate where house_gateway.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid);
            update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = 1,house_ipseg.update_time = sysdate where house_ipseg.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid);
            update idc_isms_base_house_frame set DEAL_FLAG = 1,UPDATE_TIME = sysdate where HOUSEID in (select HOUSEID from idc_isms_base_house where JYZID = p_jyzid);
            --处理IDC下面用户信息
            update idc_isms_base_user set deal_flag = 1,update_time = sysdate where jyzid = p_jyzid;
            update idc_isms_base_user_hh set deal_flag = 1,update_time = sysdate where userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
            update idc_isms_base_user_hh_ipseg set DEAL_FLAG = 1,UPDATE_TIME = sysdate where USERID in (select USERID from idc_isms_base_user where JYZID = p_jyzid);
            update idc_isms_base_user_service set deal_flag = 1,update_time = sysdate where userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
            update idc_isms_base_service_domain set deal_flag = 1,update_time = sysdate where userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
            update idc_isms_base_service_hh set deal_flag = 1,update_time = sysdate where userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid);
            update idc_isms_base_service_iptrans set DEAL_FLAG = 1,UPDATE_TIME = sysdate where USERID in (select USERID from idc_isms_base_user where JYZID = p_jyzid);
            update idc_isms_base_service_virtual set DEAL_FLAG = 1,UPDATE_TIME = sysdate where USERID in (select USERID from idc_isms_base_user where JYZID = p_jyzid);
         end if;
         exception when others then
            rollback;
            v_out_success := 0;
            return;
         commit;
         v_out_success:=1;
       end;*/

          --还原经营者
          procedure recover_idc(
            p_jyzId in varchar2,
            --出参
            v_out_success out number
          ) as

          v_idcCount number := 0;
          v_jyzId idc_isms_base_idc.jyzid%type;
          v_idcId idc_isms_base_idc.idcid%type;
          v_idcName idc_isms_base_idc.idcname%type;
          var_out t_ret_table;

          BEGIN
            begin
              var_out := split_str(p_jyzId, ',');
              for i in 1..var_out.count loop
                v_jyzId := var_out(i);
                select a.idcid,a.idcname into v_idcId,v_idcName from idc_isms_base_idc a where a.jyzid = v_jyzId;
                select count(1) into v_idcCount from idc_isms_base_idc a where (a.idcid = v_idcId or a.idcname = v_idcName) and a.del_flag = 0;
                if v_idcCount > 0 then
                  v_out_success := 0;
                  return;
                else
                  update idc_isms_base_idc a set a.del_flag = 0,a.czlx=1,a.deal_flag=0 where a.jyzid = v_jyzId;
                end if;
              end loop;
              exception
               WHEN OTHERS THEN
                    ROLLBACK;
                    v_out_success := 2;
                    RETURN;
             end;
             commit;
             v_out_success := 1;
          END;
          
       procedure completeReport(
          p_jyzid   in varchar2,
          v_out_success    out number
       ) as
      begin
       begin
         if(p_jyzid is not null) then
             update idc_isms_base_idc idc set idc.report_type = 1, idc.update_time = sysdate where idc.jyzid = p_jyzid and idc.del_flag != 1;
             --处理IDC上报
             update idc_isms_base_idc idc set idc.deal_flag = 1, idc.update_time = sysdate where idc.jyzid = p_jyzid and idc.del_flag != 1 ;
               --处理IDC下完整性机房信息上报
             update idc_isms_base_house idc_house set idc_house.deal_flag = 1,idc_house.update_time = sysdate where idc_house.jyzid = p_jyzid and idc_house.del_flag != 1 and info_complete ='是' ;
             update idc_isms_base_house_gateway house_gateway set house_gateway.deal_flag = 1,house_gateway.update_time = sysdate where house_gateway.del_flag != 1  and house_gateway.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid and info_complete ='是' and del_flag!=1);
             --update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = v_operationType,house_ipseg.update_time = sysdate where house_ipseg.del_flag != 1  and house_ipseg.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid);
             update idc_isms_base_house_ipseg house_ipseg set house_ipseg.deal_flag = 1,house_ipseg.update_time = sysdate where house_ipseg.del_flag != 1 and house_ipseg.houseid in (select idc_house.houseid from idc_isms_base_house idc_house where idc_house.jyzid = p_jyzid and info_complete ='是' and del_flag!=1); 
             update idc_isms_base_house_frame set deal_flag = 1,update_time = sysdate where del_flag != 1  and houseid in (select houseid from idc_isms_base_house where jyzid = p_jyzid and info_complete ='是' and del_flag!=1);
             --处理IDC下完整性用户信息上报
             update idc_isms_base_user set deal_flag = 1,update_time = sysdate where del_flag != 1 and jyzid = p_jyzid and info_complete ='是' and del_flag!=1 ;
             update idc_isms_base_user_hh set deal_flag = 1,update_time = sysdate where del_flag != 1 and userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid and info_complete ='是' and del_flag!=1 );
             update idc_isms_base_user_hh_ipseg set deal_flag = 1,UPDATE_TIME = sysdate where del_flag != 1 and userid in (select userid from idc_isms_base_user where jyzid = p_jyzid and info_complete ='是' and del_flag!=1);
             update idc_isms_base_user_service set deal_flag = 1,update_time = sysdate where del_flag != 1 and userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid and info_complete ='是' and del_flag!=1);
             update idc_isms_base_service_domain set deal_flag = 1,update_time = sysdate where del_flag != 1 and userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid and info_complete ='是' and del_flag!=1);
             update idc_isms_base_service_hh set deal_flag = 1,update_time = sysdate where del_flag != 1  and userid in (select idc_user.userid from idc_isms_base_user idc_user where idc_user.jyzid = p_jyzid and info_complete ='是' and del_flag!=1);
             update idc_isms_base_service_iptrans set deal_flag = 1,update_time = sysdate where del_flag != 1  and userid in (select userid from idc_isms_base_user where jyzid = p_jyzid and info_complete ='是' and del_flag!=1);
             update idc_isms_base_service_virtual set deal_flag = 1,update_time = sysdate where del_flag != 1  and userid in (select userid from idc_isms_base_user where jyzid = p_jyzid and info_complete ='是' and del_flag!=1);
           end if;
         exception when others then
             rollback;
             v_out_success := 0;
             return;
          end;
            commit;
           v_out_success:=1;
         end;
       
end IDC_ISMS_BASE_IDC_MANAGE;
/
