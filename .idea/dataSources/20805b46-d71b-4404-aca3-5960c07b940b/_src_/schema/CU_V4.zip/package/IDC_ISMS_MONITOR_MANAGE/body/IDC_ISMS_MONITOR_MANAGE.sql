CREATE package body idc_isms_monitor_manage is


  --处理信息安全管理指令
  procedure DealMonitorPolicy(
                         v_smms_cmdid in   number,
                         v_command_type in   number,
                         v_action_block in   number,
                         v_action_reason in   varchar2,
                         v_action_log in   number,
                         p_actionReport in   number,
                         v_effecttime in varchar2,
                         v_expiredtime in varchar2,
                         v_idcid in   varchar2,
                         v_houseIds in   varchar2,
                         v_opType in number,
                         v_policyLevel in number,
                         --出参
                         v_out_success    out number,
                         v_out_cmdid    out number
                         )
  as
  v_count number(5);
  v_commandid number;
  v_message_no NUMBER;
  v_seqno  NUMBER;
  v_func_ret  number;
  v_tmp varchar2(2048);
  v_int  number(10) :=0;
  v_houseid varchar2(256);
  v_bind_mes_no NUMBER;
  v_int2 number(10) :=0;
  Begin
       begin
          v_commandid:=0;
          v_out_cmdid:=0;
          select count(*) into v_count from idc_isms_monitor_policy where smms_cmdid=v_smms_cmdid;
          if(v_count=0 and v_opType = 0) then
             v_func_ret:=PKG_DPICONFIG.AddMessageNo(16, v_smms_cmdid,v_message_no);

             v_func_ret:=PKG_IDCCONFIG.AddOrUpdateIDCISMS_Policy(0,
                                                                 v_message_no,
                                                                 v_command_type,
                                                                 v_action_block,
                                                                 v_action_log,
                                                                 date2time_t(to_date(v_effecttime,'yyyy-mm-dd hh24:mi:ss')),
                                                                 date2time_t(to_date(v_expiredtime,'yyyy-mm-dd hh24:mi:ss')),
                                                                 -1,
                                                                 0,
                                                                 0,
                                                                 v_policyLevel,
                                                                 v_commandid);

             v_out_cmdid:=v_commandid;
             update idc_isms_monitor_policy
             set SMMS_CMDID=v_smms_cmdid, IDCID = v_idcid
             where commandid=v_commandid;

             /*
             v_seqno := PKG_DPICONFIG.MessageSequenceNo(v_message_no);
             select seq_idc_isms_monitorpolicy_id.nextval into v_commandid from dual;
             insert into idc_isms_monitor_policy
               (commandid, message_no, command_type, action_block, action_reason, action_log,
               effecttime, expiredtime, monitor_type, smms_cmdid, idcid, operatetype,
               message_sequenceno, create_userid)
             values
               (v_commandid, v_message_no, v_command_type, v_action_block, v_action_reason, v_action_log,
                v_effecttime, v_expiredtime, 2, v_smms_cmdid, v_idcid, 1,
                 v_seqno, -1);
              */


             if(v_houseIds is null or length(v_houseIds)=0) then
                v_func_ret:=PKG_DPICONFIG.AddMessageNo(133, v_smms_cmdid,v_bind_mes_no);
                v_func_ret:=PKG_IDCCONFIG.AddOrUpdateHousePolicy(0,v_bind_mes_no,0,null,
                              16,v_message_no,-1);
             else
                /*
                v_tmp := v_houseIds || ',';
                loop
                        BEGIN
                          if v_tmp is null or To_Number(Length(v_tmp))<2 then
                                    exit;
                          end if;
                          v_int:= INSTR(v_tmp,',');
                          if(v_int = 0 ) then
                                v_houseid := v_tmp;
                          else
                                v_houseid  := substr(v_tmp,0,v_int-1);
                          end if;
                          v_func_ret:=PKG_DPICONFIG.AddMessageNo(133, v_smms_cmdid,v_bind_mes_no);
                          v_func_ret:=PKG_IDCCONFIG.AddOrUpdateHousePolicy(0,v_bind_mes_no,2,v_houseid,
                              v_opType,v_message_no,-1);

                        END;
                         v_tmp := substr(v_tmp,v_int+1);
                end loop;
                */

                v_tmp := v_houseIds || ',';
                loop
                 BEGIN
                      if v_tmp is null or To_Number(Length(v_tmp))<2 then
                                exit;
                      end if;
                      v_int:= INSTR(v_tmp,',');
                      if(v_int = 0 ) then
                            v_houseid := v_tmp;
                      else
                            v_houseid  := substr(v_tmp,0,v_int-1);
                      end if;
                      select houseidstr into v_houseid from idc_isms_base_house where houseid=v_houseid;
                      if (v_houseid is not null) then
                         v_func_ret:=PKG_DPICONFIG.AddMessageNo(133, v_smms_cmdid,v_bind_mes_no);
                         v_func_ret:=PKG_IDCCONFIG.AddOrUpdateHousePolicy(0,v_bind_mes_no,2,v_houseid, 16,v_message_no,-1);
                      end if;
                  END;
                 v_tmp := substr(v_tmp,v_int+1);
                 end loop;
             end if;
          end if;
          if(v_count=1 and v_opType = 1) then
            select commandid,message_no into v_commandid,v_message_no from idc_isms_monitor_policy where smms_cmdid=v_smms_cmdid;
            update idc_isms_cmd_idc_manage set operation_type=v_opType where commandid=v_commandid;
            if(v_opType=1) then
                v_func_ret:=PKG_IDCCONFIG.DeleteIDCISMS_Policy(v_commandid,v_message_no,-1);
            end if;
          end if;
       exception
        WHEN OTHERS THEN
              ROLLBACK;
              v_out_success := 0;
              raise;
       end;
       commit;
       v_out_success:=1;
  end;
end idc_isms_monitor_manage;
/
