CREATE VIEW HIVE_IDC_BASE_IP_DOMAIN_VIEW_V AS select
    t.houseid houseid,
    t.ip ip,
    wm_concat(t.domainname) domainname
from hive_idc_base_ip_domain_view t
group by t.houseid,t.ip
/
