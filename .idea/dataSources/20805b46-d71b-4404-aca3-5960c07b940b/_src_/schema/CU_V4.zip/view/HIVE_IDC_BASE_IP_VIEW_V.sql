CREATE VIEW HIVE_IDC_BASE_IP_VIEW_V AS select
    t.houseid houseid,
    t.iptype,
    t.ip ip
from hive_idc_base_ip_view t
group by t.houseid,t.iptype,t.ip
/
