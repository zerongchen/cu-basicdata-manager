CREATE VIEW SQL_SDE_VIEW AS select 1 as id,'z' as name from dual
union all
select 1 as id,'f' as name from dual
union all
select 2 as id,'z' as name from dual
union all
select 1 as id,'z' as name from dual
union all
select 3 as id,'f' as name from dual
union all
select 1 as id,'z' as name from dual
/
