CREATE function time_t2date(time_t IN NUMBER) return DATE is
begin
  RETURN to_date('1970-01-01', 'yyyy-mm-dd') + (time_t+8*60*60)/60/60/24;
end time_t2date;
/
