CREATE procedure timeFormat as
begin
       --时间格式批量修改成yyyy-mm-dd格式：
       update idc_isms_base_house_ipseg set usetime = to_char(to_date(usetime,'yyyy-mm-dd'),'yyyy-mm-dd');
       update idc_isms_base_user t set t.registertime = to_char(to_date(registertime,'yyyy-mm-dd'),'yyyy-mm-dd');
       update idc_isms_base_user t set t.serverregistertime = to_char(to_date(serverregistertime,'yyyy-mm-dd'),'yyyy-mm-dd');
       update idc_isms_base_user_hh set distributetime = to_char(to_date(distributetime,'yyyy-mm-dd'),'yyyy-mm-dd');
       commit;
end;
/
