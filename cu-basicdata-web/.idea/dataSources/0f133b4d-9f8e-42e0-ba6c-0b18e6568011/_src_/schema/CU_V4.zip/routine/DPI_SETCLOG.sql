CREATE PROCEDURE DPI_SETCLOG(
                                     v_op_code IN number,
                                     v_op_type IN number,
                                     v_recid1  IN number,
                                     v_recid2  IN number,
                                     v_create_oper IN number
                                   ) IS
BEGIN
  insert into dpi_v1_clog
    (logid,
     op_code,
     op_type,
     recid1,
     recid2,
     create_oper,
     create_time)
  values
    (SEQ_dpi_clog_id.NEXTVAL,
     v_op_code,
     v_op_type,
     v_recid1,
     v_recid2,
     v_create_oper,
     SYSDATE);
---COMMIT?？?？？????？
END DPI_SETCLOG;
/
