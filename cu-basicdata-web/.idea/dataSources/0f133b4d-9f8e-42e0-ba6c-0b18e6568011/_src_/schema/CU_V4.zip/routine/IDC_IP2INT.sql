CREATE FUNCTION idc_IP2Int
(
	ip IN Varchar2
)
RETURN Int IS
   i number(5);
   tmp Varchar2(20);
   i1 number(5);
   i2 number(5);
   i3 number(5);
   i4 number(5);
BEGIN
begin
  select ip into tmp from dual;
  Select instr(tmp,'.') Into i From dual;
  Select to_number(substr(tmp,0,i-1)) Into i1 From dual;
  Select substr(tmp,i+1,length(tmp)) Into tmp From dual;
  Select instr(tmp,'.') Into i From dual;
  Select to_number(substr(tmp,0,i-1)) Into i2 From dual;
  Select substr(tmp,i+1,length(tmp)) Into tmp From dual;
  Select instr(tmp,'.') Into i From dual;
  Select to_number(substr(tmp,0,i-1)) Into i3 From dual;
  Select substr(tmp,i+1,length(tmp)) Into tmp From dual;
  Select to_number(tmp) Into i4 From dual;
  exception when others then
    return -1;
    end;

  return i1*256*256*256+i2*256*256+i3*256+i4;
END;
/
