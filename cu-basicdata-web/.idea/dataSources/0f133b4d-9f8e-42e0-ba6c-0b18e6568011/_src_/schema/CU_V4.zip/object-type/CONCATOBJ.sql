CREATE TYPE ConcatObj AS OBJECT
(
   fieldValue VARCHAR2 (4000),
   separator VARCHAR2 (100)
)
/
