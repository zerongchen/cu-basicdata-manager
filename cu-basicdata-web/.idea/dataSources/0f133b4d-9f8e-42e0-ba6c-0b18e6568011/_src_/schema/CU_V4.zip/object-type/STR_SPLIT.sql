CREATE type STR_SPLIT as table of varchar2(50);
/
