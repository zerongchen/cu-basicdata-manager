CREATE package IDC_ISMS_BASE_BASIC_MANAGE is
   /*procedure change_cancel_operation (
          p_jyzid   in NUMBER,
          p_userId  in NUMBER,
          p_houseId  in NUMBER,
          p_gatewayId  in NUMBER,
          p_ipSegId  in NUMBER,
          p_userHHId  in NUMBER,
          p_serviceId  in NUMBER,
          p_domainId  in NUMBER,
          p_serviceHHId  in NUMBER,
          p_isChangeOrCancel  in NUMBER,
          --出参
          v_out_success    out number
   );*/

   procedure report_operation (
          p_jyzid   in NUMBER,
          p_userId  in NUMBER,
          p_houseId  in NUMBER,
          --p_gatewayId  in NUMBER,
          --p_ipSegId  in NUMBER,
          p_userHHId  in NUMBER,
          p_serviceId  in NUMBER,
          --p_domainId  in NUMBER,
          --p_serviceHHId  in NUMBER,
          --p_frameId in number,
          --出参
          v_out_success    out number
   );

    procedure report_operation (
          p_jyzid   in varchar2,
          p_userId  in varchar2,
          p_houseId  in varchar2,
          p_userHHId  in varchar2,
          p_serviceId  in varchar2,
          p_reportType in number,
          --出参
          v_out_success out number
   );
   
   procedure cancelReport_operation (
          p_jyzid   in varchar2,
          p_userId  in varchar2,
          p_houseId  in varchar2,
          p_userHHId  in varchar2,
          p_serviceId  in varchar2,
          p_reportType in number,
          --出参
          v_out_success out number
   );
   
   procedure restoreDataSet(
          p_restoreDate   in varchar2,
          --出参
          v_out_success    out varchar2
       );

end IDC_ISMS_BASE_BASIC_MANAGE;
/
