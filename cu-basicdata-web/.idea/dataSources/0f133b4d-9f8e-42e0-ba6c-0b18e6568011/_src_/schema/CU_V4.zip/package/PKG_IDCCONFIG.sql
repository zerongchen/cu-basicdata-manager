CREATE PACKAGE PKG_IDCCONFIG IS

  -- 成功返回
  SUCC_CODE CONSTANT NUMBER(5) := 0;

  -- 游标类型
  TYPE C_CURSOR IS REF CURSOR;

  -- 数据库错误定义
  ERROR_DATABASE CONSTANT NUMBER(5) := 10000;



   --获取访问日志管理策略
  FUNCTION GetAccessLog
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;
--添加访问日志管理策略
  FUNCTION AddAccessLog(
    p_msgno                 IN NUMBER,
    p_logflag               IN NUMBER,
    p_operid                IN NUMBER,
    p_seqno                 OUT NUMBER,
    p_id                    OUT NUMBER
  )
  RETURN INTEGER;

--删除访问日志管理策略
  FUNCTION DeleteAccessLog
  (
    p_id                    IN NUMBER,
    p_msgno                 IN NUMBER,
    p_operid                IN NUMBER,
    p_seqno                 OUT NUMBER
  )
  RETURN INTEGER;

    --修改访问日志管理策略
  FUNCTION UpdateAccessLog
  (
    p_commonid              IN NUMBER,
    p_msgno                 IN NUMBER,
    p_operid                IN NUMBER,
    p_seqno                 OUT NUMBER
  )
  RETURN INTEGER;

 --获取IDC规则类型
  FUNCTION GetRuleType
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;

   --
  FUNCTION GetISMS_IDCList
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;

  --获取IDC规则类型 ISMS_BASE_HOUSE
  FUNCTION GetISMS_HouseList
  (
    p_cursor  OUT C_CURSOR
  )
  RETURN INTEGER;

  --
  FUNCTION GetIDCISMS_PolicyList(
    p_pageNo                    IN NUMBER,
    p_pageSize                  IN NUMBER,
    p_operstatus                IN NUMBER,
    p_commandId                 IN NUMBER,
    p_type                      IN NUMBER,
    p_blockflag                 IN NUMBER,
    p_logflag                   IN NUMBER,
    p_content                   IN VARCHAR2,
    p_createTimeS               IN VARCHAR2,
    p_createTimeE               IN VARCHAR2,
    p_policyType                IN VARCHAR2,
    p_sysIdentifier             IN VARCHAR2,
    p_outcount                  OUT NUMBER,
    p_cursor                    OUT C_CURSOR
  )
  RETURN INTEGER ;

    --
  FUNCTION GetIDCISMS_PolicyByID
  (
    p_id                        IN NUMBER,
    p_cursor                    OUT C_CURSOR
  )
  RETURN INTEGER;

   ----
  FUNCTION AddOrUpdateIDCISMS_Policy
  (
    p_id                    IN NUMBER,
    p_msgno                 IN NUMBER,
    p_type                  IN NUMBER,
    p_blockflag             IN NUMBER,
    p_logflag               IN NUMBER,
    p_starttime             IN NUMBER,
    p_endtime               IN NUMBER,
    p_operid                IN NUMBER,
    p_userName              IN VARCHAR2,
    p_unbundFlag            IN NUMBER,
    p_policyLevel           IN NUMBER,
    out_newid               OUT NUMBER
  )
  RETURN INTEGER;

FUNCTION AddIspPolicyRuleNotCommit
(
    p_id                               IN NUMBER,
    p_ruleid                           IN NUMBER,
    p_subtype                          IN NUMBER,
    p_valuestart                       IN VARCHAR2,
    p_valueend                         IN VARCHAR2,
    p_keywordrange                     IN VARCHAR2,
    p_operid                           IN NUMBER
)
RETURN INTEGER;


--添加或者修改或者删除列表
  FUNCTION AddUpdateIDCISP_PolicyRule
  (
    p_tag                              IN NUMBER,--id=1为添加操作 2修改 3 删除
    p_id                               IN NUMBER,
    p_ruleid                           IN NUMBER,
    p_subtype                          IN NUMBER,
    p_valuestart                       IN VARCHAR2,
    p_valueend                         IN VARCHAR2,
    p_keywordrange                     IN VARCHAR2,
    p_operid                           IN NUMBER
  )
  RETURN INTEGER;
      --
  FUNCTION DeleteIDCISMS_Policy
  (
      p_id                                     IN NUMBER,
      p_msgno                                  IN NUMBER,
      p_operid                                 IN NUMBER
  )
  RETURN INTEGER;
--物理删除策略信息
  FUNCTION BatchDeleteIDCISMS_Policy
  (
      p_id                                     IN VARCHAR2,
      p_msgno                                  IN VARCHAR2
  )
  RETURN INTEGER;

    ---分页获取 ISMS流量结果上报策略
FUNCTION GetFlowUpload(
    p_pageNo                     IN NUMBER,
    p_pageSize                   IN NUMBER,
    p_operstatus                IN NUMBER,
    p_type                       IN NUMBER,
    p_subtype                    IN NUMBER,
    p_method                     IN NUMBER,
    p_outcount                   OUT NUMBER,
    p_cursor                     OUT C_CURSOR
  )
RETURN INTEGER;

---分页获取 ISMS流量结果上报策略1
FUNCTION GetFlowUploadTwo(
    p_pageNo                     IN NUMBER,
    p_pageSize                   IN NUMBER,
    p_houseName                  IN VARCHAR2,
    p_operstatus                IN NUMBER,
    p_type                       IN NUMBER,
    p_subtype                    IN NUMBER,
    p_method                     IN NUMBER,
    p_outcount                   OUT NUMBER,
    p_cursor                     OUT C_CURSOR
  )
RETURN INTEGER;
---分页获取 ISMS流量结果上报策略1
FUNCTION GetFlowUploadOne(
    p_pageNo                     IN NUMBER,
    p_pageSize                   IN NUMBER,
    p_houseName                  IN VARCHAR2,
    p_operstatus                IN NUMBER,
    p_type                       IN NUMBER,
    p_subtype                    IN NUMBER,
    p_method                     IN NUMBER,
    p_outcount                   OUT NUMBER,
    p_cursor                     OUT C_CURSOR
  )
RETURN INTEGER;

 ---查询 ISMS流量结果上报策略 服务器
FUNCTION GetFlowUploadServer(
    p_id                         IN NUMBER,
    p_outcount                   OUT NUMBER,
    p_cursor                     OUT C_CURSOR
  )
RETURN INTEGER;

--添加 ISMS流量结果上报策略
  FUNCTION AddFlowUpload(
    p_msgno                 IN NUMBER,
    p_type                  IN NUMBER,
    p_subtype               IN NUMBER,
    p_method                IN NUMBER,
    p_operid                IN NUMBER,
    p_seqno                 OUT NUMBER,
    p_id                    OUT NUMBER
  )
  RETURN INTEGER;

   --添加 ISMS流量结果上报策略 服务器
  FUNCTION AddFlowUploadServer(
    p_id                    IN NUMBER,
    p_ip                    IN VARCHAR2,
    p_port                  IN NUMBER,
    p_name                  IN VARCHAR2,
    p_pwd                   IN VARCHAR2
  )
  RETURN INTEGER;

--修改 ISMS流量结果上报策略
  FUNCTION UpdateFlowUpload
  (
    p_id                    IN NUMBER,
    p_msgno                 IN NUMBER,
    p_type                  IN NUMBER,
    p_subtype               IN NUMBER,
    p_method                IN NUMBER,
    p_operid                IN NUMBER,
    p_seqno                 OUT NUMBER
  )
  RETURN INTEGER;

 --删除 ISMS流量结果上报策略
  FUNCTION DeleteFlowUpload
  (
    p_id                    IN NUMBER,
    p_msgno                 IN NUMBER,
    p_operid                IN NUMBER,
    p_seqno                 OUT NUMBER
  )
  RETURN INTEGER;

---分页获取 IDC机房与IP地址段对应信息下发
FUNCTION GetHouseIpList(
    p_pageNo                     IN NUMBER,
    p_pageSize                   IN NUMBER,
    p_operstatus                IN NUMBER,
    p_houseid                    IN varchar2,
    p_outcount                   OUT NUMBER,
    p_cursor                     OUT C_CURSOR,
    p_userHouseIDStrs in varchar2
  )
RETURN INTEGER;

---查询 IDC机房与IP地址段对应信息下发 houseid是否存在
FUNCTION GetHouseIp(
    p_houseid                    IN varchar2,
    p_cursor                     OUT C_CURSOR
  )
RETURN INTEGER;

--添加  IDC机房与IP地址段对应信息下发
FUNCTION AddHouseIp(
    p_msgno                 IN NUMBER,
    p_seqno                 IN NUMBER,
    p_houseid               IN varchar2,
    p_operid                IN NUMBER
  )
RETURN INTEGER;

  --修改  IDC机房与IP地址段对应信息下发
  FUNCTION UpadateHouseIp(
    p_seqno                 IN NUMBER,
    p_houseid               IN varchar2,
    p_operid                IN NUMBER
  )
  RETURN INTEGER;

--添加 IDC机房与IP地址段对应信息下发 IP
  FUNCTION AddHouseIp_Ip(
    p_seqno                 IN NUMBER,
    p_houseid               IN varchar2,
    p_userip                IN VARCHAR2,
    p_prefic                IN NUMBER,
    p_operid                IN NUMBER
  )
  RETURN INTEGER;

 --删除 IDC机房与IP地址段对应信息下发 IP
  FUNCTION DeleteHouseIp_Ip
  (
    p_id                    IN NUMBER,
    p_seqno                 IN NUMBER,
    p_operid                IN NUMBER
  )
  RETURN INTEGER;

  --获取机房/应用策略绑定
  /*FUNCTION GetHousePolicyBind(
    p_pageNo                    IN NUMBER,
    p_pageSize                  IN NUMBER,
    p_operstatus                IN NUMBER,
    p_type                      IN NUMBER,
    p_bindmsgno                  IN NUMBER,
    p_name                       IN VARCHAR2,
    p_outcount                   OUT NUMBER,
    p_cursor                    OUT C_CURSOR
  )
  RETURN INTEGER;*/

   --查询机房策略绑定信息
  FUNCTION getHousePolicyBinds(
        p_isPaging in number,
        p_curIndex in number,
        p_pageSize in number,
        p_isCount in number,
        p_sortName in varchar2,
        p_direction in varchar2,

        p_cursor out sys_refcursor,
        p_recordCount out number,

        p_isBindHouse in number,
        p_houseNo in varchar2,
        p_messageType in number,
        p_bindMessageNo in varchar2,
        p_userHouseIDStrs in varchar2
  )
  RETURN INTEGER;

    --添加或者修改机房/应用策略绑定
  FUNCTION AddOrUpdateHousePolicy
  (
    p_id                    IN NUMBER,
    p_msgno                 IN NUMBER,
    p_housetype             IN NUMBER,
    p_houseid               IN VARCHAR2,
    p_type                  IN NUMBER,
    p_bindmsgno             IN NUMBER,
    p_operid                IN NUMBER
  )
  RETURN INTEGER;


  --删除某一个机房/应用策略绑定(yufs 支持批量删除)
  FUNCTION DeleteHousePolicy
  (
      p_vIds                IN VARCHAR2,--如10，9，
      p_nOperid             IN NUMBER
  )
  RETURN INTEGER ;

 --删除一个策略下的所有的绑定
 FUNCTION deletePolicyHouseBinds(
         p_msgno  IN NUMBER,
         p_msgType IN NUMBER,
         p_operid IN NUMBER
) RETURN INTEGER;

  --根据起始,结束策略Id批量删除绑定
  function batchDeletePolicy
  (
      p_operid                IN NUMBER,
      p_messageNo             IN NUMBER
  )
  RETURN INTEGER ;

   --分页获取所有设备静态信息
  FUNCTION GetDeviceStatusList
  (
     p_pageNo               IN NUMBER,
     p_pageSize             IN NUMBER,
     p_name                 IN VARCHAR2,
     p_outcount             OUT NUMBER,
     p_cursor               OUT C_CURSOR
  )
  RETURN INTEGER;

      --修改dpi设备状态
  FUNCTION EditCfgDevStatus(p_type    IN NUMBER,
                            p_frep    IN NUMBER,
                            p_type2   IN NUMBER,
                            p_frep2   IN NUMBER,
                            p_operid  IN NUMBER
                            )
  RETURN INTEGER;

   --初始化dpi状态查询
  FUNCTION DetailCfgDevStatus(p_cursor  OUT C_CURSOR)
  RETURN INTEGER;

    --获取设备静态端口信息
  FUNCTION GetDeviceStaticPortByDevId
  (
     p_devid                IN NUMBER,
     p_cursor               OUT C_CURSOR
  )
  RETURN INTEGER;

   FUNCTION ShowDeviceDynamicPortByDevId(
     p_devid                IN NUMBER,--对应ID
     p_count                IN NUMBER,--展示数目(-1全部)
     p_cursor               OUT C_CURSOR
  )RETURN NUMBER;
  --获取设备动态端口信息
  FUNCTION GetDeviceDynamicPortByDevId
  (
     p_devid                IN NUMBER,--对应ID
     p_ports                IN VARCHAR2,--端口字串
     p_starttime            IN VARCHAR2,--开始时间
     p_endtime              IN VARCHAR2,--结束时间
     p_cursor               OUT C_CURSOR
  )
  RETURN INTEGER;

  --获取设备动态CPU(去重)
  FUNCTION ShowtDeviceDynamicCpuByDevId(
     p_devid                IN NUMBER,--对应ID
     p_count                IN NUMBER,--展示数目(-1全部)
     p_cursor               OUT C_CURSOR
  )RETURN NUMBER;
  --获取设备动态CPU信息
  FUNCTION GetDeviceDynamicCpuByDevId
  (
     p_devid                IN NUMBER,--对应ID
     p_cpus                 IN VARCHAR2,--cpu字串
     p_starttime            IN VARCHAR2,--开始时间
     p_endtime              IN VARCHAR2,--结束时间
     p_cursor               OUT C_CURSOR
  )
  RETURN INTEGER;

      --分页综分设备信息
  FUNCTION GetZFDeviceInfo(
         p_isPaging in number,
         p_curIndex in number,
         p_pageSize in number,
         p_isCount in number,
         p_sortName in varchar2,
         p_direction in varchar2,
         p_cursor out sys_refcursor,
         p_recordCount out number,

         p_deviceIP in varchar2,
         p_devicePort in number,
         p_deviceName in varchar2
  )
  RETURN INTEGER;

--分页综分设备信息
  FUNCTION GetZFDeviceInfo1(
         p_isPaging in number,
         p_curIndex in number,
         p_pageSize in number,
         p_isCount in number,
         p_sortName in varchar2,
         p_direction in varchar2,
         p_cursor out sys_refcursor,
         p_recordCount out number,

         p_deviceIP in varchar2,
         p_devicePort in number,
         p_deviceName in varchar2
  )
  RETURN INTEGER;

   --添加综分设备信息
  FUNCTION AddZFDeviceInfo(
         p_ip in VARCHAR2,
         p_port IN NUMBER,
         p_dev_name IN VARCHAR2,
         p_operid   IN NUMBER
  ) RETURN INTEGER;

   --修改D综分设备信息
  FUNCTION EditZFDeviceInfo(
         p_dev_id IN NUMBER,
         p_ip IN VARCHAR2,
         p_port IN NUMBER,
         p_dev_name IN VARCHAR2,
         p_operid   IN NUMBER,
         p_isCited IN NUMBER
  ) RETURN INTEGER;

    --删除综分设备信息
  FUNCTION DelZFDeviceInfo(
         p_dev_id IN NUMBER,
         p_operid   IN NUMBER
  ) RETURN INTEGER;

  --分页dpi设备信息
  FUNCTION GetDpiDeviceInfo(
          p_isPaging in number,
          pageindex IN NUMBER,
          pagesize  IN NUMBER,
          p_isCount in number,
          p_sortName in varchar2,
          p_direction in varchar2,
          p_cursor          OUT C_CURSOR,
          v_out_recordcount OUT NUMBER,
          p_zongfen_id IN NUMBER,
          p_ip    IN VARCHAR2,
          p_name    IN VARCHAR2,
          p_areaCode    IN NUMBER,
          p_houseId    IN varchar2,
          p_userHouseIDStrs in varchar2
  )
  RETURN INTEGER;

 --分页dpi设备信息1
  FUNCTION GetDpiDeviceInfo1(
          p_isPaging in number,
          pageindex IN NUMBER,
          pagesize  IN NUMBER,
          p_isCount in number,
          p_sortName in varchar2,
          p_direction in varchar2,
          p_cursor          OUT C_CURSOR,
          v_out_recordcount OUT NUMBER,
          p_zongfen_id IN NUMBER,
          p_ip    IN VARCHAR2,
          p_name    IN VARCHAR2,
          p_areaCode    IN NUMBER,
          p_houseId    IN varchar2,
          p_userHouseIDStrs in varchar2
  )
  RETURN INTEGER;

  --添加DPI设备信息
  FUNCTION AddDpiDeviceInfo(
         p_msgno                   IN NUMBER,
         p_dev_flag                IN NUMBER,
         p_ip                      in VARCHAR2,
         p_port                    IN NUMBER,
         p_dev_name                IN VARCHAR2,
         p_site_name               IN VARCHAR2,
         p_zongfen_id              IN NUMBER,
         p_operid                  IN NUMBER,
         p_areacode                IN NUMBER,
         p_idcport                 IN NUMBER,
         n_dev_id                  OUT NUMBER
  ) RETURN INTEGER;

  --添加DPI设备信息与机房关系
  FUNCTION AddDpiDeviceInfo_House(
         p_dev_id   IN NUMBER,
         p_house_id IN VARCHAR2
  ) RETURN INTEGER;

  --修改DPI设备信息
  FUNCTION EditDpiDeviceInfo(
         p_dev_id IN NUMBER,
         p_msgno IN NUMBER,
         p_dev_name IN VARCHAR2,
         p_site_name IN VARCHAR2,
         p_zongfen_id  IN NUMBER,
         p_operid   IN NUMBER
  ) RETURN INTEGER;

     --删除DPI设备信息关联的机房信息
  FUNCTION DelDpiDeviceInfo_House(
         p_dev_id IN NUMBER
  ) RETURN INTEGER;

  --删除DPI设备信息
  FUNCTION DelDpiDeviceInfo(
         p_dev_id IN NUMBER,
         p_msgno IN NUMBER,
         p_operid   IN NUMBER
  ) RETURN INTEGER;

  --删除全部表idc_isms_monitor_policy数据
  FUNCTION deleteBatchISMPolicy

  return INTEGER;

--同时添加policy,policyRule,MessageNo
FUNCTION addPolicyAndPolicyRule
(
    p_commandType           IN NUMBER,
    p_actionBlock           IN NUMBER,
    p_starttime             IN NUMBER,
    p_endtime               IN NUMBER,
    p_valueStart            IN VARCHAR2,
    p_subType               IN NUMBER,
    p_msgNo                 OUT NUMBER
)
RETURN INTEGER;

  --获取全部[国家标准地区码]清单
  FUNCTION F_getChinaAreaAllList(
     out_curList       OUT C_CURSOR--返回清单
  )RETURN NUMBER;

--同时添加policy,policyRule,MessageNo
FUNCTION addUserOperateLog
(
    p_opCode           IN NUMBER,
    p_opType           IN NUMBER,
    p_seqNo            IN NUMBER,
    p_operId           IN NUMBER,
    p_tableName        IN VARCHAR2,
    p_tableId          IN VARCHAR2
)RETURN NUMBER;

--添加流量镜像策略
FUNCTION AddPolicyMirror(
         p_mirrorId               IN OUT NUMBER,
         p_messageNo              IN NUMBER,
         p_appType                IN NUMBER,
         p_appId                  IN NUMBER,
         p_startTime              IN NUMBER,
         p_endTime                IN NUMBER,
         p_mirrorPort             IN NUMBER,
         p_mirrorDirection        IN NUMBER,
         p_trafficForward         IN NUMBER,
         p_mirrorSocketLength     IN NUMBER
  ) RETURN INTEGER;

--删除流量镜像策略
FUNCTION DelCfgFlowMirror(
         p_id            IN NUMBER,
         p_msgno         IN NUMBER
 )RETURN INTEGER;

--添加用户/应用策略绑定
 FUNCTION AddPolicyBind
  (
    p_id                    IN NUMBER,
    p_msgno                 IN NUMBER,
    p_type                  IN NUMBER,
    p_bindmsgno             IN NUMBER,
    p_groupid               IN NUMBER,
    p_usertype              IN NUMBER,
    p_username              IN VARCHAR2,
    p_operid                IN NUMBER
  )RETURN INTEGER;

 --删除某一个用户/应用策略绑定
FUNCTION DeletePolicyBind
  (
      p_id IN NUMBER,
      p_msgno IN NUMBER,
      p_operid       IN NUMBER
  )RETURN INTEGER;

END PKG_IDCCONFIG;

/
