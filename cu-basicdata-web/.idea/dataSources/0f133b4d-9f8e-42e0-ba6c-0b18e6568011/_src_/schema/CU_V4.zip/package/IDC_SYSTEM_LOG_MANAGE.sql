CREATE package idc_system_LOG_MANAGE is

-- 成功返回
SUCC_CODE CONSTANT NUMBER(5) := 0;

-- 游标类型
TYPE C_CURSOR IS REF CURSOR;

-- 数据库错误定义
ERROR_DATABASE CONSTANT NUMBER(5) := 10000;

-- 错误代码定义(11000 -- 11100)
ERROR_SERVER_EXIST NUMBER(5) := 11000;  -- server存在

    procedure list_actionLog(
          --入参，分页参数
          p_isPaging in number, --是否分页，如果不分页则返回全部数据
          p_pageIndex  in number, --页索引
          p_pageSize   in number, --页大小
          p_IsCount    in number,
          p_sortName   in VARCHAR2,
          p_sortOrder  in VARCHAR2,
          
          p_userId in number,
          p_userLevel in number,
          --输出
          p_cursor      out sys_refcursor,
          p_recordCount out number, --非空为错误信息
          --入参，查询参数

          p_username in VARCHAR2,
          p_actionType in number,
          p_startActionTime in varchar2,
          p_endActionTime in varchar2
    );

    procedure list_login_log(
          p_ispaging in number,--非空
          pageindex in number,--非空
          pagesize in number,--非空
          p_iscount in number,
          --搜索条件
          p_dlyh in varchar2,
          login_s_date in varchar2,
          login_e_date in varchar2,

          sortName in varchar2,--非空
          orderItem in varchar2,--非空

          p_userId in number,
          p_userLevel in number,
          
          p_cursor out sys_refcursor,
          p_recordcount out number
    );

    procedure list_dataLog(
           --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            
            p_userId in number,
            p_userLevel in number,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数
            p_username in VARCHAR2,
            p_actionType in number,
            p_startActionTime in varchar2,
            p_endActionTime in varchar2
    );



end idc_system_LOG_MANAGE;
/
