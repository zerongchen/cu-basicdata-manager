CREATE package IDC_ISMS_BLACK_WEBSITE is

  --添加违法网站
  procedure addBlackWebsite(
             p_idcId in varchar2,
             p_content in varchar2, --ip或域名
             p_websiteType in number,
             p_levelDecimal in number,
             p_createUserId in number,
             p_userName in varchar2,
             p_result out number,
             p_blackId out number
   );

   --删除违法网站同时删除添加时添加的过滤策略
   procedure deleteBlackWebsite(
             p_blackId number,
             p_content in varchar2,
             p_result out number
   );

  --添加免过滤网站同时删除已存在的过滤策略
  procedure addWebSiteNoFilter(
             p_idcId in varchar2,
             p_content in varchar2, --ip或域名
             p_createUserId in number,
             p_userName in varchar2,
             p_websiteType in number,
             p_levelDecimal in number,
             p_result out number,
             p_filterId out number
  );

    --删除免过滤网站列表 同时判断要不要删除信安策略
   procedure deleteWebsiteNoFilter(
             p_filterId number,
             p_content in varchar2,
             p_result out number
   );
end IDC_ISMS_BLACK_WEBSITE;
/
