CREATE package IDC_ISMS_BASE_IDC_MANAGE as
procedure save_idc_information(
            p_idcId in VARCHAR2,
            p_idcName in VARCHAR2,
            p_idcAddress in VARCHAR2,
            p_idcZipCode in VARCHAR2,
            p_corporater in VARCHAR2,
            p_officerName in VARCHAR2,
            p_officerIdType in NUMBER,
            p_officerId in VARCHAR2,
            p_officerTelephone in VARCHAR2,
            p_officerMobile in VARCHAR2,
            p_officerEmail in VARCHAR2,
            p_ecName in VARCHAR2,
            p_ecIdtype in NUMBER,
            p_ecId in VARCHAR2,
            p_ecTelephone in VARCHAR2,
            p_ecMobile in VARCHAR2,
            p_ecEmail in VARCHAR2,
            p_optertionType in NUMBER,
            p_dealFlag in NUMBER,
            p_createUserId in NUMBER,
            p_msg out varchar2 --非空为错误信息
           );
           
           procedure list_idc_information(
            --入参，分页参数
            p_isPaging in number, --是否分页，如果不分页则返回全部数据
            p_pageIndex  in number, --页索引
            p_pageSize   in number, --页大小
            p_IsCount    in number,
            p_sortName   in VARCHAR2,
            p_sortOrder  in VARCHAR2,
            --输出
            p_cursor      out sys_refcursor,
            p_recordCount out number, --非空为错误信息
            --入参，查询参数

            p_idcId in VARCHAR2,
            p_idcName in VARCHAR2,
            p_corporater in VARCHAR2,
            p_officerName in VARCHAR2,
            p_ecName in VARCHAR2,
            p_dealFlag in number,
            p_delFlag in number
         );
         
          --查询列表的数据查询
         procedure idc_query_list_information(
                  --入参，分页参数
                  p_isPaging in number, --是否分页，如果不分页则返回全部数据
                  p_pageIndex  in number, --页索引
                  p_pageSize   in number, --页大小
                  p_IsCount    in number,
                  p_sortName   in VARCHAR2,
                  p_sortOrder  in VARCHAR2,
                  --输出
                  p_cursor      out sys_refcursor,
                  p_recordCount out number, --非空为错误信息
                  --入参，查询参数
                  p_idcId in VARCHAR2,
                  p_idcName in VARCHAR2,
                  p_corporater in VARCHAR2,
                  p_officerName in VARCHAR2,
                  p_ecName in VARCHAR2,
                  p_houseName in VARCHAR2,
                  p_houseProvince in NUMBER,
                  p_houseCity in NUMBER,
                  p_houseCounty in NUMBER,
                  p_houseOfficerName in VARCHAR2,
                  p_unitName in VARCHAR2,
                  p_unitOfficerName in VARCHAR2
         );
         
          procedure del_idc_information(
              p_jyzid in varchar2,
              --出参
              v_out_success out number
         );
         
          procedure delete_idc_information(
              p_jyzid in varchar2,
              --出参
              v_out_success out number
         );
         
         --统计机房数量
        procedure statisticHouseNum;
        
         --还原经营者
          procedure recover_idc(
            p_jyzId in varchar2,
            --出参
            v_out_success out number
          );
           procedure completeReport(
             p_jyzId in varchar2,
              --出参
              v_out_success out number
            );

end IDC_ISMS_BASE_IDC_MANAGE;
/
