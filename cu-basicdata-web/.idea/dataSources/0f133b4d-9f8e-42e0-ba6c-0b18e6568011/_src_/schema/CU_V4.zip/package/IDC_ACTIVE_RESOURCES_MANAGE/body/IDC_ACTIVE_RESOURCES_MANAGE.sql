CREATE package body idc_active_resources_manage is


  --基础数据ip信息
  procedure idc_base_ip_view
  as
  v_count           number;
  Begin
       begin
           --清理重复记录
           delete from hive_idc_base_ip_view
           where ip in (select ip from hive_idc_base_ip_view group by ip having count(ip) > 1)
           and rowid not in (select max(rowid) from hive_idc_base_ip_view group by ip having count(ip)>1);
           select count(1) into v_count from hive_idc_base_ip_view;
           if (v_count = 0) then
              dataTransferForBaseIp(1);
           else
              dataTransferForBaseIp(2);
           end if;
           --dataTransferForBaseIp(1);
       exception WHEN OTHERS THEN
          ROLLBACK;
          raise;
       end;
       commit;
  end;

  --基础数据ip域名信息
  procedure idc_base_ip_domain_view
  as
  v_count number;
  Begin
       begin
           select count(1) into v_count from hive_idc_base_ip_domain_view;
           if (v_count = 0) then
              dataTransferForBaseIpDomain(1);
           else
              dataTransferForBaseIpDomain(2);
           end if;
           --dataTransferForBaseIpDomain(1);
       end;
  end;

  --基础数据IP转换信息
  procedure dataTransferForBaseIp(type in number)
  as
  v_cursor sys_refcursor;
  v_houseIdStr      idc_isms_base_house.houseidstr%type;
  v_ipType          idc_isms_base_house_ipseg.iptype%type;
  v_startIp         idc_isms_base_house_ipseg.startip%type;
  v_endIp           idc_isms_base_house_ipseg.endip%type;
  v_start           number :=0;
  v_end             number :=0;
  v_length          number := 0;
  Begin
       begin
           --初始化
           if (type = 1) then              
               execute immediate 'truncate table hive_idc_base_ip_view';
               open v_cursor for select v.houseidstr,v.iptype,v.startip,v.endip from idc_base_ipseg_view v;
               loop
                   fetch v_cursor into v_houseIdStr,v_ipType,v_startIp,v_endIp;
                   exit when v_cursor%notfound;
                   v_start := ip2int(v_startIp);
                   v_end   := ip2int(v_endIp);
                   if(v_start = v_end) then
                     insert into hive_idc_base_ip_view (houseid, iptype, ip) values (v_houseIdStr, v_ipType, v_startIp);
                   end if;
                   if (v_end > v_start) then
                     v_length := v_end - v_start + 1;
                     for i in 1..v_length loop
                         insert into hive_idc_base_ip_view (houseid, iptype, ip) values (v_houseIdStr, v_ipType, int2ip(v_start));
                         v_start := v_start + 1;
                     end loop;
                   end if;
               end loop;
               close v_cursor;
           end if;
           --增量
           if (type = 2) then
               --两小时内的数据增量转换
               open v_cursor for
               select v.houseidstr,v.iptype,v.startip,v.endip
               from idc_base_ipseg_view v
               where v.update_time >= to_date(to_char(sysdate - 2/24, 'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss');
               loop
                   fetch v_cursor into v_houseIdStr,v_ipType,v_startIp,v_endIp;
                   exit when v_cursor%notfound;
                   v_start := ip2int(v_startIp);
                   v_end   := ip2int(v_endIp);
                   if(v_start = v_end) then
                     --insert into hive_idc_base_ip_view (houseid, iptype, ip) values (v_houseIdStr, v_ipType, v_startIp);
                     merge into hive_idc_base_ip_view a
                     using (select v_houseIdStr houseid,v_ipType iptype, v_startIp ip from dual) b on (a.houseid = b.houseid and a.ip = b.ip)
                     when matched then
                         update set a.iptype = b.iptype
                     when not matched then
                         insert (houseid, iptype, ip) values (v_houseIdStr, v_ipType, v_startIp);
                   end if;
                   if (v_end > v_start) then
                     v_length := v_end - v_start + 1;
                     for i in 1..v_length loop
                         --insert into hive_idc_base_ip_view (houseid, iptype, ip) values (v_houseIdStr, v_ipType, int2ip(v_start));
                         merge into hive_idc_base_ip_view a
                         using (select v_houseIdStr houseid,v_ipType iptype, int2ip(v_start) ip from dual) b on (a.houseid = b.houseid and a.ip = b.ip)
                         when matched then
                             update set a.iptype = b.iptype
                         when not matched then
                             insert (houseid, iptype, ip) values (v_houseIdStr, v_ipType, int2ip(v_start));
                         v_start := v_start + 1;
                     end loop;
                   end if;
               end loop;
               close v_cursor;
           end if;
       exception WHEN OTHERS THEN
          ROLLBACK;
          raise;
       end;
       commit;
  end;

  --基础数据IP域名转换信息
  procedure dataTransferForBaseIpDomain(type in number)
  as
  v_cursor sys_refcursor;
  v_houseIdStr      idc_isms_base_house.houseidstr%type;
  v_serviceContent  idc_isms_base_user_service.servicecontent%type;
  v_domainname      idc_isms_base_service_domain.domainname%type;
  v_startIp         idc_isms_base_house_ipseg.startip%type;
  v_endIp           idc_isms_base_house_ipseg.endip%type;
  v_start           number :=0;
  v_end             number :=0;
  v_length          number := 0;
  Begin
       begin
           --初始化
           if (type = 1) then
               execute immediate 'truncate table hive_idc_base_ip_domain_view';
               open v_cursor for select v.houseidstr,v.servicecontent,v.domain,v.startip,v.endip from idc_base_ip_domain_view v;
               loop
                   fetch v_cursor into v_houseIdStr,v_serviceContent,v_domainname,v_startIp,v_endIp;
                   exit when v_cursor%notfound;
                   v_start := ip2int(v_startIp);
                   v_end   := ip2int(v_endIp);
                   if(v_start = v_end) then
                     insert into hive_idc_base_ip_domain_view (houseid, ip, domainname) values (v_houseIdStr, v_startIp, v_domainname);
                   end if;
                   if (v_end > v_start) then
                     v_length := v_end - v_start + 1;
                     for i in 1..v_length loop
                         insert into hive_idc_base_ip_domain_view (houseid, ip, domainname) values (v_houseIdStr, int2ip(v_start), v_domainname);
                         v_start := v_start + 1;
                     end loop;
                   end if;
               end loop;
               close v_cursor;
           end if;
           --增量
           if (type = 2) then
               --两小时内的数据增量转换
               open v_cursor for
               select v.houseidstr,v.servicecontent,v.domain,v.startip,v.endip
               from idc_base_ip_domain_view v
               where v.update_time >= to_date(to_char(sysdate - 2/24, 'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss');
               loop
                   fetch v_cursor into v_houseIdStr,v_serviceContent,v_domainname,v_startIp,v_endIp;
                   exit when v_cursor%notfound;
                   v_start := ip2int(v_startIp);
                   v_end   := ip2int(v_endIp);
                   if(v_start = v_end) then
                     --insert into hive_idc_base_ip_domain_view (houseid, ip, domainname) values (v_houseIdStr, v_startIp, v_domainname);
                     merge into hive_idc_base_ip_domain_view a
                     using (select v_houseIdStr houseid, v_startIp ip, v_domainname domainname from dual) b on (a.houseid = b.houseid and a.ip = b.ip and a.domainname = b.domainname)
                     when not matched then
                         insert (houseid, ip, domainname) values (v_houseIdStr, v_startIp, v_domainname);
                   end if;
                   if (v_end > v_start) then
                     v_length := v_end - v_start + 1;
                     for i in 1..v_length loop
                         --insert into hive_idc_base_ip_domain_view (houseid, ip, domainname) values (v_houseIdStr, int2ip(v_start), v_domainname);
                         merge into hive_idc_base_ip_domain_view a
                         using (select v_houseIdStr houseid, int2ip(v_start) ip, v_domainname domainname from dual) b on (a.houseid = b.houseid and a.ip = b.ip and a.domainname = b.domainname)
                         when not matched then
                             insert (houseid, ip, domainname) values (v_houseIdStr, int2ip(v_start), v_domainname);
                         v_start := v_start + 1;
                     end loop;
                   end if;
               end loop;
               close v_cursor;
           end if;
       exception WHEN OTHERS THEN
          ROLLBACK;
          raise;
       end;
       commit;
  end;

end idc_active_resources_manage;
/
