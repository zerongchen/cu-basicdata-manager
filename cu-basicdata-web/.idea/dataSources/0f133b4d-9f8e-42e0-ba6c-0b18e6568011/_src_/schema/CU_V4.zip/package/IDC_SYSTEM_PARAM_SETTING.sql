CREATE package IDC_SYSTEM_PARAM_SETTING is

  procedure updateSystemParam(
     p_fieldName in varchar2,
     p_fieldValue in varchar2,
     p_modelType in number,
     p_flag out number
  );

end IDC_SYSTEM_PARAM_SETTING;
/
