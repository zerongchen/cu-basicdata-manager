CREATE package idc_active_resources_manage is

  --处理基础数据IP信息
  procedure idc_base_ip_view;

  --处理基础数据IP域名信息
  procedure idc_base_ip_domain_view;

  --基础数据IP转换
  procedure dataTransferForBaseIp(type in number);

  --基础数据IP域名转换
  procedure dataTransferForBaseIpDomain(type in number);

end idc_active_resources_manage;
/
