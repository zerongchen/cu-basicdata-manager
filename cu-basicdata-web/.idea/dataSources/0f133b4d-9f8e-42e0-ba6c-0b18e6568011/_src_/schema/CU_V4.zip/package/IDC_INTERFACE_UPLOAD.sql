CREATE package idc_interface_upload is

   --活动状态上报的处理
   procedure uploadActiveState (
       --出参
       p_idcId          out varchar2,
       p_houseAmount    out number,
       p_errHouseAmount out number,
       p_errorHouseIds  out sys_refcursor,
       v_out_success    out number
     );

   --活跃资源上报成功的处理
   procedure dealResourcesComplete (
       --出参
       v_out_success    out number
     );

   --处理xml文件状态信息
   procedure dealXmlFileState (
       p_commandId  in varchar2,
       p_commandTyoe in number,
       p_fileName   in varchar2,
       p_fileState  in number,
       /*
      1、文件解密失败
      2、文件校验失败
      3、文件解压缩失败
      4、文件格式异常
      5、文件内容异常
      900、其他异常
      0、文件未生成
      990、文件已生成
      991、文件已上传
       */
       p_dmms           in varchar2,
       p_insertOrUpdate in number,
          --出参
       v_out_success    out number
     );

  ---创建上传文件完成的处理
  procedure DealUploadComplete(
       p_idcId in varchar2,
       p_fileName in varchar2,
       p_type in   number,
       /*
       11-基础数据-新增；
       12-基础数据-变更；
       13-基础数据-注销；
       14-基础数据-查询；
       2-基础数据监测数据；
       3-访问日志查询结果；
       4-监测日志；
       5-过滤日志；
       51-山西自定义接口——基础数据及备案信息;
       52-山西自定义接口——域名访问量数据;
       53-山西自定义接口——过滤状态;
       54-山西自定义接口——过滤统计数据;
       56-山西自定义接口——网络协议应用数据;
       6-信息安全管理指令查询结果；
       7-ISMS活动状态;
       8-活跃资源；
       9-违法违规网站监测记录
       10-指令执行情况
       */
       p_ids  in   varchar2,
          --出参
       v_out_success    out number
        );

   --创建上传文件时xsd校验失败的处理
   procedure DealUploadError(
       p_idcId in varchar2,
       p_type in   number,
       /*
       11-基础数据-新增；
       12-基础数据-变更；
       13-基础数据-注销；
       14-基础数据-查询；
       2-基础数据监测数据；
       3-访问日志查询结果；
       4-监测日志；
       5-过滤日志；
       51-山西自定义接口——基础数据及备案信息;
       52-山西自定义接口——域名访问量数据;
       53-山西自定义接口——过滤状态;
       54-山西自定义接口——过滤统计数据;
       56-山西自定义接口——网络协议应用数据;
       6-信息安全管理指令查询结果；
       7-ISMS活动状态;
       8-活跃资源；
       9-违法违规网站监测记录
       10-指令执行情况
       */
       p_ids  in   varchar2,
          --出参
       v_out_success    out number
        );

 --创建上传文件返回的处理
 procedure DealBackdata(
       p_czlx in number,
       /*
       11-基础数据-新增；
       12-基础数据-变更；
       13-基础数据-注销；
       14-基础数据-查询；
       2-基础数据监测数据；
       3-访问日志查询结果；
       4-监测日志；
       5-过滤日志；
       51-山西自定义接口——基础数据及备案信息;
       52-山西自定义接口——域名访问量数据;
       53-山西自定义接口——过滤状态;
       54-山西自定义接口——过滤统计数据;
       56-山西自定义接口——网络协议应用数据;
       6-信息安全管理指令查询结果；
       7-ISMS活动状态;
       8-活跃资源；
       9-违法违规网站监测记录
       */
       -- 1-基础数据-新增；2-基础数据-变更；3-基础数据-注销；4-基础数据-查询；5-基础数据监测数据；6-访问日志查询结果；7-监测日志；8-过滤日志；9-信息安全管理指令查询结果；10-ISMS活动状态
       p_filename in   varchar2,
       p_jgdm  in   number,
       p_dmms  in   varchar2,
          --出参
       v_out_success    out number
        );

  --更新上报后的接口处理状态
   procedure updateReportState(
       v_ids            in varchar2,--传入的id值
       p_type           in number,  --更新的类型，1-新增更新为变更、2-变更更新为变更
       --出参
       v_out_success    out number
        );

   --更新上报后的接口处理状态
   procedure updateReportStateNew(
             v_ids            in varchar2,--传入的id值
             p_type           in number,  --更新的类型，1-新增更新为变更、2-变更更新为变更
             --出参
             v_out_success    out number
        );

end idc_interface_upload;
/
